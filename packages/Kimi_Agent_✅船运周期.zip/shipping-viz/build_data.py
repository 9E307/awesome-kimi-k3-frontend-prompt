# -*- coding: utf-8 -*-
"""
build_data.py — 解析《船运周期_完整分析数据.xlsx》生成 site/data/data.js
唯一输入：用户上传的 xlsx；不抓取、不补齐、不改写数据。
"""
import openpyxl, json, re, datetime, os, sys

XLSX = sys.argv[1] if len(sys.argv) > 1 else "/mnt/agents/upload/船运周期_完整分析数据.xlsx"
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "site", "data", "data.js")

wb = openpyxl.load_workbook(XLSX, data_only=True)

def rows_of(name):
    return [list(r) for r in wb[name].iter_rows(values_only=True)]

def clean(v):
    """把 xlsx 单元格值转成 JSON 友好值；去掉字符串外层的冗余引号。"""
    if v is None:
        return None
    if isinstance(v, datetime.datetime):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, str):
        s = v.strip()
        if len(s) >= 2 and s.startswith('"') and s.endswith('"'):
            s = s[1:-1]
        m = re.match(r"^(\d{4}-\d{2}-\d{2})T00:00:00\.000Z$", s)
        if m:
            return m.group(1)
        return s
    return v

def kv_sheet(name):
    """path/value/value_type 三列结构 → 嵌套 dict。"""
    out = {}
    for r in rows_of(name)[3:]:
        if not r or r[0] is None:
            continue
        path, val = str(r[0]), clean(r[1])
        tokens = re.findall(r"([^\.\[\]]+)|\[(\d+)\]", path)
        keys = [t[0] if t[0] else int(t[1]) for t in tokens]
        cur = out
        for i, k in enumerate(keys):
            last = i == len(keys) - 1
            if last:
                if isinstance(k, int):
                    while len(cur) <= k:
                        cur.append(None)
                    cur[k] = val
                else:
                    cur[k] = val
            else:
                nk = keys[i + 1]
                if isinstance(k, int):
                    while len(cur) <= k:
                        cur.append(None)
                    if cur[k] is None:
                        cur[k] = [] if isinstance(nk, int) else {}
                    cur = cur[k]
                else:
                    if k not in cur or cur[k] is None:
                        cur[k] = [] if isinstance(nk, int) else {}
                    cur = cur[k]
    return out

def table_sheet(name, header_row=2):
    """带表头的结构化表：返回 ([dict], meta)。"""
    rr = rows_of(name)
    headers = [str(h) for h in rr[header_row]]
    meta, recs = {}, []
    for r in rr[header_row + 1:]:
        if r[0] is None:
            continue
        d = {}
        for h, v in zip(headers, r):
            v = clean(v)
            if h.startswith("_"):
                if v is not None:
                    meta[h[1:]] = v
            else:
                d[h] = v
        recs.append(d)
    if "source" in meta and isinstance(meta["source"], str):
        try:
            meta["source"] = json.loads(meta["source"])
        except Exception:
            pass
    return recs, meta

def monthly_series(name):
    rr = rows_of(name)
    basis = None
    rows = []
    for r in rr[3:]:
        if r[0] is None:
            continue
        d, v = clean(r[0]), r[1]
        if basis is None and len(r) > 2 and r[2]:
            basis = str(r[2])
        if v is not None:
            rows.append([d, v])
    return {"rows": rows, "basis": basis}

def points_series(name):
    rr = rows_of(name)
    pts = []
    for r in rr[3:]:
        if r[0] is None:
            continue
        pts.append({"date": clean(r[0]), "value": r[1], "label": clean(r[2]), "source": clean(r[3])})
    return pts

DATA = {}

# ---------- meta ----------
mkv = kv_sheet("meta")
DATA["meta"] = {
    "title": mkv.get("title"),
    "asof": mkv.get("asof"),
    "run_id": mkv.get("run_id") or "（源数据未提供 run_id）",
    "source_pack": mkv.get("source_pack"),
}

# ---------- 主时间序列 ----------
DATA["anchor_monthly"] = monthly_series("cosco monthly")
DATA["anchor_monthly"]["name"] = "中远海控（601919）前复权月线 · 月末收盘"
DATA["indexA_monthly"] = monthly_series("bdi monthly")
DATA["indexA_monthly"]["name"] = "BDI 波罗的海干散货指数（月均）"
DATA["indexB_monthly"] = monthly_series("bdti monthly")
DATA["indexB_monthly"]["name"] = "BDTI 波罗的海原油油轮指数（月均）"
DATA["indexC_monthly"] = monthly_series("bcti monthly")
DATA["indexC_monthly"]["name"] = "BCTI 波罗的海成品油轮指数（月均）"

# ---------- 披露点（禁止插值） ----------
DATA["spot_points"] = points_series("scfi points")          # SCFI
DATA["composite_points"] = points_series("ccfi points")     # CCFI
rr = rows_of("ccfi annual")
DATA["ccfi_annual"] = [{"period": clean(r[0]), "value": r[1], "label": clean(r[2]), "source": clean(r[3])}
                       for r in rr[3:] if r[0] is not None]

# ---------- 订单簿 ----------
SRC_KEY = {
    "hapag_prospectus": {"label": "Hapag-Lloyd 招股书：2007 订单簿≈船队 56%", "url": "https://www.hapag-lloyd.com/content/dam/website/downloads/ir/prospectus.pdf"},
    "vliz_notteboom": {"label": "Notteboom/VLIZ：2008-07 订单簿 干散 67.6% / 集箱 53.2%", "url": "https://www.vliz.be/imisdocs/publications/248197.pdf"},
    "unctad_rmt2012": {"label": "UNCTAD RMT 2012：订单簿较 2008 峰值 -43%", "url": "https://unctad.org/system/files/official-document/rmt2012_en.pdf"},
    "costamare_20f": {"label": "Costamare 20-F：订单簿 8.4%（2020-10）→23.1%（2021-12）", "url": "https://www.costamare.com/images/annual_reports/cmre_2021_20-f.pdf"},
    "offshore_energy_clarksons": {"label": "Offshore Energy / Clarksons：2023-12 订单簿 集 25% / 干 9% / 油 7%", "url": None},
    "riviera_tanker": {"label": "Riviera/Clarksons 2025-11-10：油轮订单簿 14.7%", "url": "https://www.rivieramm.com/news-content-hub/news-content-hub/tanker-earnings-surged-in-jan-sept-2025-86673"},
    "alphaliner_safety4sea": {"label": "SAFETY4SEA/Alphaliner 2026-06-24：订单簿 38.3%", "url": "https://safety4sea.com/alphaliner-containership-ordering-moves-towards-smaller-tonnage/"},
}
rr = rows_of("orderbook")
ob_cats, ob_container, ob_dry, ob_tanker, ob_srcs, ob_note = [], [], [], [], [], None
for r in rr[3:]:
    if r[0] is None:
        continue
    ob_cats.append(clean(r[0]))
    ob_container.append(r[1])
    ob_dry.append(r[2])
    ob_tanker.append(r[3])
    ob_srcs.append(SRC_KEY.get(str(r[4]), {"label": str(r[4]), "url": None}))
    if ob_note is None and len(r) > 5 and r[5]:
        ob_note = str(r[5])
chart_meta = {}
rr = rows_of("chart specs")
for r in rr[3:]:
    cid = r[0]
    if cid and cid not in chart_meta:
        src = r[7]
        try:
            src = json.loads(src) if isinstance(src, str) else src
        except Exception:
            pass
        chart_meta[cid] = {"title": clean(r[1]), "unit": clean(r[5]),
                           "metric_definition": clean(r[6]), "source": src,
                           "asof": clean(r[8]), "caption": clean(r[9])}
DATA["chart_meta"] = chart_meta

def cat_label(c):
    if c == "2007":
        return "2007"
    return c[:7] if isinstance(c, str) else str(c)

DATA["orderbook"] = {
    "title": chart_meta["chart_orderbook_history"]["title"],
    "unit": "%",
    "metric_definition": chart_meta["chart_orderbook_history"]["metric_definition"],
    "categories": [cat_label(c) for c in ob_cats],
    "series": [
        {"key": "container", "name": "集装箱（TEU）", "data": ob_container},
        {"key": "dry", "name": "干散（dwt）", "data": ob_dry},
        {"key": "tanker", "name": "油轮（dwt）", "data": ob_tanker},
    ],
    "rowSources": ob_srcs,
    "source": chart_meta["chart_orderbook_history"]["source"],
    "asof": chart_meta["chart_orderbook_history"]["asof"],
    "caption": chart_meta["chart_orderbook_history"]["caption"],
    "note": ob_note,
}

# ---------- 季度财务三视图 ----------
def quarterly(name):
    rr = rows_of(name)
    return [{"period": clean(r[0]), "rev": r[1], "npp": r[2], "margin": r[3]}
            for r in rr[3:] if r[0] is not None]

Q_BASIS = "单季为累计报表差分（derived）；iFinD 与 sina 两口径交叉核验；2016 年含重组非经常项；2014–2015 归母含资产出售脉冲"
DATA["quarterly"] = {
    "w2": {"label": "2011–2016 出清", "rows": quarterly("cosco q w2"), "basis": Q_BASIS,
           "note": "年报“两年巨亏”拆到季度：六年负利率常态与几次资产出售脉冲（报告 p09）",
           "source": [{"label": "iFinD / sina 利润表差分（limitations[5]）", "url": None},
                      {"label": "财新周刊 2022-11-05《中远备战新周期》", "url": "https://weekly.caixin.com/2022-11-05/101960892.html"}]},
    "w4": {"label": "2020–2022 暴利", "rows": quarterly("cosco q w4"), "basis": Q_BASIS,
           "note": "SCFI 2022-01 峰 5109.60；中远海控 2021/2022 归母 892.96 / 1095.95 亿（报告 p11）",
           "source": [{"label": "iFinD / sina 利润表差分（limitations[5]）", "url": None},
                      {"label": "FreightAmigo：SCFI 2022-01 峰值 5109.60", "url": "https://www.freightamigo.com/tc/blog/logistics/understanding-the-shanghai-containerized-freight-index-scfi-history-and-market-trends/"}]},
    "current": {"label": "2024–2026 当前", "rows": quarterly("cosco q current"), "basis": Q_BASIS,
                "note": "事件红利兑现进报表：2026Q1 单季净利率 11.35%（signals：锚公司单季净利率）",
                "source": [{"label": "iFinD / sina 利润表差分（limitations[5]）", "url": None},
                           {"label": "上海航交所官网（SCFI 2026-07-10：3184.83）", "url": "https://www.sse.net.cn/index/singleIndex?indexType=scfi"}]},
}

# ---------- lead-lag ----------
def simple_series(name, val_key):
    rr = rows_of(name)
    return [{"period": clean(r[0]), val_key: r[1]} for r in rr[3:] if r[0] is not None]

def to_quarter(datestr):
    y, m = int(datestr[:4]), int(datestr[5:7])
    return "%dQ%d" % (y, (m - 1) // 3 + 1)

cosco_margin = simple_series("cosco q leadlag", "margin")
cmes_margin = simple_series("cmes q leadlag", "margin")
bdti_q_all = simple_series("bdti q", "value")
# 与 chart_leadlag_tanker_rate 的 25 行对齐：只保留利润率序列覆盖的季度
cmes_q = set(d["period"] for d in cmes_margin)
bdti_q = [d for d in bdti_q_all if d["period"] in cmes_q]
q_range = [d["period"] for d in cosco_margin]
ccfi_ll = [{"date": p["date"], "value": p["value"], "label": p["label"], "source": p["source"],
            "quarter": to_quarter(p["date"])}
           for p in DATA["composite_points"] if p["date"] >= "2020-01-01" and to_quarter(p["date"]) in q_range]
DATA["leadlag"] = {
    "container": {
        "name": "集运：CCFI 披露点 vs 中远海控单季归母净利率",
        "margin": cosco_margin, "ratePoints": ccfi_ll, "rateName": "CCFI（披露点）",
        "maxShift": 4,
        "note": "CCFI 为披露点非连续序列，按季落位、不连线；长协缓冲使利润滞后运价 1–4 个季度（报告 p12）",
        "source": chart_meta["chart_leadlag_container_rate"]["source"],
        "asof": chart_meta["chart_leadlag_container_rate"]["asof"],
    },
    "tanker": {
        "name": "油运：BDTI 季均 vs 招商轮船单季净利率",
        "margin": cmes_margin, "rate": bdti_q, "rateName": "BDTI 季均",
        "maxShift": 2,
        "note": "招商轮船为多业务公司（油/散/LNG/滚装），利润率非纯油运口径（limitations[6]）；现货直通，滞后 1–2 季",
        "source": chart_meta["chart_leadlag_tanker_rate"]["source"],
        "asof": chart_meta["chart_leadlag_tanker_rate"]["asof"],
    },
}

# ---------- 核心叙事 ----------
DATA["answer_box"] = kv_sheet("answer box")
DATA["decision_frame"] = kv_sheet("decision frame")
DATA["industry101"] = kv_sheet("industry101")
DATA["event_timeline"] = kv_sheet("event timeline")

rr = rows_of("pages")
DATA["pages"] = []
for r in rr[3:]:
    if r[0] is None:
        continue
    bullets = r[3]
    try:
        bullets = json.loads(bullets) if isinstance(bullets, str) else bullets
    except Exception:
        pass
    DATA["pages"].append({"id": clean(r[0]), "title": clean(r[1]), "claim": clean(r[2]), "bullets": bullets})

# ---------- 阶段航道 ----------
rr = rows_of("stage strips")
ss = {"container": [], "dry": [], "tanker": []}
lane_map = {"container_stage": "container", "dry_stage": "dry", "tanker_stage": "tanker"}
for r in rr[3:]:
    if r[0] is None:
        continue
    ss[lane_map[str(r[0])]].append({"stage_id": clean(r[1]), "label": clean(r[2]),
                                    "period": clean(r[3]), "current": bool(r[4])})
DATA["stage_strips"] = ss

# ---------- 信号 ----------
sigs, _ = table_sheet("signals")
DATA["signals"] = sigs

# ---------- 旧牌桌 ----------
tiles, _ = table_sheet("cohort tiles")
DATA["cohort_tiles"] = tiles
DATA["ledger_sources"] = [{"label": clean(r[0]), "url": clean(r[1])} for r in rows_of("ledger sources")[3:] if r[0]]

# ---------- 锚公司事件 ----------
rr = rows_of("cosco events")
DATA["events"] = [{"date": clean(r[0]), "label": clean(r[1]), "detail": clean(r[2]), "src": clean(r[3])}
                  for r in rr[3:] if r[0] is not None]

# ---------- 表格 ----------
sc_rows, sc_meta = table_sheet("table analog scorecard")
DATA["table_analog_scorecard"] = {"title": sc_meta.get("title"), "rows": sc_rows,
                                  "source": sc_meta.get("source"), "asof": sc_meta.get("asof")}
rj_rows, rj_meta = table_sheet("table rejected")
DATA["table_rejected"] = {"title": rj_meta.get("title"), "rows": rj_rows,
                          "source": rj_meta.get("source"), "asof": rj_meta.get("asof")}
cmp_rows, cmp_meta = table_sheet("table subindustry compare")
DATA["table_subindustry_compare"] = {"title": cmp_meta.get("title"), "rows": cmp_rows,
                                     "source": cmp_meta.get("source"), "asof": cmp_meta.get("asof")}
gap_rows, gap_meta = table_sheet("table gap register")
DATA["table_gap_register"] = {"title": gap_meta.get("title"), "rows": gap_rows,
                              "source": gap_meta.get("source"), "asof": gap_meta.get("asof")}
legend_rows, legend_meta = table_sheet("table cohort legend")
DATA["table_cohort_legend"] = {"title": legend_meta.get("title"), "rows": legend_rows,
                               "source": legend_meta.get("source"), "asof": legend_meta.get("asof"),
                               "note": legend_meta.get("note")}
ledger_rows, ledger_meta = table_sheet("table dead ticker ledger")
DATA["table_dead_ticker_ledger"] = {"title": ledger_meta.get("title"), "rows": ledger_rows,
                                    "source": ledger_meta.get("source"), "asof": ledger_meta.get("asof")}

DATA["limitations"] = [clean(r[1]) for r in rows_of("limitations")[3:] if r[0] is not None]

rr = rows_of("windows")
DATA["windows"] = []
for r in rr[3:]:
    if r[0] is None:
        continue
    span = r[1]
    try:
        span = json.loads(span) if isinstance(span, str) else span
    except Exception:
        pass
    DATA["windows"].append({"id": clean(r[0]), "span": span, "label": clean(r[2]),
                            "role": clean(r[3]), "note": clean(r[4])})

rr = rows_of("chart specs")
losses = [{"period": clean(r[2]), "value": r[4]} for r in rr[3:] if r[0] == "chart_cosco_losses"]
DATA["cosco_losses"] = {"rows": losses, "meta": chart_meta.get("chart_cosco_losses")}

# ---------- 三套时钟 ----------
cmp_by_dim = {r["维度"]: r for r in cmp_rows}
DATA["clocks"] = [
    {"key": "container", "name": "集运", "ship": "container", "stageIndex": 0,
     "badge": "事件性紧张（订单簿前置）",
     "indexLabel": "SCFI", "indexValue": 3184.83, "indexDate": "2026-07-10",
     "reason": "溢价在、洪峰未至（利润压力前夜）；更像 2007 末的供给侧",
     "source": [{"label": "上海航交所官网（SCFI 2026-07-10：3184.83）", "url": "https://www.sse.net.cn/index/singleIndex?indexType=scfi"},
                {"label": "answer_box：cohort_stage_split（集运）", "url": None}]},
    {"key": "dry", "name": "干散", "ship": "dry", "stageIndex": 5,
     "badge": "早期上行（tentative）",
     "indexLabel": "BDI", "indexValue": 2944, "indexDate": "2026-07-10",
     "reason": "BDI 同比 +101%；7% 订单簿 + 绕航 ton-mile + 霍尔木兹溢价",
     "source": [{"label": "akshare 日度（signals：干散 BDI，2026-07-10）", "url": None},
                {"label": "answer_box：cohort_stage_split（干散）", "url": None}]},
    {"key": "tanker", "name": "油运", "ship": "tanker", "stageIndex": 6,
     "badge": "重新扩张（tentative）",
     "indexLabel": "BDTI", "indexValue": 2031, "indexDate": "2026-07-10",
     "reason": "景气写进报表：收益 19 个月新高；悬念在 14.7% 订单簿与零拆船",
     "source": [{"label": "akshare 日度（table_subindustry_compare：BDTI 2031，2026-07-10）", "url": None},
                {"label": "Riviera/Clarksons 2025-11-10：油轮收益 19 个月新高、订单簿 14.7%", "url": "https://www.rivieramm.com/news-content-hub/news-content-hub/tanker-earnings-surged-in-jan-sept-2025-86673"}]},
]

# ---------- 三行业现在时 ----------
def page(pid):
    return next(p for p in DATA["pages"] if p["id"] == pid)

DATA["current_lanes"] = [
    {"key": "container", "name": "集运", "ship": "container",
     "title": page("p15_current_container")["title"], "verdict": page("p15_current_container")["claim"],
     "bullets": page("p15_current_container")["bullets"],
     "numbers": [
         {"label": "当前运价", "value": cmp_by_dim["当前运价 07-10"]["集运"]},
         {"label": "订单簿占船队", "value": cmp_by_dim["订单簿占船队"]["集运"]},
         {"label": "需求驱动", "value": cmp_by_dim["需求驱动"]["集运"]},
         {"label": "地缘暴露", "value": cmp_by_dim["地缘暴露"]["集运"]},
         {"label": "当前阶段", "value": cmp_by_dim["当前阶段（tentative）"]["集运"]},
     ]},
    {"key": "dry", "name": "干散", "ship": "dry",
     "title": page("p16_current_dry")["title"], "verdict": page("p16_current_dry")["claim"],
     "bullets": page("p16_current_dry")["bullets"],
     "numbers": [
         {"label": "当前运价", "value": cmp_by_dim["当前运价 07-10"]["干散"]},
         {"label": "订单簿占船队", "value": cmp_by_dim["订单簿占船队"]["干散"]},
         {"label": "需求驱动", "value": cmp_by_dim["需求驱动"]["干散"]},
         {"label": "地缘暴露", "value": cmp_by_dim["地缘暴露"]["干散"]},
         {"label": "当前阶段", "value": cmp_by_dim["当前阶段（tentative）"]["干散"]},
     ]},
    {"key": "tanker", "name": "油运", "ship": "tanker",
     "title": page("p17_current_tanker")["title"], "verdict": page("p17_current_tanker")["claim"],
     "bullets": page("p17_current_tanker")["bullets"],
     "numbers": [
         {"label": "当前运价", "value": cmp_by_dim["当前运价 07-10"]["油运"]},
         {"label": "订单簿占船队", "value": cmp_by_dim["订单簿占船队"]["油运"]},
         {"label": "需求驱动", "value": cmp_by_dim["需求驱动"]["油运"]},
         {"label": "地缘暴露", "value": cmp_by_dim["地缘暴露"]["油运"]},
         {"label": "当前阶段", "value": cmp_by_dim["当前阶段（tentative）"]["油运"]},
     ]},
]

# ---------- 封面三个订单簿指标 ----------
DATA["cover_stats"] = [
    {"key": "container", "value": 38.7, "suffix": "%", "label": "集运订单簿占船队",
     "note": "1298–1328 万 TEU，交付高峰 2029（Alphaliner/Linerlytica 2026-06）",
     "source": SRC_KEY["alphaliner_safety4sea"]},
    {"key": "dry", "value": 7, "suffix": "%", "label": "干散订单簿占船队",
     "note": "多年低位；供给纪律未瓦解（Clarksons 经 Benzinga/FINVIZ 2026-02-16）",
     "source": {"label": "Clarksons 经 Benzinga/FINVIZ（signals：干散订单簿）", "url": None}},
    {"key": "tanker", "value": 14.7, "suffix": "%", "label": "油轮订单簿占船队",
     "note": "从约 7% 低位抬头；拆船几乎为零（Riviera/Clarksons 2025-11-10）",
     "source": SRC_KEY["riviera_tanker"]},
]

js = "window.DATA = " + json.dumps(DATA, ensure_ascii=False, separators=(",", ":")) + ";\n"
os.makedirs(os.path.dirname(OUT), exist_ok=True)
with open(OUT, "w", encoding="utf-8") as f:
    f.write(js)
print("written", OUT, len(js), "bytes")
print("anchor months:", len(DATA["anchor_monthly"]["rows"]),
      "| bdi:", len(DATA["indexA_monthly"]["rows"]),
      "| bdti:", len(DATA["indexB_monthly"]["rows"]),
      "| scfi pts:", len(DATA["spot_points"]),
      "| ccfi pts:", len(DATA["composite_points"]),
      "| cohort:", len(DATA["cohort_tiles"]),
      "| signals:", len(DATA["signals"]),
      "| events:", len(DATA["events"]))
