# REPORT.md — 交付报告

## 1. 模块结构

```
shipping-viz/
├─ build_data.py        # 解析 xlsx → site/data/data.js（唯一数据管线）
├─ DESIGN.md            # 视觉系统
├─ NOTES-pudding.md     # Pudding 范式对应记录
├─ REPORT.md            # 本文件
└─ site/
   ├─ index.html        # 13 区块骨架，禁用外部资源
   ├─ css/main.css      # 海图纸视觉系统
   ├─ data/data.js      # window.DATA（由 build_data.py 生成，勿手改）
   ├─ js/
   │  ├─ pixel.js       # 字符矩阵 → SVG 像素船（.px-ship, data-w/data-h）
   │  ├─ charts.js      # UI 助手 + 8 个 D3 图表构建器
   │  ├─ sections.js    # 13 区块 DOM 渲染与步骤文案
   │  ├─ scrolly.js     # 3 个 Scrollama scrolly
   │  └─ main.js        # 启动
   └─ vendor/
      ├─ d3.min.js         # D3 v7.9.0（本地化）
      └─ scrollama.min.js  # Scrollama v3.2.0（本地化）
```

## 2. 数据契约（window.DATA）

| 键 | 内容 | 来源工作表 |
|---|---|---|
| meta | 标题 / asof / run_id / source_pack | meta |
| anchor_monthly | 中远海控前复权月线 225 行 + basis | cosco monthly |
| indexA/B/C_monthly | BDI 454 / BDTI 296 / BCTI 月均 + basis | bdi/bdti/bcti monthly |
| spot_points / composite_points | SCFI 13 / CCFI 9 披露点（date,value,label,source） | scfi/ccfi points |
| ccfi_annual | CCFI 年度点 | ccfi annual |
| orderbook | 8 时点 × 3 船型 + metric_definition + 逐行/全表来源 | orderbook + chart specs |
| quarterly.w2/w4/current | 三视图季度利润（rev/npp/margin）+ 口径 | cosco q w2/w4/current |
| leadlag.container/tanker | 净利率 + 运价（CCFI 披露点按季落位 / BDTI 季均）+ maxShift | cosco/cmes q leadlag、bdti q、ccfi points |
| clocks | 3 套时钟（stageIndex、指数现值、理由、来源） | answer_box + subindustry compare + signals 推导 |
| answer_box / decision_frame / pages / industry101 / event_timeline | 叙事文本 | 同名表 |
| stage_strips | 三航道各 4 段（label/period/current） | stage strips |
| signals | 8 信号（family/status/现值/阈值/时滞/证伪/来源/asof） | signals |
| cohort_tiles + ledger_sources | 26 公司牌（sector/name/fate/detail/src） | cohort tiles、ledger sources |
| events | 8 个锚公司事件钉 | cosco events |
| table_analog_scorecard / table_rejected / table_subindustry_compare / table_gap_register / table_cohort_legend / table_dead_ticker_ledger | 结构化表（含 _title/_source/_asof） | 同名表 |
| limitations / windows / chart_meta / cosco_losses / cover_stats / current_lanes | 其余支撑数据 | 同名/推导 |

JS 端只读 `window.DATA`；任何数字改动都应改 xlsx 后重跑 `python3 build_data.py`。

## 3. 数据完整性核对结果

| 项 | 期望 | 实测 | 结果 |
|---|---|---|---|
| 锚公司月线 | 2007-06 → 2026-07，225 个月 | 225 | ✔ |
| BDI 月均 | 454 | 454 | ✔ |
| BDTI 月均 | 296 | 296 | ✔ |
| SCFI 披露点 | 13 | 13 | ✔ |
| CCFI 披露点 | 9 | 9 | ✔ |
| 公司牌 | 26（集 13 / 干 8 / 油 5） | 26 | ✔ |
| 信号 | 8 | 8 | ✔ |
| 事件钉 | 8 | 8 | ✔ |
| 订单簿时点 | 8（2007…2026-06） | 8 | ✔ |
| 季度视图 | w2=24 / w4=12 / current=9 | 24/12/9 | ✔ |
| 五窗口打分卡 | 5 | 5 | ✔ |
| 缺口登记簿 | 6 | 6 | ✔ |
| lead-lag 季度 | 各 25 季（2020Q1–2026Q1） | 25/25 | ✔（bdti q 多出的 2026Q2 按 chart spec 裁去） |

## 4. 数据 → 像素映射表

| 图 | 映射 |
|---|---|
| 时钟 | 7 阶段 → d3.pie（-0.82π → +0.82π，pad .012）；当前阶段 → 船型色扇区 + 指针中角；R=118、环宽 34 |
| 股价 | 月 → x（scaleTime）；前复权价 → y（linear，0→max×1.18）；事件 → 5px 红圆 + 26px 引线；步骤窗口 → 浅红虚线矩形 |
| 三曲线 | 年 → 共享 x（1988–2026）；SCFI 点+stem / CCFI 空心方块；BDI/BDTI 面积+线；面板高 172、间距 34 |
| 牌桌 | 公司 → 62px 牌；fate → 标签色 + 变形参数（下沉 10px / -6° / .75 / .22） |
| 季度利润 | 季 → band x；margin% → y；正集运蓝 / 负信号红；稀疏标签 |v|>12 或小样本 |
| 订单簿 | 1 立体层 = 5 个百分点；块高 17 / 面宽 26 / 斜深 12；尾数按比例不满一层；值标签 12.5px mono + 4px 纸色描边 |
| lead-lag | margin → 灰/红柱（左轴）；运价 → 船型色点/线（右轴）；右移 k×x.step() |
| 传导桥 | linkHorizontal：能传导 2.4px 船型色实线 / 不能传导 1.4px 灰虚线 + 中点红叉 |

## 5. 时钟级数
七阶段表盘：过热顶部 → 初段下行 → 利润压力 → 出清 → 底部观察 → 早期上行 → 重新扩张（decision_frame.stage_taxonomy）。
当前落位（可溯源推导，见 data.js `clocks[].source`）：集运 = 过热顶部（事件性紧张，利润压力前夜）、干散 = 早期上行、油运 = 重新扩张。

## 6. 测试方式与结果
- 本地 `python3 -m http.server` + Playwright（Chromium 1440×900 与 390×844）。
- **结构断言**：3 封面指标、38 个 `.px-ship`、3×7 表盘扇区、8 事件钉、7/7/4 步骤卡、13+9 披露点、26 牌、24/12/9 季度柱、13 货堆、2 lead-lag 面板、5 打分卡、2 排除卡、3×4 航道段、8 信号卡、6 缺口行、9 limitations、3 浪 + 3 船 —— 全部命中。
- **交互断言**：封面数字 1400ms 滚到 38.7%/7%/14.7%；时钟扇区 hover tooltip；真实增量滚动下 scrolly 逐步激活（股价 step5 非相关钉 0.16 / 相关 1、窗口矩形出现）；事件钉点击开数据卡、Esc 关；季度三按钮切换并更新注释与来源行；货堆点击开卡、遮罩点击关；播放键禁用→"形状对上了"→"重新播放"；打分卡开卡；牌桌终局 12 张压暗 / 26 标签全显、破产牌 transform 正确；曲线步骤窗口矩形 ×3 + 注释圆圈显隐正确。
- **控制台错误：0**（修复项：modal `hidden` 被 CSS display:flex 覆盖导致遮罩常驻拦截点击 —— 已加 `[hidden]{display:none}`；bdti q 多一季导致 NaN 坐标 —— 已按口径裁剪）。
- 移动端 390px：封面/时钟纵向堆叠、scrolly 图全宽 sticky 86vh，无错误。

## 7. 覆盖 / 未覆盖清单

**已覆盖（13 区块）**：封面 → 三套时钟 → 股价 scrolly → 三曲线 scrolly → 旧牌桌 scrolly → 季度利润三视图 → 订单簿 2.5D → lead-lag 双面板 → 五窗口打分卡（含 2 条排除类比）→ 传导桥 → 三行业现在时 → 监控仪表盘 ×8 → 缺口/限制/出处页脚。全站离线（D3/Scrollama 本地化，无外部资源）、每图来源行、tooltip + 数据卡、披露点不连线、像素船实时生成、中英术语按数据原文、响应式 ≤900px。

**未覆盖（有意舍弃）**：BCTI 序列与 ccfi_annual 已入 data.js 但未单独成图（任务未要求对应区块）；chart specs 中的 peers_rebased / fro_quarterly / bci_bpi_current 等辅助 spec 未绘制（不在 13 区块范围内，数据仍可由 chart_meta 取得）。

## 8. 已知缺口与口径声明
- CCFI/SCFI 为披露点非连续序列：三曲线图中点间不插值、不连线；lead-lag 面板按原版形态将 CCFI 披露点按季落位并以折线连接（点+线）。
- 1988–2002 集运无公开指数：斜纹缺口带，不拼接、不补零。
- 中远海控为前复权月线（akshare qfq 月末重采样），与行情软件不复权价格不可直接比。
- 季度利润为累计报表差分，2014–2015 含资产出售脉冲、2016 含重组非经常项。
- 招商轮船为多业务公司，其净利率非纯油运口径（limitations[6]）。
- 时钟"当前阶段"为 tentative 推导值，依据与来源写在表盘下与 data.js 中。
- 完整 6 条缺口与 11 条 limitations 见页面最后一屏，均来自源数据原文。

## 9. 修改方法
- **改数字/文案**：编辑 xlsx 对应工作表 → `python3 build_data.py` → 刷新页面。不要手改 `site/data/data.js`。
- **改颜色/字体/间距**：只动 `site/css/main.css` 的 `:root` 变量与对应组件；图表内颜色在 `charts.js` 顶部 `C` 表。
- **改时钟当前阶段**：改 xlsx 的 answer_box / compare 后重跑 build_data.py（`clocks[].stageIndex` 随之更新）。
- **改步骤文案**：`sections.js` 中 STOCK_STEPS / CURVES_STEPS / COHORT_STEPS。
- **改像素船**：`pixel.js` 的 MATRICES/PALETTE（保持字符集与调色板一致）。
- **重新本地预览**：`python3 -m http.server 8000 --directory site` 后开 `http://localhost:8000`。
