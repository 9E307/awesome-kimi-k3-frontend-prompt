# DESIGN.md — 设计系统说明

## 风格定位
复古海图纸 × 数据叙事长页。纸面底色、墨蓝硬边、直出阴影，像一张可以滚动的航海日志；三种像素船是全站唯一的"插画"，全部由字符矩阵实时生成 SVG，不使用任何图片素材。

## 色彩（CSS 变量）
| 变量 | 值 | 用途 |
|---|---|---|
| `--paper` | #F7F2E7 | 主背景（海图纸） |
| `--paper-deep` | #EFE7D3 | 区块交替带 |
| `--card` | #FDFAF2 | 卡片纸白 |
| `--ink` | #14263B | 主墨色（标题/边框/轴） |
| `--ink2` | #3D4E63 | 次级文字 |
| `--gray` | #8C8577 | 弱灰褐（注释/刻度） |
| `--line` | #D8CFBA | 分隔线 |
| `--c-container` | #0E67B5 | 集运 |
| `--c-dry` | #C25E28 | 干散 |
| `--c-tanker` | #1F8A70 | 油运 |
| `--red` | #C0392B | 亏损/风险/事件/负值 |
| 辅助 | #C9A227 / #2E8B57 / #E4DBC4 | 状态金 / 状态绿 / 表盘非当前扇区 |

全站每个像素颜色均来自上表（含 pixel.js 的 PALETTE）。

## 字体
- 标题：`"Songti SC","Noto Serif SC","STSong",serif`
- 正文：`"PingFang SC","Hiragino Sans GB","Microsoft YaHei",sans-serif`，17px / 1.9
- 数字与刻度：`"SF Mono","Menlo",monospace`

## 版式
- H2 40px / 1.35，下方 64×4px 墨色短棒；≤900px 降为 30px
- 文字列 720px、图表列 1080px，水平 padding 24px
- 13 个区块上下 padding 110px（≤900px 为 70px），背景纸色 / 深纸色交替

## 组件语汇
- **硬边报纸卡**：1.5–2px 墨描边 + 纸白底 + 右下 4–10px 直出硬阴影（无圆角、无模糊）
- **tooltip**：fixed，深墨底纸字 13px，max-width 300px，右下硬阴影；位置按视口边缘收敛
- **数据卡（modal）**：遮罩 rgba(20,38,59,.45)，卡片 max-width 520px / max-height 82vh，2px 墨描边 10px 硬阴影；Esc / 遮罩点击关闭
- **按钮组**：相邻边框重叠，选中态墨底纸字；播放键 2px 描边 + 4px 硬阴影
- **来源行**：首条直接可见，其余 `details` 折叠（含 URL），附数据截至日期

## Scrolly 布局
容器 max-width 1240px；sticky 图左（top 0、高 100vh），步骤卡右 360/340px；
卡片间距 78vh、首卡上距 12vh、末卡下距 55vh；
非激活卡 opacity .32 + translateY(6px)，激活 0.35s 过渡；Scrollama offset 0.62。
≤900px：步骤列全宽居中，sticky 图高 86vh，步骤间距 65vh。

## 像素系统
三种像素船由 pixel.js 的字符矩阵（8×28）× 调色板实时生成 `<rect>`：
`px-ship` 根组带 `data-w`/`data-h`；`image-rendering: pixelated`。
出现位置：封面 3 条航行船（52/74/96s 横渡）、时钟轴心、26 张公司牌、传导桥节点、现在时航道标记。
封面海浪为 96px 周期方波，三层在海底上方 96/72/48px，速度 7s 正 / 11s 反 / 9s 正。
