/**
 * js/data-v53.js — VERDICT & EVIDENCE DATASETS
 * Forty-Two Years of Inference Silicon · data layer (spec §16 + §11)
 *
 * Namespace: window.DATA (no modules, no imports).
 * Datum convention identical to js/data.js:
 *   { value, state, src, unit, fmt, tip, drill } — shared fields hoisted
 *   into `meta` on grouped datasets.
 * Keys: assumptions, analogMatrix, verdictTree, scenarios, signals,
 *       companyDeepDives, nowWave, crossoverData, sources (K1–K41),
 *       drillFacts.
 */
window.DATA = window.DATA || {};
(function (D) {
  'use strict';

  /* ------------------------------------------------------------------ *
   * assumptions — three bold consensus assumptions, stress-tested
   * (#sec-assumptions). Grades: fail · undecidable · late.
   * ------------------------------------------------------------------ */
  D.assumptions = [
    {
      id: 'A1',
      title: 'Where the AI dollar pools',
      claim: 'Custom silicon captures the majority of AI accelerator dollars.',
      grade: 'fail',
      gradeLabel: 'FAIL',
      evidence: 'On the only basis eligible for scenario math — dollars — custom silicon is ≈12% of 2025E accelerator spend and ≈20% even in 2027F. The dollar still pools at merchant GPUs; the unit-basis crossover story does not survive conversion to money.',
      state: 'estimate', src: 'K8', drill: 'a1',
      tip: 'A1 · dollar pooling — grade: fail'
    },
    {
      id: 'A2',
      title: 'ASIC units overtake GPUs in 2027',
      claim: 'Custom ASIC unit shipments pass merchant GPU units in 2027.',
      grade: 'undecidable',
      gradeLabel: 'UNDECIDABLE',
      evidence: 'The 50% unit line requires ≈8.0–8.4M TPU-class units in 2027F. Published 2026 estimates span 6.5M–15M — a range that straddles the required line by ±40%. No disclosed evidence closes it; the claim is unadjudicable, not wrong.',
      state: 'gap', src: 'K35', drill: 'a2',
      tip: 'A2 · 2027 unit crossover — grade: undecidable'
    },
    {
      id: 'A3',
      title: 'Demand is visible to 2028',
      claim: 'Hyperscaler demand visibility extends through 2028.',
      grade: 'late',
      gradeLabel: 'LATE',
      evidence: 'Visibility rests on 2026 guidance plus announced programs and backlogs. The revision ledger has only ever moved upward — but the 2027–2028 prints that would confirm the assumption arrive after the window in which positioning decisions must be made.',
      state: 'estimate', src: 'K5', drill: 'a3',
      tip: 'A3 · demand visibility to 2028 — grade: late'
    }
  ];

  /* ------------------------------------------------------------------ *
   * analogMatrix — seven historical windows × five dimensions
   * (#matrix-chart, HTML matrix). Each cell: same | partial | none,
   * read as “how does this window compare to the 2023–2026 cycle on
   * this dimension”. Blue = same, hatched = partial, grey = none.
   * ------------------------------------------------------------------ */
  D.analogMatrix = {
    meta: {
      note: 'Forty-two years in one table. Read each row as a comparison against the current cycle.',
      dimensions: [
        { id: 'demand',     label: 'Demand composition' },
        { id: 'constraint', label: 'Binding constraint' },
        { id: 'clearing',   label: 'Clearing mechanism' },
        { id: 'capital',    label: 'Capital intensity' },
        { id: 'software',   label: 'Software lock-in' }
      ],
      states: { same: 'same', partial: 'partial', none: 'none' },
      drill: 'matrix'
    },
    rows: [
      {
        id: 'survivorship', label: '1975–2026 · Survivorship record',
        cells: {
          demand:     { v: 'none',    note: 'Long-run aggregation hides every demand shock.' },
          constraint: { v: 'partial', note: 'Constraints always existed; their identity migrated.' },
          clearing:   { v: 'same',    note: 'Acquisition-led clearing — the constant (bankruptcy-law restructuring rare but not absent).' },
          capital:    { v: 'partial', note: 'Fabs were always capital-heavy; scale differs.' },
          software:   { v: 'same',    note: 'The toolchain selects survivors in every era.' }
        },
        drill: 'matrix'
      },
      {
        id: 'w1', label: '1985–1995 · The FPGA founding',
        cells: {
          demand:     { v: 'none',    note: 'Design-win demand, not fleet deployment.' },
          constraint: { v: 'none',    note: 'No binding external gate; gates were internal (tools).' },
          clearing:   { v: 'same',    note: 'Consolidation grammar already in place.' },
          capital:    { v: 'none',    note: 'Fabless from birth — capital lived at the foundry.' },
          software:   { v: 'same',    note: 'Toolchain lock-in is the founding moat.' }
        },
        drill: 'matrix'
      },
      {
        id: 'w2', label: '1995–2003 · Boom and bust',
        cells: {
          demand:     { v: 'partial', note: 'Single-vertical demand shock (optical) ≈ single-vertical shock (AI).' },
          constraint: { v: 'partial', note: 'Then: wafer fabs. Now: HBM, packaging, power.' },
          clearing:   { v: 'same',    note: 'The −39% reset cleared through consolidation.' },
          capital:    { v: 'partial', note: 'Carrier capex then; hyperscaler capex now.' },
          software:   { v: 'none',    note: 'No ecosystem moat comparable to CUDA yet.' }
        },
        drill: 'matrix'
      },
      {
        id: 'w3', label: '2004–2012 · The quiet decade',
        cells: {
          demand:     { v: 'none',    note: 'No demand shock; the decade is the control group.' },
          constraint: { v: 'partial', note: 'Submarine deployments hid the real constraint: disclosure.' },
          clearing:   { v: 'same',    note: 'Actel, SiliconBlue: acquisition grammar continues.' },
          capital:    { v: 'none',    note: 'Pilots, not build-outs.' },
          software:   { v: 'partial', note: 'CUDA founded 2006–2007; moat under construction.' }
        },
        drill: 'matrix'
      },
      {
        id: 'w4', label: '2013–2018 · Ignition',
        cells: {
          demand:     { v: 'partial', note: 'Real workload demand (deep learning) — smaller scale, same shape.' },
          constraint: { v: 'partial', note: 'Constraint was algorithmic (perf/W), not physical.' },
          clearing:   { v: 'same',    note: 'Altera, Nervana, Habana: acquisition grammar holds.' },
          capital:    { v: 'partial', note: 'First fleet-scale checks: $16.7B for Altera.' },
          software:   { v: 'same',    note: 'The ecosystem verdict: CUDA decides who scores.' }
        },
        drill: 'matrix'
      },
      {
        id: 'w5', label: '2019–2022 · Shortage and the M&A supercycle',
        cells: {
          demand:     { v: 'partial', note: 'Pulled-forward demand; NCNR grammar identical to today’s.' },
          constraint: { v: 'partial', note: 'Substrate and mature-node shortage ≈ today’s HBM/CoWoS gate.' },
          clearing:   { v: 'same',    note: 'Five $B deals in 108 days; AMD–Xilinx $49B.' },
          capital:    { v: 'partial', note: 'Capex supercycle — one order of magnitude smaller.' },
          software:   { v: 'partial', note: 'CUDA dominant; frameworks not yet consolidated.' }
        },
        drill: 'matrix'
      },
      {
        id: 'mining', label: '2017–2022 · The mining mirror',
        cells: {
          demand:     { v: 'partial', note: 'Speculative demand with real revenue — the closest demand analog.' },
          constraint: { v: 'partial', note: 'Leading-edge nodes (55→16nm race) as the gate.' },
          clearing:   { v: 'same',    note: 'Two full crash-and-clear cycles in five years.' },
          capital:    { v: 'none',    note: 'NRE-scale capital, not fleet-scale.' },
          software:   { v: 'none',    note: 'Fixed-function hashing: zero software moat.' }
        },
        drill: 'matrix'
      }
    ]
  };

  /* ------------------------------------------------------------------ *
   * verdictTree — same-case / different-case / policy-partition
   * (#verdict-tree-chart, SVG). The policy branch renders dashed.
   * ------------------------------------------------------------------ */
  D.verdictTree = {
    meta: {
      note: 'The verdict in two scenarios — plus the dashed partition neither scenario survives.',
      drill: 'verdict-root'
    },
    root: 'q0',
    nodes: [
      { id: 'q0',        parent: null,    branch: 'root',      dashed: false, label: '2023–2026: replay or new cycle?', note: 'The exam question. Six windows of evidence feed two scenarios — and one partition.', drill: 'verdict-root' },
      { id: 'same',      parent: 'q0',    branch: 'same',      dashed: false, label: 'Same case',                        note: 'A replay of the 1995–2000 optical overbuild: real demand, over-ordered capacity, one clearing wave.', drill: 'verdict-same' },
      { id: 'same-e1',   parent: 'same',  branch: 'same',      dashed: false, label: 'Evidence',                         note: 'Capex/OCF hits the 0.8 caution line in 2025; NCNR grammar and double-ordering repeat verbatim.', drill: 'ocf-stress' },
      { id: 'same-out',  parent: 'same',  branch: 'same',      dashed: false, label: 'Outcome',                          note: 'Contraction scenario: −15% to −35% over three years; survivors consolidate. Exit by acquisition.', drill: 'scen-contraction' },
      { id: 'diff',      parent: 'q0',    branch: 'different', dashed: false, label: 'Different case',                   note: 'New constraints — HBM, CoWoS, the grid — plus a deeper software moat and multi-vertical demand.', drill: 'verdict-diff' },
      { id: 'diff-e1',   parent: 'diff',  branch: 'different', dashed: false, label: 'Evidence',                         note: 'Gates sold out 12+ months ahead; 415→945TWh grid trajectory; toolchain lock-in at record depth.', drill: 'power-iea' },
      { id: 'diff-out',  parent: 'diff',  branch: 'different', dashed: false, label: 'Outcome',                          note: 'Base case: ≈2.5× over three years (range 2.0–4.7×). Kill switch armed at +14%.', drill: 'scen-base' },
      { id: 'policy',    parent: 'q0',    branch: 'policy',    dashed: true,  label: 'Policy partition',                 note: 'Export controls and industrial policy split demand into US-aligned and China spheres.', drill: 'verdict-policy' },
      { id: 'policy-out', parent: 'policy', branch: 'policy',  dashed: true,  label: 'Outcome',                          note: 'Neither scenario survives intact: two partial clearings, one per sphere. Watch the triggers at each print (register cutoff 2026-07-18).', drill: 'signals-summary' }
    ]
  };

  /* ------------------------------------------------------------------ *
   * scenarios — scenario arithmetic (#scenario-chain-chart, SVG).
   * Chain: capex path × custom-silicon dollar share → demand multiple.
   * Base ≈2.5× (range 2.0–4.7×) · Conservative ≈2.0× ·
   * Contraction −15% to −35% · Kill switch: Top-4 2027E capex growth
   * below +14%.
   * ------------------------------------------------------------------ */
  D.scenarios = {
    meta: {
      horizon: '2025 → 2028',
      note: 'REBUILT MODEL (Option A — compatible denominators): custom-silicon accelerator revenue = total accelerator spending × custom-silicon share of accelerator spending. Both inputs are accelerator-dollar spending — NOT total hyperscaler capex, which also buys buildings, land, power, networking, storage and general-purpose servers and is not a compatible denominator.',
      formula: 'multiple = (accelerator spending 2028 / accelerator spending 2025) × (custom share 2028 / custom share 2025)',
      denominatorNote: 'The earlier 3.0–4.3× chain multiplied total capex growth by a custom-silicon dollar share — incompatible denominators. It has been withdrawn and rebuilt; do not cite it.',
      srcSet: ['K1', 'K2', 'K3', 'K4'],
      drill: 'scen-base'
    },
    model: {
      formula: 'customRevenueMultiple = (spendTarget / spendBase) × (shareTarget / shareBase)',
      baseYear: 2025,
      targetYear: 2028,
      inputs: {
        spendBase: { value: 330, unit: 'US$B', class: 'derived', label: '2025 global AI-accelerator spending', source: 'derived working assumption — see spendBaseDerivation', url: null, date: '2026-07-18' },
        spendTarget: { value: 500, unit: 'US$B', class: 'guidance', label: '2028 AI data-center accelerator TAM', source: 'AMD-stated AI DC accelerator TAM “>$500B by 2028” (company claim, Oct 2024, reiterated Jun 2025) — a company TAM claim, not a consensus forecast', url: null, date: '2025-06-12' },
        shareBase: { value: 0.12, unit: 'share', class: 'estimate', label: '2025E custom-silicon share of accelerator dollars (Series A)', source: 'compiled broker accelerator-spending tallies (access limited)', url: null, date: '2026-06' },
        shareTargetLow: { value: 0.16, unit: 'share', class: 'scenario-assumption', label: '2028 custom share — low (share stalls at the 2026F read)', source: 'scenario assumption', url: null, date: '2026-07-18' },
        shareTargetBase: { value: 0.20, unit: 'share', class: 'scenario-assumption', label: '2028 custom share — base (2027F read held into 2028)', source: 'extrapolation of the 2027F Series-A broker read — scenario assumption', url: null, date: '2026-07-18' },
        shareTargetHigh: { value: 0.37, unit: 'share', class: 'estimate', label: '2028 custom share — high (JPM custom-share path)', source: 'JPMorgan custom-share tallies (37% 2024 → 45% 2028) — SECONDARY citation only, low confidence, access limited; used here as the upper bound 2028 read (37%)', url: null, date: '2026-06' }
      },
      spendBaseDerivation: {
        note: '2025 global AI-accelerator spending ≈ $330B — a derived working assumption, summed from the components below. Each component is an estimate; the total is not a reported figure.',
        components: [
          { label: 'NVIDIA data-center revenue, annualized', value: 205, unit: 'US$B', class: 'derived', note: 'NVIDIA DC revenue run-rate entering 2026 (Q1 FY27 $75.2B/quarter reported May 2026; FY2026 annualization ≈$205B) — working assumption' },
          { label: 'AMD AI (Instinct-class)', value: 15, unit: 'US$B', class: 'estimate', note: 'compiled estimate' },
          { label: 'Custom ASIC programs (Broadcom XPU + Marvell custom + Alchip/GUC-class)', value: 45, unit: 'US$B', class: 'estimate', note: 'compiled estimate at program value (incl. internal transfer pricing)' },
          { label: 'Others (Intel Gaudi, Cerebras/Groq/SambaNova-class, other merchant + in-house parts)', value: 65, unit: 'US$B', class: 'estimate', note: 'compiled estimate' }
        ],
        total: 330
      },
      outputRange: { low: 2.0, base: 2.5, high: 4.7, unit: '×', basis: 'custom-silicon accelerator revenue multiple, 2025→2028' },
      outputs: {
        spendGrowth: { value: 1.515, exact: 500 / 330, note: '500/330 ≈ 1.52×' },
        shareGrowthBase: { value: 1.667, exact: 20 / 12, note: '20/12 ≈ 1.67×' },
        base: { value: 2.5, exact: (500 / 330) * (20 / 12), note: '1.515 × 1.667 ≈ 2.5×' },
        low: { value: 2.0, exact: (500 / 330) * (16 / 12), note: '1.515 × (16/12) ≈ 2.0×' },
        high: { value: 4.7, exact: (500 / 330) * (37 / 12), note: '1.515 × (37/12) ≈ 4.7×' }
      },
      sensitivity: {
        note: 'Output multiple = spend growth (rows) × share growth (columns). Share growth 1.33/1.67/2.5 corresponds to 2028 shares of 16%/20%/30% on a 12% base; the AMD-TAM spend case (1.52×) sits between rows 1.5 and 1.7.',
        spendAxis: [1.3, 1.5, 1.7],
        shareAxis: [1.33, 1.67, 2.5],
        values: [
          [1.729, 2.171, 3.25],
          [1.995, 2.505, 3.75],
          [2.261, 2.839, 4.25]
        ]
      },
      killSwitch: { metric: 'Top-4 2027E capex growth', threshold: '< +14%', note: 'If Top-4 2027E capex growth prints below +14%, the base case is void on contact.', src: 'K4', drill: 'kill-switch' }
    },
    list: [
      {
        id: 'base', name: 'Base case',
        multiple: { low: 2.0, high: 4.7, mid: 2.5, fmt: 'mult' },
        chain: {
          years: [2025, 2026, 2027, 2028],
          /* accelerator-dollar spending path ($330B → $500B), NOT total capex.
             Legacy key names capexPath/capexMultiple retained for chart
             compatibility — chart agent should relabel to ACCELERATOR SPEND. */
          capexPath: [330, 379, 435, 500],
          capexMultiple: 1.52,
          spendPath: [330, 379, 435, 500],
          spendMultiple: 1.52,
          sharePath: [0.12, 0.142, 0.169, 0.20],
          shareMultiple: 1.67,
          demandMultiple: 2.53
        },
        killSwitch: { metric: 'Top-4 2027E capex growth', threshold: '< +14%', src: 'K4', drill: 'kill-switch' },
        state: 'derived', src: 'K1', drill: 'scen-base',
        note: 'Accelerator spending $330B → $500B (1.52×, AMD-stated TAM claim for 2028) × custom-silicon dollar share 12% → 20% (1.67×; 2027F broker read held into 2028) ≈ 2.5× custom-silicon accelerator revenue. Range 2.0× (share stalls at 16%) to 4.7× (JPM 37% secondary read).',
        tip: 'Base case · ≈2.5× over three years · range 2.0–4.7× · compatible accelerator-dollar denominators'
      },
      {
        id: 'conservative', name: 'Conservative',
        multiple: { low: 1.9, high: 2.1, mid: 2.0, fmt: 'mult' },
        chain: {
          years: [2025, 2026, 2027, 2028],
          capexPath: [330, 379, 435, 500],
          capexMultiple: 1.52,
          spendPath: [330, 379, 435, 500],
          spendMultiple: 1.52,
          sharePath: [0.12, 0.133, 0.147, 0.16],
          shareMultiple: 1.33,
          demandMultiple: 2.02
        },
        killSwitch: null,
        state: 'derived', src: 'K2', drill: 'scen-cons',
        note: 'The TAM path is met but the share stalls at the 2026F read: 1.52× accelerator-spend growth × 1.33× share growth (12% → 16%) ≈ 2.0× (band 1.9–2.1× for 15–17% 2028 share).',
        tip: 'Conservative · ≈2.0× over three years'
      },
      {
        id: 'contraction', name: 'Contraction',
        multiple: { low: -0.35, high: -0.15, mid: -0.25, fmt: 'pct' },
        chain: {
          years: [2025, 2026, 2027, 2028],
          capexPath: [330, 400, 345, 304],
          capexMultiple: 0.92,
          spendPath: [330, 400, 345, 304],
          spendMultiple: 0.92,
          sharePath: [0.12, 0.11, 0.10, 0.095],
          shareMultiple: 0.79,
          demandMultiple: 0.73
        },
        killSwitch: null,
        state: 'derived', src: 'K3', drill: 'scen-contraction',
        note: 'The same-case replay: accelerator spending mean-reverts (≈−8%) and the custom share stalls (0.79×) → 0.73×, i.e. −15% to −35% custom-silicon demand, cleared by consolidation.',
        tip: 'Contraction · −15% to −35% over three years'
      }
    ]
  };

  /* ------------------------------------------------------------------ *
   * signals — eight falsification triggers, point-in-time register
   * (#sec-signals). status: 'met' | 'partial' | 'missing'.
   * Summary as of research cutoff 2026-07-18: 1 confirmed · 7 partial · 0 missing.
   * ------------------------------------------------------------------ */
  D.signals = {
    meta: {
      note: 'Eight falsification triggers. A trigger reports what would kill the thesis — not what would flatter it. Point-in-time register, research cutoff 2026-07-18; not a live or quarterly-updated product.',
      cadence: 'point-in-time register, research cutoff 2026-07-18',
      lastReviewed: '2026-07-18',
      summary: { confirmed: 1, partial: 7, missing: 0 },
      drill: 'signals-summary'
    },
    list: [
      {
        id: 'sig-1', name: 'Top-4 capex guidance vs plan',
        status: 'partial',
        falsification: 'Any quarter in which aggregate guided 2026 capex is cut below +20% YoY.',
        invalidation: 'Trigger retires as confirmed if guidance holds ≥ +20% through the Q2-2026 prints with the OCF funding gap not widening.',
        currentReading: 'Q1-2026 earnings (Apr 29–30 2026) reaffirmed 2026 guidance of ≈$695–725B combined — Amazon ≈$200B, Microsoft ≈$190B (explicitly CY2026), Alphabet $180–190B, Meta $125–145B — versus ≈$410–413B spent in 2025 (compiled estimate): +68–76% YoY.',
        reading: 'Q1-2026 earnings (Apr 29–30 2026) reaffirmed 2026 guidance of ≈$695–725B combined — Amazon ≈$200B, Microsoft ≈$190B (explicitly CY2026), Alphabet $180–190B, Meta $125–145B — versus ≈$410–413B spent in 2025 (compiled estimate): +68–76% YoY.',
        lastReviewed: '2026-07-18',
        nextWindow: 'Q2-2026 earnings: Alphabet 2026-07-28 · Microsoft 2026-07-28/29 · Meta 2026-07-29 · Amazon 2026-07-30',
        nextWindowDate: '2026-07-28',
        sourceUrl: 'https://abc.xyz/investor/',
        state: 'estimate', src: 'K5', drill: 'sig-1',
        tip: 'Trigger 1 · capex guidance — building'
      },
      {
        id: 'sig-2', name: 'NVIDIA data-center growth',
        status: 'partial',
        falsification: 'Data-center YoY growth below +20% for two consecutive quarters.',
        invalidation: 'Trigger retires as confirmed if growth holds ≥ +20% through the Q2 FY2027 print.',
        currentReading: 'Q1 FY2027 (quarter ended 2026-04-26): data-center revenue $75.2B, +92% YoY — compute $60.4B, networking $14.8B; total revenue $81.6B; Q2 FY27 guided at $91.0B ± 2%. Growth is decelerating from triple digits but remains far above the falsification line.',
        reading: 'Q1 FY2027 (quarter ended 2026-04-26): data-center revenue $75.2B, +92% YoY — compute $60.4B, networking $14.8B; total revenue $81.6B; Q2 FY27 guided at $91.0B ± 2%. Growth is decelerating from triple digits but remains far above the falsification line.',
        lastReviewed: '2026-07-18',
        nextWindow: 'Q2 FY2027 report ≈2026-08-26',
        nextWindowDate: '2026-08-26',
        sourceUrl: 'https://nvidianews.nvidia.com/news/nvidia-announces-financial-results-for-first-quarter-fiscal-2027',
        state: 'estimate', src: 'K10', drill: 'sig-2',
        tip: 'Trigger 2 · NVIDIA DC growth — building'
      },
      {
        id: 'sig-3', name: 'Broadcom custom-silicon momentum',
        status: 'partial',
        falsification: 'FY2027 AI guidance cut below the FY2026 level (≈$56B), or a qualified XPU customer lost.',
        invalidation: 'Trigger retires as confirmed if FY2027 AI revenue tracks the >$100B guide with all six qualified customers shipping.',
        currentReading: 'Q2 FY26 (Jun 3 2026): 6 qualified XPU customers — Google, Meta, ByteDance, OpenAI, Anthropic, Fujitsu — plus 2 ramping; AI backlog ≈$73B+; FY26 AI ≈$56B; FY27 AI guided >$100B. (The $110B total-backlog and “4+3” figures were Q3 FY25 and are stale.)',
        reading: 'Q2 FY26 (Jun 3 2026): 6 qualified XPU customers — Google, Meta, ByteDance, OpenAI, Anthropic, Fujitsu — plus 2 ramping; AI backlog ≈$73B+; FY26 AI ≈$56B; FY27 AI guided >$100B. (The $110B total-backlog and “4+3” figures were Q3 FY25 and are stale.)',
        lastReviewed: '2026-07-18',
        nextWindow: 'Q3 FY26 earnings 2026-09-02',
        nextWindowDate: '2026-09-02',
        sourceUrl: 'https://investors.broadcom.com/',
        state: 'estimate', src: 'K23', drill: 'sig-3',
        tip: 'Trigger 3 · Broadcom custom silicon — building'
      },
      {
        id: 'sig-4', name: 'Announced GW programs vs energized reality',
        status: 'partial',
        falsification: 'Announced GW-scale programs show no incremental energized capacity for two consecutive quarters at named sites.',
        invalidation: 'Trigger retires if operational capacity at named Stargate sites converges on the announced multi-GW path during 2026.',
        currentReading: 'Stargate: ≈7GW planned and $400B+ claimed versus ≈0.6GW operational at Abilene (Apr 2026 satellite imagery) — announcement-scale figures remain program ceilings, not build-outs. Meta Hyperion/Prometheus and xAI Colossus on announced schedules.',
        reading: 'Stargate: ≈7GW planned and $400B+ claimed versus ≈0.6GW operational at Abilene (Apr 2026 satellite imagery) — announcement-scale figures remain program ceilings, not build-outs. Meta Hyperion/Prometheus and xAI Colossus on announced schedules.',
        lastReviewed: '2026-07-18',
        nextWindow: 'Oracle quarterly earnings (Sep 2026) + rolling satellite re-checks',
        nextWindowDate: '2026-09-15',
        sourceUrl: 'https://www.oracle.com/investor/',
        state: 'estimate', src: 'K5', drill: 'sig-4',
        tip: 'Trigger 4 · GW programs vs reality — building'
      },
      {
        id: 'sig-5', name: 'HBM supply, pricing and lead times',
        status: 'met',
        falsification: 'HBM3E/HBM4 ASPs down >15% or lead times under two quarters.',
        invalidation: 'Trigger retires as failed (constraint relaxed) if any maker reports unbooked HBM4 capacity for 2027.',
        currentReading: 'SK hynix 2026 HBM supply is sold out and customer requests exceed its three-year capacity roadmap; HBM ≈8% (2023) → ≈41% (2027F) of DRAM revenue (estimate framing). The gate is confirmed binding for 2026.',
        reading: 'SK hynix 2026 HBM supply is sold out and customer requests exceed its three-year capacity roadmap; HBM ≈8% (2023) → ≈41% (2027F) of DRAM revenue (estimate framing). The gate is confirmed binding for 2026.',
        lastReviewed: '2026-07-18',
        nextWindow: 'Q3-2026 memory earnings (SK hynix / Samsung / Micron, Oct 2026)',
        nextWindowDate: '2026-10-23',
        sourceUrl: 'https://news.skhynix.com/',
        state: 'estimate', src: 'K15', drill: 'sig-5',
        tip: 'Trigger 5 · HBM gate — confirmed binding'
      },
      {
        id: 'sig-6', name: 'CoWoS capacity and utilization',
        status: 'partial',
        falsification: 'TSMC CoWoS utilization below 85% while capacity still ramps.',
        invalidation: 'Trigger retires as confirmed if the 120–130kwpm end-2026 target lands with utilization ≥ 85%.',
        currentReading: '≈75–80kwpm end-2025 (third-party estimates, vary) ramping toward a 120–130kwpm end-2026 target; “sold out through 2026” (C.C. Wei, AGM Jun 2026). Capacity numbers are third-party — TSMC does not guide kwpm; the sold-out statement is company-made.',
        reading: '≈75–80kwpm end-2025 (third-party estimates, vary) ramping toward a 120–130kwpm end-2026 target; “sold out through 2026” (C.C. Wei, AGM Jun 2026). Capacity numbers are third-party — TSMC does not guide kwpm; the sold-out statement is company-made.',
        lastReviewed: '2026-07-18',
        nextWindow: 'TSMC monthly revenue prints (≈10th monthly, next 2026-08-10) + Q3-2026 call (Oct 2026)',
        nextWindowDate: '2026-08-10',
        sourceUrl: 'https://investor.tsmc.com/english/monthly-revenue',
        state: 'estimate', src: 'K12', drill: 'sig-6',
        tip: 'Trigger 6 · CoWoS gate — building'
      },
      {
        id: 'sig-7', name: 'Custom-silicon share momentum',
        status: 'partial',
        falsification: 'Custom-silicon unit share prints below ≈20% (TrendForce basis) or the Series-A dollar share tracks below 15% into 2027F.',
        invalidation: 'Trigger retires as confirmed if the 2026 ASIC unit share lands at/above the TrendForce 27.8% read with the dollar share (Series A) at ≥16%.',
        currentReading: 'TrendForce: ASIC = 27.8% of 2026 AI-server shipments (units; from 20.9% in 2025), custom-ASIC shipments +44.6% vs GPU +16.1% in 2026. Series-A dollar share: ≈12% (2025E) → ≈16% (2026F). The custom-vs-merchant dollar split inside hyperscalers remains undisclosed (standing gap).',
        reading: 'TrendForce: ASIC = 27.8% of 2026 AI-server shipments (units; from 20.9% in 2025), custom-ASIC shipments +44.6% vs GPU +16.1% in 2026. Series-A dollar share: ≈12% (2025E) → ≈16% (2026F). The custom-vs-merchant dollar split inside hyperscalers remains undisclosed (standing gap).',
        lastReviewed: '2026-07-18',
        nextWindow: 'TrendForce next AI-server shipment update (Q4 2026); Broadcom print 2026-09-02',
        nextWindowDate: '2026-09-02',
        sourceUrl: 'https://www.trendforce.com/',
        state: 'estimate', src: 'K6', drill: 'sig-7',
        tip: 'Trigger 7 · custom share momentum — building'
      },
      {
        id: 'sig-8', name: 'Google TPU program cadence',
        status: 'partial',
        falsification: 'TPU 8t/8i GA slips into 2027, or Anthropic’s contracted GW-scale TPU capacity fails to come online in 2026.',
        invalidation: 'Trigger retires as confirmed if TPU 8t/8i reach GA in 2026 with Anthropic’s >1GW TPU capacity online.',
        currentReading: 'TPU 8t/8i unveiled 2026-04-22 (Cloud Next), GA later in 2026 (estimate). Ironwood (TPU v7) GA late 2025: 9,216-chip pods, 42.5 EF FP8. Anthropic: up to 1M TPUs with >1GW of TPU capacity coming online in 2026 (Oct 2025 announcement).',
        reading: 'TPU 8t/8i unveiled 2026-04-22 (Cloud Next), GA later in 2026 (estimate). Ironwood (TPU v7) GA late 2025: 9,216-chip pods, 42.5 EF FP8. Anthropic: up to 1M TPUs with >1GW of TPU capacity coming online in 2026 (Oct 2025 announcement).',
        lastReviewed: '2026-07-18',
        nextWindow: 'Alphabet Q2-2026 earnings 2026-07-28; TPU 8t/8i GA (H2 2026)',
        nextWindowDate: '2026-07-28',
        sourceUrl: 'https://cloud.google.com/blog/products/compute/tpu-8t-and-tpu-8i-technical-deep-dive',
        state: 'estimate', src: 'K28', drill: 'sig-8',
        tip: 'Trigger 8 · TPU cadence — building'
      }
    ]
  };

  /* ------------------------------------------------------------------ *
   * companyDeepDives — six companies on the supply chain’s toll roads
   * (#invest-chart, expandable HTML table, spec §14).
   * Columns: company · what it is in this chain · customers · key risk.
   * Expanded row: customers · project stage · revenue model · moat ·
   * key risk · room to grow.
   * ------------------------------------------------------------------ */
  D.companyDeepDives = [
    {
      id: 'avgo', name: 'Broadcom', ticker: 'AVGO',
      whatItIs: 'Toll road #1: the custom-silicon design house of record — XPU co-design programs plus the networking franchise (Tomahawk/Jericho).',
      customers: ['Google (TPU partner since v1)', 'Meta', 'ByteDance', 'OpenAI', 'Anthropic', 'Fujitsu', '+ 2 ramping'],
      projectStage: 'Six qualified XPU customers plus two ramping (Q2 FY26, Jun 3 2026); FY27 AI guided >$100B.',
      revenueModel: 'NRE + per-unit silicon + SerDes IP content; AI revenue ≈$56B guided FY2026 with ≈$73B+ AI backlog; FY27 AI >$100B guided.',
      moat: 'Thirty years of ASIC methodology, the deepest SerDes IP library outside a foundry, and co-design lock-in with Google since 2015.',
      keyRisk: 'Customer concentration: Google is the first and largest XPU customer — revenue share undisclosed — a single-program company wearing a portfolio’s clothes.',
      roomToGrow: 'Every engaged prospect that converts is an incremental multi-GW program; the pipeline is the valuation.',
      state: 'estimate', src: 'K23', drill: 'dd-avgo',
      tip: 'Broadcom · AVGO · custom XPU champion'
    },
    {
      id: 'mrvl', name: 'Marvell', ticker: 'MRVL',
      whatItIs: 'Toll road #2: the second custom-silicon house — cloud XPUs plus the optical DSP franchise (Inphi, 2020).',
      customers: ['Amazon (Trainium line)', 'Microsoft (Maia line)', 'Google (programs)', 'optical: all hyperscalers'],
      projectStage: 'Two XPU programs in production, next-generation designs taped out; optical DSP shipping at 800G, 1.6T ramping.',
      revenueModel: 'NRE + per-unit custom silicon + merchant optical DSPs; custom silicon is the growth line, optical the annuity.',
      moat: 'The Inphi optical DSP franchise plus turnkey custom-silicon execution at 5nm/3nm — the only scaled alternative to Broadcom.',
      keyRisk: 'Program timing: a single XPU slip moves a full year of revenue; priced as if every tape-out lands.',
      roomToGrow: '1.6T optical cycle plus third and fourth XPU programs; company-stated custom-XPU TAM $40.8B by 2028 (Jun 2025 — company claim).',
      state: 'estimate', src: null, drill: 'dd-mrvl',
      tip: 'Marvell · MRVL · custom silicon #2 + optical DSP'
    },
    {
      id: 'mediatek', name: 'MediaTek', ticker: '2454.TW',
      whatItIs: 'The SoC house turned ASIC partner — reported co-design role on Google’s inference-class TPU variants.',
      customers: ['Google (TPU inference variants, reported)', 'merchant SoC base (phones, edge, auto)'],
      projectStage: 'First hyperscale ASIC programs in ramp; merchant SoC franchise funds the learning curve.',
      revenueModel: 'Merchant SoC royalties-scale volume + ASIC NRE and per-unit economics on the custom programs.',
      moat: 'Twenty years of shipping billions of SoCs: power management, SerDes integration, and cost discipline at consumer margins.',
      keyRisk: 'Newcomer pricing: wins the second source by undercutting, so program margins start thin.',
      roomToGrow: 'If the TPU partnership extends across v8-class variants, MediaTek becomes the default second design house for inference XPUs.',
      state: 'estimate', src: null, drill: 'dd-mediatek',
      tip: 'MediaTek · 2454.TW · the SoC house goes custom'
    },
    {
      id: 'guc', name: 'GUC', ticker: '3443.TW',
      whatItIs: 'TSMC’s aligned design-service arm — the front door for custom silicon that wants TSMC’s leading edge.',
      customers: ['hyperscalers (via TSMC alignment)', 'networking and AI program houses'],
      projectStage: 'AI and networking NRE ladder 2020–2024; revenue ≈NT$24.9B (2024) after the mining fade.',
      revenueModel: 'NRE fees + wafer/turnkey margin through TSMC; NRE leads revenue by 1–2 years — the sawtooth is the model.',
      moat: 'Privileged TSMC process access and CoWoS allocation adjacency — the structural seat at the gate.',
      keyRisk: 'NRE cyclicality: 2018–2019 showed the sawtooth; a program gap cuts revenue before it cuts backlog.',
      roomToGrow: 'Every new XPU program that needs TSMC starts at a design-service door; GUC’s is the closest.',
      state: 'derived', src: 'K27', drill: 'dd-guc',
      tip: 'GUC · 3443.TW · the TSMC-aligned design arm'
    },
    {
      id: 'alchip', name: 'Alchip', ticker: '3661.TW',
      whatItIs: 'The pure-play ASIC design house — survivor of the 2018–2019 crypto sawtooth, now an AI-program specialist.',
      customers: ['AWS (Trainium line, reported)', 'US and China AI program houses'],
      projectStage: 'Multiple 3nm/5nm AI programs in production; revenue rebuilt after the 2019 trough (NT$0.62B quarter).',
      revenueModel: 'NRE + turnkey production margin; concentration in a handful of large AI programs.',
      moat: 'Leading-edge ASIC execution that survived two clearings — the resume is the moat.',
      keyRisk: 'Customer concentration squared: one hyperscaler program is the growth line; crypto history shows the drawdown shape.',
      roomToGrow: 'Second and third hyperscaler programs would re-rate the name from sawtooth survivor to platform.',
      state: 'estimate', src: 'K37', drill: 'dd-alchip',
      tip: 'Alchip · 3661.TW · the sawtooth survivor'
    },
    {
      id: 'verisilicon', name: 'VeriSilicon', ticker: '688521.SH',
      whatItIs: 'China-facing design service and IP licensing — the custom-silicon toll road inside the policy partition.',
      customers: ['China AI and consumer silicon programs', 'IP licensees worldwide'],
      projectStage: 'Design-service and IP-royalty model; China AI programs ramping under export-control constraints.',
      revenueModel: 'NRE + IP licensing royalties (GPU/NPU IP cores) + turnkey production services.',
      moat: 'The IP catalog plus the local design-service bench — the default partner inside the China sphere.',
      keyRisk: 'The partition itself: export controls can strand process access and customer roadmaps in a single rule change.',
      roomToGrow: 'If the China sphere builds its own inference fleet, VeriSilicon is the local Broadcom-shaped door.',
      state: 'estimate', src: null, drill: 'dd-verisilicon',
      tip: 'VeriSilicon · 688521.SH · inside the partition'
    }
  ];

  /* ------------------------------------------------------------------ *
   * nowWave — the second in-house wave (#sec-now, deepdive/now charts).
   * Four announced in-house parts with specs; measurement discipline:
   * unit / CoWoS-allocation / dollar bases presented side by side.
   * ------------------------------------------------------------------ */
  D.nowWave = {
    meta: {
      note: 'The second in-house wave: every hyperscaler now fields its own inference silicon.',
      drill: 'now-wave'
    },
    chips: [
      {
        name: 'Ironwood (TPU v7)', maker: 'Google', year: 2025,
        process: '3nm-class', hbm: 'HBM3E · 192GB-class',
        perf: '4,614 TFLOPS FP8 per chip · 9,216 chips/pod · 42.5 EFLOPS',
        status: 'GA late 2025, ramping 2026', state: 'actual', src: null, drill: 'ironwood',
        tip: 'Google Ironwood · 2025 · 42.5 EFLOPS/pod FP8'
      },
      {
        name: 'Trainium 3', maker: 'AWS', year: 2025,
        process: '3nm — AWS’s first 3nm AI chip', hbm: 'HBM3E-class',
        perf: '≈2.4× Trainium 2 (company framing)',
        status: 'announced Dec 2025', state: 'estimate', src: null, drill: 'trainium3',
        tip: 'AWS Trainium 3 · 2025 · first 3nm in-house part'
      },
      {
        name: 'Maia 200', maker: 'Microsoft', year: 2025,
        process: '3nm-class', hbm: 'HBM3E-class',
        perf: 'second-generation in-house inference part',
        status: 'in fab / ramp', state: 'estimate', src: null, drill: 'maia200',
        tip: 'Microsoft Maia 200 · 2025 · second-gen in-house'
      },
      {
        name: 'MTIA v3', maker: 'Meta', year: 2026,
        process: 'advanced-node (undisclosed)', hbm: 'HBM-class',
        perf: 'next-generation ranking & inference part',
        status: 'program disclosed via supply chain', state: 'estimate', src: null, drill: 'mtia3',
        tip: 'Meta MTIA v3 · 2026E · third-generation MTIA'
      }
    ]
  };

  /* ------------------------------------------------------------------ *
   * crossoverData — the 2027 crossover claim, stress-tested
   * (#sec-crossover). The 50% unit line requires ≈8.0–8.4M TPU-class
   * units; the published estimate range spans 6.5M–15M; the verdict
   * stays unadjudicable.
   * ------------------------------------------------------------------ */
  D.crossoverData = {
    meta: {
      unit: 'M units', fmt: 'ratio',
      basis: 'accelerator unit shipments, 2027F',
      note: 'The 50% crossover line, stress-tested. The estimate range straddles the requirement — the claim cannot be adjudicated.',
      drill: 'crossover-verdict'
    },
    required: { low: 8.0, high: 8.4, mid: 8.2, state: 'estimate', src: 'K33', drill: 'crossover-req', tip: '50% unit share ⇒ ≈8.0–8.4M TPU-class units required in 2027F' },
    estimates: {
      low: 6.5, high: 15.0, mid: 10.75,
      state: 'estimate', src: 'K31', drill: 'crossover-range',
      tip: 'Published 2026 TPU-class unit estimates: 6.5M–15M — ±40% around the requirement',
      sources: ['broker teardowns', 'supply-chain tallies', 'company-adjacent reporting']
    },
    gpuBaseline: { value: 8.2, state: 'estimate', src: 'K33', drill: 'crossover-req', tip: 'Merchant GPU unit baseline 2027F ≈8M-class' },
    verdict: {
      text: 'UNADJUDICABLE',
      state: 'gap', src: 'K35', drill: 'crossover-verdict',
      note: 'The range straddles the line. No disclosed evidence closes it; the crossover claim is neither confirmed nor refuted — it is unadjudicable on the record.'
    }
  };

  /* ------------------------------------------------------------------ *
   * sources — the K1–K41 evidence register (#sec-sources, spec §11).
   * sourceClass: 'kimi' | 'broker' | 'company' | 'industry'
   * state: 'derived' | 'estimate' | 'gap'
   * Badge colors (spec §11): kimi blue · broker copper · company green ·
   * industry violet.
   * ------------------------------------------------------------------ */
  /* ------------------------------------------------------------------ *
   * sources — the K1–K41 evidence register (#sec-sources, spec §11).
   * Canonical topic map (V2): K1–K5 scenarios & capex · K6–K9 penetration
   * bases & TAM · K10 merchant benchmark · K11–K12 CoWoS · K13–K16 HBM ·
   * K17–K18 the 2001 record · K19–K22 TPU units & per-GW economics ·
   * K23–K25 custom vendors · K26 power · K27–K28 merchant-adjacent ·
   * K29–K30 stress paths · K31–K35 crossover stress test · K36–K38 the
   * mining mirror · K39–K41 the platform-opening questions.
   * sourceClass: 'kimi' | 'broker' | 'company' | 'industry'
   * state: 'derived' | 'estimate' | 'gap'
   * ------------------------------------------------------------------ */
  D.sources = [
    /* Canonical topic map (kept): K1–K5 scenarios & capex · K6–K9 penetration bases
       & TAM · K10 merchant benchmark · K11–K12 CoWoS · K13–K16 HBM · K17–K18 the
       2001 record · K19–K22 TPU units & per-GW economics · K23–K25 custom vendors
       · K26 power · K27–K28 merchant-adjacent · K29–K30 stress paths · K31–K35
       crossover stress test · K36–K38 mining mirror · K39–K41 platform-opening
       questions. Rows whose source cannot be publicly linked name the institution
       and say "access limited"; numbers with no identifiable source are labeled
       unsupported working assumptions. All rows lastVerified 2026-07-18. */

    { key: 'K1', factName: 'Base-case custom-silicon revenue multiple',
      value: '≈2.5× over three years (2025→2028) · range 2.0–4.7×',
      sourceClass: 'kimi', citation: 'This report — rebuilt scenario arithmetic (Option A: accelerator spending × custom dollar share)', date: '2026-07-18', state: 'derived',
      unit: '×', classification: 'scenario',
      scope: 'global custom-silicon accelerator revenue', period: '2025 → 2028',
      institution: 'this report', title: 'Option-A scenario model (compatible denominators)', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: '(500/330) × (0.20/0.12) = 1.515 × 1.667 ≈ 2.5',
      notes: 'Inputs: $330B 2025 accelerator spending (derived working assumption — see DATA.scenarios.model.spendBaseDerivation); $500B 2028 accelerator TAM (AMD-stated company claim, Oct 2024/Jun 2025); custom dollar share 12% (2025E broker estimate) → 20% (scenario assumption). Replaces the withdrawn 3.0–4.3× chain, which multiplied total capex by an accelerator-dollar share — incompatible denominators.' },

    { key: 'K2', factName: 'Conservative-case multiple',
      value: '≈2.0× over three years · band 1.9–2.1×',
      sourceClass: 'kimi', citation: 'This report — scenario arithmetic (TAM path met, share stalls at the 2026F read)', date: '2026-07-18', state: 'derived',
      unit: '×', classification: 'scenario',
      scope: 'global custom-silicon accelerator revenue', period: '2025 → 2028',
      institution: 'this report', title: 'Option-A conservative case', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: '(500/330) × (0.16/0.12) ≈ 2.02 (band for 15–17% 2028 share: 1.89–2.15)',
      notes: 'Same accelerator-spend growth as the base case (1.52×); the custom dollar share stalls at ≈16% instead of reaching 20%.' },

    { key: 'K3', factName: 'Contraction-case multiple',
      value: '−15% to −35% over three years',
      sourceClass: 'kimi', citation: 'This report — scenario arithmetic (mean-reversion replay)', date: '2026-07-18', state: 'derived',
      unit: '×', classification: 'scenario',
      scope: 'global custom-silicon accelerator revenue', period: '2025 → 2028',
      institution: 'this report', title: 'Option-A contraction case', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: '(304/330) × (0.095/0.12) = 0.92 × 0.79 ≈ 0.73',
      notes: 'Accelerator spending mean-reverts ≈8% and the custom share drifts to ≈9.5% — the same-case replay of the 2001 clearing.' },

    { key: 'K4', factName: 'Kill switch',
      value: 'Top-4 2027E capex growth prints below +14% → base case void on contact',
      sourceClass: 'kimi', citation: 'This report — falsification design; threshold sits below every third-party 2027 tally in K30', date: '2026-07-18', state: 'derived',
      unit: '% YoY', classification: 'scenario',
      scope: 'Top-4 hyperscaler capex (Amazon, Alphabet, Meta, Microsoft)', period: 'CY2027E',
      institution: 'this report', title: 'kill-switch trigger', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'Checked at each quarterly guidance print; next windows 2026-07-28 → 2026-07-30 (Alphabet, Microsoft, Meta, Amazon).' },

    { key: 'K5', factName: 'Top-4 hyperscaler capex',
      value: '≈$410–413B (2025, compiled estimate) · $695–725B guided (2026E)',
      sourceClass: 'company', citation: 'Company guidance, Q1-2026 earnings (Apr 29–30 2026): Amazon ≈$200B + Microsoft ≈$190B (explicitly CY2026) + Alphabet $180–190B + Meta $125–145B', date: '2026-04-30', state: 'estimate',
      unit: 'US$B', classification: 'guidance',
      scope: 'Amazon, Alphabet, Meta, Microsoft (Top-4)', period: 'CY2025 (estimated) · CY2026 (guidance)',
      institution: 'Amazon / Microsoft / Alphabet / Meta (company guidance)', title: 'Q1-2026 earnings guidance', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: '2026: 200 + 190 + 185 + 135 = 710 midpoint (low 695, high 725)',
      notes: '2025 has no single reported aggregate: FT tally ≈$410B; per-company sum ≈$413.3B; the $412.9B figure is a compiled estimate, not verified. Alphabet/Amazon/Meta are calendar-year; Microsoft’s ≈$190B is explicitly calendar-2026.' },

    { key: 'K6', factName: 'Custom share of accelerator units',
      value: 'broker tallies ≈30% of 2024 units, claimed ≈50% of 2027F units; TrendForce (server basis): ASIC = 27.8% of 2026 AI-server shipments (units; 20.9% in 2025), custom-ASIC shipments +44.6% vs GPU +16.1% in 2026',
      sourceClass: 'broker', citation: 'Broker teardown tallies (access limited); TrendForce AI-server shipment tallies', date: '2026-06', state: 'estimate',
      unit: '% of units', classification: 'estimate',
      scope: 'global AI accelerators (chip basis) · global AI servers (TrendForce basis — different denominator)', period: '2024–2027F',
      institution: 'TrendForce · broker teardown tallies', title: 'AI-server / accelerator unit-share tallies', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'Two different unit denominators — accelerator chips (broker) vs AI servers (TrendForce) — are cross-checks, not the same series. Unit bases are ineligible for scenario multiplication.' },

    { key: 'K7', factName: 'Custom share of booked CoWoS',
      value: '≈25% of 2025 booked slots, rising toward ≈34% by 2027F',
      sourceClass: 'broker', citation: 'Supply-chain CoWoS booking tallies (access limited)', date: '2026-06', state: 'estimate',
      unit: '% of slots', classification: 'estimate',
      scope: 'TSMC CoWoS advanced-packaging bookings', period: '2024–2027F',
      institution: 'supply-chain tallies (institution-level, access limited)', title: 'CoWoS allocation tallies', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'Booked capacity ≠ demand ≠ dollars; allocation share is a capacity-basis read.' },

    { key: 'K8', factName: 'Custom-silicon dollar share — two distinct series, never conflated',
      value: 'Series A (global accelerator-dollar share): ≈8% (2024) → ≈12% (2025E) → ≈16% (2026F) → ≈20% (2027F) · Series B (TSMC AI-revenue attribution, third-party, NOT TSMC-disclosed): 8/12/20/28/34% (2023–2027)',
      sourceClass: 'broker', citation: 'Compiled broker accelerator-spending tallies (Series A); third-party TSMC-revenue attribution models (Series B) — both access limited', date: '2026-06', state: 'estimate',
      unit: '% of dollars', classification: 'estimate',
      scope: 'Series A: global accelerator-dollar spending · Series B: TSMC AI-accelerator revenue attribution', period: '2023–2027F',
      institution: 'compiled broker tallies · third-party attribution models (NOT TSMC)', title: 'custom-silicon dollar share, two bases', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'Series A is the only series eligible for scenario multiplication. TSMC does NOT publish a GPU-vs-ASIC split (analysts declined); every 66/34-style foundry split is a third-party attribution estimate. Official TSMC framing: AI-accelerator revenue = high-teens % of total 2025 revenue, roughly doubled in 2025, CAGR mid-to-high-50s % 2024–2029; HPC = 66% of Q2-2026 revenue (2026-07-16).' },

    { key: 'K9', factName: 'Custom-ASIC serviceable TAM',
      value: '"$60 billion to $90 billion in fiscal 2027" (Hock Tan, verbatim, Q4 FY24 call) — AI SAM from then-3 hyperscale customers; 6 qualified customers by Q2 FY26',
      sourceClass: 'company', citation: 'Broadcom Q4 FY2024 earnings call (2024-12-12), CEO Hock Tan', date: '2024-12-12', state: 'estimate',
      unit: 'US$B', classification: 'guidance',
      scope: 'Broadcom AI serviceable addressable market (XPU + networking)', period: 'FY2027',
      institution: 'Broadcom', title: 'Q4 FY2024 earnings call', author: 'Hock Tan (President & CEO)',
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'Company-framed SAM, not a market size. Tan later noted additional engaged customers; by Q2 FY26 Broadcom reported 6 qualified XPU customers (see K23). Transcript via Broadcom IR (access limited).' },

    { key: 'K10', factName: 'NVIDIA data-center revenue run',
      value: '$4.28B (Q1 FY2024, quarter ended 2023-04-30) → $75.2B (Q1 FY2027, quarter ended 2026-04-26) · 17.57× over 12 quarter-intervals = 13 quarterly observations',
      sourceClass: 'company', citation: 'NVIDIA Q1 FY2024 results (SEC 8-K Ex-99.1, 2023-05-24) · NVIDIA Q1 FY2027 results (2026-05)', date: '2026-05-27', state: 'derived',
      unit: 'US$B/quarter', classification: 'reported',
      scope: 'NVIDIA data-center segment revenue', period: 'Q1 FY2024 → Q1 FY2027',
      institution: 'NVIDIA', title: 'Q1 FY2024 / Q1 FY2027 quarterly results', author: null,
      url: 'https://nvidianews.nvidia.com/news/nvidia-announces-financial-results-for-first-quarter-fiscal-2027', page: null,
      lastVerified: '2026-07-18', formula: '75.2 / 4.28 = 17.57× across 12 quarter-intervals (13 observations)',
      notes: 'Q1 FY2024 filing: https://www.sec.gov/Archives/edgar/data/1045810/000104581023000087/q1fy24pr.htm. Q1 FY2027 detail: DC +92% YoY; compute $60.4B, networking $14.8B; total revenue $81.6B; Q2 FY27 guided $91.0B ± 2%. Label as “12 intervals, 13 observations, Q1 FY2024→Q1 FY2027” — never “thirteen quarters”.' },

    { key: 'K11', factName: 'CoWoS demand',
      value: 'demand ≈2× installed capacity through 2025; sold out through 2026 (C.C. Wei, AGM Jun 2026)',
      sourceClass: 'broker', citation: 'TSMC/advanced-packaging supply-chain checks (access limited); sold-out statement is company-made (TSMC AGM, Jun 2026)', date: '2026-06', state: 'estimate',
      unit: 'ratio', classification: 'estimate',
      scope: 'TSMC CoWoS advanced packaging', period: '2025–2026',
      institution: 'supply-chain checks · TSMC (AGM statement)', title: 'CoWoS demand vs capacity', author: 'C.C. Wei (TSMC Chairman, AGM quote)',
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'The 2× demand ratio is a supply-chain estimate; “sold out through 2026” is a company statement (AGM, Jun 2026).' },

    { key: 'K12', factName: 'CoWoS capacity path',
      value: '≈12kwpm (2022) → ≈38kwpm (2024) → ≈75–80kwpm end-2025 → 120–130kwpm target end-2026',
      sourceClass: 'broker', citation: 'Third-party capacity tallies (access limited); estimates vary — TSMC does not guide kwpm', date: '2026-06', state: 'estimate',
      unit: 'kwpm', classification: 'estimate',
      scope: 'TSMC CoWoS installed capacity', period: '2022–2026E',
      institution: 'third-party capacity tallies (institution-level, access limited)', title: 'CoWoS capacity tallies', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'End-2026 120–130kwpm is a third-party target range, not TSMC guidance. Historical points are compiled estimates.' },

    { key: 'K13', factName: 'HBM stacked-die capacity',
      value: '≈170kwpm (2023) → ≈460kwpm (2026E), all three makers combined',
      sourceClass: 'broker', citation: 'Memory supply-chain capacity tallies (access limited)', date: '2026-06', state: 'estimate',
      unit: 'kwpm', classification: 'estimate',
      scope: 'SK hynix + Samsung + Micron HBM TSV capacity', period: '2023–2026E',
      institution: 'memory supply-chain tallies (access limited)', title: 'HBM capacity tallies', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'Yield loss at the TSV/stack step is what makes HBM scarce — capacity alone overstates output.' },

    { key: 'K14', factName: 'HBM supply gap',
      value: 'SK hynix 2026 HBM sold out; customer requests exceed its three-year capacity roadmap',
      sourceClass: 'company', citation: 'SK hynix company statements; memory supply-chain checks (access limited)', date: '2026-06', state: 'estimate',
      unit: 'text', classification: 'reported',
      scope: 'HBM supply vs booked demand', period: '2025–2026',
      institution: 'SK hynix (company statements)', title: 'HBM sell-out and capacity-roadmap statements', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: '“Sold out” and “requests exceed three-year capacity” are company statements; the broader pre-booking picture is supply-chain reporting.' },

    { key: 'K15', factName: 'HBM pricing',
      value: '≈5–6× conventional DRAM per bit',
      sourceClass: 'broker', citation: 'Memory pricing tallies (access limited)', date: '2026-06', state: 'estimate',
      unit: '×', classification: 'estimate',
      scope: 'HBM vs conventional DRAM ASP per bit', period: '2025–2026',
      institution: 'memory pricing tallies (access limited)', title: 'HBM/DRAM price ratio', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'Ratio compresses as HBM supply normalizes; watch ASP prints at memory earnings.' },

    { key: 'K16', factName: 'HBM share of DRAM revenue',
      value: '≈8% (2023) → ≈41% (2027F) of DRAM revenue, on a fraction of the bits',
      sourceClass: 'broker', citation: 'Memory revenue tallies (access limited)', date: '2026-06', state: 'estimate',
      unit: '% of revenue', classification: 'estimate',
      scope: 'DRAM industry revenue mix', period: '2023–2027F',
      institution: 'memory revenue tallies (access limited)', title: 'HBM revenue share', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'Estimate framing retained — the 2027F share is a forecast, and bit-share remains far below revenue share.' },

    { key: 'K17', factName: 'The 2001 bust',
      value: 'Xilinx −39%, Altera −39%, industry ≈−32% (2001); Xilinx FY2003 revenue back at FY2001 level two years later',
      sourceClass: 'kimi', citation: 'Xilinx/Altera 10-K filings; WSTS industry tallies', date: '2002', state: 'derived',
      unit: '% YoY', classification: 'derived',
      scope: 'FPGA duopoly + global semiconductor revenue', period: '2000–2003',
      institution: 'Xilinx / Altera (SEC filings) · WSTS', title: 'FY2001–FY2003 annual filings', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: 'Xilinx $1,659M → $1,014M = −38.9%',
      notes: 'The telecom-cycle anchor for the clearing mechanics: two halvings, then recovery — the mirror the AI cycle is tested against.' },

    { key: 'K18', factName: 'Telecom clearing precedent',
      value: 'demand halved, everyone lived — the telecom bubble cleared through consolidation, not mass bankruptcy',
      sourceClass: 'industry', citation: 'Industry record (vendor filings, 2000–2003)', date: '2003', state: 'derived',
      unit: 'text', classification: 'derived',
      scope: 'optical/telecom equipment vendors', period: '2000–2003',
      institution: 'public record', title: 'telecom-equipment clearing', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'The mechanism precedent for the AI clearing analog; “not mass bankruptcy” refers to that window’s majors (Nortel’s collapse came later, 2009).' },

    { key: 'K19', factName: 'TPU unit estimates',
      value: 'broad range — estimates diverge ≈2× on 2026–27 TPU volumes',
      sourceClass: 'broker', citation: 'Broker unit tallies (access limited)', date: '2026-06', state: 'estimate',
      unit: 'M units', classification: 'estimate',
      scope: 'Google TPU production volumes', period: '2025–2027F',
      institution: 'broker unit tallies (access limited)', title: 'TPU volume estimates', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'Google does not disclose TPU units; the range itself is the fact (see K31).' },

    { key: 'K20', factName: 'Trainium 2 ramp',
      value: '1.4M chips in 12 months, ≈10× quarter-over-quarter',
      sourceClass: 'company', citation: 'AWS re:Invent 2024 keynote (2024-12)', date: '2024-12-03', state: 'derived',
      unit: 'M units', classification: 'reported',
      scope: 'AWS Trainium 2 deployment', period: 'CY2024',
      institution: 'Amazon Web Services', title: 're:Invent 2024 keynote', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'Company-stated ramp figures.' },
    { key: 'K21', factName: 'TSMC revenue per gigawatt',
      value: '≈$2.1B of TSMC revenue per GW of AI compute',
      sourceClass: 'kimi', citation: 'Derived from die sizes, package counts, and wafer/CoWoS pricing tallies', date: '2026-06', state: 'derived',
      unit: 'US$B/GW', classification: 'derived',
      scope: 'TSMC content in 1GW-class AI deployments', period: '2025–2026',
      institution: 'this report', title: 'per-GW TSMC content derivation', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: '≈$3.5k logic + CoWoS + interposer per package × ≈600k packages per GW ≈ $2.1B',
      notes: 'Order-of-magnitude derivation; sensitive to package count and pricing assumptions.' },

    { key: 'K22', factName: 'Cost per token',
      value: '≈10× per-year decline on the frontier — Jevons arithmetic does the rest',
      sourceClass: 'industry', citation: 'Public inference pricing pages, compiled', date: '2026-06', state: 'estimate',
      unit: '×/yr', classification: 'estimate',
      scope: 'frontier-model inference pricing', period: '2023–2026',
      institution: 'public API pricing pages (compiled)', title: 'inference price-per-token tallies', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'Mix-shift and model-generation effects dominate; treat as an order-of-magnitude.' },

    { key: 'K23', factName: 'Broadcom XPU franchise',
      value: 'Q2 FY26 (Jun 3 2026): 6 qualified XPU customers (Google, Meta, ByteDance, OpenAI, Anthropic, Fujitsu) + 2 ramping · AI backlog ≈$73B+ · FY26 AI ≈$56B · FY27 AI >$100B (guidance) · next earnings 2026-09-02',
      sourceClass: 'company', citation: 'Broadcom Q2 FY2026 results (2026-06-03)', date: '2026-06-03', state: 'derived',
      unit: 'text', classification: 'reported',
      scope: 'Broadcom AI / XPU segment', period: 'Q2 FY2026 (quarter ended May 2026)',
      institution: 'Broadcom', title: 'Q2 FY2026 earnings', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'STALE — do not cite: the $110B total backlog and “4+3” customer framing are Q3 FY25 figures. Current: 6 qualified + 2 ramping, AI backlog ≈$73B+, FY27 AI guided >$100B. FY27 figure is guidance; the rest reported.' },

    { key: 'K24', factName: 'Broadcom custom share',
      value: '≈70% of the custom-ASIC merchant market',
      sourceClass: 'broker', citation: 'Broker share tallies (access limited)', date: '2026-06', state: 'estimate',
      unit: '%', classification: 'estimate',
      scope: 'merchant custom-ASIC design-win revenue', period: '2025–2026',
      institution: 'broker share tallies (access limited)', title: 'custom-ASIC market share', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'Share of the merchant custom market, not of all custom silicon (in-house programs excluded).' },

    { key: 'K25', factName: 'Marvell custom programs',
      value: 'custom XPU programs at two hyperscalers carry the data-center ramp; company-stated custom-XPU TAM $40.8B by 2028 (Jun 2025)',
      sourceClass: 'company', citation: 'Marvell investor communications (custom-XPU TAM, Jun 2025); broker program tallies (access limited)', date: '2025-06', state: 'estimate',
      unit: 'text', classification: 'guidance',
      scope: 'Marvell custom-silicon franchise', period: '2025–2028',
      institution: 'Marvell', title: 'custom-XPU TAM framing (company claim)', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'The $40.8B-by-2028 TAM is a company claim, not a consensus forecast; program-count detail is broker tallies (access limited).' },

    { key: 'K26', factName: 'IEA data-centre electricity',
      value: '415TWh (2024) → 945TWh (2030, Base Case)',
      sourceClass: 'industry', citation: 'IEA, Energy and AI — Energy demand from AI (2025-04-10)', date: '2025-04-10', state: 'derived',
      unit: 'TWh', classification: 'reported',
      scope: 'global data-centre electricity consumption', period: '2024 actual → 2030 Base Case',
      institution: 'International Energy Agency', title: 'Energy and AI — Energy demand from AI', author: 'IEA (Fatih Birol, Executive Director)',
      url: 'https://www.iea.org/reports/energy-and-ai/energy-demand-from-ai', page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'The 2024 value is the IEA’s estimated actual; 945TWh is the Base Case projection for 2030 (not the high-AI sensitivity).' },

    { key: 'K27', factName: 'GUC revenue',
      value: 'NT$19.5B (2019) → NT$38.3B (2024) — the ASIC tide in one line',
      sourceClass: 'company', citation: 'GUC (3443.TW) annual reports', date: '2025-03', state: 'derived',
      unit: 'NT$B', classification: 'reported',
      scope: 'GUC annual revenue', period: '2019–2024',
      institution: 'Global Unichip Corp.', title: 'annual reports 2019–2024', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'The merchant-ASIC tide visible in a single design house’s revenue line.' },

    { key: 'K28', factName: 'TPU v8 (8t/8i) unveiling',
      value: 'TPU 8t/8i unveiled 2026-04-22 (Cloud Next); GA later in 2026 (estimate) · ≈9 PFLOPS FP4-class per chip — estimate, widest precision caveat of all',
      sourceClass: 'company', citation: 'Google Cloud, TPU 8t and TPU 8i technical deep dive (2026-04-22)', date: '2026-04-22', state: 'estimate',
      unit: 'TFLOPS', classification: 'estimate',
      scope: 'Google TPU v8 generation', period: '2026',
      institution: 'Google Cloud', title: 'TPU 8t and TPU 8i technical deep dive', author: null,
      url: 'https://cloud.google.com/blog/products/compute/tpu-8t-and-tpu-8i-technical-deep-dive', page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'The unveiling and GA window are company-stated; the per-chip ≈9 PFLOPS FP4-class figure is an unsupported working assumption pending GA specifications.' },

    { key: 'K29', factName: 'Top-4 capex/OCF ratio',
      value: '0.45–0.56 (2021–24, reported) → 0.80 (2025, estimate) → 1.21 midpoint, range 1.18–1.24 (2026E)',
      sourceClass: 'kimi', citation: 'Derived: capex guidance (K5) ÷ operating cash flow; OCF 2026E ≈$587B is a working estimate — no public consensus aggregate', date: '2026-07-18', state: 'estimate',
      unit: 'ratio', classification: 'derived',
      scope: 'Top-4 hyperscalers (Amazon, Alphabet, Meta, Microsoft; calendar-year basis, Microsoft calendarized)', period: '2021–2026E',
      institution: 'this report (ratio math on company figures)', title: 'capex/OCF stress ratio', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: '710/587 = 1.2095 ≈ 1.21 · 695/587 = 1.184 ≈ 1.18 · 725/587 = 1.235 ≈ 1.24',
      notes: '2026E capex $695–725B is company guidance; 2026E OCF ≈$587B is a working estimate — no public consensus aggregate exists. Above 1.0, projected capex exceeds projected OCF for the cohort: increased dependence on balance-sheet liquidity, external financing, or reduced other cash uses. It does not by itself prove every marginal dollar is financed rather than earned.' },

    { key: 'K30', factName: 'Third-party 2027 capex estimates',
      value: '$520B · $568B · $591B — three tallies, all above +14%',
      sourceClass: 'broker', citation: 'Broker 2027 capex models (access limited)', date: '2026-06', state: 'estimate',
      unit: 'US$B', classification: 'estimate',
      scope: 'Top-4 hyperscaler capex', period: 'CY2027F',
      institution: 'broker capex models (access limited)', title: '2027 capex tallies', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'The kill-switch threshold (+14%) sits below every third-party tally — deliberately.' },

    { key: 'K31', factName: 'TPU unit estimate range',
      value: '6.5M → 15M units (2025 → 2027F); broker range, divergence ≈2×',
      sourceClass: 'broker', citation: 'Broker unit tallies (access limited)', date: '2026-06', state: 'estimate',
      unit: 'M units', classification: 'estimate',
      scope: 'Google TPU production volumes', period: '2025–2027F',
      institution: 'broker unit tallies (access limited)', title: 'TPU unit estimate range', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'The stress test uses the range, not a point (see K33/K35).' },

    { key: 'K32', factName: 'Anthropic TPU capacity',
      value: 'up to ≈1M TPUs; >1GW of TPU capacity coming online 2026',
      sourceClass: 'company', citation: 'Anthropic, Expanding our use of Google Cloud TPUs and services (Oct 2025)', date: '2025-10', state: 'derived',
      unit: 'text', classification: 'reported',
      scope: 'Anthropic compute commitment on Google TPUs', period: 'announced Oct 2025; capacity online 2026',
      institution: 'Anthropic', title: 'Expanding our use of Google Cloud TPUs and services', author: null,
      url: 'https://www.anthropic.com/news/expanding-our-use-of-google-cloud-tpus-and-services', page: null, lastVerified: '2026-07-18', formula: null,
      notes: '“Up to one million TPUs” and “well over a gigawatt of capacity coming online in 2026” are the announced figures.' },

    { key: 'K33', factName: 'Crossover requirement',
      value: 'units needed for a dollar crossover: ≈7.2M → 8.0–8.4M (2026–2027F)',
      sourceClass: 'broker', citation: 'This report arithmetic on broker unit ranges and ASP mixes (access limited)', date: '2026-06', state: 'derived',
      unit: 'M units', classification: 'derived',
      scope: 'TPU-class units required for custom dollar share ≥ merchant', period: '2026–2027F',
      institution: 'this report (arithmetic on K31 ranges)', title: 'crossover unit requirement', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: 'required units = merchant dollars at stake ÷ custom ASP mix',
      notes: 'The claim fails only if even the top of the TPU estimate range cannot reach the requirement — see K35.' },

    { key: 'K34', factName: 'External arbiters',
      value: 'Hyperscaler segment disclosures · Synopsys IP licensing · Alchip/GUC order mix',
      sourceClass: 'kimi', citation: 'Standing instrumentation list — public filings, reviewed at each print', date: '2026-07-18', state: 'gap',
      unit: 'text', classification: 'scenario',
      scope: 'independent observables for the custom-vs-merchant question', period: 'rolling',
      institution: 'this report', title: 'arbitration instrumentation', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'The custom-vs-merchant dollar split inside hyperscalers remains undisclosed — a standing gap this instrumentation exists to close.' },

    { key: 'K35', factName: 'Adjudication',
      value: 'the claim fails the strong form — the crossover is not demonstrated even on the friendliest unit estimates',
      sourceClass: 'kimi', citation: 'This report adjudication of K31/K33 arithmetic', date: '2026-06', state: 'derived',
      unit: 'text', classification: 'derived',
      scope: 'custom-vs-merchant dollar crossover claim', period: '2026–2027F',
      institution: 'this report', title: 'crossover adjudication', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: 'requirement (8.0–8.4M) sits inside the estimate range (6.5–15M) → not demonstrable; strong form fails',
      notes: 'Requirement reachable in the range does not demonstrate the crossover — the dollar math must close too, and on Series A it reads ≈20% by 2027F, not 50%.' },

    { key: 'K36', factName: 'NVIDIA crypto',
      value: '≈70% of gaming revenue into mining at the peak — then two sequential halvings; “The crypto hangover lasted longer than we expected.” (Huang, 2018-11-15)',
      sourceClass: 'company', citation: 'NVIDIA Q3 FY2019 earnings call and segment commentary (2018-11-15); hangover estimate is ours', date: '2018-11-15', state: 'derived',
      unit: '%', classification: 'reported',
      scope: 'NVIDIA gaming-segment mining exposure', period: '2017–2019',
      institution: 'NVIDIA', title: 'Q3 FY2019 earnings call', author: 'Jensen Huang (CEO, quote)',
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'The ≈70% figure is an estimate from segment commentary; the quote is verbatim. The mining mirror: exposure share hidden inside a headline segment.' },

    { key: 'K37', factName: 'Alchip AI share',
      value: '≈70% of revenue from AI by 2023 — mining was 30–40% at the peak',
      sourceClass: 'company', citation: 'Alchip (3661.TW) results and commentary', date: '2024', state: 'derived',
      unit: '%', classification: 'reported',
      scope: 'Alchip revenue mix', period: '2018–2023',
      institution: 'Alchip Technologies', title: 'quarterly results commentary', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'The merchant-ASIC mirror: the same design house that rode crypto ASICs now rides AI ASICs.' },

    { key: 'K38', factName: 'GUC mining share',
      value: '≈20% at the 2018 peak',
      sourceClass: 'company', citation: 'GUC results commentary', date: '2019', state: 'derived',
      unit: '%', classification: 'reported',
      scope: 'GUC revenue mix', period: '2017–2019',
      institution: 'Global Unichip Corp.', title: 'results commentary', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'Same mirror, smaller dose.' },

    { key: 'K39', factName: 'NVLink Fusion',
      value: '“NVLink Fusion opens NVIDIA’s AI platform and rich ecosystem for partners to build specialized AI infrastructures.” (Huang, 2025-05-19, verbatim)',
      sourceClass: 'company', citation: 'NVIDIA Computex 2025 keynote (2025-05-19)', date: '2025-05-19', state: 'derived',
      unit: 'text', classification: 'reported',
      scope: 'NVIDIA platform-opening posture', period: 'May 2025',
      institution: 'NVIDIA', title: 'Computex 2025 keynote', author: 'Jensen Huang (CEO, quote)',
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'Quote verbatim. The strategic read — open the interconnect, keep the accelerator — is ours.' },

    { key: 'K40', factName: 'NVIDIA-designed custom die',
      value: 'No confirmed NVIDIA-designed custom ASIC die as of 2026-07-18',
      sourceClass: 'kimi', citation: 'Standing gap — absence of evidence in the public record, watched', date: '2026-07-18', state: 'gap',
      unit: 'text', classification: 'estimate',
      scope: 'NVIDIA custom-silicon participation', period: 'through 2026-07-18',
      institution: 'public record', title: 'standing gap register', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'Absence of evidence, not evidence of absence; the Groq licensing deal (Dec 2025) is a technology license, not a confirmed custom-die program.' },

    { key: 'K41', factName: 'NVIDIA-inside-ASIC path',
      value: 'the supported path is M&A — NVIDIA clears markets; it does not join them',
      sourceClass: 'kimi', citation: 'This report reasoning on the public record', date: '2026-07-18', state: 'estimate',
      unit: 'text', classification: 'derived',
      scope: 'NVIDIA strategic options in custom silicon', period: '2026+',
      institution: 'this report', title: 'platform-opening reasoning', author: null,
      url: null, page: null, lastVerified: '2026-07-18', formula: null,
      notes: 'Interpretation, not reportage: the Dec 2025 Groq non-exclusive license (≈$20B CNBC-reported, NVIDIA unconfirmed) is the closest observed move and still is not a custom-die program.' }
  ];

  /* ------------------------------------------------------------------ *
   * drillFacts — keyed fact cards for the global evidence drill card
   * (spec §11). Every `drill` key used anywhere in the datasets (or by
   * inline ◆ anchors in the HTML) resolves here.
   *   big   : 25px monospaced main fact
   *   line  : 10px source text
   *   class : 'kimi' | 'broker' | 'company' | 'industry' (badge color)
   *   src   : register key K1–K41 (null where outside the register)
   * ------------------------------------------------------------------ */
  D.drillFacts = {
    /* — windows & timeline — */
    'xc2064':            { big: '64 blocks · 1,000–1,500 gates', line: 'Xilinx XC2064 product brief, 1985 — the first commercial FPGA.', class: 'company', src: null },
    'xilinx-boom':       { big: '$560M → $1,659M', line: 'Xilinx revenue 1996 → FY2001 · 10-K filings.', class: 'company', src: null },
    'altera-boom':       { big: '$402M → $1,377M', line: 'Altera revenue 1995 → 2000 · 10-K filings.', class: 'company', src: null },
    'duopoly-reset':     { big: '−39% · industry ≈−32%', line: 'FPGA duopoly combined revenue decline, 2001 · derived from 10-K filings; WSTS industry tally.', class: 'kimi', src: 'K17' },
    'catapult-scale':    { big: '1,632 FPGA servers', line: 'Microsoft Project Catapult medium-scale deployment · Andrew Putnam first author (23 authors; senior: Doug Burger), ISCA 2014.', class: 'company', src: null },
    'catapult-perf':     { big: '95% throughput · 29% tail latency', line: 'Catapult abstract (Putnam et al., ISCA 2014, verbatim): 95% ranking-throughput gain per server at fixed latency — or a 29% tail-latency reduction.', class: 'company', src: null },
    'tpu-deploy-2015':   { big: 'Deployed 2015', line: 'Google TPU in production since 2015 · Jouppi et al.; Google Cloud blog.', class: 'company', src: null },
    'tpu-disclose-2016': { big: 'Disclosed 2016-05-18', line: 'Jouppi, Google blog (verbatim): “We’ve been running TPUs inside our data centers for more than a year, and have found them to deliver an order of magnitude better-optimized performance per watt for machine learning.” · ISCA paper 2017.', class: 'company', src: null },
    'intel-altera':      { big: '$16.7B', line: 'Intel acquires Altera · merger announcement, June 2015.', class: 'company', src: null },
    'deals-108':         { big: '5 deals · 108 days', line: 'ADI–Maxim, NVIDIA–Arm, SK hynix–Intel NAND, AMD–Xilinx, Marvell–Inphi · Jul–Oct 2020.', class: 'industry', src: null },
    'amd-xilinx':        { big: '$35B bid → ≈$49B close', line: 'AMD–Xilinx: $35B all-stock bid inside the 108-day window (Oct 2020); closed ≈$49B on 2022-02-14.', class: 'company', src: null },
    'nvda-dc-run':       { big: '$4.28B → $75.2B · 17.6×', line: 'NVIDIA data-center revenue: 17.6× (12 intervals, 13 observations, Q1 FY2024→Q1 FY2027) · company filings.', class: 'company', src: 'K10', url: 'https://nvidianews.nvidia.com/news/nvidia-announces-financial-results-for-first-quarter-fiscal-2027' },
    'top4-2025':         { big: '≈$410–413B', line: 'Top-4 hyperscaler capex, 2025 · compiled estimate — FT tally ≈$410B; per-company sum ≈$413.3B; no single reported aggregate.', class: 'kimi', src: 'K5' },
    'top4-2026e':        { big: '$695–725B', line: 'Top-4 2026E capex · company guidance (Q1-2026 earnings, Apr 29–30 2026): Amazon ≈$200B + Microsoft ≈$190B (CY2026) + Alphabet $180–190B + Meta $125–145B.', class: 'company', src: 'K5' },
    'capex-history':     { big: '$123B → ≈$413B', line: 'Top-4 capex 2021 → 2025 · 2021–24 from company disclosures; 2025 a compiled estimate (≈$410–413B).', class: 'kimi', src: 'K5' },
    /* — mechanism — */
    'mechanism-loop':    { big: 'One wave, five stations', line: 'Demand ignition → capacity failure → panic double-ordering → block arrivals → clearing · R&D holds through the trough into the next technology base — 300mm, EUV, HBM/CoWoS — and the wave re-ignites.', class: 'kimi', src: null },
    'mech-demand':       { big: 'Demand ignition', line: 'The real workload line — everything else is an echo of it.', class: 'kimi', src: null },
    'mech-capacity-fail': { big: 'Assumptions fail', line: 'Capacity is ordered against a demand line that has already moved: 10kwpm slabs arrive against last year’s slope.', class: 'kimi', src: 'K12' },
    'mech-panic':        { big: 'Double-ordering', line: 'Non-cancellable, non-returnable: buyers book twice to secure once — the queue becomes the demand signal.', class: 'kimi', src: null },
    'mech-arrivals':     { big: 'Blocks arrive', line: 'Ordered at the peak, delivered into the trough: capacity lands after the demand line has turned.', class: 'kimi', src: null },
    'mech-clearing':     { big: 'Acquisition first', line: 'The clearing grammar of inference silicon favors acquisition and consolidation; bankruptcy-law restructuring is rare but not absent (Wave Computing, Chapter 11, 2020).', class: 'kimi', src: null },
    /* — cohorts & conflow — */
    'clearing-grammar':  { big: '14 companies · 7 outcomes', line: 'Cohort through 2026-07-18: 6 acquired · 1 asset-sale · 1 licensing · 1 IPO · 5 independent · 0 dissolved — acquisition the most common, not the only, grammar. One Chapter 11 restructuring en route (Wave).', class: 'kimi', src: null },
    'xilinx-exit':       { big: 'Xilinx → AMD · ≈$49B', line: 'Founded 1984; $35B bid October 2020, closed ≈$49B February 2022 · all-stock.', class: 'company', src: null },
    'altera-exit':       { big: 'Altera → Intel · $16.7B', line: 'Founded 1983, acquired 2015 · Intel sold 51% of the Altera business to Silver Lake, Sep 2025.', class: 'company', src: null },
    'lattice-survived':  { big: 'Lattice · survived', line: 'Founded 1983; the independent FPGA survivor (public).', class: 'company', src: null },
    'actel-exit':        { big: 'Actel → Microsemi · ≈$430M', line: 'Founded 1985, acquired 2010.', class: 'company', src: null },
    'quicklogic-survived': { big: 'QuickLogic · survived', line: 'Founded 1988; independent (public).', class: 'company', src: null },
    'tabula-dead':       { big: 'Tabula · dissolved 2015', line: 'The rare straight-line death — founded 2003, shut down March 2015.', class: 'industry', src: null },
    'achronix-survived': { big: 'Achronix · survived', line: 'Founded 2004; independent (private).', class: 'industry', src: null },
    'siliconblue-exit':  { big: 'SiliconBlue → Lattice · ≈$62M', line: 'Founded 2006, acquired December 2011.', class: 'company', src: null },
    'nervana-exit':      { big: 'Nervana → Intel · ≈$350M', line: 'Founded 2014, acquired 2016; product line dissolved inside Intel, 2020.', class: 'industry', src: null },
    'groq-licensing':    { big: 'Groq → NVIDIA license', line: 'Non-exclusive inference-technology license, 2025-12-24 (≈$20B CNBC-reported; NVIDIA unconfirmed); founders + engineers joined NVIDIA — remnant independent (CEO Simon Edwards).', class: 'industry', src: null, url: 'https://groq.com/newsroom/groq-and-nvidia-enter-non-exclusive-inference-technology-licensing-agreement-to-accelerate-ai-inference-at-global-scale' },
    'groq-survived':     { big: 'Groq · remnant independent', line: 'Founded 2016; NVIDIA non-exclusive license (Dec 2025); remnant continues independently.', class: 'industry', src: null },
    'graphcore-exit':    { big: 'Graphcore → SoftBank', line: 'Founded 2016, acquired July 2024 (reported value ≈$500–600M, unconfirmed).', class: 'industry', src: null },
    'cerebras-ipo':      { big: 'Cerebras → Nasdaq CBRS', line: 'IPO priced $185/share, raised ≈$5.5B, May 13–14 2026 · wafer-scale engine goes public.', class: 'company', src: null, url: 'https://www.cerebras.ai/press-release/cerebras-systems-announces-pricing-of-initial-public-offering' },
    'cerebras-survived': { big: 'Cerebras · public (CBRS)', line: 'Founded 2015; IPO May 2026 — no longer private, never acquired.', class: 'company', src: null },
    'wave-exit':         { big: 'Wave → MIPS → GlobalFoundries', line: 'Founded 2008; Chapter 11 (2020), emerged as MIPS (Mar 2021, Tallwood); acquired by GlobalFoundries, Aug 2025.', class: 'industry', src: null, url: 'https://www.reuters.com/article/technology/ai-chip-firm-wave-computing-emerges-from-chapter-11-bankruptcy-protection-idUSKCN2AT3T7/' },
    'flexlogix-exit':    { big: 'Flex Logix → Analog Devices', line: 'Founded 2014; eFPGA/AI technology assets and team transferred to ADI (Nov 2024, completed ≈Jan 2025); terms undisclosed.', class: 'industry', src: null },
    'mythic-status':     { big: 'Mythic · independent', line: 'Founded 2012; revived with a $125M financing (Dec 2025).', class: 'industry', src: null },
    'sifive-status':     { big: 'SiFive · independent', line: 'Founded 2015; pre-IPO, independent as of 2026-07-18.', class: 'industry', src: null },
    'tenstorrent-status': { big: 'Tenstorrent · independent', line: 'Founded 2016; Qualcomm acquisition rumor publicly denied (Jun 2026).', class: 'industry', src: null },
    'sambanova-status':  { big: 'SambaNova · independent', line: 'Founded 2017; $1B Series F at an $11B valuation (Jul 2026).', class: 'industry', src: null },
    'habana-exit':       { big: 'Habana → Intel · $2B', line: 'Founded 2016, acquired December 2019.', class: 'company', src: null },
    /* — submarine — */
    'submarine-pattern': { big: 'Deploy first, disclose later', line: 'Production truth runs 1–4 years ahead of public knowledge across the record.', class: 'kimi', src: null },
    'sub-google':        { big: '2015 → 2016', line: 'Google TPU v1: deployed 2015; disclosed in a May 2016 blog, ISCA paper 2017.', class: 'company', src: null },
    'sub-microsoft':     { big: '2012 → 2014', line: 'Microsoft Catapult: 1,632 servers wired by end-2012, disclosed at ISCA 2014; 95% throughput gain.', class: 'company', src: null },
    'sub-baidu':         { big: '≈2017 → 2018', line: 'Baidu FPGA XPUs in production ≈2017; Kunlun silicon disclosed 2018.', class: 'industry', src: null },
    'sub-amazon':        { big: '2018 → 2018', line: 'Amazon Inferentia: internal deployment and re:Invent disclosure, 2018; Inf1 GA 2019.', class: 'company', src: null },
    'sub-meta':          { big: '≈2022 → 2023', line: 'Meta MTIA v1: internal ≈2022, disclosed May 2023.', class: 'company', src: null },
    'sub-tesla':         { big: '2021 → 2023', line: 'Tesla Dojo D1: the counter-pattern — disclosed AI Day 2021, production 2023.', class: 'company', src: null },
    /* — atlas & tpu — */
    'nvda-merchant-line': { big: 'V100 → B200', line: 'The merchant compute line: Volta 2017 to Blackwell 2024.', class: 'company', src: 'K10' },
    'amd-merchant-line': { big: 'MI300X · 2023', line: 'AMD re-enters merchant AI accelerators at scale.', class: 'company', src: null },
    'fpga-line':         { big: 'XC2064 → Agilex', line: 'FPGA generations 1985–2019: the founding lineage.', class: 'company', src: null },
    'gb200-rack':        { big: '≈120kW / rack', line: 'GB200 NVL72 rack power · NVIDIA system documentation.', class: 'company', src: null },
    'tpu-generations':   { big: '92 TOPS → 4,614 TFLOPS', line: 'TPU v1 (2015, INT8) → Ironwood v7 (2025, FP8) · log scale; precision bases differ — compare with care.', class: 'company', src: null },
    'trillium':          { big: '4.7× v5e', line: 'TPU v6 Trillium peak compute vs v5e · Google Cloud, GA late 2024.', class: 'company', src: null },
    'ironwood':          { big: '42.5 EFLOPS / pod', line: 'TPU v7 Ironwood: 9,216 chips/pod, FP8 · announced Apr 2025, GA late 2025.', class: 'company', src: null, url: 'https://blog.google/products/google-cloud/ironwood-tpu-age-of-inference/' },
    'tpu-v8':            { big: 'TPU 8t/8i · 2026', line: 'Unveiled 2026-04-22 (Cloud Next), GA later in 2026 (estimate) · ≈9 PFLOPS FP4-class per chip (estimate; widest precision caveat of all).', class: 'kimi', src: 'K28', url: 'https://cloud.google.com/blog/products/compute/tpu-8t-and-tpu-8i-technical-deep-dive' },
    'trainium3':         { big: 'Trainium 3 · 3nm', line: 'AWS’s first 3nm AI chip · ≈2.4× Trainium 2 · re:Invent 2025.', class: 'company', src: null },
    'maia200':           { big: 'Maia 200', line: 'Microsoft’s second-generation in-house accelerator · 3nm-class.', class: 'company', src: null },
    'mtia3':             { big: 'MTIA v3 · 2026E', line: 'Meta’s next-generation inference part · supply-chain reporting.', class: 'industry', src: null },
    'now-wave':          { big: 'The second wave', line: 'Ironwood · Trainium 3 · Maia 200 · MTIA v3 — every hyperscaler fields its own silicon.', class: 'kimi', src: null }
,
    /* — mining mirror — */
    'mining-mirror':     { big: 'Two cycles · five years', line: 'Crypto incubated custom silicon, then crashed it twice: 2017–2019 and 2020–2022.', class: 'kimi', src: null },
    'mining-cycle-1':    { big: '$19.7k → clearing', line: 'Cycle 1: BTC peak Dec 2017 → 16nm panic ordering → 2018–2019 inventory clearing.', class: 'industry', src: null },
    'mining-cycle-2':    { big: '$69k → the Merge', line: 'Cycle 2: BTC peak Nov 2021 → 5nm panic ordering → Ethereum merge clears the channel, Sep 2022.', class: 'industry', src: 'K36' },
    'mining-asic-race':  { big: '55nm → 16nm → 5nm', line: 'The mining-ASIC process race: 55nm to 16nm in four years; 5nm by 2021.', class: 'industry', src: null },
    'nvda-crypto':       { big: '−45% YoY', line: 'NVIDIA gaming revenue, Q4 FY2019 — the crypto hangover print.', class: 'company', src: 'K36' },
    'alchip-sawtooth':   { big: 'NT$2.35B → NT$0.62B', line: 'Alchip quarterly revenue, 4Q17 peak → 1Q19 trough · company releases.', class: 'company', src: 'K37' },
    'alchip-q':          { big: 'NT$6.9B → NT$3.87B', line: 'Alchip annual revenue 2017 → 2019 · the crypto sawtooth in one company.', class: 'company', src: 'K37' },
    'guc-q':             { big: 'NT$11.6B → NT$24.9B', line: 'GUC annual revenue 2017 → 2024 · mining fade, then the AI ladder.', class: 'company', src: 'K27' },
    /* — finance — */
    'ocf-top4':          { big: '$272B → $513B → $587B', line: 'Top-4 operating cash flow 2021 → 2025E → 2026E · the 2026E ≈$587B is a working estimate — no public consensus aggregate.', class: 'kimi', src: 'K29' },
    'ocf-stress':        { big: '0.80 → 1.21', line: 'Top-4 capex/OCF 2025 → 2026E midpoint (range 1.18–1.24) · caution 0.8, binding 1.0 · OCF $587B is a working estimate.', class: 'kimi', src: 'K29' },
    'tsmc-split':        { big: '66% / 34% (2027F)', line: 'TSMC AI-revenue attribution, GPU vs ASIC camp — third-party attribution estimate, NOT TSMC-disclosed; not the global accelerator-dollar share (Series A).', class: 'broker', src: 'K8' },
    'pergw-dies':        { big: '≈1.2M dies / GW', line: '1GW ≈ 8,300 NVL72-class racks ≈ 600k packages ≈ 1.2M compute dies.', class: 'kimi', src: null },
    'pergw-price':       { big: '≈$35k ASP', line: 'Blackwell-class accelerator ASP (estimate).', class: 'broker', src: null },
    'pergw-capex':       { big: '≈$50B / GW', line: 'All-in AI datacenter capex per gigawatt: silicon, systems, power, buildings (estimate).', class: 'broker', src: null },
    'pergw-tsmc':        { big: '≈$2.1B / GW', line: 'TSMC revenue captured per GW: logic + CoWoS + interposer content.', class: 'kimi', src: 'K21' },
    /* — gates & capacity — */
    'gates-profit-pool': { big: 'The pool sits at the gates (hypothesis)', line: 'HBM · leading-edge process · CoWoS · optical interconnect — rigidity-ranked; comparative margin/ROIC evidence is not public.', class: 'kimi', src: null },
    'gate-hbm':          { big: 'HBM · 3 makers', line: 'Rigidity 5/5: 18–24-month qualification, 2026 supply largely booked.', class: 'broker', src: 'K13' },
    'gate-process':      { big: '1 foundry of record', line: 'Leading-edge process: wafer agreements signed 2–3 years out.', class: 'industry', src: null },
    'gate-cowos':        { big: 'CoWoS · slabs of 10kwpm', line: 'Bookings lead capacity by ≈2 quarters through 2026E.', class: 'broker', src: 'K12' },
    'gate-optical':      { big: '800G → 1.6T', line: 'Optical interconnect: the 1995 gate returns; DSP supply is the watch item.', class: 'industry', src: null },
    'cowos-path':        { big: '75–80 → 120–130kwpm', line: 'CoWoS capacity end-2025 → end-2026 target (third-party estimates, vary) · “sold out through 2026” (C.C. Wei, AGM Jun 2026) · 1 slab = 10kwpm.', class: 'broker', src: 'K12' },
    'hbm-capacity':      { big: '≈460kwpm (2026E)', line: 'Stacked HBM capacity: SK hynix + Samsung + Micron.', class: 'broker', src: 'K13' },
    'hbm-share':         { big: '≈8% → ≈41%', line: 'HBM share of DRAM revenue, 2023 → 2027F · broker memory models.', class: 'broker', src: 'K16' },
    'hbm-gen':           { big: '4-hi → 16-hi', line: 'HBM1 (2015) → HBM4E (2027F) · slab count = stack height; hatched = estimate.', class: 'industry', src: 'K13' },
    'power-iea':         { big: '415 → 945TWh', line: 'IEA data-centre electricity, 2024 → 2030 Base Case · “Energy and AI”, April 2025.', class: 'industry', src: 'K26', url: 'https://www.iea.org/reports/energy-and-ai/energy-demand-from-ai' },
    'stargate':          { big: '≈7GW planned vs ≈0.6GW operational', line: 'Stargate (announced Jan 2025): $400B+ claimed; Abilene ≈0.6GW energized per Apr 2026 satellite imagery — announcement figures are program ceilings.', class: 'company', src: null },
    'hyperion':          { big: '≈5GW', line: 'Meta Hyperion, Louisiana · announced July 2025.', class: 'company', src: null },
    'xai-colossus':      { big: '≈1GW-class', line: 'xAI Colossus, Memphis · site path to GW scale.', class: 'industry', src: null },
    'rainier':           { big: '≈2GW-class', line: 'Amazon Project Rainier · multi-campus Anthropic cluster.', class: 'industry', src: null },
    /* — measurement & assumptions — */
    'pen-units':         { big: '27.8% of 2026 AI-server units', line: 'TrendForce: ASIC = 27.8% of 2026 AI-server shipments (units; 20.9% in 2025), ASIC +44.6% vs GPU +16.1% — a unit basis, ineligible for scenario math; the claimed ≈50% 2027 chip-unit line remains broker-estimated.', class: 'broker', src: 'K6' },
    'pen-cowos':         { big: '≈34% of CoWoS (2027F)', line: 'Allocation basis: booked packaging slots — capacity, not dollars.', class: 'broker', src: 'K7' },
    'pen-dollar':        { big: '≈20% of dollars (2027F)', line: 'Series A: global accelerator-dollar share of custom silicon (broker estimates) — the only basis eligible for scenario multiplication; never the TSMC attribution read (Series B).', class: 'broker', src: 'K8' },
    'avgo-customers':    { big: '6 qualified + 2 ramping', line: 'Broadcom XPU customers (Q2 FY26, Jun 3 2026): Google, Meta, ByteDance, OpenAI, Anthropic, Fujitsu · AI backlog ≈$73B+ · FY27 AI >$100B guided.', class: 'company', src: 'K23' },
    'google-concentration': { big: 'Share undisclosed', line: 'Google is Broadcom’s first and largest XPU customer; exact revenue share is not disclosed.', class: 'broker', src: 'K23' },
    'ledger-revisions':  { big: 'Every revision: up', line: 'Meta $60–65B→$70–72B · Alphabet $75B→$91–93B · Microsoft ≈$80B→$140B+ · Amazon ≈$105B→$125B.', class: 'kimi', src: 'K5' },
    'a1':                { big: 'A1 · FAIL', line: 'The dollar still pools at merchant GPUs: custom ≈12% of 2025E accelerator dollars.', class: 'kimi', src: 'K8' },
    'a2':                { big: 'A2 · UNDECIDABLE', line: 'Required ≈8.0–8.4M units vs a 6.5M–15M estimate range — the claim cannot be adjudicated.', class: 'kimi', src: 'K35' },
    'a3':                { big: 'A3 · LATE', line: 'Visibility rests on 2026 guidance; the confirming prints arrive after the decision window.', class: 'kimi', src: 'K5' },
    /* — verdict & scenarios — */
    'matrix':            { big: '7 windows × 5 dimensions', line: 'Forty-two years in one table: same (blue), partial (hatched), none (grey).', class: 'kimi', src: null },
    'verdict-root':      { big: 'Replay or new cycle?', line: 'Six windows of evidence feed two scenarios — and one dashed partition.', class: 'kimi', src: null },
    'verdict-same':      { big: 'Same case', line: 'A 1995–2000 replay: real demand, over-ordered capacity, one clearing wave.', class: 'kimi', src: 'K3' },
    'verdict-diff':      { big: 'Different case', line: 'New constraints (HBM, CoWoS, grid) + deeper software moat + multi-vertical demand.', class: 'kimi', src: 'K1' },
    'verdict-policy':    { big: 'Policy partition', line: 'Export controls and industrial policy split demand into two spheres; neither scenario survives intact.', class: 'kimi', src: null },
    'scen-base':         { big: '≈2.5× · range 2.0–4.7×', line: 'Rebuilt base case: accelerator-spend growth 500/330 ≈1.52× × custom dollar-share growth 20/12 ≈1.67× (2025→2028). Compatible accelerator-dollar denominators — not total capex.', class: 'kimi', src: 'K1' },
    'scen-cons':         { big: '≈2.0× · band 1.9–2.1×', line: 'Conservative: TAM path met, share stalls at ≈16% — 1.52× spend × 1.33× share over three years.', class: 'kimi', src: 'K2' },
    'scen-contraction':  { big: '−15% to −35%', line: 'Contraction: accelerator spending mean-reverts ≈−8% and the custom share stalls → 0.73×; clearing by consolidation.', class: 'kimi', src: 'K3' },
    'kill-switch':       { big: '< +14%', line: 'Base-case kill switch: Top-4 2027E capex growth below +14%.', class: 'kimi', src: 'K4' },
    'signals-summary':   { big: '1 confirmed · 7 partial · 0 missing', line: 'Eight falsification triggers — point-in-time register, research cutoff 2026-07-18 (not a live product).', class: 'kimi', src: null },
    'sig-1':             { big: '$695–725B guided (+68–76%)', line: 'Trigger 1: falsified if 2026E guidance is cut below +20% YoY · next: Alphabet 2026-07-28, Microsoft 07-28/29, Meta 07-29, Amazon 07-30.', class: 'company', src: 'K5' },
    'sig-2':             { big: '$75.2B · +92% YoY', line: 'Trigger 2: falsified by two consecutive quarters below +20% YoY growth · Q2 FY27 guide $91.0B ±2% · next report ≈2026-08-26.', class: 'company', src: 'K10' },
    'sig-3':             { big: '6 qualified + 2 ramping', line: 'Trigger 3: Broadcom custom momentum — falsified by an FY27 AI guide below ≈$56B or a lost qualified customer · next: 2026-09-02.', class: 'company', src: 'K23' },
    'sig-4':             { big: '≈7GW vs ≈0.6GW', line: 'Trigger 4: announced GW programs vs energized reality — falsified by two stalled quarters at named sites · next: Oracle earnings (Sep 2026).', class: 'industry', src: 'K5' },
    'sig-5':             { big: '2026 HBM sold out', line: 'Trigger 5: HBM gate confirmed binding — SK hynix sold out for 2026, requests exceed 3-yr capacity · falsified by >15% ASP declines or <2-quarter lead times · next: memory earnings Oct 2026.', class: 'company', src: 'K15' },
    'sig-6':             { big: '120–130kwpm target', line: 'Trigger 6: CoWoS gate — falsified by utilization <85% amid the ramp · next: TSMC monthly revenue ≈2026-08-10, Q3 call Oct 2026.', class: 'broker', src: 'K12' },
    'sig-7':             { big: '27.8% of 2026 AI-server units', line: 'Trigger 7: custom-share momentum (TrendForce) — falsified below ≈20% unit share or Series-A dollar share <15% into 2027F · next: TrendForce update Q4 2026.', class: 'industry', src: 'K6' },
    'sig-8':             { big: 'TPU 8t/8i GA later 2026', line: 'Trigger 8: TPU cadence — falsified if 8t/8i GA slips to 2027 or Anthropic’s >1GW TPU capacity misses 2026 · next: Alphabet 2026-07-28, GA watch H2 2026.', class: 'company', src: 'K28' },
    /* — deep dives — */
    'dd-avgo':           { big: 'AVGO · toll road #1', line: 'Custom XPU champion: 6 qualified customers + 2 ramping, ≈$73B+ AI backlog, FY27 AI >$100B guided; concentration — Google first and largest, share undisclosed — is the key risk.', class: 'company', src: 'K23' },
    'dd-mrvl':           { big: 'MRVL · toll road #2', line: 'Custom silicon #2 plus the Inphi optical DSP annuity; program timing is the key risk.', class: 'broker', src: null },
    'dd-mediatek':       { big: '2454.TW · SoC → custom', line: 'Reported co-design role on inference TPU variants; newcomer pricing is the key risk.', class: 'industry', src: null },
    'dd-guc':            { big: '3443.TW · TSMC-aligned', line: 'The design-service front door to TSMC’s leading edge; NRE cyclicality is the key risk.', class: 'company', src: 'K27' },
    'dd-alchip':         { big: '3661.TW · sawtooth survivor', line: 'Pure-play ASIC house; customer concentration squared is the key risk.', class: 'company', src: 'K37' },
    'dd-verisilicon':    { big: '688521.SH · inside the partition', line: 'China-facing design service + IP; the partition itself is the key risk.', class: 'industry', src: null },
    /* — timeline (V2) — */
    'duopoly-founded':   { big: '1983–84', line: 'Altera (1983) and Xilinx (1984) founded · the programmable duopoly opens the record.', class: 'company', src: null },
    'xilinx-pld-crown':  { big: '#1 in PLDs', line: 'Xilinx takes the programmable-logic crown, 1994 · company records.', class: 'company', src: null },
    'telecom-peak':      { big: 'The optical peak', line: 'Telecom bubble peaks, 2000 · carrier capex crests and the order books go quiet.', class: 'industry', src: null },
    'fpga-12m-gates':    { big: '12M gates', line: 'The 12-million-gate FPGA arrives, 2003 · programmable logic crosses into ASIC territory.', class: 'company', src: null },
    'intel-ai-entry':    { big: 'Intel enters AI', line: '2016: Intel buys into the AI accelerator wave — Nervana (≈$350M) after Altera ($16.7B, 2015).', class: 'company', src: null },
    'amd-xilinx-bid':    { big: '$35B bid', line: 'AMD bids $35B for Xilinx inside the 108-day M&A window (Jul–Oct 2020) · closes ≈$49B, Feb 2022.', class: 'company', src: null },
    'export-controls-2022': { big: '2022-10-07', line: 'The peak meets export controls: advanced-compute rules split the demand map into two spheres.', class: 'industry', src: null },
    'nvlink-fusion':     { big: 'The platform opens', line: 'NVLink Fusion (May 2025): NVIDIA opens its interconnect to third-party custom silicon.', class: 'company', src: 'K39' },
    'peak-open-2026':    { big: 'Expansion confirmed', line: '2026: $695–725B guided and the peak is still not in sight — the forty-third year opens at full throttle.', class: 'kimi', src: 'K5' },
    /* — crossover — */
    'crossover-req':     { big: '≈8.0–8.4M units', line: 'The 50% unit line requires ≈8.0–8.4M TPU-class units in 2027F.', class: 'broker', src: 'K33' },
    'crossover-range':   { big: '6.5M–15M', line: 'Published 2026 TPU-class unit estimates — ±40% around the requirement.', class: 'broker', src: 'K31' },
    'crossover-verdict': { big: 'UNADJUDICABLE', line: 'The range straddles the line; the claim is neither confirmed nor refuted on the record.', class: 'kimi', src: 'K35' }
  };

})(window.DATA);
