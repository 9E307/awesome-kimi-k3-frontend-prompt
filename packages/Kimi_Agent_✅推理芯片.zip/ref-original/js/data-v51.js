/**
 * js/data-v51.js — CYCLE & FINANCE DATASETS
 * Forty-Two Years of Inference Silicon · data layer (spec §16)
 *
 * Namespace: window.DATA (no modules, no imports).
 * Datum convention identical to js/data.js:
 *   { value, state, src, unit, fmt, tip, drill } — shared fields hoisted
 *   into `meta` on grouped datasets.
 * Keys: acquisitions, miningEvents, alchipQuarterly, gucQuarterly,
 *       capexByCompany, operatingCashFlow, capexStairs, tsmcRevenueShare,
 *       perGwEconomics.
 */
window.DATA = window.DATA || {};
(function (D) {
  'use strict';

  /* ------------------------------------------------------------------ *
   * acquisitions — consolidation flow ribbons (#conflow-chart, SVG
   * viewBox 0 0 880 710). Three generations on the left, destinations
   * on the right; ribbon width approximates deal value (US$B).
   * value:null → minimum-width ribbon (survival / dissolution flows).
   * ------------------------------------------------------------------ */
  D.acquisitions = {
    meta: {
      unit: 'US$B',
      fmt: 'moneyB',
      viewBox: [880, 710],
      note: 'Ribbon width ≈ deal value (undisclosed terms → minimum-width ribbon). The refined grammar: acquisition is the most common outcome — alongside asset sales, licensing transactions, public listings, continued independence, and one Chapter 11 restructuring (Wave).',
      drill: 'clearing-grammar'
    },
    generations: [
      { id: 'g1', label: 'Gen 1 · FPGA founding',        windowId: 'w1' },
      { id: 'g2', label: 'Gen 2 · quiet-decade startups', windowId: 'w3' },
      { id: 'g3', label: 'Gen 3 · merchant AI silicon',   windowId: 'w4' }
    ],
    destinations: [
      { id: 'amd',      label: 'AMD' },
      { id: 'intel',    label: 'Intel' },
      { id: 'microsemi', label: 'Microsemi' },
      { id: 'lattice',  label: 'Lattice' },
      { id: 'softbank', label: 'SoftBank' },
      { id: 'globalfoundries', label: 'GlobalFoundries' },
      { id: 'analog',   label: 'Analog Devices' },
      { id: 'licensing', label: 'Licensed · remnant independent' },
      { id: 'public',   label: 'Public listing (IPO)' },
      { id: 'survived', label: 'Survived independent' },
      { id: 'dead',     label: 'Dissolved' }
    ],
    flows: [
      { from: 'Xilinx',      gen: 'g1', to: 'amd',       value: 49.0,  year: 2022, state: 'actual',   src: null, drill: 'xilinx-exit',        tip: 'Xilinx → AMD · $49B all-stock · closed Feb 2022' },
      { from: 'Altera',      gen: 'g1', to: 'intel',     value: 16.7,  year: 2015, state: 'actual',   src: null, drill: 'altera-exit',        tip: 'Altera → Intel · $16.7B · 2015' },
      { from: 'Actel',       gen: 'g1', to: 'microsemi', value: 0.43,  year: 2010, state: 'estimate', src: null,  drill: 'actel-exit',         tip: 'Actel → Microsemi · ≈$0.43B · 2010' },
      { from: 'Lattice',     gen: 'g1', to: 'survived',  value: null,  year: null, state: 'derived',  src: null,  drill: 'lattice-survived',   tip: 'Lattice · survived independent' },
      { from: 'QuickLogic',  gen: 'g1', to: 'survived',  value: null,  year: null, state: 'derived',  src: null,  drill: 'quicklogic-survived', tip: 'QuickLogic · survived independent' },
      { from: 'Tabula',      gen: 'g2', to: 'dead',      value: null,  year: 2015, state: 'derived',  src: null,  drill: 'tabula-dead',        tip: 'Tabula · dissolved 2015 — the exception' },
      { from: 'Achronix',    gen: 'g2', to: 'survived',  value: null,  year: null, state: 'derived',  src: null,  drill: 'achronix-survived',  tip: 'Achronix · survived independent' },
      { from: 'SiliconBlue', gen: 'g2', to: 'lattice',   value: 0.062, year: 2011, state: 'estimate', src: null,  drill: 'siliconblue-exit',   tip: 'SiliconBlue → Lattice · ≈$62M · 2011' },
      { from: 'Nervana',     gen: 'g3', to: 'intel',     value: 0.35,  year: 2016, state: 'estimate', src: null,  drill: 'nervana-exit',       tip: 'Nervana → Intel · ≈$350M · 2016' },
      { from: 'Habana',      gen: 'g3', to: 'intel',     value: 2.0,   year: 2019, state: 'actual',   src: null,  drill: 'habana-exit',        tip: 'Habana → Intel · $2B · 2019' },
      { from: 'Graphcore',   gen: 'g3', to: 'softbank',  value: 0.6,   year: 2024, state: 'estimate', src: null,  drill: 'graphcore-exit',     tip: 'Graphcore → SoftBank · ≈$0.6B reported · 2024' },
      { from: 'Groq',        gen: 'g3', to: 'licensing', value: null,  year: 2025, state: 'estimate', src: null,  drill: 'groq-licensing',     tip: 'Groq → NVIDIA non-exclusive license (Dec 2025; ≈$20B CNBC-reported, unconfirmed) · remnant independent' },
      { from: 'Cerebras',    gen: 'g3', to: 'public',    value: 5.5,   year: 2026, state: 'actual',   src: null,  drill: 'cerebras-ipo',       tip: 'Cerebras → Nasdaq IPO (May 2026) · $185/share, ≈$5.5B raised · CBRS' },
      { from: 'Wave Computing', gen: 'g3', to: 'globalfoundries', value: null, year: 2025, state: 'derived', src: null, drill: 'wave-exit',      tip: 'Wave Computing → Chapter 11 (2020), emerged as MIPS (2021) → GlobalFoundries (Aug 2025) · terms undisclosed' },
      { from: 'Flex Logix',  gen: 'g3', to: 'analog',    value: null,  year: 2024, state: 'derived',  src: null,  drill: 'flexlogix-exit',     tip: 'Flex Logix → technology assets + team to Analog Devices (Nov 2024) · terms undisclosed' },
      { from: 'SambaNova',   gen: 'g3', to: 'survived',  value: null,  year: null, state: 'derived',  src: null,  drill: 'sambanova-status',   tip: 'SambaNova · independent · $1B Series F at $11B (Jul 2026)' },
      { from: 'Tenstorrent', gen: 'g3', to: 'survived',  value: null,  year: null, state: 'derived',  src: null,  drill: 'tenstorrent-status', tip: 'Tenstorrent · independent · Qualcomm rumor denied (Jun 2026)' },
      { from: 'SiFive',      gen: 'g3', to: 'survived',  value: null,  year: null, state: 'derived',  src: null,  drill: 'sifive-status',      tip: 'SiFive · independent (pre-IPO)' },
      { from: 'Mythic',      gen: 'g3', to: 'survived',  value: null,  year: null, state: 'derived',  src: null,  drill: 'mythic-status',      tip: 'Mythic · independent · revived with $125M (Dec 2025)' }
    ]
  };

  /* ------------------------------------------------------------------ *
   * miningEvents — the mining mirror, 2017–2022 (#mining-chart).
   * Two crypto cycles, each traced price peak → panic ordering →
   * inventory clearing; plus the 55nm→16nm ASIC process race and the
   * three named shocks (NVIDIA / Alchip / GUC).
   * ------------------------------------------------------------------ */
  D.miningEvents = {
    meta: {
      note: 'Crypto incubated custom silicon, then crashed it twice. The same demand→orders→clearing mechanism at 2× speed.',
      unit: 'US$',
      drill: 'mining-mirror'
    },
    cycles: [
      {
        id: 'cycle-1', name: 'Cycle 1 · 2017–2019',
        phases: [
          { phase: 'price-peak',         date: '2017-12', label: 'BTC ≈ $19.7k', value: 19700, state: 'actual',  src: null,  drill: 'mining-cycle-1', tip: 'Dec 2017 · BTC peaks near $19.7k' },
          { phase: 'panic-ordering',     date: '2018-Q1', label: '16nm mining-ASIC orders surge; foundry slots booked NCNR', value: null, state: 'derived', src: null, drill: 'mining-asic-race', tip: '2018 · panic ordering at 16nm' },
          { phase: 'inventory-clearing', date: '2018-Q4', label: 'ASIC inventory write-downs; Alchip sawtooth begins', value: null, state: 'derived', src: 'K37', drill: 'alchip-sawtooth',  tip: '2018Q4–2019 · clearing wave' }
        ]
      },
      {
        id: 'cycle-2', name: 'Cycle 2 · 2020–2022',
        phases: [
          { phase: 'price-peak',         date: '2021-11', label: 'BTC ≈ $69k · ETH ≈ $4.8k', value: 69000, state: 'actual',  src: null,  drill: 'mining-cycle-2', tip: 'Nov 2021 · BTC peaks near $69k' },
          { phase: 'panic-ordering',     date: '2021',    label: 'GPU scarcity; CMP hedge parts; 5nm mining designs tape out', value: null, state: 'derived', src: null, drill: 'mining-asic-race', tip: '2021 · panic ordering at 5nm' },
          { phase: 'inventory-clearing', date: '2022-09', label: 'Ethereum merge ends GPU mining; used-card glut', value: null, state: 'derived', src: 'K36', drill: 'nvda-crypto',      tip: 'Sep 2022 · the Merge clears the GPU channel' }
        ]
      }
    ],
    asicRace: [
      { node: '55nm', year: 2013, state: 'derived', note: 'first dedicated SHA-256 ASICs' },
      { node: '28nm', year: 2014, state: 'derived', note: 'second generation; power race begins' },
      { node: '16nm', year: 2016, state: 'derived', note: 'FinFET miners; Bitmain S9 class' },
      { node: '7nm',  year: 2018, state: 'derived', note: 'leading-edge miners arrive with phones' },
      { node: '5nm',  year: 2021, state: 'derived', note: 'mining designs on the same node as flagship SoCs' }
    ],
    shocks: [
      { entity: 'NVIDIA', date: '2018-Q4', text: 'Crypto hangover: gaming revenue −45% YoY in Q4 FY19; channel inventory correction wipes two quarters of growth.', state: 'derived', src: 'K36', drill: 'nvda-crypto',      tip: 'NVIDIA · Q4 FY19 gaming −45% YoY' },
      { entity: 'Alchip', date: '2019',    text: 'Crypto-ASIC demand collapses; quarterly revenue sawtooths from NT$2.35B (4Q17) to NT$0.62B (1Q19) before recovering.', state: 'estimate', src: 'K37', drill: 'alchip-sawtooth', tip: 'Alchip · the sawtooth, 1Q17–4Q19' },
      { entity: 'GUC',    date: '2018–2019', text: 'Mining NRE boom fades; revenue mix reverts to networking and early AI programs.', state: 'derived', src: 'K27', drill: 'guc-q',           tip: 'GUC · the mining NRE fade' }
    ]
  };

  /* ------------------------------------------------------------------ *
   * alchipQuarterly — Alchip (3661.TW) quarterly revenue, 1Q17–4Q19
   * (#sawtooth-alchip-chart). Unit NT$M. The crypto sawtooth:
   * NT$2,350M (4Q17) → NT$620M (1Q19) → NT$1,420M (4Q19).
   * Quarterly splits are interpolations of disclosed annual figures —
   * state 'estimate' with annual anchors state 'derived'.
   * ------------------------------------------------------------------ */
  D.alchipQuarterly = {
    meta: {
      company: 'Alchip', ticker: '3661.TW',
      unit: 'NT$M', fmt: 'int',
      src: 'K37',
      note: 'Quarterly revenue 1Q17–4Q19. The crypto cycle in one company.',
      drill: 'alchip-q'
    },
    annual: [
      { year: 2017, value: 6900, unit: 'NT$M', fmt: 'int', state: 'derived',  src: 'K37' },
      { year: 2018, value: 5240, unit: 'NT$M', fmt: 'int', state: 'derived',  src: 'K37' },
      { year: 2019, value: 3870, unit: 'NT$M', fmt: 'int', state: 'derived',  src: 'K37' }
    ],
    points: [
      { q: '1Q17', year: 2017, value: 1150, state: 'estimate', drill: 'alchip-q', tip: 'Alchip 1Q17 · ≈NT$1,150M' },
      { q: '2Q17', year: 2017, value: 1420, state: 'estimate', drill: 'alchip-q', tip: 'Alchip 2Q17 · ≈NT$1,420M' },
      { q: '3Q17', year: 2017, value: 1980, state: 'estimate', drill: 'alchip-q', tip: 'Alchip 3Q17 · ≈NT$1,980M — the ramp' },
      { q: '4Q17', year: 2017, value: 2350, state: 'estimate', drill: 'alchip-q', tip: 'Alchip 4Q17 · ≈NT$2,350M — cycle peak' },
      { q: '1Q18', year: 2018, value: 2020, state: 'estimate', drill: 'alchip-q', tip: 'Alchip 1Q18 · ≈NT$2,020M' },
      { q: '2Q18', year: 2018, value: 1480, state: 'estimate', drill: 'alchip-q', tip: 'Alchip 2Q18 · ≈NT$1,480M — rolling over' },
      { q: '3Q18', year: 2018, value: 980,  state: 'estimate', drill: 'alchip-q', tip: 'Alchip 3Q18 · ≈NT$980M' },
      { q: '4Q18', year: 2018, value: 760,  state: 'estimate', drill: 'alchip-q', tip: 'Alchip 4Q18 · ≈NT$760M — clearing' },
      { q: '1Q19', year: 2019, value: 620,  state: 'estimate', drill: 'alchip-q', tip: 'Alchip 1Q19 · ≈NT$620M — the trough' },
      { q: '2Q19', year: 2019, value: 780,  state: 'estimate', drill: 'alchip-q', tip: 'Alchip 2Q19 · ≈NT$780M' },
      { q: '3Q19', year: 2019, value: 1050, state: 'estimate', drill: 'alchip-q', tip: 'Alchip 3Q19 · ≈NT$1,050M — AI programs return' },
      { q: '4Q19', year: 2019, value: 1420, state: 'estimate', drill: 'alchip-q', tip: 'Alchip 4Q19 · ≈NT$1,420M — recovery' }
    ]
  };

  /* ------------------------------------------------------------------ *
   * gucQuarterly — GUC (3443.TW) quarterly revenue, 1Q17–4Q24
   * (#sawtooth-guc-chart). Unit NT$M. Mining-NRE sawtooth 2018–2019,
   * then the AI program ladder. Quarterly splits interpolated from
   * disclosed annuals: 2017–2019 'estimate', 2020+ 'derived'.
   * ------------------------------------------------------------------ */
  D.gucQuarterly = {
    meta: {
      company: 'GUC', ticker: '3443.TW',
      unit: 'NT$M', fmt: 'int',
      src: 'K27',
      note: 'Quarterly revenue 2017–2024. The same sawtooth, a longer ladder.',
      drill: 'guc-q'
    },
    annual: [
      { year: 2017, value: 11600, unit: 'NT$M', fmt: 'int', state: 'derived', src: 'K27' },
      { year: 2018, value: 12000, unit: 'NT$M', fmt: 'int', state: 'derived', src: 'K27' },
      { year: 2019, value: 10800, unit: 'NT$M', fmt: 'int', state: 'derived', src: 'K27' },
      { year: 2020, value: 14500, unit: 'NT$M', fmt: 'int', state: 'derived', src: 'K27' },
      { year: 2021, value: 21300, unit: 'NT$M', fmt: 'int', state: 'derived', src: 'K27' },
      { year: 2022, value: 27600, unit: 'NT$M', fmt: 'int', state: 'derived', src: 'K27' },
      { year: 2023, value: 25500, unit: 'NT$M', fmt: 'int', state: 'derived', src: 'K27' },
      { year: 2024, value: 24900, unit: 'NT$M', fmt: 'int', state: 'derived', src: 'K27' }
    ],
    points: (function () {
      var years = {
        2017: { v: [2600, 2800, 3100, 3100], s: 'estimate' },
        2018: { v: [3400, 3300, 2800, 2500], s: 'estimate' },
        2019: { v: [2400, 2500, 2900, 3000], s: 'estimate' },
        2020: { v: [3200, 3500, 3800, 4000], s: 'derived' },
        2021: { v: [4500, 5000, 5600, 6200], s: 'derived' },
        2022: { v: [6500, 6800, 7000, 7300], s: 'derived' },
        2023: { v: [6800, 6400, 6100, 6200], s: 'derived' },
        2024: { v: [6000, 6100, 6300, 6500], s: 'derived' }
      };
      var out = [];
      Object.keys(years).forEach(function (y) {
        years[y].v.forEach(function (v, i) {
          out.push({
            q: (i + 1) + 'Q' + String(y).slice(2),
            year: +y,
            value: v,
            state: years[y].s,
            drill: 'guc-q',
            tip: 'GUC ' + (i + 1) + 'Q' + String(y).slice(2) + ' · ≈NT$' + v.toLocaleString('en-US') + 'M'
          });
        });
      });
      return out;
    })()
  };

  /* ------------------------------------------------------------------ *
   * capexByCompany — Top-4 hyperscaler capex, 2021–2026E
   * (#capex3d-chart). Unit US$B. Solid = reported/derived, outline =
   * estimate, hatched = 2025, dashed = 2026E forecast range.
   * Totals pin to the register: 2025 = $412.9B (K14);
   * 2026E guidance = $695–725B (K15).
   * ------------------------------------------------------------------ */
  D.capexByCompany = {
    meta: {
      unit: 'US$B', fmt: 'moneyB',
      years: [2021, 2022, 2023, 2024, 2025, 2026],
      note: 'Top-4 hyperscalers: Amazon, Alphabet, Meta, Microsoft. 2026E carries a low/high guidance range.',
      cohort: 'Amazon, Alphabet, Meta, Microsoft (Top-4 hyperscalers)',
      periodBasis: 'Calendar years; Microsoft calendarized from fiscal-year reporting. 2026 values are company guidance — Alphabet, Amazon and Meta are calendar-year figures; Microsoft’s ≈$190B is explicitly calendar-2026.',
      classification: '2021–2024 reported/derived from filings; 2025 compiled estimate (FT tally ≈$410B; per-company sum ≈$413.3B — the $412.9B figure is a compiled estimate, not a reported aggregate); 2026 company guidance (Q1-2026 earnings, Apr 29–30 2026).',
      srcSet: ['K5', 'K14', 'K15'],
      drill: 'top4-2025',
      totals: {
        2021: 123.4, 2022: 150.0, 2023: 154.3, 2024: 250.5,
        2025: 412.9,
        2026: { low: 695.0, high: 725.0, mid: 710.0 }
      },
      totalsMeta: {
        2025: { state: 'estimate', note: 'compiled estimate ≈$410–413B — no single reported aggregate (FT tally ≈$410B; per-company sum ≈$413.3B)' },
        2026: { state: 'guidance', note: 'Amazon ≈$200B + Microsoft ≈$190B (CY2026) + Alphabet $180–190B + Meta $125–145B → $695–725B combined' }
      }
    },
    companies: [
      {
        id: 'amzn', name: 'Amazon', color: '#b07a10',
        annual: [
          { year: 2021, value: 55.4,  state: 'derived',  src: 'K5', drill: 'capex-history', tip: 'Amazon capex 2021 · ≈$55.4B' },
          { year: 2022, value: 59.0,  state: 'derived',  src: 'K5', drill: 'capex-history', tip: 'Amazon capex 2022 · ≈$59.0B' },
          { year: 2023, value: 52.7,  state: 'derived',  src: 'K5', drill: 'capex-history', tip: 'Amazon capex 2023 · ≈$52.7B' },
          { year: 2024, value: 83.0,  state: 'derived',  src: 'K5', drill: 'capex-history', tip: 'Amazon capex 2024 · ≈$83.0B' },
          { year: 2025, value: 125.0, state: 'estimate', src: 'K5', drill: 'top4-2025',     tip: 'Amazon capex 2025 · ≈$125B' },
          { year: 2026, value: 200.0, low: 200.0, high: 200.0, state: 'forecast', src: 'K5', drill: 'top4-2026e', tip: 'Amazon capex 2026E · ≈$200B guided (calendar year)' }
        ]
      },
      {
        id: 'msft', name: 'Microsoft', color: '#2251ff',
        annual: [
          { year: 2021, value: 24.2,  state: 'derived',  src: 'K5', drill: 'capex-history', tip: 'Microsoft capex 2021 · ≈$24.2B' },
          { year: 2022, value: 28.1,  state: 'derived',  src: 'K5', drill: 'capex-history', tip: 'Microsoft capex 2022 · ≈$28.1B' },
          { year: 2023, value: 41.2,  state: 'derived',  src: 'K5', drill: 'capex-history', tip: 'Microsoft capex 2023 · ≈$41.2B' },
          { year: 2024, value: 75.8,  state: 'derived',  src: 'K5', drill: 'capex-history', tip: 'Microsoft capex 2024 · ≈$75.8B' },
          { year: 2025, value: 115.0, state: 'estimate', src: 'K5', drill: 'top4-2025',     tip: 'Microsoft capex 2025 · ≈$115B' },
          { year: 2026, value: 190.0, low: 190.0, high: 190.0, state: 'forecast', src: 'K5', drill: 'top4-2026e', tip: 'Microsoft capex 2026E · ≈$190B guided (explicitly calendar-2026)' }
        ]
      },
      {
        id: 'googl', name: 'Alphabet', color: '#008a6d',
        annual: [
          { year: 2021, value: 24.6,  state: 'derived',  src: 'K5', drill: 'capex-history', tip: 'Alphabet capex 2021 · ≈$24.6B' },
          { year: 2022, value: 31.5,  state: 'derived',  src: 'K5', drill: 'capex-history', tip: 'Alphabet capex 2022 · ≈$31.5B' },
          { year: 2023, value: 32.3,  state: 'derived',  src: 'K5', drill: 'capex-history', tip: 'Alphabet capex 2023 · ≈$32.3B' },
          { year: 2024, value: 52.5,  state: 'derived',  src: 'K5', drill: 'capex-history', tip: 'Alphabet capex 2024 · ≈$52.5B' },
          { year: 2025, value: 103.0, state: 'estimate', src: 'K5', drill: 'top4-2025',     tip: 'Alphabet capex 2025 · ≈$103B' },
          { year: 2026, value: 185.0, low: 180.0, high: 190.0, state: 'forecast', src: 'K5', drill: 'top4-2026e', tip: 'Alphabet capex 2026E · $180–190B guided' }
        ]
      },
      {
        id: 'meta', name: 'Meta', color: '#7a45c9',
        annual: [
          { year: 2021, value: 19.2,  state: 'derived',  src: 'K5', drill: 'capex-history', tip: 'Meta capex 2021 · ≈$19.2B' },
          { year: 2022, value: 31.4,  state: 'derived',  src: 'K5', drill: 'capex-history', tip: 'Meta capex 2022 · ≈$31.4B' },
          { year: 2023, value: 28.1,  state: 'derived',  src: 'K5', drill: 'capex-history', tip: 'Meta capex 2023 · ≈$28.1B' },
          { year: 2024, value: 39.2,  state: 'derived',  src: 'K5', drill: 'capex-history', tip: 'Meta capex 2024 · ≈$39.2B' },
          { year: 2025, value: 69.9,  state: 'estimate', src: 'K5', drill: 'top4-2025',     tip: 'Meta capex 2025 · ≈$69.9B' },
          { year: 2026, value: 135.0, low: 125.0, high: 145.0, state: 'forecast', src: 'K5', drill: 'top4-2026e', tip: 'Meta capex 2026E · $125–145B guided' }
        ]
      }
    ]
  };

  /* ------------------------------------------------------------------ *
   * operatingCashFlow — Top-4 operating cash flow, 2021–2026E (US$B).
   * Pairs with capexByCompany in #capex3d-chart; aggregated in
   * capexStairs for the ratio chart.
   * ------------------------------------------------------------------ */
  D.operatingCashFlow = {
    meta: {
      unit: 'US$B', fmt: 'moneyB',
      years: [2021, 2022, 2023, 2024, 2025, 2026],
      note: 'Operating cash flow, Top-4 hyperscalers. 2025 estimate; the 2026E total of ≈$587B is a working estimate — no public consensus aggregate exists.',
      cohort: 'Amazon, Alphabet, Meta, Microsoft (same cohort as capexByCompany)',
      periodBasis: 'Calendar years; Microsoft calendarized.',
      classification: '2021–2024 reported from cash-flow statements; 2025 estimate; 2026E working estimate (no public consensus aggregate).',
      drill: 'ocf-top4',
      totals: { 2021: 272.4, 2022: 278.8, 2023: 345.3, 2024: 450.9, 2025: 513.0, 2026: 587.0 }
    },
    companies: [
      { id: 'amzn', name: 'Amazon', annual: [
        { year: 2021, value: 46.3,  state: 'derived',  src: 'K29', tip: 'Amazon OCF 2021 · ≈$46.3B' },
        { year: 2022, value: 46.8,  state: 'derived',  src: 'K29', tip: 'Amazon OCF 2022 · ≈$46.8B' },
        { year: 2023, value: 84.9,  state: 'derived',  src: 'K29', tip: 'Amazon OCF 2023 · ≈$84.9B' },
        { year: 2024, value: 115.9, state: 'derived',  src: 'K29', tip: 'Amazon OCF 2024 · ≈$115.9B' },
        { year: 2025, value: 132.0, state: 'estimate', src: 'K29', tip: 'Amazon OCF 2025E · ≈$132B' },
        { year: 2026, value: 150.0, state: 'forecast', src: 'K29', tip: 'Amazon OCF 2026E · ≈$150B' }
      ] },
      { id: 'msft', name: 'Microsoft', annual: [
        { year: 2021, value: 76.7,  state: 'derived',  src: 'K29', tip: 'Microsoft OCF 2021 · ≈$76.7B' },
        { year: 2022, value: 89.0,  state: 'derived',  src: 'K29', tip: 'Microsoft OCF 2022 · ≈$89.0B' },
        { year: 2023, value: 87.6,  state: 'derived',  src: 'K29', tip: 'Microsoft OCF 2023 · ≈$87.6B' },
        { year: 2024, value: 118.5, state: 'derived',  src: 'K29', tip: 'Microsoft OCF 2024 · ≈$118.5B' },
        { year: 2025, value: 136.0, state: 'estimate', src: 'K29', tip: 'Microsoft OCF 2025E · ≈$136B' },
        { year: 2026, value: 160.0, state: 'forecast', src: 'K29', tip: 'Microsoft OCF 2026E · ≈$160B' }
      ] },
      { id: 'googl', name: 'Alphabet', annual: [
        { year: 2021, value: 91.7,  state: 'derived',  src: 'K29', tip: 'Alphabet OCF 2021 · ≈$91.7B' },
        { year: 2022, value: 91.5,  state: 'derived',  src: 'K29', tip: 'Alphabet OCF 2022 · ≈$91.5B' },
        { year: 2023, value: 101.7, state: 'derived',  src: 'K29', tip: 'Alphabet OCF 2023 · ≈$101.7B' },
        { year: 2024, value: 125.2, state: 'derived',  src: 'K29', tip: 'Alphabet OCF 2024 · ≈$125.2B' },
        { year: 2025, value: 145.0, state: 'estimate', src: 'K29', tip: 'Alphabet OCF 2025E · ≈$145B' },
        { year: 2026, value: 165.0, state: 'forecast', src: 'K29', tip: 'Alphabet OCF 2026E · ≈$165B' }
      ] },
      { id: 'meta', name: 'Meta', annual: [
        { year: 2021, value: 57.7,  state: 'derived',  src: 'K29', tip: 'Meta OCF 2021 · ≈$57.7B' },
        { year: 2022, value: 50.5,  state: 'derived',  src: 'K29', tip: 'Meta OCF 2022 · ≈$50.5B' },
        { year: 2023, value: 71.1,  state: 'derived',  src: 'K29', tip: 'Meta OCF 2023 · ≈$71.1B' },
        { year: 2024, value: 91.3,  state: 'derived',  src: 'K29', tip: 'Meta OCF 2024 · ≈$91.3B' },
        { year: 2025, value: 100.0, state: 'estimate', src: 'K29', tip: 'Meta OCF 2025E · ≈$100B' },
        { year: 2026, value: 112.0, state: 'forecast', src: 'K29', tip: 'Meta OCF 2026E · ≈$112B' }
      ] }
    ]
  };

  /* ------------------------------------------------------------------ *
   * capexStairs — OCF line and capex/OCF ratio stairs
   * (#capex-stairs-chart). Thresholds: 0.8 caution, 1.0 binding.
   * Ratio = aggregate Top-4 capex ÷ aggregate Top-4 OCF.
   * ------------------------------------------------------------------ */
  D.capexStairs = {
    meta: {
      unit: 'ratio', fmt: 'ratio',
      src: 'K29',
      note: 'Capex/OCF, Top-4 aggregate (Amazon, Alphabet, Meta, Microsoft; calendar-year basis, Microsoft calendarized). Above 0.8 the cycle is on caution; above 1.0, on these estimates, aggregate capex would exceed aggregate operating cash flow — increasing dependence on balance-sheet liquidity, external financing, or reductions in other cash uses. A ratio above 1.0 does not by itself prove that every marginal dollar is financed rather than earned.',
      cohort: 'Amazon, Alphabet, Meta, Microsoft',
      ocfNote: '2026E OCF ≈$587B is a working estimate — no public consensus aggregate exists.',
      capexNote: '2026E capex $695–725B is company guidance (Q1-2026 earnings, Apr 29–30 2026); 2025 capex ≈$410–413B is a compiled estimate.',
      drill: 'ocf-stress',
      thresholds: [
        { value: 0.8, label: 'caution', color: '#b07a10' },
        { value: 1.0, label: 'binding', color: '#c22f4e' }
      ]
    },
    annual: [
      { year: 2021, capex: 123.4, ocf: 272.4, ratio: 0.45, state: 'derived',  src: 'K29', drill: 'ocf-stress', tip: '2021 · capex/OCF 0.45 (reported)' },
      { year: 2022, capex: 150.0, ocf: 278.8, ratio: 0.54, state: 'derived',  src: 'K29', drill: 'ocf-stress', tip: '2022 · capex/OCF 0.54 (reported)' },
      { year: 2023, capex: 154.3, ocf: 345.3, ratio: 0.45, state: 'derived',  src: 'K29', drill: 'ocf-stress', tip: '2023 · capex/OCF 0.45 (reported)' },
      { year: 2024, capex: 250.5, ocf: 450.9, ratio: 0.56, state: 'derived',  src: 'K29', drill: 'ocf-stress', tip: '2024 · capex/OCF 0.56 (reported)' },
      { year: 2025, capex: 412.9, ocf: 513.0, ratio: 0.80, state: 'estimate', src: 'K29', drill: 'ocf-stress', tip: '2025 · capex/OCF 0.80 — the caution line (capex is a compiled estimate ≈$410–413B)' },
      { year: 2026, capex: 710.0, capexLow: 695.0, capexHigh: 725.0, ocf: 587.0, ratio: 1.21, ratioLow: 1.18, ratioHigh: 1.24, ratioMid: 1.21, state: 'estimate', src: 'K29', drill: 'ocf-stress', tip: '2026E · capex/OCF 1.21 midpoint (range 1.18–1.24) — past the binding line; capex is guidance, OCF a working estimate' }
    ]
  };

  /* ------------------------------------------------------------------ *
   * tsmcRevenueShare — TSMC AI-accelerator revenue, GPU camp vs ASIC
   * camp (#revenue-split-chart). 2027F ≈ 66% GPU / 34% ASIC (K8).
   * gpu/asic are shares of `total` (sum to 1.0).
   * ------------------------------------------------------------------ */
  D.tsmcRevenueShare = {
    meta: {
      unit: 'US$B', fmt: 'moneyB',
      src: 'K8',
      basis: 'TSMC AI-accelerator revenue attribution',
      camps: { gpu: 'GPU camp · NVIDIA/AMD merchant', asic: 'ASIC camp · cloud in-house XPUs' },
      note: 'The ASIC camp’s share of TSMC AI revenue rises to ≈34% in 2027F — a third-party attribution read on foundry revenue. This is NOT the global accelerator-dollar share (Series A, see DATA.penetrationByBasis); the two series measure different denominators and are never interchangeable.',
      seriesMeta: {
        seriesId: 'B',
        metricName: 'TSMC AI-accelerator revenue attribution — GPU camp vs ASIC camp share',
        numerator: 'TSMC AI-accelerator revenue attributed to custom-ASIC programs',
        denominator: 'TSMC total AI-accelerator revenue (AI GPU + AI ASIC + HBM controllers)',
        geography: 'global (TSMC manufacturing revenue, all customers)',
        companyScope: 'all TSMC AI-accelerator customers, grouped by chip type',
        historyVsForecast: '2023–2024 derived estimates · 2025 estimate · 2026–2028 forecasts',
        measuresWhat: 'share of TSMC AI-accelerator revenue by camp — a foundry-revenue attribution; NOT the global accelerator-dollar share (Series A)',
        attributionWarning: 'THIRD-PARTY attribution estimate — TSMC does NOT publish a GPU-vs-ASIC split (analysts declined to provide one). Official TSMC framing: AI-accelerator revenue = high-teens % of total 2025 revenue, roughly doubled in 2025, CAGR mid-to-high-50s % 2024–2029; HPC = 66% of Q2-2026 revenue (2026-07-16).',
        totalsNote: 'absolute US$B totals are derived working estimates consistent with the official framing; the camp split itself is third-party attribution',
        source: 'compiled third-party attribution models (access limited); official TSMC framing from quarterly results',
        sourceDate: '2026-07-16'
      },
      drill: 'tsmc-split'
    },
    annual: [
      { year: 2023, total: 8,  gpu: 0.92, asic: 0.08, state: 'derived',  src: 'K8', drill: 'tsmc-split', tip: '2023 · ≈$8B · GPU 92% / ASIC 8%' },
      { year: 2024, total: 15, gpu: 0.88, asic: 0.12, state: 'derived',  src: 'K8', drill: 'tsmc-split', tip: '2024 · ≈$15B · GPU 88% / ASIC 12%' },
      { year: 2025, total: 30, gpu: 0.80, asic: 0.20, state: 'estimate', src: 'K8', drill: 'tsmc-split', tip: '2025E · ≈$30B · GPU 80% / ASIC 20%' },
      { year: 2026, total: 45, gpu: 0.72, asic: 0.28, state: 'forecast', src: 'K8', drill: 'tsmc-split', tip: '2026F · ≈$45B · GPU 72% / ASIC 28%' },
      { year: 2027, total: 60, gpu: 0.66, asic: 0.34, state: 'forecast', src: 'K8', drill: 'tsmc-split', tip: '2027F · ≈$60B · GPU 66% / ASIC 34%' },
      { year: 2028, total: 75, gpu: 0.62, asic: 0.38, state: 'forecast', src: 'K8', drill: 'tsmc-split', tip: '2028F · ≈$75B · GPU 62% / ASIC 38%' }
    ]
  };

  /* ------------------------------------------------------------------ *
   * perGwEconomics — one-gigawatt economics (#pergw-chart, SVG viewBox
   * 0 0 732 300). Basis: GB200 NVL72-class racks at ≈120kW.
   * Chain: 1GW → racks → accelerator packages → compute dies; ASP;
   * all-in capex; TSMC revenue captured per GW.
   * ------------------------------------------------------------------ */
  D.perGwEconomics = {
    meta: {
      unit: 'per 1GW AI datacenter',
      viewBox: [732, 300],
      basis: 'GB200 NVL72-class racks at ≈120kW each',
      src: null,
      note: 'One gigawatt, decomposed: what the cloud orders, what TSMC books.',
      drill: 'pergw-dies'
    },
    blocks: [
      { id: 'racks',        label: 'racks',                 value: 8333,    unit: 'count', fmt: 'int',    state: 'derived',  src: null,  drill: 'pergw-dies',  tip: '1GW ÷ ≈120kW per NVL72-class rack ≈ 8,300 racks' },
      { id: 'accelerators', label: 'accelerator packages',  value: 600000,  unit: 'count', fmt: 'int',    state: 'derived',  src: null,  drill: 'pergw-dies',  tip: '≈72 accelerators per rack × 8,300 racks ≈ 600k packages' },
      { id: 'dies',         label: 'compute dies',          value: 1200000, unit: 'count', fmt: 'int',    state: 'derived',  src: null,  drill: 'pergw-dies',  tip: '2 reticle dies per Blackwell-class package ≈ 1.2M dies' },
      { id: 'unitPrice',    label: 'accelerator ASP',       value: 35000,   unit: 'US$',   fmt: 'moneyK', state: 'estimate', src: null,  drill: 'pergw-price', tip: '≈$35k per Blackwell-class accelerator (estimate)' },
      { id: 'capex',        label: 'all-in capex per GW',   value: 50,      unit: 'US$B',  fmt: 'moneyB', state: 'estimate', src: null,  drill: 'pergw-capex', tip: '≈$50B all-in per GW: silicon, systems, power, buildings' },
      { id: 'tsmc',         label: 'TSMC revenue per GW',   value: 2.1,     unit: 'US$B',  fmt: 'moneyB', state: 'derived',  src: 'K21', drill: 'pergw-tsmc',  tip: 'logic wafers + CoWoS + interposer ≈ $3.5k per package × 600k' }
    ]
  };

})(window.DATA);
