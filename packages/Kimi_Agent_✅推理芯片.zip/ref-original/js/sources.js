/**
 * js/sources.js — K-REGISTER + EVIDENCE ANCHORS (spec §11)
 * Forty-Two Years of Inference Silicon · core layer
 *
 * 1. Renders the K1–K41 appendix register rows into #kreg-body from
 *    DATA.sources — the full audit table: K · fact · value · class pill ·
 *    type (classification) · scope · period · institution · title link ·
 *    citation/date · formula · notes · state. The wrapper
 *    (.table-scroll.kreg-scroll) scrolls horizontally; long note cells
 *    clamp at two lines.
 * 2. Wires every inline evidence button `.ev[data-src]` to the drill
 *    card (event delegation on document — one listener for the whole
 *    page, so it also covers buttons injected later by charts).
 *
 *   window.SOURCES = { init() }
 */
window.SOURCES = (function () {
  'use strict';

  var STATE_LABELS = {
    derived: 'derived', estimate: 'estimate', forecast: 'forecast',
    actual: 'actual', gap: 'gap'
  };

  function renderRegister() {
    var body = document.getElementById('kreg-body');
    if (!body) return;
    var D = window.DATA || {};
    var rows = D.sources || [];
    body.textContent = '';
    if (!rows.length) {
      var tr0 = document.createElement('tr');
      tr0.className = 'kreg-placeholder';
      var td0 = document.createElement('td');
      td0.colSpan = 13;
      td0.textContent = 'The evidence register is unavailable (DATA.sources missing).';
      tr0.appendChild(td0);
      body.appendChild(tr0);
      return;
    }
    var frag = document.createDocumentFragment();
    for (var i = 0; i < rows.length; i++) {
      var s = rows[i];
      if (!s) continue;
      var tr = document.createElement('tr');
      tr.id = 'kreg-' + s.key;
      /* plain row (a11y diet): NOT a button, NOT a Tab stop — mouse
         users can still click the row to open its evidence card */
      tr.className = 'k-row';
      tr.setAttribute('data-src', s.key);
      tr.setAttribute('title', 'Open evidence card for ' + s.key);
      tr.style.cursor = 'pointer';

      /* K number + drill affordance (decorative glyph, not a control) */
      var tdK = document.createElement('td');
      tdK.className = 'k-k';
      tdK.appendChild(document.createTextNode(s.key));
      var glyph = document.createElement('span');
      glyph.className = 'ev';
      glyph.setAttribute('aria-hidden', 'true');
      glyph.textContent = '◆';
      tdK.appendChild(glyph);
      tr.appendChild(tdK);

      var tdFact = document.createElement('td');
      tdFact.textContent = s.factName || '';
      tr.appendChild(tdFact);

      var tdVal = document.createElement('td');
      tdVal.className = 'k-val';
      tdVal.textContent = s.value || '';
      tr.appendChild(tdVal);

      /* source-class pill: kimi blue · broker copper · company green ·
         industry violet (colors via .sc in css/style.css) */
      var tdCls = document.createElement('td');
      var pill = document.createElement('span');
      pill.className = 'sc ' + (s.sourceClass || 'kimi');
      pill.textContent = window.UTILS
        ? window.UTILS.classLabel(s.sourceClass)
        : (s.sourceClass || '');
      tdCls.appendChild(pill);
      tr.appendChild(tdCls);

      /* estimate-type pill: reported blue · guidance copper · estimate
         grey · derived violet · scenario red-outline (.clsf in style.css) */
      var tdType = document.createElement('td');
      var tp = document.createElement('span');
      var cls = (s.classification || 'estimate').toLowerCase();
      tp.className = 'clsf ' + cls;
      tp.textContent = cls;
      tdType.appendChild(tp);
      tr.appendChild(tdType);

      var tdScope = document.createElement('td');
      tdScope.className = 'k-dim';
      tdScope.textContent = s.scope || '—';
      tr.appendChild(tdScope);

      var tdPeriod = document.createElement('td');
      tdPeriod.className = 'k-dim';
      tdPeriod.textContent = s.period || '—';
      tr.appendChild(tdPeriod);

      var tdInst = document.createElement('td');
      tdInst.className = 'k-dim';
      tdInst.textContent = s.institution || '—';
      tr.appendChild(tdInst);

      /* title as an outbound link to the primary document */
      var tdTitle = document.createElement('td');
      tdTitle.className = 'k-title';
      if (s.url && s.title) {
        var a = document.createElement('a');
        a.href = s.url;
        a.rel = 'noopener';
        a.target = '_blank';
        a.textContent = s.title + ' ↗';
        tdTitle.appendChild(a);
      } else {
        tdTitle.textContent = s.title || '—';
      }
      tr.appendChild(tdTitle);

      var tdCit = document.createElement('td');
      tdCit.textContent = (s.citation || '') + (s.date ? ' · ' + s.date : '');
      tr.appendChild(tdCit);

      var tdFormula = document.createElement('td');
      tdFormula.className = 'k-formula';
      tdFormula.textContent = s.formula || '—';
      tr.appendChild(tdFormula);

      var tdNotes = document.createElement('td');
      tdNotes.className = 'k-notes';
      tdNotes.textContent = s.notes || '—';
      if (s.notes) tdNotes.setAttribute('title', s.notes);
      tr.appendChild(tdNotes);

      var tdState = document.createElement('td');
      var st = document.createElement('span');
      st.className = 'pill';
      var state = STATE_LABELS[s.state] ? s.state : 'derived';
      st.textContent = state;
      if (state === 'gap') {
        st.style.color = '#c22f4e';
        st.style.borderColor = '#c22f4e';
      }
      tdState.appendChild(st);
      tr.appendChild(tdState);

      frag.appendChild(tr);
    }
    body.appendChild(frag);
  }

  /* one delegated listener wires every ◆ evidence button on the page,
     including buttons injected into charts and signal cards later.
     The trigger element is forwarded so the drill card can restore
     focus and anchor keyboard-activated openings at the trigger. */
  function wireEvidence() {
    document.addEventListener('click', function (e) {
      var b = e.target && e.target.closest ? e.target.closest('.ev[data-src]') : null;
      if (b) {
        var key = b.getAttribute('data-src');
        if (!key || !window.UTILS || !window.UTILS.drill) return;
        e.preventDefault();
        window.UTILS.drill(key, e.clientX, e.clientY, b);
        return;
      }
      /* K-register rows are plain (mouse-only) drill triggers */
      var row = e.target && e.target.closest ? e.target.closest('#kreg-body tr.k-row[data-src]') : null;
      if (!row || !window.UTILS || !window.UTILS.drill) return;
      var rkey = row.getAttribute('data-src');
      if (rkey) window.UTILS.drill(rkey, e.clientX, e.clientY, null);
    });
  }

  var inited = false;
  return {
    init: function () {
      if (inited) return;
      inited = true;
      renderRegister();
      wireEvidence();
    },
    render: renderRegister
  };
})();
