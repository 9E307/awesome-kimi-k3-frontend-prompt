/**
 * js/data.js — CORE DATASETS
 * Forty-Two Years of Inference Silicon · data layer (spec §16)
 *
 * Namespace: window.DATA (no modules, no imports).
 *
 * Datum convention (spec §16 / CONTRACT.md):
 *   Every point object supports:  { value, state, src, unit, fmt, tip, drill }
 *     value : number or null (null = not disclosed)
 *     state : 'actual' | 'estimate' | 'forecast' | 'derived' | 'gap'
 *     src   : key into DATA.sources ('K1'..'K41'); null where the fact is a
 *             minor historical record outside the 41-fact register
 *     unit  : machine unit string ('US$B', 'US$M', 'NT$M', 'TWh', 'kwpm', ...)
 *     fmt   : display hint ('moneyB' | 'moneyM' | 'moneyK' | 'int' | 'mult' |
 *             'pct' | 'pct1' | 'ratio' | 'text')
 *     tip   : tooltip copy (hover)
 *     drill : key into DATA.drillFacts (click drill-down)
 *   Grouped datasets hoist shared fields into `meta` instead of repeating
 *   them per point.
 */
window.DATA = window.DATA || {};
(function (D) {
  'use strict';

  /* ------------------------------------------------------------------ *
   * windows — six analytic windows, 1985–2026.
   * Used by: timeline42 (shaded bands), era rail, dashboard status box,
   * matrix row labels. Era color drives band shading and rail segments.
   * ------------------------------------------------------------------ */
  D.windows = [
    {
      id: 'w1',
      years: [1985, 1995],
      name: 'The FPGA founding',
      sectionId: 'sec-w2',
      color: '#8595a6',
      judgment: 'Positioning was the strategy. Xilinx framed the FPGA as “a better ASIC” — slower per gate, faster to market — and sold time, not silicon. The variable that selected survivors was the software toolchain, not the die.',
      state: 'derived',
      src: null,
      drill: 'xc2064',
      tip: 'Window 1 · 1985–1995 · The FPGA founding'
    },
    {
      id: 'w2',
      years: [1995, 2003],
      name: 'Boom and bust',
      sectionId: 'sec-w3',
      color: '#7a45c9',
      judgment: 'One shock, four different scars. The duopoly rode optical networking up roughly 3×, then gave back −39% in a single reset. The exit grammar stayed acquisition and consolidation, not bankruptcy.',
      state: 'derived',
      src: 'K17',
      drill: 'duopoly-reset',
      tip: 'Window 2 · 1995–2003 · Boom and bust'
    },
    {
      id: 'w3',
      years: [2004, 2012],
      name: 'The quiet decade',
      sectionId: 'sec-w4',
      color: '#008a6d',
      judgment: 'Deploy first, disclose later. The first hyperscale in-house accelerators were submarines: Microsoft’s Catapult ran in production years before its 2014 paper. What was knowable at the time lagged what was true by roughly four years.',
      state: 'derived',
      src: null,
      drill: 'catapult-scale',
      tip: 'Window 3 · 2004–2012 · The quiet decade'
    },
    {
      id: 'w4',
      years: [2013, 2018],
      name: 'Ignition',
      sectionId: 'sec-w5',
      color: '#b07a10',
      judgment: 'Two answers to one exam: Google deployed the TPU in 2015 and disclosed it in 2016; Intel wrote a $16.7B check for Altera the same month. The software ecosystem — CUDA, then the frameworks — decided which answer scored.',
      state: 'derived',
      src: null,
      drill: 'tpu-deploy-2015',
      tip: 'Window 4 · 2013–2018 · Ignition'
    },
    {
      id: 'w5',
      years: [2019, 2022],
      name: 'Shortage and the M&A supercycle',
      sectionId: 'sec-w6',
      color: '#c22f4e',
      judgment: 'The timing device. NCNR orders pulled two years of demand into eighteen months; five billion-dollar deals printed in 108 days; then the inventory correction arrived on schedule. The shortest fuse in the forty-two-year record.',
      state: 'derived',
      src: null,
      drill: 'deals-108',
      tip: 'Window 5 · 2019–2022 · Shortage and the M&A supercycle'
    },
    {
      id: 'w6',
      years: [2023, 2026],
      name: 'The current cycle',
      sectionId: 'sec-w7',
      color: '#2251ff',
      judgment: 'Demand is real; the constraint migrated. NVIDIA data-center revenue ran 17.6× from Q1 FY2024 to Q1 FY2027 — twelve quarter-intervals, thirteen quarterly observations — and Top-4 capex reached ≈$413B in 2025 (compiled estimate). The working hypothesis: the profit pool now sits at the gates — HBM, CoWoS, leading-edge wafers, and the grid — rather than in the cloud (a hypothesis; comparative margin and ROIC evidence is not public).',
      state: 'estimate',
      src: 'K10',
      drill: 'nvda-dc-run',
      tip: 'Window 6 · 2023–2026 · The current cycle'
    }
  ];

  /* ------------------------------------------------------------------ *
   * eraSegments — top era rail. One segment per window; `target` is the
   * section id the rail scrolls to on click. (spec §13)
   * ------------------------------------------------------------------ */
  D.eraSegments = [
    { id: 'era-1985', label: '1985',    year: 1985, target: 'sec-w2', windowId: 'w1' },
    { id: 'era-1995', label: '1995',    year: 1995, target: 'sec-w3', windowId: 'w2' },
    { id: 'era-2004', label: '2004',    year: 2004, target: 'sec-w4', windowId: 'w3' },
    { id: 'era-2013', label: '2013',    year: 2013, target: 'sec-w5', windowId: 'w4' },
    { id: 'era-2019', label: '2019',    year: 2019, target: 'sec-w6', windowId: 'w5' },
    { id: 'era-2023', label: '2023→26', year: 2023, target: 'sec-w7', windowId: 'w6' }
  ];

  /* ------------------------------------------------------------------ *
   * timelineEvents — exactly thirteen clickable plaques on the
   * 1983–2026 wall chart (#timeline42-chart). Shape (V2):
   *   year      : numeric x position on the wall (fractional for dates)
   *   yearLabel : display label for the x position ('2022-10-07')
   *   label     : plaque title · blurb : plaque body
   *   target    : section id for scroll-through
   *   drill     : evidence-card key · src : register key or null
   *   state/tip : legacy V1 chart fields (kept for compatibility)
   * ------------------------------------------------------------------ */
  D.timelineEvents = [
    {
      year: 1984, yearLabel: '1983–84', label: 'Xilinx & Altera founded', target: 'sec-w2',
      blurb: 'Altera (1983) and Xilinx (1984) open the programmable-logic record. “A better ASIC” becomes a product category — the first window of inference silicon begins.',
      state: 'derived', src: null, drill: 'duopoly-founded',
      tip: '1983–84 · the programmable duopoly is founded'
    },
    {
      year: 1994, yearLabel: '1994', label: 'Xilinx takes the PLD crown', target: 'sec-w2',
      blurb: 'A decade in, Xilinx takes the programmable-logic crown. The duopoly grammar — two finalists, one graveyard — is set.',
      state: 'derived', src: null, drill: 'xilinx-pld-crown',
      tip: '1994 · Xilinx #1 in programmable logic'
    },
    {
      year: 2000, yearLabel: '2000', label: 'Telecom bubble peaks', target: 'sec-w3',
      blurb: 'Carrier capex crests. Optical line cards have pulled FPGA revenue to records — Xilinx $1,659M, Altera $1,377M — and the order books go quiet.',
      state: 'derived', src: null, drill: 'telecom-peak',
      tip: '2000 · the optical peak'
    },
    {
      year: 2001, yearLabel: '2001', label: 'Industry ≈−32%, duopoly ≈−39%', target: 'sec-w3',
      blurb: 'The clearing cuts the industry by roughly a third and the FPGA duopoly’s combined revenue by ≈39% in one year. Nobody dies; everybody consolidates.',
      state: 'derived', src: 'K17', drill: 'duopoly-reset',
      tip: '2001 · industry ≈−32% · duopoly ≈−39%'
    },
    {
      year: 2003, yearLabel: '2003', label: '12-million-gate FPGA', target: 'sec-w4',
      blurb: 'Programmable logic crosses into ASIC territory. The same process wave that mints merchant SoCs makes FPGAs big enough to hold real infrastructure logic.',
      state: 'derived', src: null, drill: 'fpga-12m-gates',
      tip: '2003 · the 12M-gate FPGA arrives'
    },
    {
      year: 2012, yearLabel: '2012', label: 'Microsoft wires 1,632 FPGA servers', target: 'sec-w4',
      blurb: 'Project Catapult puts a Stratix-class FPGA on every board of a 1,632-server Bing pilot — wired by the end of 2012, disclosed at ISCA 2014. The submarine era opens.',
      state: 'derived', src: null, drill: 'catapult-scale',
      tip: '2012 · Catapult deployed; disclosed 2014'
    },
    {
      year: 2015, yearLabel: '2015', label: 'Google deploys TPU v1', target: 'sec-w5',
      blurb: 'Google’s first in-house inference chip is already serving Search, Translate, and Photos traffic. The world learns about it in a May 2016 blog; the ISCA paper follows in 2017.',
      state: 'actual', src: null, drill: 'tpu-deploy-2015',
      tip: '2015 · TPU v1 in production'
    },
    {
      year: 2016, yearLabel: '2016', label: 'Intel enters/acquires into AI', target: 'sec-w5',
      blurb: 'Intel answers the same exam with its checkbook: Altera ($16.7B, 2015), then Nervana (≈$350M, 2016). The incumbent buys its way into the accelerator wave.',
      state: 'actual', src: null, drill: 'intel-ai-entry',
      tip: '2016 · Intel buys into AI'
    },
    {
      year: 2020, yearLabel: '2020', label: 'AMD bids $35B for Xilinx', target: 'sec-w6',
      blurb: 'Inside the 108-day M&A supercycle (July–October 2020) AMD bids $35B, all-stock, for the founding FPGA franchise — a deal that closes at ≈$49B in February 2022.',
      state: 'derived', src: null, drill: 'amd-xilinx-bid',
      tip: '2020 · AMD–Xilinx $35B bid'
    },
    {
      year: 2022.77, yearLabel: '2022-10-07', label: 'Peak meets export controls', target: 'sec-w6',
      blurb: 'The demand peak meets the October 7 export rules. Advanced-compute controls split the map into two spheres; neither scenario survives the partition intact.',
      state: 'actual', src: null, drill: 'export-controls-2022',
      tip: '2022-10-07 · export controls'
    },
    {
      year: 2023, yearLabel: '2023', label: 'Generative AI ignites', target: 'sec-w7',
      blurb: 'Inference stops being a workload and becomes a business. NVIDIA data-center revenue runs $4.28B (Q1 FY2024) → $75.2B (Q1 FY2027) — a 17.6× climb across twelve quarter-intervals, with no precedent in the record.',
      state: 'actual', src: 'K10', drill: 'nvda-dc-run',
      tip: '2023 · the demand shock'
    },
    {
      year: 2025, yearLabel: '2025', label: 'NVLink Fusion opens the platform', target: 'sec-w7',
      blurb: 'NVIDIA opens its interconnect to third-party custom silicon. The merchant’s answer to the second in-house wave: join the platform, keep the stack.',
      state: 'derived', src: 'K39', drill: 'nvlink-fusion',
      tip: '2025 · NVLink Fusion'
    },
    {
      year: 2026, yearLabel: '2026', label: 'Expansion confirmed, peak not reached', target: 'sec-w7',
      blurb: 'The Top-4 guide 2026 capex to $695–725B and the second in-house wave ships — Ironwood, Trainium 3, Maia 200, MTIA v3. Forty-two years in, the question is which constraint binds first.',
      state: 'forecast', src: 'K5', drill: 'peak-open-2026',
      tip: '2026 · $695–725B guided; peak not in sight'
    }
  ];

  /* ------------------------------------------------------------------ *
   * mechanismStages — the demand→clearing waveform (#mechanism-chart).
   * Exactly five stages (V2). Shape per stage:
   *   name : station name · amp : wave amplitude at the station
   *          (1.0 / 1.6 / 2.6 / 4.0 / 4.0) · desc : stage body
   *   drill: evidence-card key
   *   id/order/description/tip : legacy V1 chart fields (kept).
   * meta.drill explains the feedback edge; DATA.mechanismMeta carries
   * the feedback / amplitude / break labels for the rebuilt chart.
   * ------------------------------------------------------------------ */
  D.mechanismStages = {
    meta: {
      note: 'One wave, five stations. The cycle mechanism is identical in every window; only the binding constraint moves.',
      drill: 'mechanism-loop'
    },
    stages: [
      {
        id: 'demand', order: 1, name: 'Demand ignition', amp: 1.0,
        desc: 'Unconstrained appetite for compute. Real workloads — search ranking, optical line cards, transformer inference — establish the underlying growth line.',
        description: 'Unconstrained appetite for compute. Real workloads — search ranking, optical line cards, transformer inference — establish the underlying growth line.',
        drill: 'mech-demand', tip: 'Stage 1 · Demand ignition — the real workload line'
      },
      {
        id: 'capacity-fail', order: 2, name: 'Capacity assumptions fail', amp: 1.6,
        desc: 'Wafer starts, HBM stacks, and CoWoS slots are booked 12–24 months out against a demand line that has already moved. The supply plan is wrong on arrival.',
        description: 'Wafer starts, HBM stacks, and CoWoS slots are booked 12–24 months out against a demand line that has already moved. The supply plan is wrong on arrival.',
        drill: 'mech-capacity-fail', tip: 'Stage 2 · Capacity assumptions fail — the plan meets the slope'
      },
      {
        id: 'panic', order: 3, name: 'Panic double-ordering', amp: 2.6,
        desc: 'Under scarcity the grammar turns NCNR — non-cancellable, non-returnable — and every tier of the chain books twice to secure once. The queue becomes the demand signal.',
        description: 'Under scarcity the grammar turns NCNR — non-cancellable, non-returnable — and every tier of the chain books twice to secure once. The queue becomes the demand signal.',
        drill: 'mech-panic', tip: 'Stage 3 · Panic double-ordering — the queue becomes the signal'
      },
      {
        id: 'arrivals', order: 4, name: 'Block arrivals', amp: 4.0,
        desc: 'Capacity ordered at the peak is delivered into the trough — slabs of wafers, stacks of HBM, campuses of power landing after the demand line has turned.',
        description: 'Capacity ordered at the peak is delivered into the trough — slabs of wafers, stacks of HBM, campuses of power landing after the demand line has turned.',
        drill: 'mech-arrivals', tip: 'Stage 4 · Block arrivals — ordered at the peak, delivered into the trough'
      },
      {
        id: 'clearing', order: 5, name: 'Clearing', amp: 4.0,
        desc: 'Excess works off through write-downs, cancellations, and consolidation. In this industry the clearing grammar has favored acquisition and consolidation; bankruptcy-law restructuring is rare but not absent (Wave Computing, Chapter 11, 2020).',
        description: 'Excess works off through write-downs, cancellations, and consolidation. In this industry the clearing grammar has favored acquisition and consolidation; bankruptcy-law restructuring is rare but not absent (Wave Computing, Chapter 11, 2020).',
        drill: 'mech-clearing', tip: 'Stage 5 · Clearing — acquisition, not bankruptcy'
      }
    ]
  };

  /* Labels for the rebuilt mechanism chart (V2). */
  D.mechanismMeta = {
    feedbackLabel: 'R&D holds through the trough → the next technology base (300mm → EUV → HBM/CoWoS) → re-ignition',
    ampNote: 'amplification →',
    breakNote: 'break ↓'
  };

  /* ------------------------------------------------------------------ *
   * companyCohorts — three generations of challengers (#clearing-chart)
   * plus the thirteen-player cohort strip for the dashboard.
   *
   * outcome: 'acquired' | 'survived' | 'dead'
   * letter : state letter for the cohort strip —
   *          A = acquired · S = survived independent · D = dissolved
   * symbols: box = founding · arrow = acquired/merged · dot = survived ·
   *          cross = dissolved (dashboard legend, spec §12 item 8)
   * deal.value in US$M where applicable (null otherwise).
   * ------------------------------------------------------------------ */
  D.companyCohorts = {
    meta: {
      unit: 'US$M',
      fmt: 'moneyM',
      note: 'Fourteen companies, one question: how does the merchant-AI-silicon wave clear? Acquisition is the most common terminal status in this selected cohort — but not the only one: outcomes also include a licensing transaction, a public listing, continued independent operation, and (en route, for Wave Computing) a Chapter 11 restructuring.',
      inclusionRule: 'AI-accelerator / FPGA startups founded 2010–2017 (the merchant wave), plus two named predecessors that contested the same market (Achronix, founded 2004; Wave Computing, founded 2008) and the two FPGA duopolists (Xilinx, Altera) for reference. Observation through 2026-07-18.',
      observationEnd: '2026-07-18',
      statuses: {
        acquired: 'sold to another operating company — terminal corporate status',
        'asset-sale': 'technology assets and engineering team transferred to a buyer; terms undisclosed; no continuing independent chip vendor',
        licensing: 'technology licensed to a larger platform with associated talent moves; the remnant continues independently',
        restructuring: 'underwent bankruptcy-law restructuring (e.g., Chapter 11) — an event on the path, not necessarily a terminal status',
        ipo: 'completed an initial public offering; trades publicly',
        independent: 'operating independently (private or pre-IPO) as of the observation date',
        dissolved: 'ceased operations with no continuing successor business'
      },
      /* legacy chart fields (clearing chart + dashboard strip) */
      legend: { A: 'acquired / asset-sale', S: 'continuing (independent · IPO · licensing remnant)', D: 'dissolved' },
      symbols: { box: 'founding', arrow: 'acquired / transferred', dot: 'continuing', cross: 'dissolved' },
      drill: 'clearing-grammar'
    },
    generations: [
      {
        id: 'ref',
        name: 'Reference · the FPGA duopolists (founded 1983–1984)',
        windowId: 'w1',
        scope: 'reference',
        companies: [
          {
            name: 'Xilinx', founded: 1984, cleared: 2022,
            status: 'acquired', outcome: 'acquired', letter: 'A',
            acquirer: 'AMD', date: '2022-02-14',
            deal: { value: 49000, unit: 'US$M', fmt: 'moneyM', state: 'actual', src: null },
            events: [
              { date: '2020-10-27', event: 'AMD announces $35B all-stock acquisition' },
              { date: '2022-02-14', event: 'deal closes at ≈$49B' }
            ],
            source: 'AMD–Xilinx announcements (Oct 2020; Feb 2022)', url: null,
            tip: 'Xilinx · founded 1984 → acquired by AMD 2022 · $35B bid, ≈$49B close',
            drill: 'xilinx-exit'
          },
          {
            name: 'Altera', founded: 1983, cleared: 2015,
            status: 'acquired', outcome: 'acquired', letter: 'A',
            acquirer: 'Intel', date: '2015-06-01',
            deal: { value: 16700, unit: 'US$M', fmt: 'moneyM', state: 'actual', src: null },
            events: [
              { date: '2015-06-01', event: 'Intel announces $16.7B acquisition' },
              { date: '2025-09-16', event: 'Intel sells 51% of the Altera business to Silver Lake' }
            ],
            source: 'Intel–Altera announcement (Jun 2015); Intel–Silver Lake announcement (Sep 2025)', url: null,
            tip: 'Altera · founded 1983 → Intel $16.7B (2015); 51% of the business sold to Silver Lake (2025)',
            drill: 'altera-exit'
          }
        ]
      },
      {
        id: 'pred',
        name: 'Named predecessors (founded 2004–2008)',
        windowId: 'w3',
        scope: 'predecessor',
        companies: [
          {
            name: 'Achronix', founded: 2004, cleared: null,
            status: 'independent', outcome: 'survived', letter: 'S',
            acquirer: null, date: null,
            deal: { value: null, unit: 'US$M', fmt: 'moneyM', state: 'derived', src: null },
            events: [
              { date: '2021-07', event: 'SPAC merger cancelled; remains private and independent' }
            ],
            source: 'company statements; SPAC termination coverage (2021)', url: null,
            tip: 'Achronix · founded 2004 → independent (private); SPAC cancelled 2021',
            drill: 'achronix-survived'
          },
          {
            name: 'Wave Computing', founded: 2008, cleared: 2025,
            status: 'acquired', outcome: 'acquired', letter: 'A',
            acquirer: 'GlobalFoundries', date: '2025-08',
            deal: { value: null, unit: 'US$M', fmt: 'moneyM', state: 'gap', src: null },
            statusPath: 'Chapter 11 restructuring (2020) → emerged as MIPS (Mar 2021, Tallwood) → acquired by GlobalFoundries (Aug 2025)',
            events: [
              { date: '2020-04', event: 'files Chapter 11 — the cohort’s only bankruptcy-law restructuring' },
              { date: '2021-03', event: 'emerges from Chapter 11 as MIPS, backed by Tallwood Ventures' },
              { date: '2025-08', event: 'GlobalFoundries announces acquisition of MIPS' }
            ],
            source: 'Reuters, Chapter 11 emergence report (Mar 2021); GlobalFoundries announcement (Aug 2025)',
            url: 'https://www.reuters.com/article/technology/ai-chip-firm-wave-computing-emerges-from-chapter-11-bankruptcy-protection-idUSKCN2AT3T7/',
            tip: 'Wave Computing · founded 2008 → Chapter 11 (2020), emerged as MIPS (2021) → acquired by GlobalFoundries (2025)',
            drill: 'wave-exit'
          }
        ]
      },
      {
        id: 'wave',
        name: 'The merchant AI-accelerator wave (founded 2012–2017)',
        windowId: 'w4',
        scope: 'wave',
        companies: [
          {
            name: 'Mythic', founded: 2012, cleared: null,
            status: 'independent', outcome: 'survived', letter: 'S',
            acquirer: null, date: null,
            deal: { value: null, unit: 'US$M', fmt: 'moneyM', state: 'derived', src: null },
            events: [
              { date: '2025-12', event: 'revived with a $125M financing round' }
            ],
            source: 'company financing announcement (Dec 2025)', url: null,
            tip: 'Mythic · founded 2012 → independent; revived with a $125M raise (Dec 2025)',
            drill: 'mythic-status'
          },
          {
            name: 'Nervana', founded: 2014, cleared: 2016,
            status: 'acquired', outcome: 'acquired', letter: 'A',
            acquirer: 'Intel', date: '2016-08',
            deal: { value: 350, unit: 'US$M', fmt: 'moneyM', state: 'estimate', src: null },
            events: [
              { date: '2016-08', event: 'acquired by Intel for ≈$350M' },
              { date: '2020-01', event: 'product line dissolved inside Intel (Nervana NNP programs cancelled)' }
            ],
            source: 'Intel acquisition reports (2016); product-line discontinuation reporting (2020)', url: null,
            tip: 'Nervana · founded 2014 → Intel ≈$350M (2016); product line dissolved 2020',
            drill: 'nervana-exit'
          },
          {
            name: 'Flex Logix', founded: 2014, cleared: 2024,
            status: 'asset-sale', outcome: 'acquired', letter: 'A',
            acquirer: 'Analog Devices', date: '2024-11-08',
            deal: { value: null, unit: 'US$M', fmt: 'moneyM', state: 'gap', src: null },
            events: [
              { date: '2024-11-08', event: 'eFPGA/AI technology assets and technical team transfer to Analog Devices; terms undisclosed (completed ≈Jan 2025)' }
            ],
            source: 'EE Times / company statements (Nov 2024)', url: null,
            tip: 'Flex Logix · founded 2014 → technology assets and team to Analog Devices (Nov 2024); terms undisclosed',
            drill: 'flexlogix-exit'
          },
          {
            name: 'SiFive', founded: 2015, cleared: null,
            status: 'independent', outcome: 'survived', letter: 'S',
            acquirer: null, date: null,
            deal: { value: null, unit: 'US$M', fmt: 'moneyM', state: 'derived', src: null },
            events: [],
            source: 'company status as of 2026-07-18 (pre-IPO)', url: null,
            tip: 'SiFive · founded 2015 → independent (pre-IPO)',
            drill: 'sifive-status'
          },
          {
            name: 'Cerebras', founded: 2015, cleared: null,
            status: 'ipo', outcome: 'survived', letter: 'S',
            acquirer: null, date: '2026-05-13',
            deal: { value: null, unit: 'US$M', fmt: 'moneyM', state: 'derived', src: null },
            ipo: { date: '2026-05-13', priced: '2026-05-13/14', price: 185, raised: 5500, exchange: 'Nasdaq', ticker: 'CBRS' },
            events: [
              { date: '2026-05-13', event: 'prices IPO at $185/share, raising ≈$5.5B; lists on Nasdaq as CBRS' }
            ],
            source: 'Cerebras IPO pricing announcement (May 2026)',
            url: 'https://www.cerebras.ai/press-release/cerebras-systems-announces-pricing-of-initial-public-offering',
            tip: 'Cerebras · founded 2015 → IPO May 2026 at $185/share, ≈$5.5B raised · Nasdaq CBRS',
            drill: 'cerebras-ipo'
          },
          {
            name: 'Groq', founded: 2016, cleared: null,
            status: 'licensing', outcome: 'survived', letter: 'S',
            acquirer: null, date: '2025-12-24',
            deal: { value: null, unit: 'US$M', fmt: 'moneyM', state: 'estimate', src: null },
            licensing: { date: '2025-12-24', counterparty: 'NVIDIA', type: 'non-exclusive inference-technology license', reportedValue: '≈$20B (CNBC-reported; NVIDIA unconfirmed)', talent: 'founder Jonathan Ross, president Sunny Madra and engineering staff joined NVIDIA; remnant independent under CEO Simon Edwards' },
            events: [
              { date: '2025-12-24', event: 'NVIDIA non-exclusive inference-technology licensing agreement; founders and engineers join NVIDIA; remnant independent' }
            ],
            source: 'Groq–NVIDIA licensing announcement (Dec 2025); CNBC value reporting (unconfirmed)',
            url: 'https://groq.com/newsroom/groq-and-nvidia-enter-non-exclusive-inference-technology-licensing-agreement-to-accelerate-ai-inference-at-global-scale',
            tip: 'Groq · founded 2016 → NVIDIA non-exclusive license (Dec 2025, ≈$20B CNBC-reported, unconfirmed); remnant independent',
            drill: 'groq-licensing'
          },
          {
            name: 'Graphcore', founded: 2016, cleared: 2024,
            status: 'acquired', outcome: 'acquired', letter: 'A',
            acquirer: 'SoftBank', date: '2024-07',
            deal: { value: 600, unit: 'US$M', fmt: 'moneyM', state: 'estimate', src: null },
            events: [
              { date: '2024-07', event: 'acquired by SoftBank; reported value ≈$500–600M (unconfirmed)' }
            ],
            source: 'SoftBank acquisition announcement (Jul 2024); value press-reported', url: null,
            tip: 'Graphcore · founded 2016 → acquired by SoftBank (Jul 2024) · ≈$600M reported',
            drill: 'graphcore-exit'
          },
          {
            name: 'Habana', founded: 2016, cleared: 2019,
            status: 'acquired', outcome: 'acquired', letter: 'A',
            acquirer: 'Intel', date: '2019-12-16',
            deal: { value: 2000, unit: 'US$M', fmt: 'moneyM', state: 'actual', src: null },
            events: [
              { date: '2019-12-16', event: 'acquired by Intel for ≈$2B' },
              { date: '2025', event: 'Gaudi product line winding down inside Intel' }
            ],
            source: 'Intel acquisition announcement (Dec 2019)', url: null,
            tip: 'Habana · founded 2016 → Intel $2B (Dec 2019); Gaudi line winding down',
            drill: 'habana-exit'
          },
          {
            name: 'Tenstorrent', founded: 2016, cleared: null,
            status: 'independent', outcome: 'survived', letter: 'S',
            acquirer: null, date: null,
            deal: { value: null, unit: 'US$M', fmt: 'moneyM', state: 'derived', src: null },
            events: [
              { date: '2026-06', event: 'Qualcomm acquisition rumor publicly denied' }
            ],
            source: 'company statement (Jun 2026)', url: null,
            tip: 'Tenstorrent · founded 2016 → independent; Qualcomm rumor denied (Jun 2026)',
            drill: 'tenstorrent-status'
          },
          {
            name: 'SambaNova', founded: 2017, cleared: null,
            status: 'independent', outcome: 'survived', letter: 'S',
            acquirer: null, date: null,
            deal: { value: null, unit: 'US$M', fmt: 'moneyM', state: 'derived', src: null },
            events: [
              { date: '2026-07', event: '$1B Series F at an $11B valuation' }
            ],
            source: 'company financing announcement (Jul 2026)', url: null,
            tip: 'SambaNova · founded 2017 → independent; $1B Series F at $11B (Jul 2026)',
            drill: 'sambanova-status'
          }
        ]
      }
    ],
    /* Terminal-status counts over the 14-company cohort — the SAME numbers
       the clearing chart, dashboard cohort strip, and prose must derive.
       byStatus sums to total; legacyByOutcome maps statuses onto the
       legacy three-state chart vocabulary (acquired/survived/dead). */
    cohortSummary: {
      asOf: '2026-07-18',
      total: 14,
      byStatus: { acquired: 6, 'asset-sale': 1, licensing: 1, restructuring: 0, ipo: 1, independent: 5, dissolved: 0 },
      scopeCounts: { reference: 2, predecessor: 2, wave: 10 },
      pathEvents: {
        chapter11Restructuring: 1,          /* Wave Computing (2020–2021) — an event, not a terminal status */
        productLineDissolvedPostAcquisition: 1, /* Nervana products dissolved inside Intel (2020) */
        majorityStakeSale: 1,               /* Altera: Intel sells 51% to Silver Lake (2025) */
        licensingWithTalentMove: 1,         /* Groq → NVIDIA license + talent move (2025) */
        ipoCompleted: 1                     /* Cerebras, Nasdaq CBRS (May 2026) */
      },
      legacyByOutcome: { acquired: 7, survived: 7, dead: 0 },
      note: 'Counts are terminal statuses over the 14-company cohort as of 2026-07-18. Wave Computing passed through Chapter 11 restructuring (2020–2021) before its acquisition; Nervana’s product line was dissolved inside Intel (2020) after its 2016 acquisition; Altera’s business was majority-sold to Silver Lake (2025) a decade after the Intel acquisition. No cohort member’s terminal status is dissolution or an unresolved restructuring — but “acquisition, never bankruptcy” would be false for this record.'
    },
    /* Cohort strip — dashboard item 8. `outcome`/`letter` are the legacy
       three-state fields; `status` carries the refined taxonomy. */
    strip: [
      { name: 'Xilinx',         letter: 'A', symbol: 'arrow', outcome: 'acquired', status: 'acquired',   note: '→ AMD ≈$49B (2022)',                        drill: 'xilinx-exit' },
      { name: 'Altera',         letter: 'A', symbol: 'arrow', outcome: 'acquired', status: 'acquired',   note: '→ Intel $16.7B (2015); 51% → Silver Lake (2025)', drill: 'altera-exit' },
      { name: 'Achronix',       letter: 'S', symbol: 'dot',   outcome: 'survived', status: 'independent', note: 'independent · private',                    drill: 'achronix-survived' },
      { name: 'Wave Computing', letter: 'A', symbol: 'arrow', outcome: 'acquired', status: 'acquired',   note: 'Chapter 11 (2020) → MIPS → GlobalFoundries (2025)', drill: 'wave-exit' },
      { name: 'Mythic',         letter: 'S', symbol: 'dot',   outcome: 'survived', status: 'independent', note: 'independent · revived ($125M, 2025)',      drill: 'mythic-status' },
      { name: 'Nervana',        letter: 'A', symbol: 'arrow', outcome: 'acquired', status: 'acquired',   note: '→ Intel ≈$350M (2016); line dissolved 2020', drill: 'nervana-exit' },
      { name: 'Flex Logix',     letter: 'A', symbol: 'arrow', outcome: 'acquired', status: 'asset-sale', note: 'assets + team → Analog Devices (2024)',     drill: 'flexlogix-exit' },
      { name: 'SiFive',         letter: 'S', symbol: 'dot',   outcome: 'survived', status: 'independent', note: 'independent · pre-IPO',                    drill: 'sifive-status' },
      { name: 'Cerebras',       letter: 'S', symbol: 'dot',   outcome: 'survived', status: 'ipo',        note: 'IPO May 2026 · Nasdaq CBRS',                drill: 'cerebras-ipo' },
      { name: 'Groq',           letter: 'S', symbol: 'dot',   outcome: 'survived', status: 'licensing',  note: 'NVIDIA license (2025) · remnant independent', drill: 'groq-licensing' },
      { name: 'Graphcore',      letter: 'A', symbol: 'arrow', outcome: 'acquired', status: 'acquired',   note: '→ SoftBank (2024)',                         drill: 'graphcore-exit' },
      { name: 'Habana',         letter: 'A', symbol: 'arrow', outcome: 'acquired', status: 'acquired',   note: '→ Intel $2B (2019)',                        drill: 'habana-exit' },
      { name: 'Tenstorrent',    letter: 'S', symbol: 'dot',   outcome: 'survived', status: 'independent', note: 'independent · Qualcomm rumor denied',      drill: 'tenstorrent-status' },
      { name: 'SambaNova',      letter: 'S', symbol: 'dot',   outcome: 'survived', status: 'independent', note: 'independent · $1B Series F at $11B (2026)', drill: 'sambanova-status' }
    ]
  };

  /* ------------------------------------------------------------------ *
   * submarineRecords — deploy vs disclose dates (#submarine-chart).
   * Disclosure dates sit above the waterline; deployment dates below.
   * gapYears = disclosed − deployed (positive = submarine pattern).
   * ------------------------------------------------------------------ */
  D.submarineRecords = {
    meta: {
      note: 'Deploy first, disclose later. The waterline is public knowledge; below it, production truth.',
      unit: 'year',
      drill: 'submarine-pattern'
    },
    records: [
      {
        id: 'google-tpu', entity: 'Google', project: 'TPU v1',
        deployed: { year: 2015, state: 'actual', src: null },
        disclosed: { year: 2016, state: 'actual', src: null },
        gapYears: 1,
        scale: 'datacenter production fleet',
        claim: '15–30× performance-per-watt over contemporary GPU/CPU baselines',
        tip: 'Google TPU v1 · deployed 2015; disclosed 2016 (blog), ISCA paper 2017',
        drill: 'sub-google'
      },
      {
        id: 'microsoft-catapult', entity: 'Microsoft', project: 'Project Catapult',
        deployed: { year: 2012, state: 'actual', src: null },
        disclosed: { year: 2014, state: 'actual', src: null },
        gapYears: 2,
        scale: '1,632 FPGA servers in the disclosed pilot',
        claim: '95% ranking-throughput gain per server at fixed latency — or 29% tail-latency reduction (ISCA 2014 abstract)',
        tip: 'Microsoft Catapult · 1,632 servers wired by end-2012, 95% throughput gain, disclosed ISCA 2014',
        drill: 'sub-microsoft'
      },
      {
        id: 'baidu-xpu', entity: 'Baidu', project: 'XPU / Kunlun line',
        deployed: { year: 2017, state: 'estimate', src: null },
        disclosed: { year: 2018, state: 'actual', src: null },
        gapYears: 1,
        scale: 'FPGA-based XPU fleets; Kunlun silicon announced 2018',
        claim: 'in-house inference for search and Ernie workloads',
        tip: 'Baidu · FPGA XPUs in production ≈2017; Kunlun disclosed 2018',
        drill: 'sub-baidu'
      },
      {
        id: 'amazon-inferentia', entity: 'Amazon', project: 'Inferentia (Annapurna)',
        deployed: { year: 2018, state: 'estimate', src: null },
        disclosed: { year: 2018, state: 'actual', src: null },
        gapYears: 0,
        scale: 'Annapurna Labs silicon inside AWS; Inf1 GA late 2019',
        claim: 'Alexa-class inference moved in-house; GA as Inf1 instances',
        tip: 'Amazon Inferentia · internal 2018, disclosed re:Invent 2018',
        drill: 'sub-amazon'
      },
      {
        id: 'meta-mtia', entity: 'Meta', project: 'MTIA v1',
        deployed: { year: 2022, state: 'estimate', src: null },
        disclosed: { year: 2023, state: 'actual', src: null },
        gapYears: 1,
        scale: 'ranking and recommendation inference fleet',
        claim: 'first-generation Meta Training & Inference Accelerator',
        tip: 'Meta MTIA v1 · internal ≈2022, disclosed May 2023',
        drill: 'sub-meta'
      },
      {
        id: 'tesla-dojo', entity: 'Tesla', project: 'Dojo D1',
        deployed: { year: 2023, state: 'actual', src: null },
        disclosed: { year: 2021, state: 'actual', src: null },
        gapYears: -2,
        scale: 'D1 tile + ExaPOD program',
        claim: 'the counter-pattern: disclosed at AI Day 2021, production 2023',
        tip: 'Tesla Dojo · disclosed 2021, deployed 2023 — the exception',
        drill: 'sub-tesla'
      }
    ]
  };

  /* ------------------------------------------------------------------ *
   * playerAtlas — lineage stamp atlas (#stamps-chart).
   * Three lineages: merchant compute · cloud in-house · FPGA generations.
   * ~24 chips; each stamp: year, maker, name, lineage, generation tag.
   * ------------------------------------------------------------------ */
  D.playerAtlas = {
    meta: {
      note: 'Twenty-four stamps, three lineages. Click any stamp for its drill card.',
      lineages: [
        { id: 'merchant', name: 'Merchant compute', color: '#2251ff' },
        { id: 'cloud',    name: 'Cloud in-house',   color: '#b07a10' },
        { id: 'fpga',     name: 'FPGA generations', color: '#8595a6' }
      ]
    },
    chips: [
      /* — Merchant compute — */
      { year: 2017, maker: 'NVIDIA', name: 'V100',      lineage: 'merchant', gen: 'Volta',     state: 'actual',   src: null,  drill: 'nvda-merchant-line', tip: 'NVIDIA V100 · 2017 · Volta — the training franchise consolidates' },
      { year: 2018, maker: 'NVIDIA', name: 'T4',        lineage: 'merchant', gen: 'Turing',    state: 'actual',   src: null,  drill: 'nvda-merchant-line', tip: 'NVIDIA T4 · 2018 · the inference volume part' },
      { year: 2020, maker: 'NVIDIA', name: 'A100',      lineage: 'merchant', gen: 'Ampere',    state: 'actual',   src: null,  drill: 'nvda-merchant-line', tip: 'NVIDIA A100 · 2020 · Ampere' },
      { year: 2022, maker: 'NVIDIA', name: 'H100',      lineage: 'merchant', gen: 'Hopper',    state: 'actual',   src: 'K10', drill: 'nvda-dc-run',        tip: 'NVIDIA H100 · 2022 · Hopper — the boom part' },
      { year: 2023, maker: 'NVIDIA', name: 'H200',      lineage: 'merchant', gen: 'Hopper',    state: 'actual',   src: null,  drill: 'nvda-merchant-line', tip: 'NVIDIA H200 · 2023 · HBM3e refresh' },
      { year: 2023, maker: 'AMD',    name: 'MI300X',    lineage: 'merchant', gen: 'CDNA 3',    state: 'actual',   src: null,  drill: 'amd-merchant-line',  tip: 'AMD MI300X · 2023 · the merchant challenger' },
      { year: 2024, maker: 'NVIDIA', name: 'B200/GB200', lineage: 'merchant', gen: 'Blackwell', state: 'actual',   src: null,  drill: 'gb200-rack',         tip: 'NVIDIA Blackwell · 2024 · NVL72 ≈120kW/rack' },
      { year: 2024, maker: 'Intel',  name: 'Gaudi 3',   lineage: 'merchant', gen: 'Gaudi',     state: 'actual',   src: null,  drill: 'habana-exit',        tip: 'Intel Gaudi 3 · 2024 · Habana lineage' },
      /* — Cloud in-house — */
      { year: 2015, maker: 'Google', name: 'TPU v1',    lineage: 'cloud', gen: 'gen 1', state: 'actual',   src: null,  drill: 'tpu-deploy-2015',  tip: 'TPU v1 · 2015 · deployed before disclosure' },
      { year: 2017, maker: 'Google', name: 'TPU v2',    lineage: 'cloud', gen: 'gen 2', state: 'actual',   src: null,  drill: 'tpu-generations',  tip: 'TPU v2 · 2017 · bfloat16 training pod' },
      { year: 2018, maker: 'Google', name: 'TPU v3',    lineage: 'cloud', gen: 'gen 3', state: 'actual',   src: null,  drill: 'tpu-generations',  tip: 'TPU v3 · 2018 · liquid-cooled pod' },
      { year: 2019, maker: 'Amazon', name: 'Inferentia', lineage: 'cloud', gen: 'Inf 1', state: 'actual',   src: null,  drill: 'sub-amazon',       tip: 'AWS Inferentia · 2019 · Annapurna silicon GA' },
      { year: 2021, maker: 'Google', name: 'TPU v4',    lineage: 'cloud', gen: 'gen 4', state: 'actual',   src: null,  drill: 'tpu-generations',  tip: 'TPU v4 · 2021 · optical circuit switch pod' },
      { year: 2023, maker: 'Google', name: 'TPU v5p',   lineage: 'cloud', gen: 'gen 5', state: 'actual',   src: null,  drill: 'tpu-generations',  tip: 'TPU v5p · 2023 · the workhorse generation' },
      { year: 2024, maker: 'Google', name: 'Trillium (v6)', lineage: 'cloud', gen: 'gen 6', state: 'actual', src: null,  drill: 'trillium',        tip: 'TPU v6 Trillium · 2024 · 4.7× peak compute vs v5e' },
      { year: 2024, maker: 'Amazon', name: 'Trainium 2', lineage: 'cloud', gen: 'Trn 2', state: 'actual',   src: 'K20', drill: 'sub-amazon',       tip: 'AWS Trainium 2 · 2024 · Anthropic-scale clusters' },
      { year: 2025, maker: 'Google', name: 'Ironwood (v7)', lineage: 'cloud', gen: 'gen 7', state: 'actual', src: null,  drill: 'ironwood',        tip: 'TPU v7 Ironwood · 2025 · 42.5 EFLOPS/pod FP8' },
      { year: 2026, maker: 'Google', name: 'TPU v8 (8t/8i)', lineage: 'cloud', gen: 'gen 8', state: 'estimate', src: null, drill: 'tpu-v8',         tip: 'TPU 8t/8i (v8) · unveiled 2026-04-22 (Cloud Next) · GA later in 2026 (estimate)' },
      /* — FPGA generations — */
      { year: 1985, maker: 'Xilinx', name: 'XC2064',    lineage: 'fpga', gen: 'gen 1', state: 'actual',   src: null,  drill: 'xc2064',           tip: 'XC2064 · 1985 · 64 logic blocks' },
      { year: 1990, maker: 'Xilinx', name: 'XC4000',    lineage: 'fpga', gen: 'gen 2', state: 'actual',   src: null,  drill: 'fpga-line',        tip: 'XC4000 · 1990 · the workhorse family' },
      { year: 1998, maker: 'Xilinx', name: 'Virtex',    lineage: 'fpga', gen: 'gen 3', state: 'actual',   src: null,  drill: 'fpga-line',        tip: 'Virtex · 1998 · the optical-boom part' },
      { year: 2002, maker: 'Altera', name: 'Stratix',   lineage: 'fpga', gen: 'gen 4', state: 'actual',   src: null,  drill: 'fpga-line',        tip: 'Stratix · 2002 · high-end duopoly flag' },
      { year: 2012, maker: 'Altera', name: 'Stratix V', lineage: 'fpga', gen: 'gen 5', state: 'actual',   src: null,  drill: 'catapult-scale',   tip: 'Stratix V · 2012 · the Catapult substrate' },
      { year: 2019, maker: 'Intel',  name: 'Agilex',    lineage: 'fpga', gen: 'gen 6', state: 'actual',   src: null,  drill: 'intel-altera',     tip: 'Agilex · 2019 · the post-acquisition flag' }
    ]
  };

  /* ------------------------------------------------------------------ *
   * tpuGenerations — eight TPU generations, log scale (#tpu-chart).
   * peak.value is per-chip peak throughput in TFLOPS (v1: TOPS INT8).
   * `precision` is the numeric basis; `warn` is the precision-basis
   * warning the chart must render (bases are NOT directly comparable).
   * ------------------------------------------------------------------ */
  D.tpuGenerations = {
    meta: {
      unit: 'TFLOPS',
      fmt: 'int',
      scale: 'log',
      note: 'Peak per-chip throughput on a logarithmic axis. Precision basis varies by generation — read the warnings before comparing heights.',
      drill: 'tpu-generations'
    },
    generations: [
      { gen: 'TPU v1', year: 2015, peak: { value: 92,   unit: 'TOPS',   fmt: 'int', state: 'actual',   src: null  }, precision: 'INT8',   warn: 'INT8 TOPS — not comparable with floating-point figures', drill: 'tpu-generations', tip: 'TPU v1 · 2015 · 92 TOPS INT8 · inference only' },
      { gen: 'TPU v2', year: 2017, peak: { value: 45,   unit: 'TFLOPS', fmt: 'int', state: 'derived',  src: null  }, precision: 'BF16',   warn: 'bfloat16 basis — the pod-training generation',         drill: 'tpu-generations', tip: 'TPU v2 · 2017 · 45 TFLOPS BF16 per chip' },
      { gen: 'TPU v3', year: 2018, peak: { value: 123,  unit: 'TFLOPS', fmt: 'int', state: 'derived',  src: null  }, precision: 'BF16',   warn: 'bfloat16 basis; liquid-cooled pod',                    drill: 'tpu-generations', tip: 'TPU v3 · 2018 · 123 TFLOPS BF16 per chip' },
      { gen: 'TPU v4', year: 2021, peak: { value: 275,  unit: 'TFLOPS', fmt: 'int', state: 'derived',  src: null  }, precision: 'BF16',   warn: 'bfloat16 basis; optical circuit switch fabric',        drill: 'tpu-generations', tip: 'TPU v4 · 2021 · 275 TFLOPS BF16 per chip' },
      { gen: 'TPU v5p', year: 2023, peak: { value: 459, unit: 'TFLOPS', fmt: 'int', state: 'derived',  src: null  }, precision: 'BF16',   warn: 'bfloat16 basis; v5e sibling is the cost part',         drill: 'tpu-generations', tip: 'TPU v5p · 2023 · 459 TFLOPS BF16 per chip' },
      { gen: 'Trillium (v6)', year: 2024, peak: { value: 918, unit: 'TFLOPS', fmt: 'int', state: 'actual', src: null }, precision: 'BF16', warn: 'bfloat16 basis; 4.7× v5e peak compute',                drill: 'trillium',        tip: 'Trillium v6 · 2024 · ≈918 TFLOPS BF16 per chip' },
      { gen: 'Ironwood (v7)', year: 2025, peak: { value: 4614, unit: 'TFLOPS', fmt: 'int', state: 'actual', src: null }, precision: 'FP8', warn: 'FP8 basis — roughly 2× the BF16-equivalent number',    drill: 'ironwood',        tip: 'Ironwood v7 · 2025 · 4,614 TFLOPS FP8 per chip' },
      { gen: 'TPU v8 (8t/8i)', year: 2026, peak: { value: 9000, unit: 'TFLOPS', fmt: 'int', state: 'estimate', src: null  }, precision: 'FP4',    warn: 'FP4-class estimate — the widest precision caveat of all', drill: 'tpu-v8',         tip: 'TPU 8t/8i · unveiled 2026-04-22, GA later in 2026 · ≈9 PFLOPS FP4-class per chip (estimate)' }
    ]
  };

})(window.DATA);
