/**
 * js/data-v52.js — SUPPLY-CHAIN DATASETS
 * Forty-Two Years of Inference Silicon · data layer (spec §16)
 *
 * Namespace: window.DATA (no modules, no imports).
 * Datum convention identical to js/data.js:
 *   { value, state, src, unit, fmt, tip, drill } — shared fields hoisted
 *   into `meta` on grouped datasets.
 * Keys: supplyGates, cowosCapacity, hbmCapacity, hbmGenerations,
 *       powerTrajectory, namedGigawattCommitments, penetrationByBasis,
 *       assumeA2, assumeA3.
 */
window.DATA = window.DATA || {};
(function (D) {
  'use strict';

  /* ------------------------------------------------------------------ *
   * supplyGates — four rigidity-ranked supply gates (#gates-chart).
   * Each gate carries six score blocks (0–5, higher = more binding):
   * rigidity, concentration, leadTime, capexIntensity, substitutability,
   * visibility — plus its bypass routes.
   * ------------------------------------------------------------------ */
  D.supplyGates = {
    meta: {
      note: 'Working hypothesis: the profit pool sits at the gates rather than in the cloud (comparative margin and ROIC evidence is not public — held as a hypothesis, not a demonstrated fact). Scores 0–5; higher binds harder.',
      blocks: ['rigidity', 'concentration', 'leadTime', 'capexIntensity', 'substitutability', 'visibility'],
      blockLabels: {
        rigidity: 'capacity rigidity',
        concentration: 'supplier concentration',
        leadTime: 'order lead time',
        capexIntensity: 'capex intensity',
        substitutability: 'substitutability (5 = none)',
        visibility: 'demand visibility (5 = opaque)'
      },
      drill: 'gates-profit-pool'
    },
    gates: [
      {
        id: 'hbm', rank: 1, name: 'HBM',
        scores: { rigidity: 5, concentration: 5, leadTime: 4, capexIntensity: 4, substitutability: 5, visibility: 3 },
        verdict: 'The tightest gate. Three makers, 18–24-month qualification cycles, and 2026 supply largely booked a year ahead.',
        bypass: 'No scaled bypass. LPDDR/GDDR offload covers edge inference only; the datacenter part has no substitute.',
        state: 'estimate', src: 'K13', drill: 'gate-hbm',
        tip: 'Gate 1 · HBM — rigidity 5/5'
      },
      {
        id: 'process', rank: 2, name: 'Leading-edge process',
        scores: { rigidity: 4, concentration: 5, leadTime: 5, capexIntensity: 5, substitutability: 3, visibility: 4 },
        verdict: 'One foundry of record at 3nm-class. Wafer agreements are signed 2–3 years out; a node slip moves every roadmap downstream.',
        bypass: 'N−1/N−2 nodes with 2.5D compensation — viable at a 20–30% performance and power tax.',
        state: 'estimate', src: null, drill: 'gate-process',
        tip: 'Gate 2 · leading-edge process — one foundry of record'
      },
      {
        id: 'cowos', rank: 3, name: 'CoWoS advanced packaging',
        scores: { rigidity: 4, concentration: 4, leadTime: 4, capexIntensity: 3, substitutability: 3, visibility: 3 },
        verdict: 'The bottleneck of 2023–2025. Capacity triples in slabs of 10kwpm; bookings still lead capacity by roughly two quarters.',
        bypass: 'OSAT CoWoS-likes (ASE, Amkor), Intel EMIB, and panel-level interposers — ramping but unqualified at the frontier.',
        state: 'estimate', src: 'K12', drill: 'gate-cowos',
        tip: 'Gate 3 · CoWoS — the slab-staircase gate'
      },
      {
        id: 'optical', rank: 4, name: 'Optical interconnect',
        scores: { rigidity: 3, concentration: 3, leadTime: 3, capexIntensity: 3, substitutability: 2, visibility: 3 },
        verdict: 'The 1995 window’s own gate, back for a second run. 800G shipping, 1.6T ramping; DSP supply is the watch item.',
        bypass: 'Copper inside the rack (NVLink-class), LPO then CPO transitions; linear-pluggable optics cut DSP dependence.',
        state: 'estimate', src: null, drill: 'gate-optical',
        tip: 'Gate 4 · optical interconnect — the returning gate'
      }
    ]
  };

  /* ------------------------------------------------------------------ *
   * cowosCapacity — CoWoS monthly capacity in kwpm (#cowos-chart, SVG
   * viewBox 0 0 860 457). Isometric towers; ONE SLAB = 10kwpm.
   * state 'forecast' → render hollow with dashed outline.
   * ------------------------------------------------------------------ */
  D.cowosCapacity = {
    meta: {
      unit: 'kwpm', fmt: 'int',
      slab: 10,
      slabNote: '1 slab = 10kwpm',
      viewBox: [860, 457],
      src: 'K12',
      note: 'CoWoS capacity arrives in stair-step slabs, not curves. Forecast slabs are hollow and dashed. Capacity figures are third-party estimates and vary; TSMC does not guide kwpm. C.C. Wei (AGM, Jun 2026): sold out through 2026.',
      drill: 'cowos-path'
    },
    annual: [
      { year: 2022, value: 12,  slabs: 1.2, state: 'derived',  src: 'K12', drill: 'cowos-path', tip: '2022 · ≈12kwpm — the pre-boom baseline' },
      { year: 2023, value: 15,  slabs: 1.5, state: 'derived',  src: 'K12', drill: 'cowos-path', tip: '2023 · ≈15kwpm — the bottleneck year' },
      { year: 2024, value: 38,  slabs: 3.8, state: 'estimate', src: 'K12', drill: 'cowos-path', tip: '2024 · ≈38kwpm — capacity doubles-plus (supply-chain estimate)' },
      { year: 2025, value: 78,  slabs: 7.8, state: 'estimate', src: 'K12', drill: 'cowos-path', tip: '2025 · ≈75–80kwpm end-2025 (third-party estimates, vary)' },
      { year: 2026, value: 125, slabs: 12.5, state: 'forecast', src: 'K12', drill: 'cowos-path', tip: '2026E · ≈120–130kwpm target end-2026 — hollow slab (third-party target; “sold out through 2026” per C.C. Wei, AGM Jun 2026)' },
      { year: 2027, value: 130, slabs: 13,  state: 'forecast', src: 'K12', drill: 'cowos-path', tip: '2027F · ≈130kwpm-class — hollow slab (forecast extension; third-party estimate)' }
    ]
  };

  /* ------------------------------------------------------------------ *
   * hbmCapacity — HBM wafer capacity stacked by maker (#hbm-chart),
   * plus HBM share of total DRAM revenue. Unit kwpm (capacity) and %
   * (share). 2025–2026 are estimates/forecasts.
   * ------------------------------------------------------------------ */
  D.hbmCapacity = {
    meta: {
      unit: 'kwpm', fmt: 'int',
      shareUnit: '%', shareFmt: 'pct',
      src: 'K13',
      note: 'Three makers, one gate. Stacked bars are kwpm by maker; the overlay line is HBM share of DRAM revenue (≈8% 2023 → ≈41% 2027F remains an estimate framing). SK hynix 2026 HBM supply is sold out; customer requests exceed its three-year capacity roadmap.',
      drill: 'hbm-capacity',
      makers: [
        { id: 'skhynix', name: 'SK hynix', color: '#2251ff' },
        { id: 'samsung', name: 'Samsung',  color: '#7d9bff' },
        { id: 'micron',  name: 'Micron',   color: '#b07a10' }
      ]
    },
    annual: [
      { year: 2022, skhynix: 55,  samsung: 50,  micron: 8,  hbmShareOfDram: 4,  state: 'derived',  src: 'K13', drill: 'hbm-capacity', tip: '2022 · ≈113kwpm total · HBM ≈4% of DRAM revenue' },
      { year: 2023, skhynix: 80,  samsung: 75,  micron: 15, hbmShareOfDram: 8,  state: 'derived',  src: 'K13', drill: 'hbm-capacity', tip: '2023 · ≈170kwpm total · HBM ≈8% of DRAM revenue' },
      { year: 2024, skhynix: 120, samsung: 130, micron: 30, hbmShareOfDram: 16, state: 'estimate', src: 'K13', drill: 'hbm-capacity', tip: '2024 · ≈280kwpm total · HBM ≈16% of DRAM revenue (estimate)' },
      { year: 2025, skhynix: 170, samsung: 160, micron: 55, hbmShareOfDram: 24, state: 'estimate', src: 'K16', drill: 'hbm-share',     tip: '2025E · ≈385kwpm total · HBM ≈24% of DRAM revenue (estimate)' },
      { year: 2026, skhynix: 200, samsung: 185, micron: 75, hbmShareOfDram: 33, state: 'forecast', src: 'K16', drill: 'hbm-share',     tip: '2026E · ≈460kwpm total · HBM ≈33% of DRAM revenue (forecast)' },
      { year: 2027, skhynix: 225, samsung: 200, micron: 90, hbmShareOfDram: 41, state: 'forecast', src: 'K16', drill: 'hbm-share',     tip: '2027F · ≈515kwpm total · HBM ≈41% of DRAM revenue (forecast)' }
    ]
  };

  /* ------------------------------------------------------------------ *
   * hbmGenerations — HBM1→HBM4E die stacks (#hbmgen-chart, SVG viewBox
   * 0 0 760 356). SLAB COUNT = STACK HEIGHT. state 'forecast' →
   * hatched slabs.
   * ------------------------------------------------------------------ */
  D.hbmGenerations = {
    meta: {
      viewBox: [760, 356],
      unit: 'dies per stack', fmt: 'int',
      note: 'Slab count equals stack height. Hatched stacks are estimates.',
      drill: 'hbm-gen'
    },
    generations: [
      { gen: 'HBM1',  year: 2015, stack: 4,  pinGbps: 1.0,  state: 'actual',   src: null,  drill: 'hbm-gen', tip: 'HBM1 · 2015 · 4-hi · ≈1.0Gbps/pin' },
      { gen: 'HBM2',  year: 2016, stack: 8,  pinGbps: 2.4,  state: 'actual',   src: null,  drill: 'hbm-gen', tip: 'HBM2 · 2016 · up to 8-hi · ≈2.4Gbps/pin' },
      { gen: 'HBM2E', year: 2019, stack: 8,  pinGbps: 3.6,  state: 'actual',   src: null,  drill: 'hbm-gen', tip: 'HBM2E · 2019 · 8-hi · ≈3.6Gbps/pin' },
      { gen: 'HBM3',  year: 2022, stack: 12, pinGbps: 6.4,  state: 'actual',   src: null,  drill: 'hbm-gen', tip: 'HBM3 · 2022 · up to 12-hi · ≈6.4Gbps/pin' },
      { gen: 'HBM3E', year: 2024, stack: 12, pinGbps: 9.2,  state: 'actual',   src: 'K13', drill: 'hbm-gen', tip: 'HBM3E · 2024 · 12-hi · ≈9.2Gbps/pin — the current part' },
      { gen: 'HBM4',  year: 2026, stack: 16, pinGbps: 11.0, state: 'forecast', src: 'K13', drill: 'hbm-gen', tip: 'HBM4 · 2026E · up to 16-hi · ≈11Gbps/pin (hatched estimate)' },
      { gen: 'HBM4E', year: 2027, stack: 16, pinGbps: 13.0, state: 'forecast', src: 'K13', drill: 'hbm-gen', tip: 'HBM4E · 2027F · 16-hi · ≈13Gbps/pin (hatched estimate)' }
    ]
  };

  /* ------------------------------------------------------------------ *
   * powerTrajectory — datacenter electricity consumption (#partition-
   * chart, SVG). IEA anchor: 415TWh (2024) → 945TWh (2030E).
   * Intermediate years are interpolation estimates.
   * ------------------------------------------------------------------ */
  D.powerTrajectory = {
    meta: {
      unit: 'TWh', fmt: 'int',
      src: 'K26',
      note: 'IEA datacenter electricity trajectory. The constraint’s last stop: the grid.',
      drill: 'power-iea'
    },
    annual: [
      { year: 2015, value: 190, state: 'estimate', src: 'K26', drill: 'power-iea', tip: '2015 · ≈190TWh (estimate)' },
      { year: 2018, value: 205, state: 'estimate', src: 'K26', drill: 'power-iea', tip: '2018 · ≈205TWh (estimate)' },
      { year: 2020, value: 220, state: 'estimate', src: 'K26', drill: 'power-iea', tip: '2020 · ≈220TWh (estimate)' },
      { year: 2022, value: 270, state: 'estimate', src: 'K26', drill: 'power-iea', tip: '2022 · ≈270TWh (IEA range midpoint)' },
      { year: 2024, value: 415, state: 'derived',  src: 'K26', drill: 'power-iea', tip: '2024 · 415TWh — IEA anchor' },
      { year: 2025, value: 520, state: 'estimate', src: 'K26', drill: 'power-iea', tip: '2025E · ≈520TWh (interpolation)' },
      { year: 2026, value: 620, state: 'forecast', src: 'K26', drill: 'power-iea', tip: '2026E · ≈620TWh' },
      { year: 2027, value: 700, state: 'forecast', src: 'K26', drill: 'power-iea', tip: '2027E · ≈700TWh' },
      { year: 2028, value: 790, state: 'forecast', src: 'K26', drill: 'power-iea', tip: '2028E · ≈790TWh' },
      { year: 2029, value: 870, state: 'forecast', src: 'K26', drill: 'power-iea', tip: '2029E · ≈870TWh' },
      { year: 2030, value: 945, state: 'forecast', src: 'K26', drill: 'power-iea', tip: '2030E · 945TWh — IEA Base Case (Energy and AI, Apr 2025)' }
    ]
  };

  /* ------------------------------------------------------------------ *
   * namedGigawattCommitments — named GW-scale datacenter commitments,
   * overlaid on the power trajectory (#partition-chart).
   * ------------------------------------------------------------------ */
  D.namedGigawattCommitments = {
    meta: {
      unit: 'GW', fmt: 'ratio',
      note: 'Named gigawatt-scale commitments. Announcement-scale figures are program ceilings, not build-outs.',
      drill: 'stargate'
    },
    commitments: [
      { id: 'stargate',  name: 'Stargate (OpenAI × Oracle × SoftBank)', gw: 7.0, gwPlanned: 7.0, gwOperational: 0.6, capex: '$400B+ claimed', announced: '2025-01', site: 'Abilene TX + expansions', state: 'estimate', src: null,  drill: 'stargate',        tip: 'Stargate · ≈7GW planned / $400B+ claimed vs ≈0.6GW operational at Abilene (Apr 2026 satellite imagery) — announcement figures are program ceilings' },
      { id: 'oracle-45', name: 'OpenAI–Oracle expansion',               gw: 4.5,  capex: 'part of Stargate program', announced: '2025-07', site: 'US multi-site', state: 'estimate', src: null,  drill: 'stargate', tip: 'OpenAI–Oracle · 4.5GW expansion announced Jul 2025' },
      { id: 'hyperion',  name: 'Meta Hyperion',                         gw: 5.0,  capex: 'multi-hundred-$B program', announced: '2025-07', site: 'Richland Parish, Louisiana', state: 'estimate', src: null,  drill: 'hyperion',    tip: 'Meta Hyperion · scales to ≈5GW' },
      { id: 'prometheus', name: 'Meta Prometheus',                      gw: 1.0,  capex: '—', announced: '2025-07', site: 'New Albany, Ohio', state: 'estimate', src: null,  drill: 'hyperion',   tip: 'Meta Prometheus · ≈1GW, online 2026' },
      { id: 'colossus',  name: 'xAI Colossus',                          gw: 1.0,  capex: '—', announced: '2024-09', site: 'Memphis, Tennessee', state: 'estimate', src: null, drill: 'xai-colossus',   tip: 'xAI Colossus · ≈1GW-class site path' },
      { id: 'rainier',   name: 'Amazon Project Rainier',                gw: 2.2,  capex: '—', announced: '2024-11', site: 'US multi-campus (Anthropic)', state: 'estimate', src: null, drill: 'rainier',        tip: 'Amazon Project Rainier · ≈2GW-class cluster campuses' }
    ]
  };

  /* ------------------------------------------------------------------ *
   * penetrationByBasis — ASIC share of accelerator demand on three
   * measurement bases (#penetration-chart, HTML table).
   * RULE: only the dollar basis is eligible for scenario multiplication.
   * ------------------------------------------------------------------ */
  D.penetrationByBasis = {
    meta: {
      note: 'Three ways to measure the same crossover claim. They disagree because they measure different things. Series A (dollar basis, below) is the global accelerator-dollar share of custom silicon; it must never be conflated with Series B (TSMC AI-revenue attribution, DATA.tsmcRevenueShare).',
      rule: 'Only the dollar basis may enter scenario multiplication.',
      eligibleBasis: 'dollar',
      drill: 'pen-dollar'
    },
    bases: [
      {
        id: 'units', name: 'Unit shipments', eligible: false,
        reason: 'TPU/Trainium-class units are cheaper per chip — unit share overstates economics.',
        seriesMeta: {
          metricName: 'Custom-ASIC share of AI-accelerator unit shipments',
          numerator: 'custom-ASIC accelerator chips shipped (TPU/Trainium/MTIA-class)',
          denominator: 'all AI-accelerator chips shipped (custom ASIC + merchant GPU)',
          geography: 'global',
          companyScope: 'all hyperscalers and merchant vendors',
          historyVsForecast: '2024–2025 estimates; 2026–2027 forecasts',
          measuresWhat: 'chip unit share — a units basis; ineligible for scenario multiplication',
          source: 'broker teardown tallies, compiled (access limited). Cross-check on a different denominator: TrendForce puts ASICs at 27.8% of 2026 AI-server shipments (units; from 20.9% in 2025), with custom-ASIC shipments growing +44.6% vs GPU +16.1% in 2026.',
          sourceDate: '2026-06'
        },
        asicShare: [
          { year: 2024, value: 0.30, state: 'estimate', src: 'K6',  tip: '2024 · ASIC ≈30% of units' },
          { year: 2025, value: 0.38, state: 'estimate', src: 'K6',  tip: '2025E · ASIC ≈38% of units' },
          { year: 2026, value: 0.45, state: 'forecast', src: 'K6',  tip: '2026F · ASIC ≈45% of units' },
          { year: 2027, value: 0.50, state: 'forecast', src: 'K6',  tip: '2027F · the claimed 50% line' }
        ],
        drill: 'pen-units'
      },
      {
        id: 'cowos', name: 'CoWoS allocation', eligible: false,
        reason: 'Allocation measures booked packaging slots — capacity, not demand or dollars.',
        seriesMeta: {
          metricName: 'Custom-ASIC share of booked CoWoS advanced-packaging capacity',
          numerator: 'CoWoS slots booked for custom-ASIC programs',
          denominator: 'all CoWoS slots booked (ASIC + GPU programs)',
          geography: 'global (TSMC advanced-packaging capacity)',
          companyScope: 'all CoWoS customers',
          historyVsForecast: '2024–2025 estimates; 2026–2027 forecasts',
          measuresWhat: 'booked packaging capacity by camp — a capacity-allocation basis; ineligible for scenario multiplication',
          source: 'supply-chain CoWoS booking tallies, compiled (access limited)',
          sourceDate: '2026-06'
        },
        asicShare: [
          { year: 2024, value: 0.18, state: 'estimate', src: 'K7',  tip: '2024 · ASIC ≈18% of CoWoS allocation' },
          { year: 2025, value: 0.25, state: 'estimate', src: 'K7',  tip: '2025E · ASIC ≈25% of CoWoS allocation' },
          { year: 2026, value: 0.30, state: 'forecast', src: 'K7',  tip: '2026F · ASIC ≈30% of CoWoS allocation' },
          { year: 2027, value: 0.34, state: 'forecast', src: 'K7',  tip: '2027F · ASIC ≈34% of CoWoS allocation' }
        ],
        drill: 'pen-cowos'
      },
      {
        id: 'dollar', name: 'Dollar value', eligible: true,
        reason: 'The only basis that enters scenario math: dollars are what revenue, margins, and clearing are made of.',
        seriesMeta: {
          seriesId: 'A',
          metricName: 'Custom-silicon share of global AI-accelerator dollar spending',
          numerator: 'accelerator dollars spent on custom silicon (cloud XPUs at program value, incl. internal transfer pricing)',
          denominator: 'all AI-accelerator dollars (custom silicon + merchant GPUs and accelerators)',
          geography: 'global',
          companyScope: 'all accelerator buyers (hyperscalers, labs, enterprises)',
          historyVsForecast: '2024–2025 estimates; 2026–2027 forecasts',
          measuresWhat: 'accelerator-dollar share — the ONLY basis eligible for scenario multiplication; NOT the TSMC AI-revenue attribution (Series B, DATA.tsmcRevenueShare)',
          source: 'compiled broker accelerator-spending tallies (access limited)',
          sourceDate: '2026-06'
        },
        asicShare: [
          { year: 2024, value: 0.08, state: 'estimate', src: 'K8',  tip: '2024 · ASIC ≈8% of accelerator dollars' },
          { year: 2025, value: 0.12, state: 'estimate', src: 'K8',  tip: '2025E · ASIC ≈12% of accelerator dollars' },
          { year: 2026, value: 0.16, state: 'forecast', src: 'K8',  tip: '2026F · ASIC ≈16% of accelerator dollars' },
          { year: 2027, value: 0.20, state: 'forecast', src: 'K8',  tip: '2027F · ASIC ≈20% of accelerator dollars' }
        ],
        drill: 'pen-dollar'
      }
    ]
  };

  /* ------------------------------------------------------------------ *
   * assumeA2 — the consensus under test (#assume-a2-chart):
   * Broadcom XPU customer count (announced + engaged) and Google
   * revenue concentration inside Broadcom AI revenue.
   * ------------------------------------------------------------------ */
  D.assumeA2 = {
    meta: {
      src: 'K23',
      note: 'Assumption A2 stress inputs: how many customers does the custom champion actually have, and how concentrated is the largest one (Google — first and largest; exact share undisclosed)? Broadcom Q2 FY26 (Jun 3 2026): 6 qualified XPU customers + 2 ramping; AI backlog ≈$73B+; FY26 AI ≈$56B; FY27 AI >$100B guided.',
      drill: 'avgo-customers'
    },
    xpuCustomers: {
      announced: [
        { year: 2022, value: 1, state: 'derived',  src: 'K23', drill: 'avgo-customers', tip: '2022 · 1 XPU customer (Google)' },
        { year: 2023, value: 2, state: 'derived',  src: 'K23', drill: 'avgo-customers', tip: '2023 · 2 XPU customers' },
        { year: 2024, value: 3, state: 'derived',  src: 'K23', drill: 'avgo-customers', tip: '2024 · 3 XPU customers' },
        { year: 2025, value: 4, state: 'actual',   src: 'K23', drill: 'avgo-customers', tip: '2025 · 4 XPU customers in production/ramp (Q3 FY25)' },
        { year: 2026, value: 6, state: 'actual',   src: 'K23', drill: 'avgo-customers', tip: '2026 · 6 qualified XPU customers (Q2 FY26, Jun 3 2026): Google, Meta, ByteDance, OpenAI, Anthropic, Fujitsu' }
      ],
      engaged: { value: 2, state: 'actual', src: 'K23', drill: 'avgo-customers', tip: '2 additional customers ramping (Q2 FY26, Jun 3 2026)' }
    },
    googleConcentration: [
      /* Google’s share of Broadcom AI revenue is NOT disclosed. Values are
         null on purpose: the register carries the hedged statement, not a
         fabricated series. */
      { year: 2022, value: null, state: 'gap', src: null, drill: 'google-concentration', tip: '2022 · Google — first and largest XPU customer; revenue share undisclosed' },
      { year: 2023, value: null, state: 'gap', src: null, drill: 'google-concentration', tip: '2023 · Google — first and largest XPU customer; revenue share undisclosed' },
      { year: 2024, value: null, state: 'gap', src: null, drill: 'google-concentration', tip: '2024 · Google — first and largest XPU customer; revenue share undisclosed' },
      { year: 2025, value: null, state: 'gap', src: null, drill: 'google-concentration', tip: '2025E · Google — first and largest XPU customer; revenue share undisclosed' }
    ]
  };

  /* ------------------------------------------------------------------ *
   * assumeA3 — program revision ledger, before → after
   * (#assume-a3-chart). Evidence for the “demand is visible to 2028”
   * assumption: every revision so far has been upward.
   * ------------------------------------------------------------------ */
  D.assumeA3 = {
    meta: {
      unit: 'US$B', fmt: 'moneyB',
      src: 'K5',
      note: 'The revision ledger. Every material AI-capex program revision since 2024 has moved in one direction.',
      drill: 'ledger-revisions'
    },
    revisions: [
      { program: 'Meta 2025 capex guide',            before: '$60–65B',      after: '$70–72B',      beforeVal: 62.5, afterVal: 71,   date: '2025-07', direction: 'up', state: 'actual',   src: 'K5',  drill: 'ledger-revisions', tip: 'Meta · 2025 guide raised twice, $60–65B → $70–72B' },
      { program: 'Alphabet 2025 capex guide',        before: '$75B',         after: '$91–93B',      beforeVal: 75,   afterVal: 92,   date: '2025-10', direction: 'up', state: 'actual',   src: 'K5',  drill: 'ledger-revisions', tip: 'Alphabet · 2025 guide $75B → $91–93B' },
      { program: 'Microsoft FY2026 capex',           before: '$80B',         after: '$140B+',       beforeVal: 80,   afterVal: 140,  date: '2025-10', direction: 'up', state: 'estimate', src: 'K5',  drill: 'ledger-revisions', tip: 'Microsoft · FY26 capex ≈$80B → $140B+ run-rate' },
      { program: 'Amazon 2025 capex',                before: '$105B',        after: '$125B',        beforeVal: 105,  afterVal: 125,  date: '2025-10', direction: 'up', state: 'estimate', src: 'K5',  drill: 'ledger-revisions', tip: 'Amazon · 2025 capex ≈$105B → ≈$125B' },
      { program: 'OpenAI infrastructure commitments', before: '$300B (Oracle)', after: '$1T+ aggregate', beforeVal: 300, afterVal: 1000, date: '2025-09', direction: 'up', state: 'estimate', src: null,  drill: 'stargate', tip: 'OpenAI · announced commitments passed ≈$1T in aggregate' },
      { program: 'Broadcom XPU customer count',      before: '4 + 3 engaged (Q3 FY25)', after: '6 qualified + 2 ramping (Q2 FY26)', beforeVal: 4, afterVal: 6, date: '2026-06', direction: 'up', state: 'actual', src: 'K23', drill: 'avgo-customers', tip: 'Broadcom · qualified XPU customers 4 → 6 (Google, Meta, ByteDance, OpenAI, Anthropic, Fujitsu); AI backlog ≈$73B+; FY27 AI >$100B guided' }
    ]
  };

})(window.DATA);
