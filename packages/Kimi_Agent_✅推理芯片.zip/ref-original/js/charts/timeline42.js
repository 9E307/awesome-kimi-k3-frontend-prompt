/**
 * js/charts/timeline42.js — "Forty-two years on one line"
 * Forty-Two Years of Inference Silicon · chart module (CONTRACT.md)
 *
 * CHARTS['timeline42'].render(container, data, ctx)
 *   data : DATA.timelineEvents (13 plaques) — windows read from DATA.windows
 *   ctx  : { tooltip, drill, d3, topojson, reducedMotion, DPR }
 *
 * 1985–2026 wall chart (SVG, viewBox, vector-crisp at every width):
 *   · six shaded window bands, names on THREE staggered rows (mono,
 *     uppercase, ink-lo)
 *   · thirteen event plaques (bold mono year + short label + 2px blue
 *     accent), packed greedily left→right into staggered rows
 *   · dotted connector from each plaque to a year pin (small tick) on a
 *     hairline year axis with light grid ticks
 *   · hover → tooltip (blurb) · click → evidence drill + smooth-scroll to
 *     the event's target section
 *
 * Desktop height is pinned at 504px; the chart redraws (never scales
 * blurrily) on resize, growing rows instead of colliding, and never drops
 * below ~380px at 342px width. Idempotent; own debounced ResizeObserver.
 */
window.CHARTS = window.CHARTS || {};
window.CHARTS['timeline42'] = (function () {
  'use strict';

  var MONO = 'Menlo, Consolas, "SF Mono", monospace';
  var C = {
    blue: '#2251ff', blueHi: '#1233b8', blueLo: '#7d9bff',
    ink: '#051c2c', inkMd: '#42566a', inkLo: '#8595a6',
    line: '#dbe2ea', lineLo: '#eef1f6', paper: '#ffffff'
  };
  var NS = 'http://www.w3.org/2000/svg';

  /* vertical metrics */
  var WIN_ROW_Y = [16, 31, 46];   /* three staggered window-label rows   */
  var BAND_TOP = 60;              /* shaded bands start below label rows */
  var AXIS_BLOCK = 30;            /* axis + tick labels at the bottom    */
  var PLAQUE_H = 32;              /* two-line plaque                     */
  var MIN_PITCH = PLAQUE_H + 11;  /* tightest staggered-row spacing      */
  var YEAR_FS = 10, LABEL_FS = 9, WIN_FS = 9;
  var YEAR_CW = YEAR_FS * 0.602, LABEL_CW = LABEL_FS * 0.602;

  function debounce(fn, ms) {
    if (window.UTILS && window.UTILS.debounce) return window.UTILS.debounce(fn, ms);
    var t = null;
    return function () {
      var a = arguments, s = this;
      if (t) clearTimeout(t);
      t = setTimeout(function () { t = null; fn.apply(s, a); }, ms);
    };
  }

  function hexA(hex, a) {
    var r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16);
    return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
  }

  function el(name, attrs, parent) {
    var n = document.createElementNS(NS, name);
    if (attrs) for (var k in attrs) n.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(n);
    return n;
  }

  /* truncate a mono label to a pixel budget */
  function fit(text, maxPx, charW) {
    if (text.length * charW <= maxPx) return text;
    var n = Math.max(3, Math.floor(maxPx / charW) - 1);
    return text.slice(0, n).replace(/[\s:;,.\-–—&]+$/, '') + '…';
  }

  function scrollToId(id, reduced) {
    var t = id && document.getElementById(id);
    if (t) t.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth', block: 'start' });
  }

  /* desktop target 504px; shrinks proportionally, floored at 380px */
  function targetH(W) {
    if (W >= 720) return 504;
    return Math.max(380, Math.round(504 * W / 876));
  }

  function render(container, data, ctx) {
    if (!container) return;
    ctx = ctx || {};
    var d3 = ctx.d3 || window.d3;
    var tooltip = ctx.tooltip || { show: function () {}, move: function () {}, hide: function () {} };
    var drill = typeof ctx.drill === 'function' ? ctx.drill : function () {};
    var reduced = !!ctx.reducedMotion;

    /* teardown of the previous render (idempotency) */
    var st = container.__tl42;
    if (st && st.ro) st.ro.disconnect();
    st = container.__tl42 = { ro: null, w: 0 };
    container.innerHTML = '';

    var events = Array.isArray(data) ? data.filter(Boolean).slice() : [];
    var D = window.DATA || {};
    var windows = Array.isArray(D.windows) ? D.windows : [];
    if (!events.length || !container.isConnected) return;

    var W = Math.max(280, container.clientWidth || 280);
    st.w = W;

    /* ---- x scale ----------------------------------------------------- */
    var margin = { l: 14, r: 14 };
    var x0d = 1984, x1d = 2027;
    function x(yr) { return margin.l + (yr - x0d) / (x1d - x0d) * (W - margin.l - margin.r); }

    /* ---- plaque text + greedy left→right row packing ------------------ */
    var labelCap = Math.min(200, Math.max(120, W * 0.42));
    var items = events.map(function (ev) {
      var yearLabel = String(ev.yearLabel !== undefined && ev.yearLabel !== null ? ev.yearLabel : ev.year);
      var label = fit(String(ev.label || ''), labelCap, LABEL_CW);
      var w = Math.max(yearLabel.length * YEAR_CW, label.length * LABEL_CW) + 14;
      return { ev: ev, yearLabel: yearLabel, label: label, cx: x(+ev.year || x0d), w: w };
    }).sort(function (a, b) { return (a.cx - b.cx) || (b.w - a.w); });

    var rowsRight = [];
    items.forEach(function (it) {
      it.left = Math.max(2, Math.min(it.cx - it.w / 2, W - 2 - it.w));
      var r = -1;
      for (var i = 0; i < rowsRight.length; i++) {
        if (rowsRight[i] + 10 <= it.left) { r = i; break; }
      }
      if (r < 0) { r = rowsRight.length; rowsRight.push(-Infinity); }
      it.row = r;
      rowsRight[r] = it.left + it.w;
    });
    var nRows = Math.max(1, rowsRight.length);

    /* ---- height: 504px desktop pin; grows rows instead of colliding --- */
    var H = targetH(W);
    var minH = BAND_TOP + (nRows - 1) * MIN_PITCH + PLAQUE_H + AXIS_BLOCK + 6;
    if (H < minH) H = minH;
    var axisY = H - AXIS_BLOCK;
    /* spread the staggered rows through the band area (pitch capped so the
       wall chart stays cohesive); the block is vertically centred */
    var avail = axisY - 4 - BAND_TOP - PLAQUE_H;
    var pitch = nRows > 1 ? Math.min(60, avail / (nRows - 1)) : 0;
    var blockH = (nRows - 1) * pitch + PLAQUE_H;
    var startY = BAND_TOP + Math.max(0, (axisY - 4 - BAND_TOP - blockH) / 2);
    function rowY(r) { return startY + r * pitch; }

    /* reserve the exact box (kills lazy-render layout shift) */
    container.style.height = H + 'px';

    /* ---- svg ---------------------------------------------------------- */
    var svg = el('svg', {
      width: W, height: H, viewBox: '0 0 ' + W + ' ' + H,
      role: 'img', 'aria-label': 'Forty-two years on one line — six shaded windows and thirteen event plaques, 1985 to 2026'
    }, container);
    svg.style.display = 'block';
    svg.style.maxWidth = '100%';
    svg.style.height = 'auto';

    /* ---- light grid ticks --------------------------------------------- */
    var tickYears = W < 560
      ? [1985, 1995, 2005, 2015, 2026]
      : [1985, 1990, 1995, 2000, 2005, 2010, 2015, 2020, 2026];
    var grid = el('g', { 'pointer-events': 'none' }, svg);
    tickYears.forEach(function (yr) {
      el('line', {
        x1: x(yr), y1: BAND_TOP, x2: x(yr), y2: axisY,
        stroke: C.lineLo, 'stroke-width': 1, 'shape-rendering': 'crispEdges'
      }, grid);
    });

    /* ---- six shaded window bands + 3 staggered label rows -------------- */
    var winRowRight = [-Infinity, -Infinity, -Infinity];
    windows.forEach(function (win, i) {
      if (!win || !Array.isArray(win.years)) return;
      var xa = x(Math.max(x0d, win.years[0])), xb = x(Math.min(x1d, win.years[1]));
      if (!(xb > xa)) return;
      var col = win.color || C.inkLo;
      var band = el('rect', {
        x: xa, y: BAND_TOP, width: xb - xa, height: axisY - BAND_TOP,
        fill: hexA(col, 0.08), stroke: 'none', cursor: 'pointer'
      }, svg);
      el('line', {
        x1: xa, y1: BAND_TOP, x2: xa, y2: axisY,
        stroke: C.line, 'stroke-width': 1, 'shape-rendering': 'crispEdges'
      }, svg);

      /* window name — mono uppercase, first-fit across the three rows */
      var name = 'W' + (i + 1) + ' · ' + String(win.name || '').toUpperCase();
      var cw = WIN_FS * 0.602 + 0.6; /* letter-spacing 0.6 */
      var lw = name.length * cw;
      var bandCx = (xa + xb) / 2;
      var placed = null, rr;
      for (rr = 0; rr < 3 && !placed; rr++) {
        var row = (i + rr) % 3;
        var left = Math.max(2, Math.min(bandCx - lw / 2, W - 2 - lw));
        if (left > winRowRight[row] + 8) placed = { row: row, left: left, text: name };
      }
      if (!placed) {
        var bestRow = 0, minRight = Infinity;
        for (rr = 0; rr < 3; rr++) {
          if (winRowRight[rr] < minRight) { minRight = winRowRight[rr]; bestRow = rr; }
        }
        var avail = Math.max(56, W - 2 - (minRight === -Infinity ? 0 : minRight + 8));
        var shrunk = fit(name, avail, cw);
        placed = { row: bestRow, left: minRight === -Infinity ? 2 : minRight + 8, text: shrunk };
        lw = shrunk.length * cw;
      }
      winRowRight[placed.row] = placed.left + placed.text.length * cw;
      /* hairline from the label down into its band */
      el('line', {
        x1: bandCx, y1: WIN_ROW_Y[placed.row] + 3, x2: bandCx, y2: BAND_TOP,
        stroke: C.lineLo, 'stroke-width': 1
      }, svg);
      var lab = el('text', {
        x: placed.left, y: WIN_ROW_Y[placed.row], 'text-anchor': 'start',
        'font-family': MONO, 'font-size': WIN_FS + 'px', 'letter-spacing': '0.6px',
        fill: C.inkLo, cursor: 'pointer'
      }, svg);
      lab.textContent = placed.text;

      function bandHover(ev) {
        tooltip.show('<b>' + (win.tip || win.name || '') + '</b><br>' +
          String(win.judgment || '').slice(0, 200), ev.clientX, ev.clientY);
        band.setAttribute('fill', hexA(col, 0.17));
      }
      function bandOut() { tooltip.hide(); band.setAttribute('fill', hexA(col, 0.08)); }
      function bandGo(ev) {
        var e = ev || {};
        drill(win.drill || win.src, e.clientX, e.clientY);
        scrollToId(win.sectionId, reduced);
      }
      [band, lab].forEach(function (node) {
        node.addEventListener('mouseover', bandHover);
        node.addEventListener('mousemove', function (ev) { tooltip.move(ev.clientX, ev.clientY); });
        node.addEventListener('mouseleave', bandOut);
        node.addEventListener('click', bandGo);
      });
    });
    /* closing boundary hairline */
    el('line', {
      x1: x(x1d), y1: BAND_TOP, x2: x(x1d), y2: axisY,
      stroke: C.line, 'stroke-width': 1, 'shape-rendering': 'crispEdges'
    }, svg);

    /* ---- dotted connectors + year pins (backdrop, non-interactive) ----- */
    var wires = el('g', { 'pointer-events': 'none' }, svg);
    items.forEach(function (it) {
      var py = rowY(it.row);
      var sx = Math.max(it.left + 8, Math.min(it.cx, it.left + it.w - 8));
      el('line', {
        x1: sx, y1: py + PLAQUE_H, x2: it.cx, y2: axisY - 5,
        stroke: C.line, 'stroke-width': 1, 'stroke-dasharray': '1.5 3'
      }, wires);
      /* year pin — small tick on the axis */
      it.pin = el('line', {
        x1: it.cx, y1: axisY - 4.5, x2: it.cx, y2: axisY + 4.5,
        stroke: C.blue, 'stroke-width': 1.5
      }, wires);
    });

    /* ---- thirteen event plaques ---------------------------------------- */
    items.forEach(function (it) {
      var py = rowY(it.row);
      /* mouse-only affordance (a11y diet): no tabindex / role / keydown —
         the plaque keeps cursor:pointer, hover tooltip, and a <title> */
      var g = el('g', { cursor: 'pointer' }, svg);
      var gTitle = el('title', {}, g);
      gTitle.textContent = it.yearLabel + ' · ' + (it.ev.label || '') + ' — click for the record';

      var rect = el('rect', {
        x: it.left, y: py, width: it.w, height: PLAQUE_H, rx: 2,
        fill: C.paper, stroke: C.line, 'stroke-width': 1
      }, g);
      /* 2px blue vertical accent on the left */
      el('rect', { x: it.left, y: py, width: 2, height: PLAQUE_H, fill: C.blue }, g);
      var year = el('text', {
        x: it.left + 8, y: py + 13, 'text-anchor': 'start',
        'font-family': MONO, 'font-size': YEAR_FS + 'px', 'font-weight': 'bold', fill: C.ink
      }, g);
      year.textContent = it.yearLabel;
      var lab = el('text', {
        x: it.left + 8, y: py + 26, 'text-anchor': 'start',
        'font-family': MONO, 'font-size': LABEL_FS + 'px', fill: C.inkMd
      }, g);
      lab.textContent = it.label;
      var pin = it.pin;

      function tipHtml() {
        return '<b>' + it.yearLabel + ' · ' + (it.ev.label || '') + '</b><br>' +
          (it.ev.blurb || it.ev.tip || '');
      }
      function hover(ev) {
        rect.setAttribute('stroke', C.blue);
        pin.setAttribute('stroke-width', '3');
        tooltip.show(tipHtml(), ev.clientX, ev.clientY);
      }
      function out() {
        rect.setAttribute('stroke', C.line);
        pin.setAttribute('stroke-width', '1.5');
        tooltip.hide();
      }
      function activate(ev) {
        var e = ev || {};
        drill(it.ev.drill || it.ev.src, e.clientX, e.clientY);
        scrollToId(it.ev.target, reduced);
      }
      g.addEventListener('mouseover', hover);
      g.addEventListener('mousemove', function (ev) { tooltip.move(ev.clientX, ev.clientY); });
      g.addEventListener('mouseleave', out);
      g.addEventListener('click', activate);
    });

    /* ---- hairline year axis --------------------------------------------- */
    var ax = el('g', { 'pointer-events': 'none' }, svg);
    el('line', {
      x1: margin.l, y1: axisY + 0.5, x2: W - margin.r, y2: axisY + 0.5,
      stroke: C.line, 'stroke-width': 1, 'shape-rendering': 'crispEdges'
    }, ax);
    tickYears.forEach(function (yr) {
      el('line', {
        x1: x(yr), y1: axisY, x2: x(yr), y2: axisY + 4,
        stroke: C.line, 'stroke-width': 1, 'shape-rendering': 'crispEdges'
      }, ax);
      var t = el('text', {
        x: x(yr), y: axisY + 16, 'text-anchor': 'middle',
        'font-family': MONO, 'font-size': '9.5px', fill: C.inkLo
      }, ax);
      t.textContent = String(yr);
    });

    /* ---- responsive redraw (debounced) ----------------------------------- */
    if ('ResizeObserver' in window) {
      var rerender = debounce(function () {
        var w = container.clientWidth || 0;
        if (Math.abs(w - st.w) < 2 || !container.isConnected) return;
        render(container, data, ctx);
      }, 140);
      st.ro = new ResizeObserver(rerender);
      st.ro.observe(container);
    }
  }

  /* reserve the desktop height before the lazy boot, so first paint and
     hash navigation land at the right scroll offset */
  function reserve() {
    var node = document.getElementById('timeline42-chart');
    if (node && !node.style.height && !node.__tl42) {
      node.style.height = targetH(Math.max(280, node.clientWidth || 876)) + 'px';
    }
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', reserve);
  } else {
    reserve();
  }

  return { render: render };
})();
