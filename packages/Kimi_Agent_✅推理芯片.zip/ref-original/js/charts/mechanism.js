/**
 * js/charts/mechanism.js — THE CYCLE MECHANISM
 * Forty-Two Years of Inference Silicon · chart module (CONTRACT.md)
 *
 * CHARTS['mechanism'].render(container, data, ctx)
 *   data : DATA.mechanismStages { meta, stages[5] }
 *   ctx  : { tooltip, drill, d3, topojson, reducedMotion, DPR }
 *
 * Canvas, DPR-aware, fixed 460px CSS height (no generic height formula).
 * One continuous waveform flows left → right through five stations —
 * demand ignition → capacity assumptions fail → panic double-ordering →
 * block arrivals → clearing — while per-stage amplitude morphs
 * 1.0 → 1.6 → 2.6 → 4.0 → 4.0 and the stroke runs blue → copper → neg
 * toward the peak. The final clearing segment BREAKS downward into a bust
 * curve (annotated `break ↓`; `amplification →` along the rise). Dashed
 * envelope lines bound the wave above and below; stage diamonds ride the
 * wave with node dots on the baseline. A large dashed Bézier feedback
 * loop arcs from Clearing back to Demand ignition carrying the exact
 * DATA.mechanismMeta.feedbackLabel. Hover a stage → tooltip (desc);
 * click → drill. The loop has its own hover + drill card. rAF phase
 * drift; one static frame under prefers-reduced-motion. Idempotent;
 * debounced ResizeObserver redraw.
 */
window.CHARTS = window.CHARTS || {};
window.CHARTS['mechanism'] = (function () {
  'use strict';

  var MONO = 'Menlo, Consolas, "SF Mono", monospace';
  var C = {
    blue: '#2251ff', blueHi: '#1233b8', blueLo: '#7d9bff',
    copper: '#b07a10', neg: '#c22f4e',
    ink: '#051c2c', inkMd: '#42566a', inkLo: '#8595a6',
    line: '#dbe2ea', lineLo: '#eef1f6', paper: '#ffffff'
  };
  var CSS_H = 460;                 /* fixed chart height — spec phase 5  */
  var AMPS_FALLBACK = [1.0, 1.6, 2.6, 4.0, 4.0];
  var CYCLES = [1.15, 1.45, 1.75, 1.35];   /* wave cycles per interval   */
  var BUST_AMP = 1.1;              /* oscillation left after the break   */

  function debounce(fn, ms) {
    if (window.UTILS && window.UTILS.debounce) return window.UTILS.debounce(fn, ms);
    var t = null;
    return function () {
      var a = arguments, s = this;
      if (t) clearTimeout(t);
      t = setTimeout(function () { t = null; fn.apply(s, a); }, ms);
    };
  }

  function hexA(hex, a) {
    var r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16);
    return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
  }

  function lerpHex(h1, h2, f) {
    var r1 = parseInt(h1.slice(1, 3), 16), g1 = parseInt(h1.slice(3, 5), 16), b1 = parseInt(h1.slice(5, 7), 16);
    var r2 = parseInt(h2.slice(1, 3), 16), g2 = parseInt(h2.slice(3, 5), 16), b2 = parseInt(h2.slice(5, 7), 16);
    function m(a, b) { return Math.round(a + (b - a) * f); }
    return 'rgb(' + m(r1, r2) + ',' + m(g1, g2) + ',' + m(b1, b2) + ')';
  }

  /* wave colour along its length: blue → copper → neg (peak) → ink (bust) */
  function waveColor(t, n) {       /* t in stage units, 0 .. n-1          */
    var peak = n - 2;              /* station index of the crest (3 of 5) */
    if (t >= peak) return lerpHex(C.neg, C.inkMd, Math.min(1, (t - peak) / (n - 1 - peak)));
    var half = peak * 0.5;
    if (t <= half) return lerpHex(C.blue, C.copper, t / half);
    return lerpHex(C.copper, C.neg, (t - half) / (peak - half));
  }

  function smoothstep(f) { return f * f * (3 - 2 * f); }

  function render(container, data, ctx) {
    if (!container) return;
    ctx = ctx || {};
    var U = window.UTILS || {};
    var tooltip = ctx.tooltip || { show: function () {}, move: function () {}, hide: function () {} };
    var drill = typeof ctx.drill === 'function' ? ctx.drill : function () {};
    var reduced = !!ctx.reducedMotion;
    var DPR = ctx.DPR || (U.DPR || Math.max(1, window.devicePixelRatio || 1));

    /* teardown of the previous render (idempotency) */
    var st = container.__mech;
    if (st) {
      if (st.ro) st.ro.disconnect();
      if (st.raf) cancelAnimationFrame(st.raf);
    }
    st = container.__mech = { ro: null, raf: 0, w: 0 };
    container.innerHTML = '';

    var stages = data && Array.isArray(data.stages) ? data.stages.filter(Boolean) : [];
    var meta = data && data.meta ? data.meta : {};
    var labels = (window.DATA && window.DATA.mechanismMeta) || {};
    var fbLabel = labels.feedbackLabel ||
      'R&D holds through the trough → the next technology base (300mm → EUV → HBM/CoWoS) → re-ignition';
    var ampNote = labels.ampNote || 'amplification →';
    var breakNote = labels.breakNote || 'break ↓';
    if (stages.length < 2 || !container.isConnected) return;
    stages.sort(function (a, b) { return (a.order || 0) - (b.order || 0); });

    var W = Math.max(280, container.clientWidth || 280);
    st.w = W;
    var H = CSS_H;

    container.style.height = H + 'px';
    var wrap = document.createElement('div');
    wrap.style.cssText = 'position:relative;width:100%;height:' + H + 'px';
    var canvas = document.createElement('canvas');
    canvas.setAttribute('role', 'img');
    canvas.setAttribute('aria-label', 'The cycle mechanism: one wave through five stages — ' +
      stages.map(function (s) { return s.name; }).join(', ') +
      ' — breaking into a bust curve, with a feedback loop back to demand.');
    wrap.appendChild(canvas);
    container.appendChild(wrap);

    /* ---- geometry ----------------------------------------------------- */
    var n = stages.length;
    var amps = stages.map(function (s, i) {
      var a = +s.amp;
      return isFinite(a) && a > 0 ? a : (AMPS_FALLBACK[i] || 1);
    });
    var padL = 30, padR = 30;
    var stageW = (W - padL - padR) / (n - 1);
    var sx = stages.map(function (_, i) { return padL + i * stageW; });
    var midY = 252;
    var crestI = n - 2;            /* block arrivals carries the peak     */
    var bustDepth = 62;

    /* feedback label wraps to the width; arc apex sits below it */
    var meas = document.createElement('canvas').getContext('2d');
    var FB_FS = 9, FB_LH = 12;
    if (meas) meas.font = FB_FS + 'px ' + MONO;
    function textW(s) { return meas ? meas.measureText(s).width : s.length * FB_FS * 0.602; }
    function wrapText(text, maxW) {
      var words = String(text).split(/\s+/), lines = [], cur = '';
      words.forEach(function (w) {
        var t = cur ? cur + ' ' + w : w;
        if (cur && textW(t) > maxW) { lines.push(cur); cur = w; }
        else cur = t;
      });
      if (cur) lines.push(cur);
      return lines.slice(0, 3);
    }
    var fbLines = wrapText(fbLabel, W - 32);
    var labelTopY = 16;
    var apexY = labelTopY + fbLines.length * FB_LH + 12;

    var baseAmp = Math.max(26, Math.min(38, (midY - apexY - 50) / amps[crestI]));

    /* amplitude morph 1.0→1.6→2.6→4.0, then the break decays to BUST_AMP */
    function ampAt(t) {
      var tt = Math.max(0, Math.min(n - 1, t));
      var i0 = Math.min(n - 1, Math.floor(tt)), i1 = Math.min(n - 1, i0 + 1);
      var a = amps[i0] + (amps[i1] - amps[i0]) * smoothstep(tt - i0);
      if (tt > crestI) {
        var f = Math.min(1, (tt - crestI) / (n - 1 - crestI));
        a = amps[crestI] + (BUST_AMP - amps[crestI]) * smoothstep(f);
      }
      return a;
    }
    /* the bust curve: mean line dives below the baseline after the peak  */
    function dropAt(t) {
      if (t <= crestI) return 0;
      return bustDepth * smoothstep(Math.min(1, (t - crestI) / (n - 1 - crestI)));
    }
    /* continuous phase: integrate local wavenumber station to station    */
    function thetaAt(t) {
      var th = 0, k;
      for (k = 0; k < Math.floor(t) && k < CYCLES.length; k++) th += CYCLES[k];
      if (t > 0 && k < CYCLES.length) th += CYCLES[k] * (t - Math.floor(t));
      return th * Math.PI * 2;
    }
    function waveY(x, phase) {
      var t = (x - padL) / stageW;
      var fade = Math.min(1, x / 22, (W - x) / 22);
      return midY + dropAt(t) - ampAt(t) * baseAmp * fade * Math.sin(thetaAt(Math.max(0, t)) + phase);
    }

    /* feedback loop geometry (static per layout) — Clearing → Demand.
       The arc leaves just above the settled bust wave at the Clearing
       station, sweeps over the whole chart, and lands above Demand. */
    var fbStart = { x: sx[n - 1], y: midY + bustDepth - BUST_AMP * baseAmp - 18 };
    var fbEnd = { x: sx[0], y: midY - amps[0] * baseAmp - 26 };
    var fbC1 = { x: sx[n - 1], y: apexY - 24 };
    var fbC2 = { x: sx[0], y: apexY - 24 };
    var fbPts = [];
    for (var pi = 0; pi <= 72; pi++) {
      var u = pi / 72, iu = 1 - u;
      fbPts.push({
        x: iu * iu * iu * fbStart.x + 3 * iu * iu * u * fbC1.x + 3 * iu * u * u * fbC2.x + u * u * u * fbEnd.x,
        y: iu * iu * iu * fbStart.y + 3 * iu * iu * u * fbC1.y + 3 * iu * u * u * fbC2.y + u * u * u * fbEnd.y
      });
    }
    var fbLabelBox = { x0: 0, y0: 0, x1: 0, y1: 0 };

    var hit = { stage: -1, fb: false };

    /* ---- drawing -------------------------------------------------------- */
    function draw(phase) {
      var env = U.dprCanvas ? U.dprCanvas(canvas) : (function () {
        canvas.width = W * DPR; canvas.height = H * DPR;
        canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
        var c = canvas.getContext('2d'); c.setTransform(DPR, 0, 0, DPR, 0, 0);
        return { ctx: c, w: W, h: H };
      })();
      var g = env.ctx;
      if (!g) return;
      g.clearRect(0, 0, W, H);
      g.lineJoin = 'round';
      g.lineCap = 'round';

      function halo(text, x, y) {
        g.lineWidth = 3;
        g.strokeStyle = 'rgba(255,255,255,0.92)';
        g.strokeText(text, x, y);
      }

      /* hairline baseline */
      g.beginPath();
      g.moveTo(0, midY + 0.5);
      g.lineTo(W, midY + 0.5);
      g.strokeStyle = C.line;
      g.lineWidth = 1;
      g.stroke();

      /* dashed envelope lines above / below the wave */
      [1, -1].forEach(function (side) {
        g.beginPath();
        for (var x = 0; x <= W; x += 3) {
          var t = Math.max(0, (x - padL) / stageW);
          var fade = Math.min(1, x / 22, (W - x) / 22);
          var y = midY + dropAt(t) - side * ampAt(t) * baseAmp * fade;
          if (x === 0) g.moveTo(x, y); else g.lineTo(x, y);
        }
        g.setLineDash([3, 4]);
        g.strokeStyle = hexA(C.inkLo, 0.55);
        g.lineWidth = 1;
        g.stroke();
        g.setLineDash([]);
      });

      /* ghost harmonic — plotted-instrument texture */
      g.beginPath();
      for (var gx = 0; gx <= W; gx += 2) {
        var gt = Math.max(0, (gx - padL) / stageW);
        var gy = midY + dropAt(gt) - (midY + dropAt(gt) - waveY(gx, phase)) * 0.32;
        if (gx === 0) g.moveTo(gx, gy); else g.lineTo(gx, gy);
      }
      g.globalAlpha = 0.4;
      g.strokeStyle = C.blueLo;
      g.lineWidth = 0.75;
      g.stroke();
      g.globalAlpha = 1;

      /* main wave — stroke colour runs blue → copper → neg → ink */
      var grad = g.createLinearGradient(0, 0, W, 0);
      grad.addColorStop(0, C.blue);
      grad.addColorStop(Math.max(0.01, Math.min(0.99, (padL + (crestI * 0.5) * stageW) / W)), C.copper);
      grad.addColorStop(Math.max(0.01, Math.min(0.99, sx[crestI] / W)), C.neg);
      grad.addColorStop(1, C.inkMd);
      g.beginPath();
      for (var wx = 0; wx <= W; wx += 2) {
        var wy = waveY(wx, phase);
        if (wx === 0) g.moveTo(wx, wy); else g.lineTo(wx, wy);
      }
      g.strokeStyle = grad;
      g.lineWidth = 1.8;
      g.stroke();

      /* annotations: amplification along the rise, break at the dive */
      g.font = '9px ' + MONO;
      g.textAlign = 'center';
      g.textBaseline = 'alphabetic';
      var ampX = padL + stageW * 1.5, ampY = midY - ampAt(1.5) * baseAmp - 12;
      halo(ampNote, ampX, ampY);
      g.fillStyle = C.copper;
      g.fillText(ampNote, ampX, ampY);
      var brkX = sx[crestI] + stageW * 0.44, brkY = midY + 34;
      halo(breakNote, brkX, brkY);
      g.fillStyle = C.neg;
      g.fillText(breakNote, brkX, brkY);

      /* feedback loop — large dashed Bézier, Clearing → Demand ignition */
      g.beginPath();
      g.moveTo(fbPts[0].x, fbPts[0].y);
      for (var fi = 1; fi < fbPts.length; fi++) g.lineTo(fbPts[fi].x, fbPts[fi].y);
      g.setLineDash([5, 5]);
      g.strokeStyle = hit.fb ? C.blue : C.inkLo;
      g.lineWidth = hit.fb ? 1.6 : 1.1;
      g.stroke();
      g.setLineDash([]);
      /* arrowhead into demand */
      g.beginPath();
      g.moveTo(fbEnd.x, fbEnd.y + 7);
      g.lineTo(fbEnd.x - 4.5, fbEnd.y - 2);
      g.lineTo(fbEnd.x + 4.5, fbEnd.y - 2);
      g.closePath();
      g.fillStyle = hit.fb ? C.blue : C.inkLo;
      g.fill();
      /* exact feedback label, centred above the arc */
      g.font = FB_FS + 'px ' + MONO;
      var fbMaxW = 0;
      fbLines.forEach(function (ln, li) {
        var ly = labelTopY + li * FB_LH;
        halo(ln, W / 2, ly);
        g.fillStyle = hit.fb ? C.blue : C.inkLo;
        g.fillText(ln, W / 2, ly);
        fbMaxW = Math.max(fbMaxW, textW(ln));
      });
      fbLabelBox = {
        x0: W / 2 - fbMaxW / 2 - 8, y0: labelTopY - FB_FS - 4,
        x1: W / 2 + fbMaxW / 2 + 8, y1: labelTopY + (fbLines.length - 1) * FB_LH + 4
      };

      /* node dots on the baseline */
      stages.forEach(function (s, i) {
        var hot = hit.stage === i;
        g.beginPath();
        g.arc(sx[i], midY, hot ? 4.5 : 3, 0, Math.PI * 2);
        g.fillStyle = hot ? C.blue : C.paper;
        g.fill();
        g.strokeStyle = hot ? C.blue : waveColor(i, n);
        g.lineWidth = 1.4;
        g.stroke();
      });

      /* stage diamond markers riding the wave */
      stages.forEach(function (s, i) {
        var y = waveY(sx[i], phase);
        var hot = hit.stage === i;
        var d = hot ? 6.5 : 5;
        g.beginPath();
        g.moveTo(sx[i], y - d);
        g.lineTo(sx[i] + d, y);
        g.lineTo(sx[i], y + d);
        g.lineTo(sx[i] - d, y);
        g.closePath();
        g.fillStyle = hot ? waveColor(i, n) : C.paper;
        g.fill();
        g.strokeStyle = hot ? C.blue : waveColor(i, n);
        g.lineWidth = 1.5;
        g.stroke();
      });

      /* stage labels — mono, uppercase, wrapped, on two staggered lanes as
         a floor; each label is tucked just below the LOCAL extent of the
         wave + envelope so the trace never strikes the text, with a dotted
         leader back up to its node dot on the baseline */
      g.font = '9px ' + MONO;
      var laneW = Math.min(2 * stageW - 12, 340);
      stages.forEach(function (s, i) {
        var hot = hit.stage === i;
        var name = (i + 1) + ' · ' + String(s.name || '').toUpperCase();
        var lines = wrapText(name, laneW);
        var w = 0;
        lines.forEach(function (ln) { w = Math.max(w, textW(ln)); });
        var lx = Math.max(4 + w / 2, Math.min(sx[i], W - 4 - w / 2));
        /* local lower extent of wave + envelope across the label's span */
        var envMax = midY;
        for (var k = -6; k <= 6; k++) {
          var xx = lx + (k / 6) * (w / 2);
          var tt = Math.max(0, (xx - padL) / stageW);
          var fd = Math.min(1, xx / 22, (W - xx) / 22);
          var ext = midY + dropAt(tt) + ampAt(tt) * baseAmp * fd;
          if (ext > envMax) envMax = ext;
        }
        var laneY = midY + 24 + (i % 2) * 18;
        var ly = Math.min(H - 8 - (lines.length - 1) * 11, Math.max(laneY, envMax + 16));
        /* dotted leader from the node dot down to a pushed-down label */
        if (ly > midY + 46) {
          g.beginPath();
          g.moveTo(sx[i] + 0.5, midY + 8);
          g.lineTo(sx[i] + 0.5, ly - 13);
          g.setLineDash([1.5, 3]);
          g.strokeStyle = C.line;
          g.lineWidth = 1;
          g.stroke();
          g.setLineDash([]);
        }
        lines.forEach(function (ln, li) {
          halo(ln, lx, ly + li * 11);
          g.fillStyle = hot ? C.blue : C.inkMd;
          g.fillText(ln, lx, ly + li * 11);
        });
      });
    }

    /* ---- hit testing ----------------------------------------------------- */
    function locate(mx, my) {
      if (mx >= fbLabelBox.x0 && mx <= fbLabelBox.x1 && my >= fbLabelBox.y0 && my <= fbLabelBox.y1) {
        return { stage: -1, fb: true };
      }
      var bd = Infinity;
      for (var i = 0; i < fbPts.length; i++) {
        var dx = mx - fbPts[i].x, dy = my - fbPts[i].y;
        var d2 = dx * dx + dy * dy;
        if (d2 < bd) bd = d2;
      }
      if (bd < 81) return { stage: -1, fb: true };   /* within 9px of the arc */
      var best = -1, bdx = Infinity;
      for (var si = 0; si < n; si++) {
        var d = Math.abs(mx - sx[si]);
        if (d < bdx) { bdx = d; best = si; }
      }
      if (bdx <= stageW / 2 && my > apexY + 4) return { stage: best, fb: false };
      return { stage: -1, fb: false };
    }

    function redrawStatic() { draw(phase); }

    canvas.addEventListener('mousemove', function (ev) {
      var r = canvas.getBoundingClientRect();
      var h = locate(ev.clientX - r.left, ev.clientY - r.top);
      var changed = h.stage !== hit.stage || h.fb !== hit.fb;
      hit = h;
      canvas.style.cursor = (h.stage >= 0 || h.fb) ? 'pointer' : 'default';
      if (h.fb) {
        tooltip.show('<b>The loop closes — feedback to the next cycle</b><br>' + fbLabel, ev.clientX, ev.clientY);
      } else if (h.stage >= 0) {
        var s = stages[h.stage];
        tooltip.show('<b>' + (s.tip || ('Stage ' + (h.stage + 1) + ' · ' + s.name)) + '</b><br>' +
          (s.desc || s.description || ''), ev.clientX, ev.clientY);
      } else {
        tooltip.hide();
      }
      if (changed && reduced) redrawStatic(); /* animated mode redraws next frame */
    });
    canvas.addEventListener('mouseleave', function () {
      hit = { stage: -1, fb: false };
      canvas.style.cursor = 'default';
      tooltip.hide();
      if (reduced) redrawStatic();
    });
    canvas.addEventListener('click', function (ev) {
      var r = canvas.getBoundingClientRect();
      var h = locate(ev.clientX - r.left, ev.clientY - r.top);
      if (h.fb) { drill(meta.drill || 'mechanism-loop', ev.clientX, ev.clientY); return; }
      if (h.stage >= 0 && stages[h.stage].drill) drill(stages[h.stage].drill, ev.clientX, ev.clientY);
    });

    /* ---- animate (static under reduced motion) ---------------------------- */
    var phase = 0;
    if (reduced) {
      draw(0);
    } else {
      var last = 0;
      var loop = function (ts) {
        if (!canvas.isConnected) { st.raf = 0; return; }   /* self-cleaning */
        st.raf = requestAnimationFrame(loop);
        if (document.hidden) return;
        if (ts - last < 33) return;                        /* ~30fps is plenty */
        last = ts;
        phase += 0.03;
        draw(phase);
      };
      st.raf = requestAnimationFrame(loop);
    }

    /* ---- responsive redraw (debounced) ------------------------------------- */
    if ('ResizeObserver' in window) {
      var rerender = debounce(function () {
        var w = container.clientWidth || 0;
        if (Math.abs(w - st.w) < 2 || !container.isConnected) return;
        render(container, data, ctx);
      }, 140);
      st.ro = new ResizeObserver(rerender);
      st.ro.observe(container);
    }
  }

  /* reserve the exact 460px before the lazy boot so first paint and hash
     navigation land at the right scroll offset */
  function reserve() {
    var node = document.getElementById('mechanism-chart');
    if (node && !node.style.height && !node.__mech) node.style.height = CSS_H + 'px';
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', reserve);
  } else {
    reserve();
  }

  return { render: render };
})();
