# QA 验收报告 v2（修复后复验）· inference-silicon-cn（只读验收）

- 对象：`/mnt/agents/output/inference-silicon-cn/`（本地 `python3 -m http.server 8765`，已停服）
- 工具：Python Playwright + Chromium headless；脚本 `/tmp/qa/qa_accept.py`（项目目录零改动）
- 复验范围：A 几何 / B 结构 / C 行为（含 console=0、hash×5）/ D 多窗口截图 + mining 专项 + 视觉抽查
- **总结：40 PASS / 1 FAIL**（唯一 FAIL 为遗留验收口径项，非回归）

## 修复确认（本轮核心）

| 修复项 | 复验结果 |
|---|---|
| 1) mining.js 重写适配器消费 CD.mining schema | **确认修复**：console.error 54→**0**（含 pageerror，load+交互全程）；mining svg NaN 元素 28→**0**；10/10 rect 全部有效；冲击带=2（第一次 2018Q4–2019 / 第二次 2022，粉色半透明带）、事件 plaque=4（2017 点火 / 2019 hangover / 2021 第二波 / 2022 转 PoS）全部正确渲染，截图 `09-1280-sec-mining-fixed.png` 目视确认 |
| 2) index.html 扩写 +47 段 | **确认达标**：scrollHeight 38707→**45267**（∈ [42000,47000]，与预告 ≈45,267 一致），<53000 硬上限 |

## A. 1280×720 几何（14/14 PASS）

| # | 项目 | 实际 |
|---|---|---|
| A1/A2 | body bg rgb(255,255,255) / color rgb(5,28,44) | 精确一致 |
| A3 | main width | 820 |
| A4 | #dash-rail | x=820 w=460 y=0 fixed |
| A5–A7 | .prose 外框 692 / 文本 x=88 / 宽 644 | 精确（容差内） |
| A8/A9 | .wide.xl chart-frame | x=24 w=772 |
| A10–A12 | .cover-inner / .cover-title | x=80 w=1120 / x=104 |
| A13 | #cover-canvas rect 宽 | 1280（全宽） |
| A14 | scrollHeight | **45267** ✓ |

## B. 结构计数（4/4 PASS）
section.band=19；.chart-frame=26；.quote-card=9；无 #now-chart。

## C. 行为（18/19 PASS）

| # | 项目 | 判定 |
|---|---|---|
| C1–C4 | cover 时双 rail 隐藏 → 进文章 .on+opacity 1 | PASS |
| C5 | era-rail = 6 段 .era-seg（0 个 `<a>`） | PASS |
| C6 | 27 个 [data-chart] 均有 svg/canvas/table | **FAIL（字面）**：26/27 符合；`invest` 为 HTML 卡片（6 张 .inv-card：Broadcom/Marvell/MediaTek/GUC/Alchip/VeriSilicon，内容完整非空）——与上轮相同，属验收口径项，非回归 |
| C6b | mining 复验：NaN=0、冲击带≥2、plaque≥4 | PASS（2 带 + 4 plaque + 财年阶梯线 + BTC 背景线齐全） |
| C7/C8 | A/B/C 模式按钮存在，b→c→a 切换 0 报错 | PASS |
| C9–C11 | tooltip hover 可见 / drill 打开（标题正确）/ Escape 关闭 | PASS |
| C12 | 控制台错误 = 0 | PASS（console.error 0 / pageerror 0） |
| C-hash ×5 | /#sec-frame 57.5 / /#sec-crossover 57.9 / /#sec-verdict 58.0 / /#sec-signals 57.8 / /#sec-invest 58.1 px（均 ±60 内）且各次加载 0 错误 | PASS ×5 |

## D. 多窗口截图（5/5 PASS，9 张全量重拍）

| # | 项目 | 实际 |
|---|---|---|
| D1 | 1280×720 ×4 + mining 复验 ×1 | 已重拍覆盖 |
| D2 | 768×1024 ×2，无横向溢出，0 错误 | scrollWidth=768=innerWidth，dash-rail display=none |
| D3–D5 | 390×844：dashboard display:none；scrollWidth=390≤391；截图 ×2，0 错误 | PASS |

## 视觉抽查（PASS）
白底不泛黄、正文深蓝 #051c2c、强调色 #2251ff、cover 左边距 ≈104、窄栏 644/宽栏 772、dashboard 固定右侧 460px 且点阵地球可见（Beijing/Seoul/Hsinchu 等标注）、mining 图两轮冲击带与 4 枚事件 plaque 清晰可见、移动端无横向溢出。扩写后 cover 与版式无回归（新增「阅读路径」等段落正常排版）。

## 遗留项（1 项，建议口径确认）
- **C6 invest 形态**：`[data-chart="invest"]` 渲染为 HTML 卡片网格而非 svg/canvas/table。内容实际完整（非空图）。若验收口径接受「svg/canvas/table 或等价 HTML 富内容」，则全量 41 项通过；若坚持字面节点类型，需前端把 invest 改为 table/svg 或修订标准。

## 截图清单（/mnt/agents/output/qa/，本轮全量重拍）
1. `01-1280-cover.png` 2. `02-1280-sec-frame.png` 3. `03-1280-sec-bottleneck.png` 4. `04-1280-sec-verdict.png`
5. `05-768x1024-cover.png` 6. `06-768x1024-sec-frame.png`
7. `07-390x844-cover.png` 8. `08-390x844-sec-frame.png`
9. `09-1280-sec-mining-fixed.png`（修复确认；旧 `09-...-bug.png` 已删除）

备注：验收全程未修改项目文件；本地服务器已关闭。
