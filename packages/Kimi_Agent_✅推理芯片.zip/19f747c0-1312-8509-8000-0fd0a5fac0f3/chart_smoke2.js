/* Smoke test v2: run all 12 chart keys in BOTH modes — fallback and real CHART_DATA. */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

function makeEl(tag) {
  const el = {
    tagName: tag, children: [], attrs: {}, _html: '', _text: '', style: {}, className: '', listeners: {},
    setAttribute(k, v) { this.attrs[k] = String(v); },
    getAttribute(k) { return this.attrs[k]; },
    removeAttribute(k) { delete this.attrs[k]; },
    appendChild(c) { this.children.push(c); return c; },
    addEventListener(t, f) { (this.listeners[t] = this.listeners[t] || []).push(f); },
    dispatchEvent(e) { e.type = e.type || 'click'; (this.listeners[e.type] || []).forEach(f => f.call(this, e)); },
    querySelector(sel) { return this.querySelectorAll(sel)[0] || null; },
    querySelectorAll(sel) {
      if (!this._stubCache) this._stubCache = {};
      const classes = sel.split(',').map(s => s.trim().replace(/^\./, ''));
      const out = [];
      for (const c of classes) {
        if (this._stubCache[c]) { out.push(...this._stubCache[c]); continue; }
        const html = this._html || '';
        const list = [];
        const re = new RegExp('<g\\b[^>]*class="([^"]*\\b' + c + '\\b[^"]*)"[^>]*>', 'g');
        let m;
        while ((m = re.exec(html))) {
          const stub = makeEl('g');
          const dm = /data-i="(\d+)"/.exec(m[0]); if (dm) stub.attrs['data-i'] = dm[1];
          const dc = /data-c="(\d+)"/.exec(m[0]); if (dc) stub.attrs['data-c'] = dc[1];
          const dz = /data-z="(\d+)"/.exec(m[0]); if (dz) stub.attrs['data-z'] = dz[1];
          const dy = /data-y="(\d+)"/.exec(m[0]); if (dy) stub.attrs['data-y'] = dy[1];
          list.push(stub);
        }
        this._stubCache[c] = list;
        out.push(...list);
      }
      return out;
    }
  };
  Object.defineProperty(el, 'innerHTML', {
    set(v) { this._html = String(v); if (v === '') { this.children = []; this._stubCache = {}; } },
    get() { return this._html; }
  });
  Object.defineProperty(el, 'textContent', { set(v) { this._text = String(v); }, get() { return this._text; } });
  return el;
}

const DIR = '/mnt/agents/output/inference-silicon-cn/js';
const chartFiles = ['gates.js', 'cowos.js', 'hbm.js', 'hbmgen.js', 'partition.js', 'assumptions.js',
  'matrix.js', 'verdict_tree.js', 'scenario_chain.js', 'signals.js', 'deepdive.js'];
const expected = ['gates', 'cowos', 'hbm', 'hbmgen', 'partition', 'assume-a2', 'assume-a3',
  'matrix', 'verdict-tree', 'scenario-chain', 'signals', 'invest'];

let totalFail = 0;
for (const withData of [false, true]) {
  const ctx = {
    console,
    getComputedStyle: () => ({ getPropertyValue: () => '' }),
    document: {
      documentElement: makeEl('html'),
      createElement: t => makeEl(t),
      createElementNS: (ns, t) => makeEl(t)
    },
    Event: function (type) { this.type = type; },
    ResizeObserver: undefined
  };
  ctx.window = ctx;
  ctx.globalThis = ctx;
  vm.createContext(ctx);
  if (withData) {
    vm.runInContext(fs.readFileSync(path.join(DIR, 'data.js'), 'utf8'), ctx, { filename: 'data.js' });
    if (!ctx.window.CHART_DATA) { console.error('CHART_DATA not defined by data.js'); process.exit(1); }
  }
  for (const f of chartFiles) {
    vm.runInContext(fs.readFileSync(path.join(DIR, 'charts', f), 'utf8'), ctx, { filename: f });
  }
  const registered = Object.keys(ctx.window.Charts || {});
  const missing = expected.filter(k => !registered.includes(k));
  if (missing.length) { console.error(`[withData=${withData}] MISSING KEYS:`, missing); process.exit(1); }

  let fail = 0;
  for (const w of [760, 360]) {
    for (const key of expected) {
      const body = makeEl('div');
      body.className = 'chart-body';
      Object.defineProperty(body, 'clientWidth', { get: () => w });
      const frame = makeEl('figure');
      frame.querySelector = sel => (sel === '.chart-body' ? body : null);
      try {
        ctx.window.Charts[key](frame);
        const hasAria = (body._html && /aria-label/.test(body._html)) ||
          body.children.some(c => c.attrs && c.attrs['aria-label']) ||
          (body.children[0] && body.children[0].attrs && body.children[0].attrs['aria-label']);
        const svg = body.children.find(c => c.tagName === 'svg');
        let evCount = 0;
        if (svg) {
          svg.querySelectorAll('.gate,.cap,.gapdir,.dem,.share,.spt,.note,.gen,.layer,.rack,.pt,.met,.ev,.verdict,.ms,.zone,.root,.br,.kill,.nd')
            .forEach(el => {
              const evt = { clientX: 10, clientY: 10, key: 'Enter', preventDefault() { } };
              ['mouseenter', 'mousemove', 'mouseleave', 'click', 'keydown'].forEach(t => {
                (el.listeners[t] || []).forEach(fn => { fn.call(el, evt); evCount++; });
              });
            });
        }
        const walk = (node) => {
          (node.children || []).forEach(ch => {
            if (ch.listeners && (ch.listeners.click || ch.listeners.mouseenter)) {
              const evt = { clientX: 5, clientY: 5, key: 'Enter', preventDefault() { } };
              ['mouseenter', 'mousemove', 'mouseleave', 'click', 'keydown'].forEach(t => {
                (ch.listeners[t] || []).forEach(fn => { fn.call(ch, evt); evCount++; });
              });
            }
            walk(ch);
          });
        };
        walk(body);
        /* undefined/NaN 泄漏检查 */
        const htmlStr = body._html || '';
        const bad = /undefined|NaN/.test(htmlStr) ||
          body.children.some(c => c._html && /undefined|NaN/.test(c._html));
        if (bad) { fail++; console.error(`BADVAL ${key} @${w} withData=${withData}`); }
        else console.log(`OK  ${key} @${w}px withData=${withData} aria=${!!hasAria} events=${evCount}`);
      } catch (e) {
        fail++;
        console.error(`FAIL ${key} @${w}px withData=${withData}: ${e.message}`);
      }
    }
  }
  console.log(withData ? (fail ? `WITH-DATA FAILURES: ${fail}` : 'WITH-DATA PASSED') : (fail ? `FALLBACK FAILURES: ${fail}` : 'FALLBACK PASSED'));
  totalFail += fail;
}
process.exit(totalFail ? 1 : 0);
