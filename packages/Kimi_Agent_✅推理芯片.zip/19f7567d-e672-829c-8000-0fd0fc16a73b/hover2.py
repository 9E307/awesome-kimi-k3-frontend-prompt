from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={'width':1440,'height':900})
    pg.goto('http://127.0.0.1:8765/', wait_until='load')
    pg.wait_for_selector('#capex3d-chart .chart-body svg', timeout=15000)
    pg.wait_for_timeout(900)
    pg.evaluate("() => document.getElementById('capex3d-chart').scrollIntoView({block:'center'})")
    pg.wait_for_timeout(400)
    box = pg.evaluate("""() => {
      const hits = [...document.querySelectorAll('#capex3d-chart rect[fill="transparent"]')];
      const r = hits[5].getBoundingClientRect(); return {x:r.x+r.width/2, y:r.y+r.height/2};
    }""")
    pg.mouse.move(box['x'], box['y'])
    pg.wait_for_timeout(250)
    print('tooltip capex3d:', pg.evaluate("() => { const t=document.getElementById('tooltip'); return {hidden:t.hidden, html:t.innerHTML.slice(0,120)}; }"))
    b.close()
