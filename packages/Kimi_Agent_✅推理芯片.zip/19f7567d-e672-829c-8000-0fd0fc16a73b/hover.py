from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={'width':1440,'height':900})
    errs=[]
    pg.on('console', lambda m: errs.append(m.text) if m.type=='error' else None)
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('http://127.0.0.1:8765/', wait_until='load')
    pg.wait_for_selector('#capex3d-chart .chart-body svg', timeout=15000)
    pg.wait_for_timeout(900)
    # hover a capex3d pair
    box = pg.evaluate("""() => {
      const hits = [...document.querySelectorAll('#capex3d-chart rect[fill="transparent"]')];
      const r = hits[5].getBoundingClientRect(); return {x:r.x+r.width/2, y:r.y+r.height/2};
    }""")
    pg.mouse.move(box['x'], box['y'])
    pg.wait_for_timeout(250)
    tip = pg.evaluate("() => { const t=document.getElementById('tooltip'); return {hidden:t.hidden, html:t.innerHTML.slice(0,90)}; }")
    print('tooltip capex3d:', tip)
    # hover stamps card
    pg.evaluate("() => document.getElementById('stamps-chart').scrollIntoView({block:'center'})")
    pg.wait_for_timeout(300)
    box2 = pg.evaluate("""() => {
      const g = document.querySelectorAll('#stamps-chart .chart-body svg > g')[7];
      const r = g.getBoundingClientRect(); return {x:r.x+40, y:r.y+40};
    }""")
    pg.mouse.move(box2['x'], box2['y'])
    pg.wait_for_timeout(250)
    print('tooltip stamps:', pg.evaluate("() => { const t=document.getElementById('tooltip'); return {hidden:t.hidden, html:t.innerHTML.slice(0,90)}; }"))
    # resize idempotency: change viewport, re-render, expect no errors & svg re-drawn
    pg.set_viewport_size({'width':1280,'height':800})
    pg.wait_for_timeout(700)
    w = pg.evaluate("() => document.querySelector('#capex3d-chart .chart-body svg').getAttribute('width')")
    h = pg.evaluate("() => document.querySelector('#stamps-chart .chart-body svg').getAttribute('height')")
    print('after resize capex3d w:', w, 'stamps h:', h)
    print('console errors:', errs)
    b.close()
