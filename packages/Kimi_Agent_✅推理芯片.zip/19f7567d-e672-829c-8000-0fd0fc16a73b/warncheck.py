from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={'width':1440,'height':900})
    msgs=[]
    pg.on('console', lambda m: msgs.append((m.type, m.text)) if m.type in ('error','warning') else None)
    pg.on('pageerror', lambda e: msgs.append(('pageerror', str(e))))
    pg.goto('http://127.0.0.1:8765/', wait_until='load')
    pg.wait_for_timeout(2500)
    bad = [m for m in msgs if '渲染失败' in m[1] or 'capex3d' in m[1] or 'stamps' in m[1] or m[0]=='pageerror' or m[0]=='error']
    print('total warn/err:', len(msgs), '| relevant:', bad[:10])
    b.close()
