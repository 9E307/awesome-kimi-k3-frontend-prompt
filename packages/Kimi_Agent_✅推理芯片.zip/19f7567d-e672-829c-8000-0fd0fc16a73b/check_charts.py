#!/usr/bin/env python3
"""Playwright 自查：capex3d / stamps 渲染质量"""
import json, sys, time
from playwright.sync_api import sync_playwright

BASE = 'http://127.0.0.1:8765/'
results = {}

def check_viewport(page, width, height, tag):
    errs = []
    page.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
    page.on('pageerror', lambda e: errs.append(str(e)))
    page.goto(BASE, wait_until='load')
    page.wait_for_selector('#capex3d-chart .chart-body svg', timeout=15000)
    page.wait_for_selector('#stamps-chart .chart-body svg', timeout=15000)
    page.wait_for_timeout(1200)

    out = {}
    # ---- capex3d ----
    cx = page.evaluate("""() => {
      const svg = document.querySelector('#capex3d-chart .chart-body svg');
      if (!svg) return {ok:false};
      const rects = svg.querySelectorAll('rect').length;
      const texts = [...svg.querySelectorAll('text')].map(t => t.textContent);
      const html = svg.innerHTML;
      return { ok:true, w: svg.getAttribute('width'), h: svg.getAttribute('height'),
        rects, paths: svg.querySelectorAll('path').length, lines: svg.querySelectorAll('line').length,
        hasNaN: html.includes('NaN'), has102: texts.includes('1.02'), has032: texts.includes('0.32'),
        hasRef: texts.some(t => t.includes('0.38') && t.includes('0.63')),
        hasHint: texts.some(t => t.includes('点击任意柱')),
        aria: svg.getAttribute('aria-label') ? svg.getAttribute('aria-label').slice(0,60) : null,
        role: svg.getAttribute('role') };
    }""")
    out['capex3d'] = cx

    # click a bar (hit rect) -> drill
    page.evaluate("""() => {
      const svg = document.querySelector('#capex3d-chart .chart-body svg');
      const hits = [...svg.querySelectorAll('rect[fill="transparent"]')];
      const r = hits[Math.floor(hits.length/2)];
      const b = r.getBoundingClientRect();
      r.dispatchEvent(new MouseEvent('click', {bubbles:true, clientX:b.x+b.width/2, clientY:b.y+b.height/2}));
    }""")
    page.wait_for_timeout(300)
    drill = page.evaluate("""() => {
      const o = document.getElementById('drill-overlay');
      return { open: o && !o.hidden, title: (document.querySelector('#drill-card .drill-title')||{}).textContent || '',
               body: ((document.querySelector('#drill-card .drill-body')||{}).textContent || '').slice(0, 80),
               src: (document.querySelector('#drill-card .drill-src')||{}).textContent || '' };
    }""")
    out['capex3d_drill'] = drill
    page.keyboard.press('Escape')
    page.wait_for_timeout(200)
    out['capex3d_drill_closed'] = page.evaluate("() => document.getElementById('drill-overlay').hidden")

    # ---- stamps ----
    st = page.evaluate("""() => {
      const svg = document.querySelector('#stamps-chart .chart-body svg');
      if (!svg) return {ok:false};
      const texts = [...svg.querySelectorAll('text')].map(t => t.textContent);
      return { ok:true, w: svg.getAttribute('width'), h: svg.getAttribute('height'),
        texts_n: texts.length, hasNaN: svg.innerHTML.includes('NaN'),
        hasUndisclosed: texts.some(t => t.includes('未披露')),
        cards: ['Ironwood','TPU v8','Trainium 3','Trainium 2','Inferentia 2','Maia 200','MTIA v3',
                'Broadcom','Marvell','Alchip','OpenAI','Anthropic'].map(k => texts.some(t => t.includes(k))),
        aria: !!svg.getAttribute('aria-label') };
    }""")
    out['stamps'] = st

    # click first stamp card -> drill
    page.evaluate("""() => {
      const g = document.querySelector('#stamps-chart .chart-body svg g');
      const b = g.getBoundingClientRect();
      g.dispatchEvent(new MouseEvent('click', {bubbles:true, clientX:b.x+30, clientY:b.y+30}));
    }""")
    page.wait_for_timeout(300)
    out['stamps_drill'] = page.evaluate("""() => {
      const o = document.getElementById('drill-overlay');
      return { open: o && !o.hidden, title: (document.querySelector('#drill-card .drill-title')||{}).textContent || '' };
    }""")
    page.keyboard.press('Escape')

    out['h_overflow'] = page.evaluate("() => document.documentElement.scrollWidth > window.innerWidth")
    out['scrollW_vs_innerW'] = page.evaluate("() => [document.documentElement.scrollWidth, window.innerWidth]")
    out['console_errors'] = errs
    results[tag] = out

with sync_playwright() as p:
    browser = p.chromium.launch()
    pg = browser.new_page(viewport={'width':1440,'height':900})
    check_viewport(pg, 1440, 900, '1440px')
    pg.close()
    pg2 = browser.new_page(viewport={'width':390,'height':844})
    check_viewport(pg2, 390, 844, '390px')
    pg2.close()
    browser.close()

print(json.dumps(results, ensure_ascii=False, indent=1))
