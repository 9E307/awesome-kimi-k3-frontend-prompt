from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={'width':1440,'height':900})
    pg.goto('http://127.0.0.1:8765/', wait_until='load')
    pg.wait_for_selector('#capex3d-chart .chart-body svg', timeout=15000)
    pg.wait_for_timeout(1000)
    el = pg.locator('#capex3d-chart')
    el.screenshot(path='capex3d_1440.png')
    pg.locator('#stamps-chart').screenshot(path='stamps_1440.png')
    # drill screenshot for MSFT '27E*
    pg.evaluate("""() => {
      const svg = document.querySelector('#capex3d-chart .chart-body svg');
      const hits = [...svg.querySelectorAll('rect[fill="transparent"]')];
      hits[17].dispatchEvent(new MouseEvent('click', {bubbles:true, clientX:100, clientY:100}));
    }""")
    pg.wait_for_timeout(300)
    pg.screenshot(path='drill_msft27.png')
    pg.keyboard.press('Escape')
    pg2 = b.new_page(viewport={'width':390,'height':844})
    pg2.goto('http://127.0.0.1:8765/', wait_until='load')
    pg2.wait_for_selector('#capex3d-chart .chart-body svg', timeout=15000)
    pg2.wait_for_timeout(1000)
    pg2.locator('#capex3d-chart').screenshot(path='capex3d_390.png')
    b.close()
print('done')
