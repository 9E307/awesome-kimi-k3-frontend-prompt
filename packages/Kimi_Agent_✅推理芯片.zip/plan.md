# 执行计划 v3：数据纠错 35 条 + 排版对齐 7 条

基准：/mnt/agents/output/ref-original/（原版 js/data.js、data-v51/52/53.js、sources.js、charts/timeline42.js、charts/mechanism.js、css/style.css、index.html）。
总原则：原版为唯一事实基准；标 STALE/withdrawn/do not cite 的口径一律禁用；缺数据标「未披露」。
任务清单：/mnt/agents/upload/user_pasted_clipboard_long_content_as_file_本次修两大块：排版对齐英文原版、数据全面.txt（35 数据条 + 7 排版条 + 验收项）

## 并行施工（5 子代理，文件互不重叠）

| Agent | 文件 | 范围 |
|---|---|---|
| DATA | js/data.js、js/sources.js | 清单 1–35 中全部数据侧修正：K 注册表（K1/K2/K5/K10/K12/K13-16/K19/K20/K21/K22/K23/K26/K28/K29/K30/K31/K33 等）、CHART_DATA（capex3d 分项、capex-stairs、sawtooth、mining、hbm、signals 八触发器整体恢复）、COHORT 13→14 家、TIMELINE_EVENTS 事件10 year→2022.77、DASH_STATES 联动数字、数据日期统一 2026-07-18、sources.js:129 及全量复查 |
| HTML | index.html | 正文数字修正（清单列出的行号与全部出现处）、7 段编造引文替换为原版逐字引文中译（Krzanich/crypto hangover/NVLink/Birol/Tan $60–90B，参照 ref-original/index.html 的 blockquote）、日期统一、K30→K5 出处、容器纠偏（conflow/submarine/tpu/mining/penetration/revenue-split/hbmgen/partition/pergw 从 .wide.xl→.wide；mechanism 容器 .wide.xl→.wide）、五对图改 .chart-pair 并排（sawtooth×2、capex3d+capex-stairs、cowos+hbm、assume-a2+a3、verdict-tree+scenario-chain）、signals figure 补 class="chart-frame"、data-chart-height 值照抄 ref-original/index.html 对应 figure、封面 lead 补「途中有一例 Chapter 11」、17.6× 表述改「12 个季度间隔、13 个季度观测值」 |
| TLM | js/charts/timeline42.js | 按 ref-original/js/charts/timeline42.js 移植：全高窗口底纹带（每窗口 color 8% alpha+左缘发丝线）、32px 统一牌匾（两行 mono、白底灰边+左 2px 蓝条、超长截断…、无红蓝描边无编号）、居中于年份针 greedy 首适行 packing、#dbe2ea 1.5/3 浅虚线+1.5px 蓝刻度针、9 刻度（1985–2020 每5年+2026）；契约适配 Charts['timeline42'](frame)，数据读本站 window.TIMELINE_EVENTS/WINDOWS（color 字段照抄原版 data.js windows） |
| MECH | js/charts/mechanism.js | 按 ref-original/js/charts/mechanism.js 移植：渐变描边（蓝→铜→红→墨破裂）、dashed 包络全段、0.32 反射 ghost 副波、顶部反馈环大跨虚线 Bézier+居中 mono 标签（白 halo）+hover 变蓝可点击、rAF 相位动画（reduced-motion 单帧）、基线圆点+骑波菱形、阶段标签下方双车道避让；契约适配 Charts['mechanism'](frame)，主体高 460 |
| CSS | css/style.css | figure 镀铬（.chart-frame border-top+padding-top:14px；.chart-sub 去 border-bottom、margin:5px 0 12px、letter-spacing:.09em；.chart-src border-top+margin-top:12px+padding-top:8px）、.chart-pair grid 1fr 1fr gap 30px、块间距 8 条组合 margin-top:28px、照抄 ref-original/css/style.css:273-291 的 data-chart-height min-height 规则块、封面 P2：h1 clamp(44px,6.6vw,78px)、.cover-inner padding 14vh 24px 112px、kicker 蓝+.26em、副题粗+ink-md、chips 原版（serif 700 11.5px/1.5px 边/8 11 padding/margin-top 56/hover 蓝底白字）、模式切换恢复胶囊 pill（border+999px+半透白底） |

## 验收（verifier）
- 数据：35 条逐条页面复核 + 一致项抽查（17.6× 端点、6,950–7,250 亿、+14%、−15%~−35%、108 天五笔、Habana 20 亿、1,632 台、415→945 TWh、≈8,300 机柜/60 万颗、Anthropic ≈100 万颗/>1GW、Ironwood 42.5 EF/9,216 颗/192GB、NVLink Fusion 2025-05-19、CoWoS 7–8→12–13、−32%/−39%）
- 排版：1280×720 与 1920：timeline42 牌匾居中于针、无长斜跨线；mechanism 渐变/动画/顶部反馈环；五对图并排；console=0
- 部署：同步到 /mnt/agents/deploy/36b0f6c（当前生效指针），curl 验证 200

## 注意
- 不改 19 section id/顺序；不减 prose；verdict-tree/scenario-chain 等图表内的情景数字（3.0–4.3× 等）由 DATA 改数据后，若图表硬编码了旧数字需一并改——TLM/MECH 以外的 chart 文件里如有硬编码 3.0–4.3/2.0–2.4，由 DATA 代理在复查阶段修复（verdict_tree.js、scenario_chain.js、dashboard.js 的数字来自 DASH_STATES/CHART_DATA，若硬编码则顺手改并在报告列出）。
- cover「模式切换恢复胶囊 pill」与上轮「纯文本 mono」冲突——以本轮清单 §42 为准。
