# SPEC.md — inference-silicon-cn 单一事实来源

所有子代理必须严格遵守本文件的接口契约。不得擅自更改文件边界、ID、类名、全局 API。

## 0. 项目与运行

- 项目根：`/mnt/agents/output/inference-silicon-cn/`（直接在此目录工作，不用 git/worktree；各 agent 文件互不重叠，禁止改动他人文件）
- 本地运行：`cd /mnt/agents/output/inference-silicon-cn && python3 -m http.server 8765`
- 技术栈：HTML5 + CSS3 + Vanilla JS + 本地 vendor（`vendor/d3.min.js` v7、`vendor/topojson-client.min.js`、`vendor/land-110m.json`）。禁止 React/Vue/iframe/外部 CDN/远程服务。
- 字体：`fonts/et-book-roman-line-figures.woff`、`fonts/et-book-bold-line-figures.woff`、`fonts/et-book-roman-old-style-figures.woff` 已存在。
- 全站中文。公司名、产品名、缩写（TPU/HBM/CoWoS/FPGA/ASIC/GPU/NVLink）、货币、年份、单位保留英文/行业写法。

## 1. 文件清单与所有权

```
inference-silicon-cn/
├── index.html            # Agent B
├── favicon.ico           # 主 agent
├── README.md             # 主 agent
├── css/fonts.css         # Agent A
├── css/style.css         # Agent A
├── vendor/*              # 已存在，勿动
├── js/data.js            # Agent C（K 注册表 + DASH_STATES + CHART_DATA）
├── js/utils.js           # Agent C（tooltip / drillcard / canvas DPR 工具）
├── js/cover.js           # Agent D（模式 A 递归）
├── js/cover-exploded.js  # Agent D（模式 B 爆炸图）
├── js/cover-wire.js      # Agent D（模式 C 蓝图）
├── js/main.js            # Agent D（启动、era-rail、section observer、hash 导航、cover 模式切换）
├── js/dashboard.js       # Agent E
└── js/charts/
    ├── timeline42.js     # Agent F
    ├── mechanism.js      # Agent F
    ├── clearing.js       # Agent F
    ├── conflow.js        # Agent F
    ├── submarine.js      # Agent F
    ├── tpu.js            # Agent F
    ├── mining.js         # Agent G
    ├── sawtooth.js       # Agent G（alchip+guc 两张，参数化）
    ├── capex3d.js        # Agent G
    ├── capex_stairs.js   # Agent G
    ├── penetration.js    # Agent G
    ├── stamps.js         # Agent G
    ├── revenue_split.js  # Agent G
    ├── pergw.js          # Agent G
    ├── gates.js          # Agent H
    ├── cowos.js          # Agent H
    ├── hbm.js            # Agent H
    ├── hbmgen.js         # Agent H
    ├── partition.js      # Agent H
    ├── assumptions.js    # Agent H（assume-a2 + assume-a3）
    ├── matrix.js         # Agent H
    ├── verdict_tree.js   # Agent H
    ├── scenario_chain.js # Agent H
    ├── signals.js        # Agent H（8 触发器表，DOM 渲染）
    └── deepdive.js       # Agent H（invest-chart，六公司深研）
```

## 2. 设计 Tokens（css/style.css `:root`，一字不改）

```css
:root {
  --paper: #ffffff; --paper-hi: #f7f9fc;
  --ink: #051c2c; --ink-md: #42566a; --ink-lo: #8595a6;
  --line: #dbe2ea; --line-lo: #eef1f6;
  --red: #2251ff; --red-hi: #1233b8;
  --blue: #2251ff; --blue-hi: #1233b8; --blue-lo: #7d9bff;
  --copper: #b07a10; --green: #008a6d; --violet: #7a45c9;
  --gold: #b07a10; --neg: #c22f4e;
  --serif: "et-book", "Songti SC", "Noto Serif CJK SC", "Source Han Serif SC", "STSong", "Iowan Old Style", Palatino, Georgia, serif;
  --sans: var(--serif);
  --mono: Menlo, Consolas, "SF Mono", "PingFang SC", monospace;
}
```

- `body { background:#fff; color:var(--ink); font-family:var(--serif); font-size:17px; line-height:1.68; -webkit-font-smoothing:antialiased; }`
- 禁止：米黄/暖纸色、全屏点阵、大渐变、厚圆角卡片、大阴影、玻璃拟态、深色模式。
- 浅灰蓝 `--paper-hi` 仅用于少量 panel/hover/缺失数据区域。

## 3. 布局契约（1280×720 验收几何）

```css
body { --railw: 460px; }
/* main 不定宽：只占满数据面板左侧全部宽度；1280×720 的几何由 1280−460=820 自然得出。
   内容列靠 .prose/.wide 的 max-width + margin:0 auto 在可用区域内居中，宽屏无中间空白。 */
main { margin-right: var(--railw); }
#appendix { margin-right: var(--railw); } /* 与 main 相同契约，不写死 820px */
#dash-rail { position: fixed; top:0; right:0; bottom:0; width: var(--railw); border:0; background:#fff; z-index:60; opacity:0; pointer-events:none; transition:opacity .6s ease; }
#dash-rail.on { opacity:1; pointer-events:auto; }
#dash-rail canvas { width:100%; height:100%; display:block; }

.prose { max-width: 692px; margin:0 auto; padding:0 24px; }   /* 文字宽 644px, x≈88 */
.wide { max-width: 800px; margin:0 auto; padding:0 24px; }    /* 图表宽 752 */
.wide.xl { max-width: 924px; }                                /* 主栏内实际 820, 图表宽 772, x≈24 */

.band { padding: 48px 0 56px; border-top: 1px solid var(--line-lo); }
.sec-no { font-family:var(--mono); font-size:11px; letter-spacing:.26em; color:var(--blue); margin-bottom:14px; text-transform:uppercase; }
h2 { font-size:36px; font-weight:700; line-height:1.25; margin-bottom:20px; }
h3 { font-size:21px; font-weight:700; line-height:1.4; margin-bottom:14px; }
.prose p { margin-bottom:15px; }
.dek { max-width:640px; margin:-4px 0 24px; padding:0; border:0; font-size:18px; font-style:italic; line-height:1.65; color:var(--ink-md); }
```

禁止在 `main`/`#article` 上使用大 padding（如 `56px 44px 96px 24px`）。

### 响应式
```css
@media (max-width:1180px){ body{--railw:0px} #dash-rail{display:none} main{width:100%;margin-right:0} #era-rail{right:0} }
@media (max-width:768px){ cover 标题≈44px；正文16px；图表宽100%；宽表格横向滚动；tooltip 改点击；drill card 底部抽屉；无横向溢出 }
```

## 4. index.html 结构契约（Agent B 实现，他人只读）

```html
<header id="cover">
  <canvas id="cover-canvas"></canvas>
  <canvas id="cover-canvas-x"></canvas>
  <canvas id="cover-canvas-w"></canvas>
  <div class="cover-inner">
    <div class="cover-kicker">推理芯片 · 1985–2026 · 周期重建 × 行业深研</div>
    <h1 class="cover-title">推理芯片的四十二年</h1>
    <div class="cover-sub">这一次，真的不一样吗？</div>
    <p class="cover-lede">…（见 §6 文案）</p>
    <div class="cover-chips">8 个 chip（见 §6）</div>
    <div class="cover-anchor">交互式研究版 · 六个窗口，1985–2026 · 24 条一手资料引文，9 条完整呈现 · 每张图均可追溯至带日期来源 · 仅供信息参考，不构成投资建议</div>
    <div id="cover-mode">封面 | A · 递归 | B · 爆炸图 | C · 蓝图（胶囊按钮，role=tablist）</div>
    <div class="scroll-hint">向下滚动开始阅读</div>
  </div>
</header>
<nav id="era-rail" aria-label="历史时间轴">
  <span class="era-badge" id="era-badge">1985</span>
  <div class="era-track">
    6 个 <span class="era-seg" data-sec="sec-w2">…（每段含年份标签 1985/1995/2004/2013/2019/2023→26）
  </div>
</nav>
<main id="article">
  19 × <section class="band" id="sec-…">
    <div class="prose">
      <div class="sec-no">§1 · 执行摘要</div>
      <h2>…</h2><p class="dek">…</p>
      <p>…正文…</p>
      <blockquote class="quote-card">…（全站共 9 张）</blockquote>
    </div>
    <div class="wide xl">
      <figure class="chart-frame" id="timeline42-chart" data-chart="timeline42" data-chart-height="637">
        <h4 class="chart-title">四十二年，一条时间线</h4>
        <p class="chart-sub">1985–2026 · 六个窗口 · 13 个事件 · 悬停查看详情</p>
        <div class="chart-body"></div>
        <figcaption class="chart-src">来源：…（mono 10px，带来源与日期）</figcaption>
      </figure>
    </div>
  </section>
</main>
<footer id="appendix"> 附录 · 来源与方法 …（§19 全文） </footer>
<aside id="dash-rail" aria-label="数据面板"><canvas id="dash-canvas"></canvas><div id="dash-html"></div></aside>
<div id="tooltip" role="tooltip" hidden></div>
<div id="drill-overlay" hidden><div id="drill-card" role="dialog" aria-modal="true">…</div></div>
```

脚本加载顺序（body 末尾，均 defer 之外的普通顺序即可）：
`vendor/d3.min.js` → `vendor/topojson-client.min.js` → `js/data.js` → `js/utils.js` → `js/charts/*.js`（26 个文件按字母序）→ `js/cover.js` → `js/cover-exploded.js` → `js/cover-wire.js` → `js/dashboard.js` → `js/main.js`。

### 19 个 section id（不可增减）与图表归属
| id | 标签 sec-no | 标题 h2 | charts (frame id → data-chart) |
|---|---|---|---|
| sec-frame | §1 · 执行摘要 | 这一次，真的不一样吗？ | timeline42-chart, mechanism-chart |
| sec-grave | §2 · 生存者 · 1975–2026 | 三代企业，同一种出清语法 | clearing-chart, conflow-chart |
| sec-w2 | §3 · 窗口一 · 1985–1995 · FPGA 创立期 | “更好的 ASIC”：定位本身就是战略 | — |
| sec-w3 | §4 · 窗口二 · 1995–2003 · 繁荣与崩塌 | −39%：同一次冲击，四种不同伤痕 | — |
| sec-w4 | §5 · 窗口三 · 2004–2012 · 安静的十年 | 先部署，后披露 | submarine-chart |
| sec-w5 | §6 · 窗口四 · 2013–2018 · 点火 | TPU 与 167 亿美元支票：两种答案，同一场考试 | tpu-chart |
| sec-w6 | §7 · 窗口五 · 2019–2022 · 短缺与并购超级周期 | 定时装置 | — |
| sec-mining | 插曲 · 2017–2022 · 挖矿镜像 | 加密货币孵化了定制芯片，又让它两次坠落 | mining-chart, sawtooth-alchip-chart, sawtooth-guc-chart |
| sec-w7 | §8 · 窗口六 · 2023–2026 · 当前周期 | 需求、卖铲者，以及不断迁移的约束 | capex3d-chart, capex-stairs-chart |
| sec-now | 9a · 当前窗口 | 9b · 第二轮自研芯片浪潮，以及测量纪律 | penetration-chart, stamps-chart |
| sec-crossover | 9c · 深入检验 | 9c · 深入检验：2027 年交叉点是否成立 | revenue-split-chart |
| sec-mismatch | 9d · 深入检验 | 9d · 深入检验：为什么模型与芯片的节奏错配仍可管理 | pergw-chart |
| sec-bottleneck | 9e · 供应关卡 | 9e · 四道供应关卡：利润池位于关口，而非云端 | gates-chart, cowos-chart, hbm-chart, hbmgen-chart |
| sec-partition | 9f · 电网 | 9f · 约束的最后一站：电网 | partition-chart |
| sec-assumptions | S10 · 共识压力测试 | 三项大胆假设 | assume-a2-chart, assume-a3-chart |
| sec-analog | §9 · 结论 | 四十二年放进一张表；结论落在两种情景 | matrix-chart |
| sec-verdict | §9b · 情景算术 | 情景算术：Base case 三年增长 3.0–4.3 倍 | verdict-tree-chart, scenario-chain-chart |
| sec-signals | §10 · 监测 | 八个证伪触发器，每季度复核 | signals-chart (data-chart="signals", DOM 表格) |
| sec-invest | §11 · 公司深研 | 六家公司，位于供应链的收费关口 | invest-chart (data-chart="invest") |

chart-frame 计数 = 26（含 signals-chart 与 invest-chart）。禁止出现 now-chart。
sec-now 的 sec-no 标签用「9a · 当前窗口」，sec-crossover 用「9c · 深入检验」，sec-mismatch 用「9d · 深入检验」，sec-bottleneck 用「9e · 供应关卡」，sec-partition 用「9f · 电网」，sec-verdict 用「§9b · 情景算术」。

## 5. JS 全局契约

### js/data.js（Agent C）— 最先加载
```js
window.K = { /* K1..K41 注册表，每项 {id,label,value,unit,asOf,source,note} */ };
window.DASH_STATES = { frame:{badge,title,stage,center:[lon,lat],nodes:[{name,lon,lat,note}],mini:{title,unit,series:[[x,y]...]},metrics:[{v,l}×4],cohort:{...}}, clearing:{…}, e2..e7, now, mismatch, gates, grid, assumptions, analog, verdict, signals, invest };
window.SECTION_TO_DASH = {"sec-frame":"frame","sec-grave":"clearing","sec-w2":"e2","sec-w3":"e3","sec-w4":"e4","sec-w5":"e5","sec-w6":"e6","sec-mining":"e6","sec-w7":"e7","sec-now":"now","sec-crossover":"now","sec-mismatch":"mismatch","sec-bottleneck":"gates","sec-partition":"grid","sec-assumptions":"assumptions","sec-analog":"analog","sec-verdict":"verdict","sec-signals":"signals","sec-invest":"invest"};
window.CHART_DATA = { timeline42:{…}, mechanism:{…}, … 每个 data-chart key 一个入口 };
window.TIMELINE_EVENTS = [ 13 个事件 {year,label,window,drill:{title,body,source,date}} ];
window.WINDOWS = [ 6 个窗口 {id,from,to,name} ]; // 1985-1995 1995-2003 2004-2012 2013-2018 2019-2022 2023-2026
```

### js/utils.js（Agent C）
```js
window.Utils = {
  css(name){ getComputedStyle(document.documentElement).getPropertyValue(name).trim() },
  fitCanvas(canvas){ 按 SPEC §6 DPR 规则初始化并返回 {ctx,w,h} ; 绝不改 canvas.style 为像素值 },
  tooltip: { show(html,x,y), move(x,y), hide() },          // 白底深蓝细灰边轻阴影
  drill:   { open({title,body,source,date}), close() },     // Escape/遮罩/焦点管理/移动端底部抽屉
  el(tag,attrs,children) // 小 helper
};
```

### 图表注册（Agent F/G/H）
```js
window.Charts = window.Charts || {};
window.Charts['timeline42'] = function(frame){ /* frame = .chart-frame 元素; 在 frame.querySelector('.chart-body') 内渲染; 数据取自 window.CHART_DATA['timeline42'] */ };
```
每个 chart 文件 IIFE 注册一个或多个 key（sawtooth.js 注册 'sawtooth-alchip' 与 'sawtooth-guc'；assumptions.js 注册 'assume-a2' 与 'assume-a3'；deepdive.js 注册 'invest'；signals.js 注册 'signals'）。图表必须绘制中文 aria-label（容器 setAttribute('role','img') + aria-label）。交互：hover → Utils.tooltip；click → Utils.drill.open。图表用 eager render，不高度假设；frame 上 `data-chart-height` 仅为参考。

### js/main.js（Agent D）
- DOMContentLoaded 后：初始化 cover 三模式（默认 A）；遍历 `[data-chart]` 调用 `Charts[key](frame)`（eager）；初始化 dashboard；初始化 era-rail；IntersectionObserver 更新当前 section → 更新 era-rail 高亮/徽章 + `Dashboard.setState(SECTION_TO_DASH[id])` + dash-rail/era-rail `.on` 类（cover 区域隐藏，进入文章显示）。
- hash 导航：等 DOMContentLoaded → 首次图表布局 → `document.fonts.ready` 后重新 `scrollIntoView`；处理 hashchange。
- `prefers-reduced-motion`：停止地球与 cover 动画。
- scroll 监听必须 rAF 节流；监听器不得重复注册。

### js/dashboard.js（Agent E）
```js
window.Dashboard = { setState(key){ 平滑插值 globe center、更新标题/阶段/mini chart/metrics/cohort } };
```
- Canvas 绘制：正射点阵地球 `d3.geoOrthographic().clipAngle(90)`，读取 `vendor/land-110m.json`（fetch 一次，topojson.feature），纬度 −58..76、经度 −178..180、约 3° 采样、`d3.geoContains` 只画陆地点；缓慢连续旋转（rAF）；状态切换时旋转角插值到新 center；只画当前状态 nodes，节点 hover（tooltip）/click（drill）。
- HTML 层 `#dash-html`：Badge、当前章节标题、周期阶段、阶段指示器、mini chart（小 SVG 折线/柱状）、4 个 metric placard、13-company cohort strip。
- 旋转与 scroll 解耦；reduced-motion 时静止。

### Cover（Agent D）
- 三 canvas：`#cover-canvas`(A 递归：递归分割的芯片版图式矩形树/走线)、`#cover-canvas-x`(B 爆炸图：芯片封装分层爆炸轴测)、`#cover-canvas-w`(C 蓝图：蓝色细线 wireframe 蓝图网格与走线)。同一时间只显示一个（display:none 切换）。全部用 `Utils.fitCanvas`，`inset:0;width:100%;height:100%`。
- 动画用 rAF；颜色仅限 tokens（白底、#2251ff 系、细线）。
- `#cover-mode` 胶囊按钮切换（aria-pressed）。

## 6. Cover CSS 与坐标（1280×720）

```css
#cover { position:relative; min-height:100vh; overflow:hidden; background:#fff; border:0; }
#cover-canvas,#cover-canvas-x,#cover-canvas-w { position:absolute; inset:0; width:100%; height:100%; }
.cover-inner { position:relative; z-index:2; max-width:1120px; margin:0 auto; padding:11vh 24px 60px; }
```
坐标目标：cover-inner x=80；内容 x=104（即 24px padding 内）；cover-title 78px/1.08 两行；chips 12.5px、1.5px 深蓝边框、6px 圆角、7px 13px padding；模式按钮为轻量圆角胶囊。Cover 实际高度约 880–930px（内容撑开，不强制 100vh 截断；min-height:100vh + 内容自然高度，可给 .cover-inner padding-bottom 使总高约 900px）。
`.scroll-hint` 在底部。kicker 用 mono 11px letter-spacing。

Cover lead 文案：「从 1985 年 Xilinx XC2064 到 2026 年 TPU v8，围绕定制计算供应权的竞争已经持续四十余年。三代挑战者进入，两轮出清发生，而退出语法始终没有改变：并购，而非破产。本报告把四十二年切分为六个窗口，重建每个时点当时能够观察到的证据，并追问一个问题：2023–2026 年的推理芯片繁荣，究竟是旧周期的重演，还是一轮受新约束驱动的新周期？」
Chips：核心结论 / 生存者记录 / 最近历史类比 / 当前周期 / 交叉点压力测试 / 两种情景 / 三项大胆假设 / 八个触发器。

## 7. Era Rail（Agent D 写 JS；CSS 在 style.css）

```css
#era-rail { position:fixed; top:0; left:0; right:460px; z-index:90; display:flex; align-items:center; gap:14px; padding:10px 22px; background:#fff; border-bottom:1px solid var(--line); opacity:0; transform:translateY(-8px); pointer-events:none; transition:opacity .4s, transform .4s; }
#era-rail.on { opacity:1; transform:none; }
```
内部：当前年份 badge + 横向轨道 + 6 个窗口段（当前段 4px 高亮蓝线，其余 2px 浅灰线）+ 年份标签 1985/1995/2004/2013/2019/2023→26。点击段跳转对应 section。不是 19 个章节菜单。

## 8. 26 图表规格（主体高度；frame 总高 = 主体 + 标题/来源约 90–133px）

| key | 形式 | 主体高 | 内容要点 |
|---|---|---|---|
| timeline42 | SVG | 504 | 六窗口 shaded、13 plaque greedy row packing 多层 staggered、dotted connector、year pin circle、plaque 左侧蓝竖线、三层错开窗口标题、hover tooltip、click drill |
| mechanism | Canvas | 460 | 五阶段（需求点火/产能假设失效/恐慌性重复下单/大块产能到达/出清），振幅 1.0/1.6/2.6/4.0/4.0，连续波形+dashed envelope+diamond node+出清下坠 bust curve+「放大 →」「断裂 ↓」标注+出清回需求的大 dashed Bézier loop 文案「研发穿越低谷 → 下一代技术底座（300mm → EUV → HBM/CoWoS）→ 再次点火」，hover/click |
| clearing | SVG | 774 | 13 家样本生存者时间泳道（成立→结局：并购/出售/独立），并购非破产主题 |
| conflow | SVG viewBox≈710 高 | ~640 | 约束迁移流图（晶圆厂→HBM/先进封装/电网）Sankey 式流 |
| submarine | SVG/Canvas | 420 | 「潜水艇」图：Catapult 2012 部署→2014 披露的隐蔽期水位线隐喻 |
| tpu | SVG | 430 | TPU 代际 2015 v1→2026 v8 演进（部署/披露错位标记） |
| mining | SVG | ~380 | 2017–2022 挖矿周期：Bitmain、NVIDIA 两次库存冲击（2019/2022） |
| sawtooth-alchip | SVG | 340 | Alchip 锯齿收入（标注 crypto 占比） |
| sawtooth-guc | SVG | 340 | GUC 锯齿收入 |
| capex3d | SVG/Canvas | 520 | Top-4 云厂 capex 3D 堆叠/阶梯面积（2023→2026E，2025≈$412.9B，2026 指引 695–725B） |
| capex-stairs | SVG | 400 | capex/OCF 阶梯约束图 |
| penetration | SVG | ~420 | 三种口径份额：单位/CoWoS/美元（并列，不混用） |
| stamps | SVG | ~360 | Ironwood/Trainium 3/Maia 200/MTIA v3 邮戳式规格卡 |
| revenue-split | SVG | ~430 | 2027 交叉点检验：TPU 800–840 万颗交叉线、650–1,500 万区间、美元口径 GPU 仍占优 |
| pergw | SVG | 300 | 每 GW 成本/单位换算 ±40% |
| gates | SVG | ~420 | 四道关卡排序 HBM>先进制程>CoWoS>光互连 |
| cowos | SVG viewBox≈457 | ~390 | CoWoS 供需（不用未证实 75→110 路径） |
| hbm | SVG | 400 | HBM 容量/缺口/定价（约 8%→41% 研究口径） |
| hbmgen | SVG viewBox≈356 | ~300 | HBM 代际 HBM3→HBM4 路线 |
| partition | SVG | ~420 | 电网：415→945 TWh、GB200 NVL72≈120kW、部署节拍器 vs 订单节拍器 |
| assume-a2 | SVG | ~360 | A2 2027 ASIC 单位超 GPU：无法判定（证据并列） |
| assume-a3 | SVG | ~360 | A3 需求可见至 2028：延迟 |
| matrix | SVG/DOM | ~460 | 六窗口机制矩阵表（需求点火/供给约束/重复下单/产能到达/出清 × 窗口），1997-98 与 2008-09 rejected |
| verdict-tree | SVG | ~420 | 情景树：Base 3.0–4.3x（中点≈3.6x）/Conservative 2.0–2.4x/Contraction −15%~−35%/kill switch +14% |
| scenario-chain | SVG | ~360 | 情景链：触发→传导→结果 |
| signals | DOM 表格 | ~420 | 8 触发器表：MediaTek 4Q26、TSMC CoWoS 表述、Alchip 3nm、Broadcom AI 指引、TPU 数量收敛、capex/OCF、订单取消扩散、库存与预建行为（含观察指标/阈值/频率列） |
| invest | DOM/SVG | ~480 | 六公司深研卡：Broadcom/Marvell/MediaTek/GUC/Alchip/VeriSilicon（关口位置、事实、风险；无评级无目标价） |

事实纪律：Catapult 2012 底部署/2014 披露；TPU 2015 部署/2016 公开/2017 ISCA；AMD/Xilinx 2020-07~10 108 天窗口；HBM 8%→41%；不用 capex/OCF 0.80→1.21；不用 Google≈70% Broadcom 无源结论；缺失标「未披露」不插值；情景乘法只用美元口径。

## 9. Quote card / tooltip / drill / 来源

- 9 张 `.quote-card`：白底、上下 1px 细线、无黄色；逐字引语无法核实用中文意译并标注「（意译）」。
- 来源四类：公司披露 / 券商研究 / 行业与官方 / 研究综合；每条带日期；聚合转载不进情景计算。
- `#tooltip`：白底、深蓝文字、1px var(--line) 边线、轻阴影；hover 显示。
- `#drill-overlay/#drill-card`：白底卡片、Escape 关闭、点遮罩关闭、焦点管理；<768px 底部抽屉。

## 10. 内容与长度纪律（Agent B）

- 19 section、26 chart frame、9 quote card、约 190 段落；1280px 下页面总高目标 42,000–47,000px，不超过 53,000px。
- 正文宽 644px、17px/1.68、段距 15px；不复述图表数据成段；不为每个数字建来源按钮。
- footer：标题「附录 · 来源与方法」、副标题「方法、缺口与来源」+ 用户 prompt §19 全部说明条目 + 数据日期 2026-07-12，更新于 2026-07-14 + 「仅供信息参考，不构成投资建议」。

## 11. 无障碍/性能

- SVG/Canvas 中文 aria-label；按钮键盘可操作；Escape 关弹层；prefers-reduced-motion 停动画；rAF；scroll 不直接重绘；IntersectionObserver 更新 section；ResizeObserver 只重绘不改预留高度；无控制台错误。
