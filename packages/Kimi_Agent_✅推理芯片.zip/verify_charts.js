/* verify_charts.js — 截 tpu / clearing 图并校验渲染与 console 错误 */
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1280, height: 1000 } });
  const errors = [];
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('pageerror', (e) => errors.push('PAGEERROR: ' + e.message));

  await page.goto('http://127.0.0.1:8123/index.html', { waitUntil: 'networkidle' });
  await page.waitForTimeout(1500);

  // ---- clearing 校验 ----
  const clearing = await page.evaluate(() => {
    const f = document.querySelector('#clearing-chart .chart-body');
    if (!f || !f.querySelector('svg')) return { ok: false };
    const svg = f.querySelector('svg');
    const texts = Array.from(svg.querySelectorAll('text')).map((t) => t.textContent);
    const names = ['Xilinx','Altera','Achronix','Wave Computing','Mythic','Nervana','Flex Logix','SiFive','Cerebras','Groq','Graphcore','Habana','Tenstorrent','SambaNova'];
    const found = names.filter((n) => texts.includes(n));
    return {
      ok: true,
      svgH: svg.getAttribute('height'),
      viewBox: svg.getAttribute('viewBox'),
      lanes: found.length,
      missing: names.filter((n) => !texts.includes(n)),
      hasIPOlabel: texts.some((t) => t.indexOf('IPO · 2026-05') >= 0),
      hasAssetSale: texts.some((t) => t.indexOf('Analog Devices 资产 · 2024') >= 0),
      hasGF: texts.some((t) => t.indexOf('GlobalFoundries 收购 · 2025') >= 0),
      countLine: texts.find((t) => t.indexOf('14 家样本') >= 0) || null,
      legend: texts.filter((t) => ['并购','资产出售','许可','IPO','仍独立'].includes(t)),
      aria: f.getAttribute('aria-label'),
      blueDots: svg.querySelectorAll('circle[fill="#2251ff"]').length,
      ipoDots: svg.querySelectorAll('circle[fill="#7d9bff"]').length
    };
  });
  console.log('CLEARING:', JSON.stringify(clearing, null, 1));

  const cEl = await page.$('#clearing-chart');
  if (cEl) await cEl.screenshot({ path: '/mnt/agents/output/shot_clearing.png' });

  // ---- tpu 校验 ----
  const tpu = await page.evaluate(() => {
    const f = document.querySelector('#tpu-chart .chart-body');
    if (!f || !f.querySelector('svg')) return { ok: false };
    const svg = f.querySelector('svg');
    const texts = Array.from(svg.querySelectorAll('text')).map((t) => t.textContent);
    return {
      ok: true,
      has9PF: texts.some((t) => t.indexOf('≈9 PFLOPS FP4（估计）· 2026') >= 0),
      hasMult20: texts.includes('≈×2.0'),
      stale126: texts.some((t) => t.indexOf('12.6') >= 0),
      stale26: texts.some((t) => t === '×2.6'),
      aria: f.getAttribute('aria-label')
    };
  });
  console.log('TPU:', JSON.stringify(tpu, null, 1));

  const tEl = await page.$('#tpu-chart');
  if (tEl) await tEl.screenshot({ path: '/mnt/agents/output/shot_tpu.png' });

  console.log('CONSOLE_ERRORS:', errors.length, JSON.stringify(errors.slice(0, 5)));
  await browser.close();
})().catch((e) => { console.error('FATAL', e); process.exit(1); });
