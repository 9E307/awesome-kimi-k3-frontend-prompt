/**
 * Procedural mechanical sound engine. No audio files — every sound is
 * synthesized from one second of white noise plus oscillators, filters
 * and gain envelopes on a lazily created AudioContext.
 */

const VARIANTS = 6;

interface NoiseOptions {
  at?: number;
  dur: number;
  gain: number;
  type: BiquadFilterType;
  freq: number;
  q?: number;
  decay?: number;
  gainCurve?: "linear" | "exponential";
}

interface ToneOptions {
  at?: number;
  freq: number;
  freqEnd?: number;
  dur: number;
  gain: number;
  type: OscillatorType;
  decay?: number;
}

export type SoundName =
  | "keyDown"
  | "linkage"
  | "swish"
  | "impact"
  | "rest"
  | "escapement"
  | "space"
  | "backspace"
  | "bell"
  | "returnPull"
  | "returnFly"
  | "ratchet"
  | "paperIn"
  | "paperOut"
  | "shift"
  | "clash"
  | "explodeMove"
  | "assembleMove";

export class MechanicalAudio {
  enabled = true;
  volume = 0.55;
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private variant = 0;
  private activeVoices = 0;
  private readonly maxVoices = 10;
  private readonly lastPlay = new Map<string, number>();

  /** Creates/resumes the AudioContext on the first user gesture. */
  unlock(): void {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return;
    }
    try {
      const Ctor = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctor) return;
      this.ctx = new Ctor();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.enabled ? this.volume : 0;
      this.master.connect(this.ctx.destination);
      const length = this.ctx.sampleRate;
      this.noiseBuffer = this.ctx.createBuffer(1, length, this.ctx.sampleRate);
      const data = this.noiseBuffer.getChannelData(0);
      for (let i = 0; i < length; i++) data[i] = Math.random() * 2 - 1;
    } catch {
      this.ctx = null;
    }
  }

  /** Fades the master gain instead of tearing down the context. */
  setEnabled(enabled: boolean): void {
    this.enabled = enabled;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(enabled ? this.volume : 0, this.ctx.currentTime, 0.03);
    }
  }

  private nextVariant(): number {
    this.variant = (this.variant + 1) % VARIANTS;
    return this.variant;
  }

  private get ready(): boolean {
    return !!(this.ctx && this.master && this.noiseBuffer && this.enabled && this.ctx.state === "running");
  }

  private throttled(name: string, ms: number): boolean {
    const now = performance.now();
    const last = this.lastPlay.get(name) ?? -Infinity;
    if (now - last < ms) return true;
    this.lastPlay.set(name, now);
    return false;
  }

  private noise(options: NoiseOptions): void {
    if (!this.ready || this.activeVoices >= this.maxVoices) return;
    const ctx = this.ctx!;
    const start = ctx.currentTime + (options.at ?? 0);
    const source = ctx.createBufferSource();
    source.buffer = this.noiseBuffer;
    source.loop = true;
    source.playbackRate.value = 0.7 + Math.random() * 0.6;
    const filter = ctx.createBiquadFilter();
    filter.type = options.type;
    filter.frequency.value = options.freq;
    filter.Q.value = options.q ?? 0.8;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(options.gain, start);
    if (options.gainCurve === "linear") gain.gain.linearRampToValueAtTime(1e-4, start + options.dur);
    else gain.gain.exponentialRampToValueAtTime(1e-4, start + (options.decay ?? options.dur));
    source.connect(filter).connect(gain).connect(this.master!);
    source.start(start, Math.random());
    source.stop(start + options.dur + 0.02);
    this.track();
  }

  private tone(options: ToneOptions): void {
    if (!this.ready || this.activeVoices >= this.maxVoices) return;
    const ctx = this.ctx!;
    const start = ctx.currentTime + (options.at ?? 0);
    const osc = ctx.createOscillator();
    osc.type = options.type;
    osc.frequency.setValueAtTime(options.freq, start);
    if (options.freqEnd) osc.frequency.exponentialRampToValueAtTime(options.freqEnd, start + options.dur);
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(options.gain, start);
    gain.gain.exponentialRampToValueAtTime(1e-4, start + (options.decay ?? options.dur));
    osc.connect(gain).connect(this.master!);
    osc.start(start);
    osc.stop(start + options.dur + 0.02);
    this.track();
  }

  private track(): void {
    this.activeVoices++;
    window.setTimeout(() => this.activeVoices--, 250);
  }

  play(name: SoundName, intensity = 1): void {
    if (!this.ready) return;
    const r = Math.min(1, intensity);
    const s = 1 + (this.nextVariant() - 2.5) * 0.018;
    switch (name) {
      case "keyDown":
        if (this.throttled(name, 18)) return;
        this.noise({ dur: 0.03, gain: 0.12 * r, type: "lowpass", freq: 900 * s });
        this.tone({ freq: 140 * s, dur: 0.04, gain: 0.05 * r, type: "sine" });
        break;
      case "linkage":
        if (this.throttled(name, 20)) return;
        this.noise({ dur: 0.014, gain: 0.06 * r, type: "bandpass", freq: 3400 * s, q: 3 });
        break;
      case "swish":
        if (this.throttled(name, 25)) return;
        this.noise({ dur: 0.05, gain: 0.05 * r, type: "bandpass", freq: 1500 * s, q: 1.4 });
        break;
      case "impact":
        if (this.throttled(name, 25)) return;
        this.noise({ dur: 0.05, gain: 0.5 * r, type: "lowpass", freq: 2600 * s, decay: 0.045 });
        this.tone({ freq: 210 * s, freqEnd: 90, dur: 0.07, gain: 0.3 * r, type: "triangle", decay: 0.06 });
        this.noise({ dur: 0.012, gain: 0.28 * r, type: "highpass", freq: 3800 * s });
        break;
      case "rest":
        if (this.throttled(name, 25)) return;
        this.noise({ dur: 0.025, gain: 0.09 * r, type: "lowpass", freq: 700 * s });
        break;
      case "escapement":
        if (this.throttled(name, 25)) return;
        this.noise({ dur: 0.02, gain: 0.14 * r, type: "bandpass", freq: 2600 * s, q: 4 });
        this.tone({ freq: 1900 * s, dur: 0.02, gain: 0.04 * r, type: "square", decay: 0.018 });
        break;
      case "space":
        if (this.throttled(name, 30)) return;
        this.noise({ dur: 0.05, gain: 0.3 * r, type: "lowpass", freq: 500 * s });
        this.tone({ freq: 95 * s, dur: 0.06, gain: 0.16 * r, type: "sine" });
        break;
      case "backspace":
        if (this.throttled(name, 30)) return;
        this.noise({ dur: 0.04, gain: 0.22 * r, type: "lowpass", freq: 750 * s });
        this.noise({ at: 0.03, dur: 0.02, gain: 0.12 * r, type: "bandpass", freq: 2200 * s, q: 4 });
        break;
      case "bell": {
        const f = 2080 * s;
        this.tone({ freq: f, dur: 0.9, gain: 0.16, type: "sine", decay: 0.7 });
        this.tone({ freq: f * 2.76, dur: 0.4, gain: 0.05, type: "sine", decay: 0.35 });
        this.noise({ dur: 0.008, gain: 0.1, type: "highpass", freq: 5000 });
        break;
      }
      case "returnPull":
        this.noise({ dur: 0.12, gain: 0.18 * r, type: "bandpass", freq: 900, q: 1.2 });
        break;
      case "returnFly": {
        this.noise({ dur: 0.3, gain: 0.3 * r, type: "bandpass", freq: 1300, q: 0.9, gainCurve: "linear" });
        for (let i = 0; i < 6; i++) {
          this.noise({ at: 0.05 + i * 0.045, dur: 0.015, gain: 0.12, type: "bandpass", freq: 2500 * s, q: 5 });
        }
        this.noise({ at: 0.32, dur: 0.05, gain: 0.4 * r, type: "lowpass", freq: 900 });
        break;
      }
      case "ratchet":
        this.noise({ dur: 0.02, gain: 0.16, type: "bandpass", freq: 1900, q: 5 });
        this.noise({ at: 0.05, dur: 0.02, gain: 0.16, type: "bandpass", freq: 2300, q: 5 });
        break;
      case "paperIn":
        this.noise({ dur: 0.25, gain: 0.12, type: "bandpass", freq: 2400, q: 0.6, gainCurve: "linear" });
        break;
      case "paperOut":
        this.noise({ dur: 0.35, gain: 0.16, type: "bandpass", freq: 3000, q: 0.6, gainCurve: "linear" });
        break;
      case "shift":
        this.tone({ freq: 80, dur: 0.09, gain: 0.12, type: "sine" });
        this.noise({ dur: 0.07, gain: 0.1, type: "lowpass", freq: 600 });
        break;
      case "clash":
        this.noise({ dur: 0.03, gain: 0.2, type: "bandpass", freq: 1600, q: 2.5 });
        this.tone({ freq: 320, dur: 0.05, gain: 0.08, type: "triangle" });
        break;
      case "explodeMove":
        if (this.throttled(name, 90)) return;
        this.noise({ dur: 0.18, gain: 0.07, type: "bandpass", freq: 1100 * s, q: 1.6 });
        break;
      case "assembleMove":
        if (this.throttled(name, 90)) return;
        this.noise({ dur: 0.15, gain: 0.06, type: "bandpass", freq: 850 * s, q: 1.6 });
        break;
    }
  }
}
