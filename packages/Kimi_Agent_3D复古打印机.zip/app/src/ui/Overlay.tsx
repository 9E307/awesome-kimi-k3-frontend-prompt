import { useEffect, useState } from "react";
import { useStore } from "../app/store";
import { getCore } from "../app/core";
import { t } from "../app/i18n";
import { PlaqueStack } from "./Plaque";
import { PartInfo } from "./PartInfo";
import { ExportDrawer } from "./ExportDrawer";
import { ClearConfirmDialog, DraftRestoreDialog } from "./ConfirmDialog";
import { ControlDesk } from "./ControlDesk";
import type { InputManager } from "../document/draftStorage";

/**
 * Full-viewport HTML overlay: title block, language toggle, breathing
 * hint, plaques, IME composition preview, dialogs, part card, export
 * drawer, control desk, privacy footer and the screen-reader text mirror.
 */
export function Overlay({ manager }: { manager: InputManager | null }) {
  const state = useStore();
  const core = getCore();
  const [impacted, setImpacted] = useState(false);
  const [imeText, setImeText] = useState("");
  const lang = state.lang;

  useEffect(() => core.machine.bus.on("impact", () => setImpacted(true)), [core]);
  useEffect(() => manager?.imeBus.on("preview", ({ text }: { text: string }) => setImeText(text)), [manager]);

  return (
    <div className="overlay">
      <header className="hud-title">
        <h1>THE IMPACT No. 01</h1>
        <p className="subtitle">{t(lang, "subtitle")}</p>
        <p className="tagline">
          {t(lang, "tagline1")}
          <br />
          <span lang="zh-CN">{t(lang, "tagline2")}</span>
        </p>
      </header>
      <button
        className="hud-btn lang-toggle"
        onClick={() => state.setLang(lang === "en" ? "zh" : "en")}
        aria-label="Switch interface language / 切换界面语言"
      >
        {t(lang, "btn.lang")}
      </button>
      {!impacted && <div className="hud-hint">{t(lang, "hint")}</div>}
      <PlaqueStack />
      {imeText && (
        <div className="ime-preview" aria-hidden={true}>
          {imeText}
        </div>
      )}
      <DraftRestoreDialog />
      <ClearConfirmDialog />
      <PartInfo />
      <ExportDrawer />
      <ControlDesk />
      <footer className="hud-footer">{t(lang, "footer")}</footer>
      <div className="sr-only" aria-live="polite" aria-label={t(lang, "aria.manuscriptText")}>
        {core.manuscript.getText().replace(/\f/g, "\n\n— new sheet —\n\n")}
      </div>
    </div>
  );
}
