import { useEffect, useState } from "react";
import { useStore } from "../app/store";
import { getCore } from "../app/core";
import { t } from "../app/i18n";
import { buildDocx, type OverstrikeMode } from "../export/buildDocx";
import { wordCountZh } from "../document/textMetrics";

const DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";

/**
 * Right-hand export drawer: title, author, overstrike policy, font status,
 * live manuscript counts and the in-browser DOCX download.
 */
export function ExportDrawer() {
  const open = useStore((s) => s.exportOpen);
  const setOpen = useStore((s) => s.setExportOpen);
  const exporting = useStore((s) => s.exporting);
  const setExporting = useStore((s) => s.setExporting);
  const result = useStore((s) => s.exportResult);
  const setResult = useStore((s) => s.setExportResult);
  const error = useStore((s) => s.exportError);
  const setError = useStore((s) => s.setExportError);
  const lang = useStore((s) => s.lang);
  const core = getCore();
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [overstrike, setOverstrike] = useState<OverstrikeMode>("final");
  const [fontAvailable, setFontAvailable] = useState<boolean | null>(null);

  useEffect(() => {
    if (!open) return;
    setResult(null);
    setError(null);
    let cancelled = false;
    fetch("fonts/CourierPrime-Regular.ttf")
      .then((res) => {
        if (!res.ok) throw new Error(String(res.status));
        return res.arrayBuffer();
      })
      .then(() => !cancelled && setFontAvailable(true))
      .catch(() => !cancelled && setFontAvailable(false));
    return () => {
      cancelled = true;
    };
  }, [open, setResult, setError]);

  if (!open) return null;
  const manuscript = core.manuscript;

  const runExport = async () => {
    if (exporting) return;
    setExporting(true);
    setError(null);
    setResult(null);
    try {
      let fontData: ArrayBuffer | undefined;
      try {
        const res = await fetch("fonts/CourierPrime-Regular.ttf");
        if (res.ok) fontData = await res.arrayBuffer();
      } catch {
        fontData = undefined;
      }
      const outcome = await buildDocx(manuscript, {
        title: title.trim(),
        author: author.trim(),
        overstrikeMode: overstrike,
        embedFont: fontData !== undefined,
        fontData,
      });
      const blob = new Blob([outcome.bytes.buffer as ArrayBuffer], { type: DOCX_MIME });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = outcome.fileName;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 8000);
      setResult(outcome);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="drawer-backdrop" onClick={() => setOpen(false)}>
      <aside className="drawer" aria-label={t(lang, "aria.exportSettings")} onClick={(event) => event.stopPropagation()}>
        <div className="part-info-head">
          <span className="part-info-system">{t(lang, "export.title")}</span>
          <button className="hud-btn small" onClick={() => setOpen(false)} aria-label={t(lang, "aria.closeExport")}>
            ×
          </button>
        </div>
        <label className="field">
          <span>{t(lang, "export.docTitle")}</span>
          <input value={title} onChange={(event) => setTitle(event.target.value)} placeholder={t(lang, "export.untitled")} />
        </label>
        <label className="field">
          <span>{t(lang, "export.author")}</span>
          <input value={author} onChange={(event) => setAuthor(event.target.value)} placeholder="" />
        </label>
        <label className="field">
          <span>{t(lang, "export.overstrike")}</span>
          <select value={overstrike} onChange={(event) => setOverstrike(event.target.value as OverstrikeMode)}>
            <option value="final">{t(lang, "export.keepFinal")}</option>
            <option value="annotated">{t(lang, "export.annotated")}</option>
          </select>
        </label>
        <div className="field-note">
          {fontAvailable === null && t(lang, "export.fontChecking")}
          {fontAvailable === true && t(lang, "export.fontOk")}
          {fontAvailable === false && t(lang, "export.fontMissing")}
        </div>
        <div className="field-note">
          {lang === "zh"
            ? `${manuscript.pages.length} ${t(lang, "stats.pages")} · ${manuscript.charCount} ${t(lang, "stats.zi")} · ${wordCountZh(manuscript.getText())} ${t(lang, "stats.words")}`
            : `${manuscript.pages.length} ${manuscript.pages.length === 1 ? t(lang, "stats.page") : t(lang, "stats.pages")} · ${manuscript.wordCount} ${t(lang, "stats.words")} · ${manuscript.charCount} ${t(lang, "stats.chars")}`}
        </div>
        <button
          className="hud-btn accent wide"
          onClick={runExport}
          disabled={exporting || manuscript.charCount === 0}
          aria-label={t(lang, "aria.export")}
        >
          {exporting ? t(lang, "export.generating") : t(lang, "export.go")}
        </button>
        {result && (
          <div className="export-result" role="status">
            <div>{result.fileName}</div>
            <div>
              {(result.size / 1024).toFixed(1)} KB · {result.fontEmbedded ? t(lang, "export.embeddedWest") : t(lang, "export.referenced")}
            </div>
            <div className="field-note">{result.fontNote}</div>
          </div>
        )}
        {error && (
          <div className="export-error" role="alert">
            {t(lang, "export.failed")}
            <br />
            {error}
          </div>
        )}
        <div className="field-note dim">{t(lang, "export.privacy")}</div>
      </aside>
    </div>
  );
}
