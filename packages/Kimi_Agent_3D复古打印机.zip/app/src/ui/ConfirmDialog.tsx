import { useStore } from "../app/store";
import { getCore } from "../app/core";
import { t } from "../app/i18n";
import { InputManager } from "../document/draftStorage";

/** Centered confirmation card before wiping the manuscript. */
export function ClearConfirmDialog() {
  const open = useStore((s) => s.clearConfirm);
  const setOpen = useStore((s) => s.setClearConfirm);
  const showPlaqueKey = useStore((s) => s.showPlaqueKey);
  const lang = useStore((s) => s.lang);
  if (!open) return null;

  const confirm = () => {
    const core = getCore();
    core.machine.clearPendingUnicode(); // un-typed adapter text must not land on the fresh sheet
    core.machine.cancelInFlight(); // nor keystrokes still travelling mechanically
    core.manuscript.clear();
    InputManager.discardDraft();
    useStore.getState().setDraftExists(false);
    setOpen(false);
    showPlaqueKey("plaque.cleared");
  };

  return (
    <div className="confirm-card" role="alertdialog" aria-label={t(lang, "aria.confirmClear")}>
      <p>{t(lang, "confirm.clear")}</p>
      <div>
        <button className="hud-btn danger" onClick={confirm}>
          {t(lang, "confirm.confirm")}
        </button>
        <button className="hud-btn" onClick={() => setOpen(false)}>
          {t(lang, "confirm.cancel")}
        </button>
      </div>
    </div>
  );
}

/** Quiet prompt offering to resume the locally stored draft. */
export function DraftRestoreDialog() {
  const draftExists = useStore((s) => s.draftExists);
  const setDraftExists = useStore((s) => s.setDraftExists);
  const showPlaqueKey = useStore((s) => s.showPlaqueKey);
  const lang = useStore((s) => s.lang);
  useStore((s) => s.stats); // re-evaluate isEmpty as the manuscript changes
  const core = getCore();
  if (!draftExists || !core.manuscript.isEmpty) return null;

  const resume = () => {
    const draft = InputManager.loadDraft();
    if (draft) {
      core.manuscript.restore(draft);
      showPlaqueKey("plaque.draftRestored");
    }
    setDraftExists(false);
  };

  const discard = () => {
    InputManager.discardDraft();
    setDraftExists(false);
  };

  return (
    <div className="confirm-card" role="dialog" aria-label={t(lang, "aria.restoreDraft")}>
      <p>{t(lang, "confirm.draft")}</p>
      <div>
        <button className="hud-btn accent" onClick={resume}>
          {t(lang, "confirm.resume")}
        </button>
        <button className="hud-btn" onClick={discard}>
          {t(lang, "confirm.discard")}
        </button>
      </div>
    </div>
  );
}
