import { useStore } from "../app/store";
import { t } from "../app/i18n";
import { BELL_COL } from "../document/constants";

/**
 * Top-center plaque stack: persistent machine-state notices (assemble,
 * margin, page full) plus transient event plaques and modern-aid notes.
 */
export function PlaqueStack() {
  const lang = useStore((s) => s.lang);
  const explodeCurrent = useStore((s) => s.explodeCurrent);
  const stats = useStore((s) => s.stats);
  const plaque = useStore((s) => s.plaque);
  const plaqueKey = useStore((s) => s.plaqueKey);
  const unicodeAdapter = useStore((s) => s.unicodeAdapter);
  const autoReturn = useStore((s) => s.autoReturn);

  const exploded = explodeCurrent > 0.08;
  const nearMargin = stats.col >= BELL_COL && !stats.pageFull && !exploded;
  const pageFull = stats.pageFull && !exploded;

  return (
    <div className="plaque-stack" aria-live="polite">
      {exploded && <div className="plaque warn">{t(lang, "plaque.assemble")}</div>}
      {nearMargin && <div className="plaque">{t(lang, "plaque.margin")}</div>}
      {pageFull && <div className="plaque">{t(lang, "plaque.pageFull")}</div>}
      {plaque && <div className="plaque transient">{plaque}</div>}
      {plaqueKey && <div className="plaque transient">{t(lang, plaqueKey)}</div>}
      {unicodeAdapter && <div className="plaque note">{t(lang, "plaque.unicode")}</div>}
      {autoReturn && <div className="plaque note">{t(lang, "plaque.autoreturn")}</div>}
    </div>
  );
}
