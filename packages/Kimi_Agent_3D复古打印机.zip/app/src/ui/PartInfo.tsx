import { useEffect } from "react";
import { useStore } from "../app/store";
import { getCore } from "../app/core";
import { partFunction, partName, systemName, t } from "../app/i18n";
import { getMachineBuild } from "../scene/machineBuildRegistry";
import { traceChainFor } from "../machine/partMetadata";

/**
 * Part information card: system, name, function, power flow and the
 * slow-motion keystroke trace trigger.
 */
export function PartInfo() {
  const selectedPart = useStore((s) => s.selectedPart);
  const explodeCurrent = useStore((s) => s.explodeCurrent);
  const selectPart = useStore((s) => s.selectPart);
  const startTrace = useStore((s) => s.startTrace);
  const stopTrace = useStore((s) => s.stopTrace);
  const setSlowMotion = useStore((s) => s.setSlowMotion);
  const showPlaqueKey = useStore((s) => s.showPlaqueKey);
  const lang = useStore((s) => s.lang);
  const build = getMachineBuild();
  const part = selectedPart ? build?.byId.get(selectedPart) : undefined;

  // Selecting a key while exploded traces its transmission chain in place.
  useEffect(() => {
    if (!selectedPart || explodeCurrent < 0.5) return;
    if (!selectedPart.startsWith("key.")) return;
    const chain = traceChainFor(selectedPart.replace(/^key\./u, ""));
    if (chain.length > 0) startTrace(chain);
  }, [selectedPart, explodeCurrent, startTrace]);

  if (!part || !selectedPart) return null;

  const followKeystroke = () => {
    const core = getCore();
    if (core.machine.explode > 0.08) {
      showPlaqueKey("plaque.assemble");
      return;
    }
    const code = selectedPart.startsWith("key.") ? selectedPart.slice(4) : "KeyA";
    const chain = traceChainFor(code);
    setSlowMotion(true);
    if (chain.length) startTrace(chain);
    core.machine.press(code);
    window.setTimeout(() => {
      setSlowMotion(false);
      stopTrace();
    }, 2600);
  };

  const describe = (ids: string[]) =>
    ids
      .map((id) => {
        const found = build?.byId.get(id);
        return found ? partName(lang, found.label) : id;
      })
      .filter(Boolean)
      .join(" · ");

  return (
    <aside className="part-info" aria-label={t(lang, "aria.partInfo")}>
      <div className="part-info-head">
        <span className="part-info-system">{systemName(lang, part.system)}</span>
        <button className="hud-btn small" onClick={() => selectPart(null)} aria-label={t(lang, "aria.closePart")}>
          ×
        </button>
      </div>
      <h3 className="part-info-label">{partName(lang, part.label)}</h3>
      <p className="part-info-fn">{partFunction(lang, part.fn)}</p>
      {part.upstream.length > 0 && (
        <p className="part-info-rel">
          <span>{t(lang, "part.from")}</span> {describe(part.upstream)}
        </p>
      )}
      {part.downstream.length > 0 && (
        <p className="part-info-rel">
          <span>{t(lang, "part.drives")}</span> {describe(part.downstream)}
        </p>
      )}
      <button className="hud-btn accent" onClick={followKeystroke} aria-label={t(lang, "aria.follow")}>
        {t(lang, "part.follow")}
      </button>
    </aside>
  );
}
