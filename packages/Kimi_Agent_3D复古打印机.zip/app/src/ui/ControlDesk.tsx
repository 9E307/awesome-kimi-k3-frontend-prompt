import { useEffect, useRef, useState, type ReactNode } from "react";
import { useStore } from "../app/store";
import { getCore } from "../app/core";
import { t } from "../app/i18n";
import { SAMPLE_TEXT } from "../document/sampleText";

function Section({ label, children, grow }: { label: string; children: ReactNode; grow?: boolean }) {
  return (
    <section className={`panel-section${grow ? " grow" : ""}`}>
      <div className="section-label">{label}</div>
      <div className="section-body">{children}</div>
    </section>
  );
}

const CAMERA_MODES = ["write", "mechanism", "inspect"] as const;

/**
 * CONTROL DESK — machine / view / document sections plus the collapsible
 * modern-aids row and the live stats line (words in English, 字 in Chinese).
 */
export function ControlDesk() {
  const state = useStore();
  const core = getCore();
  const [modernOpen, setModernOpen] = useState(false);
  // Screen-reader feedback: when a queued history op lands, announce it.
  const pendingTotal = state.pendingUndoCount + state.pendingRedoCount;
  const prevPending = useRef(0);
  const [appliedFlash, setAppliedFlash] = useState(false);
  useEffect(() => {
    const had = prevPending.current;
    prevPending.current = pendingTotal;
    if (had > 0 && pendingTotal === 0) {
      setAppliedFlash(true);
      const timer = window.setTimeout(() => setAppliedFlash(false), 1500);
      return () => window.clearTimeout(timer);
    }
  }, [pendingTotal]);
  const exploded = state.explodeTarget > 0.5;
  const words = state.stats.words;
  const chars = state.stats.chars;
  const pages = state.stats.pages;
  const lang = state.lang;

  if (state.panelHidden) {
    return (
      <button className="hud-btn panel-chip" onClick={state.togglePanel} aria-label={t(lang, "aria.showPanel")}>
        {t(lang, "panel.show")} ▴
      </button>
    );
  }

  return (
    <div className="control-bar panel" role="toolbar" aria-label={t(lang, "aria.machineControls")}>
      <div className="panel-head">
        <span className="panel-title">CONTROL DESK</span>
        <button className="hud-btn small ghost" onClick={state.togglePanel} aria-label={t(lang, "aria.hidePanel")}>
          {t(lang, "panel.hide")} ▾
        </button>
      </div>
      <div className="panel-grid">
        <Section label={t(lang, "sec.machine")}>
          <button
            className="hud-btn accent"
            aria-label={exploded ? t(lang, "aria.assemble") : t(lang, "aria.explode")}
            onClick={() => state.setExplodeTarget(exploded ? 0 : 1)}
          >
            {exploded ? t(lang, "btn.assemble") : t(lang, "btn.explode")}
          </button>
          <input
            className="explode-slider"
            type="range"
            min={0}
            max={100}
            value={Math.round(state.explodeTarget * 100)}
            aria-label={t(lang, "aria.explodeLevel")}
            onChange={(event) => state.setExplodeTarget(Number(event.target.value) / 100)}
          />
          <span className="explode-value">{Math.round(state.explodeCurrent * 100)}%</span>
          <button
            className={`hud-btn ${state.cutaway ? "on" : ""}`}
            aria-pressed={state.cutaway}
            aria-label={t(lang, "aria.cutaway")}
            onClick={() => {
              if (!state.cutaway) state.setExplodeTarget(0);
              state.toggleCutaway();
            }}
          >
            {t(lang, "btn.cutaway")}
          </button>
        </Section>

        <Section label={t(lang, "sec.view")}>
          <div className="segmented" role="group" aria-label={t(lang, "aria.cameraMode")}>
            {CAMERA_MODES.map((mode) => (
              <button
                key={mode}
                className={`hud-btn seg ${state.cameraMode === mode ? "on" : ""}`}
                aria-pressed={state.cameraMode === mode}
                aria-label={t(lang, `btn.${mode}`)}
                onClick={() => state.setCameraMode(mode)}
              >
                {t(lang, `btn.${mode}`)}
              </button>
            ))}
          </div>
          <button
            className={`hud-btn ${state.soundOn ? "on" : ""}`}
            aria-pressed={state.soundOn}
            aria-label={t(lang, "aria.toggleSound")}
            onClick={() => {
              core.sound.setEnabled(!state.soundOn);
              state.toggleSound();
            }}
          >
            {t(lang, "btn.sound")}
          </button>
        </Section>

        <Section label={t(lang, "sec.document")}>
          <button className="hud-btn" onClick={() => core.machine.newSheet()} aria-label={t(lang, "aria.newSheet")}>
            {t(lang, "btn.newSheet")}
          </button>
          <button
            className={`hud-btn${state.pendingUndoCount > 0 ? " queued" : ""}`}
            onClick={() => core.machine.requestHistoryOp("undo")}
            disabled={!state.canUndo && state.pendingUndoCount === 0}
            aria-disabled={!state.canUndo && state.pendingUndoCount === 0}
            aria-busy={state.pendingUndoCount > 0}
            aria-label={t(lang, "aria.undo")}
            title={
              !state.canUndo && state.pendingUndoCount === 0
                ? t(lang, "hint.noUndo")
                : state.machineBusy
                  ? t(lang, "hint.machineBusy")
                  : undefined
            }
          >
            {t(lang, "btn.undo")}
            {state.pendingUndoCount > 0 && <span className="queued-tag">{t(lang, "btn.queued")}</span>}
          </button>
          <button
            className={`hud-btn${state.pendingRedoCount > 0 ? " queued" : ""}`}
            onClick={() => core.machine.requestHistoryOp("redo")}
            disabled={!state.canRedo && state.pendingRedoCount === 0}
            aria-disabled={!state.canRedo && state.pendingRedoCount === 0}
            aria-busy={state.pendingRedoCount > 0}
            aria-label={t(lang, "aria.redo")}
            title={
              !state.canRedo && state.pendingRedoCount === 0
                ? t(lang, "hint.noRedo")
                : state.machineBusy
                  ? t(lang, "hint.machineBusy")
                  : undefined
            }
          >
            {t(lang, "btn.redo")}
            {state.pendingRedoCount > 0 && <span className="queued-tag">{t(lang, "btn.queued")}</span>}
          </button>
          <button className="hud-btn accent" onClick={() => state.setExportOpen(true)} aria-label={t(lang, "aria.export")}>
            {t(lang, "btn.export")}
          </button>
          <button
            className="hud-btn danger"
            onClick={() => state.setClearConfirm(true)}
            aria-label={t(lang, "aria.clear")}
            disabled={core.manuscript.isEmpty}
          >
            {t(lang, "btn.clear")}
          </button>
        </Section>

        <section className="panel-section modern">
          <button className="section-label as-toggle" onClick={() => setModernOpen((v) => !v)} aria-expanded={modernOpen}>
            {t(lang, "sec.modern")} {modernOpen ? "−" : "+"}
          </button>
          {modernOpen && (
            <div className="section-body">
              <button
                className={`hud-btn small ${state.unicodeAdapter ? "on" : ""}`}
                aria-pressed={state.unicodeAdapter}
                aria-label={t(lang, "aria.unicode")}
                onClick={() => state.toggleUnicodeAdapter()}
                title="Unicode Adapter is a contemporary digital extension, not an original mechanical capability."
              >
                {t(lang, "btn.unicode")}
              </button>
              <button
                className={`hud-btn small ${state.autoReturn ? "on" : ""}`}
                aria-pressed={state.autoReturn}
                aria-label={t(lang, "aria.autoreturn")}
                onClick={() => {
                  core.manuscript.autoReturn = !state.autoReturn;
                  state.toggleAutoReturn();
                }}
                title="Modern auto-return: wraps at the right margin. A 1930s machine never wraps."
              >
                {t(lang, "btn.autoreturn")}
              </button>
              <button
                className="hud-btn small"
                onClick={() => {
                  core.machine.clearPendingUnicode();
                  core.machine.cancelInFlight();
                  core.manuscript.loadText(SAMPLE_TEXT, performance.now());
                  state.showPlaqueKey("plaque.sample");
                }}
                aria-label={t(lang, "aria.sample")}
              >
                {t(lang, "btn.sample")}
              </button>
            </div>
          )}
        </section>
      </div>
      <div className="panel-stats" aria-live="off">
        <span>
          {lang === "zh"
            ? `${chars} ${t(lang, "stats.zi")} · ${pages} ${t(lang, pages === 1 ? "stats.page" : "stats.pages")}`
            : `${words} ${t(lang, words === 1 ? "stats.word" : "stats.words")} · ${pages} ${t(lang, pages === 1 ? "stats.page" : "stats.pages")}`}{" "}
          · L{state.stats.line + 1} C{state.stats.col + 1}
        </span>
      </div>
      <div className="sr-only" aria-live="polite" role="status">
        {state.pendingUndoCount > 0
          ? t(lang, "a11y.undoQueued")
          : state.pendingRedoCount > 0
            ? t(lang, "a11y.redoQueued")
            : appliedFlash
              ? t(lang, "a11y.historyApplied")
              : state.machineBusy
                ? t(lang, "a11y.machineBusy")
                : ""}
      </div>
    </div>
  );
}
