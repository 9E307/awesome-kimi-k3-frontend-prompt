import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router";
import App from "./app/App";
import { getCore } from "./app/core";
import { useStore } from "./app/store";
import { buildDocx } from "./export/buildDocx";
import type { Manuscript } from "./document/Manuscript";
import type { MachineState } from "./machine/machineState";
import type { PaperTexture } from "./document/PaperTexture";
import type { MachineBuild } from "./machine/buildMachine";
import "./styles/index.css";

declare global {
  interface Window {
    __impact?: {
      machine: MachineState;
      manuscript: Manuscript;
      paper: PaperTexture;
      store: typeof useStore;
      buildDocx: typeof buildDocx;
      version: string;
    };
    __impactBuild?: MachineBuild;
    __impactGL?: unknown;
    __impactCamera?: unknown;
  }
}

/** Waits for Courier Prime (bounded) so the first paint is already correct. */
async function preloadFonts(): Promise<void> {
  try {
    await Promise.race([
      Promise.all([
        document.fonts.load('400 30px "Courier Prime"'),
        document.fonts.load('600 46px "Courier Prime"'),
        document.fonts.load('700 30px "Courier Prime"'),
      ]),
      new Promise((resolve) => window.setTimeout(resolve, 1800)),
    ]);
  } catch {
    /* fonts still arrive via font-display: swap */
  }
}

async function bootstrap(): Promise<void> {
  await preloadFonts();
  const container = document.getElementById("root");
  if (!container) throw new Error("missing #root");
  createRoot(container).render(
    <StrictMode>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </StrictMode>,
  );
  const core = getCore();
  window.__impact = {
    machine: core.machine,
    manuscript: core.manuscript,
    paper: core.paper,
    store: useStore,
    buildDocx,
    version: "1.0.0",
  };
  document.body.classList.add("impact-ready");
}

void bootstrap();
