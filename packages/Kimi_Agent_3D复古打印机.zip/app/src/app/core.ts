import { Manuscript } from "../document/Manuscript";
import { MachineState } from "../machine/machineState";
import { MechanicalAudio } from "../audio/MechanicalAudio";
import { PaperTexture } from "../document/PaperTexture";

/**
 * Application core: the four long-lived singletons (document, machine,
 * sound, paper) plus one-time audio wiring from the machine event bus.
 */
export interface Core {
  manuscript: Manuscript;
  machine: MachineState;
  sound: MechanicalAudio;
  paper: PaperTexture;
  wired: boolean;
}

let core: Core | null = null;

export function getCore(): Core {
  if (!core) {
    const manuscript = new Manuscript();
    const machine = new MachineState(manuscript);
    const sound = new MechanicalAudio();
    const paper = new PaperTexture(manuscript);
    core = { manuscript, machine, sound, paper, wired: false };
  }
  return core;
}

/** Maps machine events to synthesized sounds. Runs once per session. */
export function wireAudio({ machine, sound }: Core): void {
  if (core!.wired) return;
  core!.wired = true;
  machine.bus.on("keyTravel", ({ kind }: { kind: string }) => {
    if (kind === "space") sound.play("space");
    else if (kind === "backspace") sound.play("backspace");
    else sound.play("keyDown");
  });
  machine.bus.on("linkage", () => sound.play("linkage"));
  machine.bus.on("impact", () => sound.play("impact"));
  machine.bus.on("typebarRest", () => sound.play("rest"));
  machine.bus.on("escapement", () => sound.play("escapement"));
  machine.bus.on("bell", () => sound.play("bell"));
  machine.bus.on("clash", () => sound.play("clash"));
  machine.bus.on("shiftChange", ({ engaged }: { engaged: boolean }) => sound.play("shift", engaged ? 1 : 0.6));
  machine.bus.on("carriageReturnStart", () => {
    sound.play("returnPull");
    window.setTimeout(() => sound.play("returnFly"), 180);
    window.setTimeout(() => sound.play("ratchet"), 500);
  });
  machine.bus.on("paperFeed", () => {
    sound.play("paperOut");
    window.setTimeout(() => sound.play("paperIn"), 320);
  });
  machine.bus.on("rejected", ({ reason }: { reason: string }) => {
    if (reason === "margin") sound.play("bell");
    if (reason === "exploded") sound.play("rest", 0.7);
  });
}
