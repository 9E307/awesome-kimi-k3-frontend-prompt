import { create } from "zustand";
import type { Lang } from "./i18n";
import { ADAPTER_STORAGE_KEY, LANG_STORAGE_KEY } from "../document/constants";

export type CameraMode = "write" | "mechanism" | "inspect";

export interface Stats {
  chars: number;
  words: number;
  pages: number;
  line: number;
  col: number;
  pageFull: boolean;
}

export interface TraceState {
  chain: string[];
  index: number;
}

export interface ExportResultInfo {
  fileName: string;
  size: number;
  fontEmbedded: boolean;
  fontNote: string;
  pageCount: number;
  wordCount: number;
  charCount: number;
}

interface UiState {
  lang: Lang;
  setLang: (lang: Lang) => void;

  panelHidden: boolean;
  togglePanel: () => void;

  cameraMode: CameraMode;
  setCameraMode: (mode: CameraMode) => void;

  explodeTarget: number;
  explodeCurrent: number;
  setExplodeTarget: (value: number) => void;
  setExplodeCurrent: (value: number) => void;

  cutaway: boolean;
  toggleCutaway: () => void;

  soundOn: boolean;
  toggleSound: () => void;

  unicodeAdapter: boolean;
  toggleUnicodeAdapter: () => void;

  autoReturn: boolean;
  toggleAutoReturn: () => void;

  selectedPart: string | null;
  selectPart: (id: string | null) => void;

  trace: TraceState | null;
  startTrace: (chain: string[]) => void;
  advanceTrace: () => void;
  stopTrace: () => void;

  slowMotion: boolean;
  setSlowMotion: (on: boolean) => void;

  stats: Stats;
  setStats: (stats: Stats) => void;

  /** Live machine status, synced every frame by the render loop. */
  machineBusy: boolean;
  historyPending: boolean;
  pendingUndoCount: number;
  pendingRedoCount: number;
  canUndo: boolean;
  canRedo: boolean;
  setMachineStatus: (status: {
    machineBusy: boolean;
    historyPending: boolean;
    pendingUndoCount: number;
    pendingRedoCount: number;
    canUndo: boolean;
    canRedo: boolean;
  }) => void;

  plaque: string | null;
  showPlaque: (text: string, ms?: number) => void;
  plaqueKey: string | null;
  showPlaqueKey: (key: string, ms?: number) => void;

  bellTick: number;
  jamTick: number;

  exportOpen: boolean;
  setExportOpen: (open: boolean) => void;
  exporting: boolean;
  setExporting: (on: boolean) => void;
  exportResult: ExportResultInfo | null;
  setExportResult: (result: ExportResultInfo | null) => void;
  exportError: string | null;
  setExportError: (error: string | null) => void;

  clearConfirm: boolean;
  setClearConfirm: (open: boolean) => void;

  draftExists: boolean;
  setDraftExists: (exists: boolean) => void;
  saveTick: number;
  bumpSaveTick: () => void;

  motionReduced: boolean;
}

let plaqueTimer = 0;

/** Chinese is the default interface language; English is one tap away. */
function initialLang(): Lang {
  if (typeof localStorage === "undefined") return "zh";
  return localStorage.getItem(LANG_STORAGE_KEY) === "en" ? "en" : "zh";
}

/**
 * Unicode adapter default: on a Chinese interface's first use it defaults
 * ON; once the user explicitly toggles it, the saved preference wins.
 */
function initialUnicodeAdapter(lang: Lang): boolean {
  if (typeof localStorage === "undefined") return lang === "zh";
  const saved = localStorage.getItem(ADAPTER_STORAGE_KEY);
  if (saved === "1") return true;
  if (saved === "0") return false;
  return lang === "zh";
}

export const useStore = create<UiState>()((set, get) => ({
  lang: initialLang(),
  setLang: (lang) => {
    try {
      localStorage.setItem(LANG_STORAGE_KEY, lang);
    } catch {
      /* storage unavailable */
    }
    // No saved adapter preference yet → follow the language default.
    const patch: Partial<UiState> = { lang };
    if (typeof localStorage !== "undefined" && localStorage.getItem(ADAPTER_STORAGE_KEY) === null) {
      patch.unicodeAdapter = lang === "zh";
    }
    set(patch);
  },

  panelHidden: false,
  togglePanel: () => set((s) => ({ panelHidden: !s.panelHidden })),

  cameraMode: "write",
  setCameraMode: (cameraMode) => set({ cameraMode }),

  explodeTarget: 0,
  explodeCurrent: 0,
  setExplodeTarget: (value) => set({ explodeTarget: Math.min(1, Math.max(0, value)) }),
  setExplodeCurrent: (value) => {
    const current = get().explodeCurrent;
    if (Math.abs(current - value) > 0.004 || value === 0 || value === 1) set({ explodeCurrent: value });
  },

  cutaway: false,
  toggleCutaway: () => set((s) => ({ cutaway: !s.cutaway })),

  soundOn: true,
  toggleSound: () => set((s) => ({ soundOn: !s.soundOn })),

  unicodeAdapter: initialUnicodeAdapter(initialLang()),
  toggleUnicodeAdapter: () =>
    set((s) => {
      const unicodeAdapter = !s.unicodeAdapter;
      try {
        localStorage.setItem(ADAPTER_STORAGE_KEY, unicodeAdapter ? "1" : "0");
      } catch {
        /* storage unavailable */
      }
      return { unicodeAdapter };
    }),

  autoReturn: false,
  toggleAutoReturn: () => set((s) => ({ autoReturn: !s.autoReturn })),

  selectedPart: null,
  selectPart: (selectedPart) => set({ selectedPart }),

  trace: null,
  startTrace: (chain) => set({ trace: { chain, index: 0 } }),
  advanceTrace: () => {
    const trace = get().trace;
    if (!trace) return;
    if (trace.index >= trace.chain.length - 1) set({ trace: null });
    else set({ trace: { ...trace, index: trace.index + 1 } });
  },
  stopTrace: () => set({ trace: null }),

  slowMotion: false,
  setSlowMotion: (slowMotion) => set({ slowMotion }),

  stats: { chars: 0, words: 0, pages: 1, line: 0, col: 0, pageFull: false },
  setStats: (stats) => set({ stats }),

  machineBusy: false,
  historyPending: false,
  pendingUndoCount: 0,
  pendingRedoCount: 0,
  canUndo: false,
  canRedo: false,
  setMachineStatus: (status) => set(status),

  plaque: null,
  showPlaque: (text, ms = 3200) => {
    window.clearTimeout(plaqueTimer);
    set({ plaque: text, plaqueKey: null });
    plaqueTimer = window.setTimeout(() => set({ plaque: null }), ms);
  },
  plaqueKey: null,
  showPlaqueKey: (key, ms = 3200) => {
    window.clearTimeout(plaqueTimer);
    set({ plaqueKey: key, plaque: null });
    plaqueTimer = window.setTimeout(() => set({ plaqueKey: null }), ms);
  },

  bellTick: 0,
  jamTick: 0,

  exportOpen: false,
  setExportOpen: (exportOpen) => set({ exportOpen }),
  exporting: false,
  setExporting: (exporting) => set({ exporting }),
  exportResult: null,
  setExportResult: (exportResult) => set({ exportResult }),
  exportError: null,
  setExportError: (exportError) => set({ exportError }),

  clearConfirm: false,
  setClearConfirm: (clearConfirm) => set({ clearConfirm }),

  draftExists: false,
  setDraftExists: (draftExists) => set({ draftExists }),
  saveTick: 0,
  bumpSaveTick: () => set((s) => ({ saveTick: s.saveTick + 1 })),

  motionReduced:
    typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)").matches === true,
}));
