/**
 * Interface strings, part names, part descriptions and system labels
 * in English and Chinese. Keys mirror the reference build exactly.
 */

export type Lang = "en" | "zh";

type Entry = { en: string; zh: string };

export const STRINGS: Record<string, Entry> = {
  subtitle: { en: "A mechanical document editor.", zh: "一台机械文稿编辑器。" },
  tagline1: { en: "Before words became data, they were impact.", zh: "在文字成为数据以前，它首先是一次撞击。" },
  tagline2: { en: "在文字成为数据以前，它首先是一次撞击。", zh: "Before words became data, they were impact." },
  hint: { en: "“Press any key.”", zh: "“按下任意键。”" },
  footer: { en: "Your writing never leaves this device.", zh: "你的文字永远不会离开这台设备。" },
  "sec.machine": { en: "MACHINE", zh: "机械" },
  "sec.view": { en: "VIEW", zh: "视角" },
  "sec.document": { en: "DOCUMENT", zh: "文稿" },
  "sec.modern": { en: "MODERN AIDS", zh: "现代辅助" },
  "panel.hide": { en: "HIDE PANEL", zh: "收起面板" },
  "panel.show": { en: "PANEL", zh: "面板" },
  "btn.explode": { en: "EXPLODE", zh: "拆解" },
  "btn.assemble": { en: "ASSEMBLE", zh: "聚合" },
  "btn.cutaway": { en: "CUTAWAY", zh: "剖视" },
  "btn.write": { en: "WRITE", zh: "书写" },
  "btn.mechanism": { en: "MECHANISM", zh: "机芯" },
  "btn.inspect": { en: "INSPECT", zh: "检视" },
  "btn.sound": { en: "SOUND", zh: "声音" },
  "btn.newSheet": { en: "NEW SHEET", zh: "换新纸" },
  "btn.undo": { en: "UNDO", zh: "撤销" },
  "btn.redo": { en: "REDO", zh: "重做" },
  "btn.export": { en: "EXPORT DOCX", zh: "导出 DOCX" },
  "btn.clear": { en: "CLEAR", zh: "清空" },
  "btn.unicode": { en: "UNICODE ADAPTER", zh: "UNICODE 适配器" },
  "btn.autoreturn": { en: "AUTO-RETURN", zh: "自动回车" },
  "btn.sample": { en: "SAMPLE", zh: "示例文稿" },
  "btn.lang": { en: "中文", zh: "EN" },
  "plaque.assemble": { en: "ASSEMBLE THE MACHINE TO WRITE.", zh: "请先将机器聚合复原，再行书写。" },
  "plaque.margin": { en: "RETURN CARRIAGE ↵", zh: "请回车换行 ↵" },
  "plaque.pageFull": { en: "PAGE FULL — NEW SHEET (⌘/CTRL + ENTER)", zh: "本页已满 — 请换新纸（⌘/CTRL + ENTER）" },
  "plaque.clash": { en: "TYPEBAR CLASH — TIMING STAGGERED", zh: "字杆相碰 — 已自动错峰" },
  "plaque.pageFullDone": { en: "PAGE FULL — INSERT NEW SHEET", zh: "本页已满 — 请插入新纸" },
  "plaque.draftSaved": { en: "DRAFT SAVED ON THIS DEVICE", zh: "草稿已保存在本设备上" },
  "plaque.draftFailed": { en: "DRAFT SAVE FAILED — STORAGE UNAVAILABLE", zh: "草稿保存失败 — 存储不可用" },
  "plaque.draftRestored": { en: "LOCAL DRAFT RESTORED", zh: "已恢复本地草稿" },
  "plaque.cleared": { en: "MANUSCRIPT CLEARED", zh: "文稿已清空" },
  "plaque.sample": { en: "SAMPLE MANUSCRIPT LOADED", zh: "示例文稿已载入" },
  "plaque.unicodeDroppedPage": {
    en: "PAGE FULL — {count} COMMITTED CHARACTERS COULD NOT BE ACCEPTED. NEW SHEET (⌘/CTRL + ENTER) TO CONTINUE.",
    zh: "本页已满 — {count} 个已提交字符未能上纸。请换新纸（⌘/CTRL + ENTER）后继续。",
  },
  "plaque.unicodeDroppedMargin": {
    en: "RIGHT MARGIN — {count} COMMITTED CHARACTERS COULD NOT BE ACCEPTED. RETURN CARRIAGE ↵ TO CONTINUE.",
    zh: "已到右边距 — {count} 个已提交字符未能上纸。请回车换行 ↵ 后继续。",
  },
  "btn.queued": { en: "QUEUED", zh: "已排队" },
  "a11y.machineBusy": { en: "Machine busy — mechanics in motion.", zh: "机械忙碌中 — 机构正在运转。" },
  "a11y.undoQueued": {
    en: "Undo queued — it will apply as soon as the machine is idle.",
    zh: "撤销已排队 — 机械运转结束后立即执行。",
  },
  "a11y.redoQueued": {
    en: "Redo queued — it will apply as soon as the machine is idle.",
    zh: "重做已排队 — 机械运转结束后立即执行。",
  },
  "a11y.historyApplied": { en: "History operation applied.", zh: "历史操作已执行。" },
  "hint.noUndo": { en: "Nothing to undo", zh: "没有可撤销的操作" },
  "hint.noRedo": { en: "Nothing to redo", zh: "没有可重做的操作" },
  "hint.machineBusy": {
    en: "Machine busy — click to queue; it applies when the mechanics settle.",
    zh: "机械忙碌中 — 点击将排队，机构停稳后执行。",
  },
  "plaque.unicode": {
    en: "UNICODE ADAPTER IS A CONTEMPORARY DIGITAL EXTENSION, NOT AN ORIGINAL MECHANICAL CAPABILITY.",
    zh: "UNICODE 适配器是当代数字扩展，并非原机的机械能力。",
  },
  "plaque.autoreturn": {
    en: "MODERN AUTO-RETURN ENGAGED — THE ORIGINAL MACHINE NEVER WRAPS.",
    zh: "现代自动回车已启用 — 原机从不自动换行。",
  },
  "stats.words": { en: "words", zh: "词" },
  "stats.word": { en: "word", zh: "词" },
  "stats.pages": { en: "pages", zh: "页" },
  "stats.page": { en: "page", zh: "页" },
  "stats.chars": { en: "characters", zh: "字符" },
  "stats.zi": { en: "characters", zh: "字" },
  "export.embeddedWest": { en: "Western font embedded · Chinese uses system fonts", zh: "西文字体已嵌入 · 中文使用系统字体" },
  "meta.title": { en: "THE IMPACT No. 01 — A mechanical document editor", zh: "THE IMPACT No. 01 — 一台机械文稿编辑器" },
  "meta.description": {
    en: "A mechanical document editor: every letter arrives the slow way — a finger falls, a lever turns, a typebar strikes. Your writing never leaves this device.",
    zh: "一台机械文稿编辑器：每个字母都走一条慢路 —— 手指落下，杠杆转动，字杆击打。你的文字永远不会离开这台设备。",
  },
  "webgl.failed": { en: "This browser cannot start the mechanical document editor.", zh: "当前浏览器无法启动机械文稿编辑器。" },
  "webgl.advice": {
    en: "Please enable hardware acceleration or use a modern browser with WebGL support.",
    zh: "建议启用硬件加速或使用支持 WebGL 的现代浏览器。",
  },
  "aria.machineControls": { en: "Machine controls", zh: "机械控制" },
  "aria.hidePanel": { en: "Hide control panel", zh: "收起控制面板" },
  "aria.showPanel": { en: "Show control panel", zh: "展开控制面板" },
  "aria.explode": { en: "Explode the machine", zh: "拆解机器" },
  "aria.assemble": { en: "Assemble the machine", zh: "聚合机器" },
  "aria.cutaway": { en: "Cutaway view", zh: "剖视图" },
  "aria.cameraMode": { en: "Camera mode", zh: "相机视角" },
  "aria.toggleSound": { en: "Toggle sound", zh: "切换声音" },
  "aria.newSheet": { en: "Insert a new sheet", zh: "换新纸" },
  "aria.undo": { en: "Undo", zh: "撤销" },
  "aria.redo": { en: "Redo", zh: "重做" },
  "aria.export": { en: "Export as Word document", zh: "导出为 Word 文档" },
  "aria.clear": { en: "Clear the entire manuscript", zh: "清空全部文稿" },
  "aria.unicode": { en: "Toggle modern Unicode input adapter", zh: "切换现代 UNICODE 输入适配器" },
  "aria.autoreturn": { en: "Toggle modern auto-return", zh: "切换现代自动回车" },
  "aria.sample": { en: "Load the sample manuscript", zh: "载入示例文稿" },
  "aria.imeField": { en: "Input method adapter field", zh: "输入法适配输入框" },
  "aria.partInfo": { en: "Part information", zh: "零件信息" },
  "aria.closePart": { en: "Close part information", zh: "关闭零件信息" },
  "aria.follow": { en: "Follow the keystroke in slow motion", zh: "慢速追踪这次击键" },
  "aria.exportSettings": { en: "Export settings", zh: "导出设置" },
  "aria.closeExport": { en: "Close export settings", zh: "关闭导出设置" },
  "aria.explodeLevel": { en: "Explode level", zh: "拆解程度" },
  "aria.confirmClear": { en: "Confirm clearing the manuscript", zh: "确认清空文稿" },
  "aria.restoreDraft": { en: "Restore local draft", zh: "恢复本地草稿" },
  "aria.manuscriptText": { en: "Manuscript text", zh: "文稿内容" },
  "part.follow": { en: "FOLLOW THE KEYSTROKE", zh: "慢速追踪这次击键" },
  "part.from": { en: "FROM", zh: "动力来自" },
  "part.drives": { en: "DRIVES", zh: "驱动" },
  "part.info": { en: "Part information", zh: "零件信息" },
  "confirm.draft": { en: "A LOCAL DRAFT EXISTS ON THIS DEVICE.", zh: "本设备上存在一份本地草稿。" },
  "confirm.resume": { en: "RESUME", zh: "恢复" },
  "confirm.discard": { en: "DISCARD", zh: "丢弃" },
  "confirm.clear": { en: "CLEAR THE ENTIRE MANUSCRIPT? THIS CANNOT BE UNDONE.", zh: "确定清空全部文稿？此操作不可撤销。" },
  "confirm.confirm": { en: "CONFIRM", zh: "确认" },
  "confirm.cancel": { en: "CANCEL", zh: "取消" },
  "export.title": { en: "EXPORT · DOCX", zh: "导出 · DOCX" },
  "export.docTitle": { en: "DOCUMENT TITLE", zh: "文档标题" },
  "export.author": { en: "AUTHOR (LEFT EMPTY FOR PRIVACY)", zh: "作者（默认为空，保护隐私）" },
  "export.overstrike": { en: "OVERSTRIKES", zh: "叠印处理" },
  "export.keepFinal": { en: "Keep final character", zh: "保留最终字符" },
  "export.annotated": { en: "Preserve as annotated text", zh: "保留为标注文本" },
  "export.fontChecking": { en: "CHECKING FONT…", zh: "正在检查字体…" },
  "export.fontOk": {
    en: "FONT: COURIER PRIME (SIL OFL) — EMBEDDED FOR WESTERN RUNS; CJK USES SYSTEM FONTS",
    zh: "字体：COURIER PRIME（SIL OFL）— 嵌入西文；中文使用系统字体",
  },
  "export.fontMissing": { en: "FONT FILE UNAVAILABLE — COURIER PRIME NAMED, SYSTEM FALLBACK", zh: "字体文件不可用 — 将指定 Courier Prime 并回退系统字体" },
  "export.go": { en: "EXPORT", zh: "导出" },
  "export.generating": { en: "GENERATING…", zh: "正在生成…" },
  "export.failed": { en: "EXPORT FAILED — YOUR MANUSCRIPT IS INTACT.", zh: "导出失败 — 文稿完好无损。" },
  "export.embedded": { en: "font embedded", zh: "字体已嵌入" },
  "export.referenced": { en: "font referenced", zh: "字体为引用方式" },
  "export.privacy": { en: "Your writing never leaves this device.", zh: "你的文字永远不会离开这台设备。" },
  "export.untitled": { en: "Untitled manuscript", zh: "未命名文稿" },
  "export.settings": { en: "Export settings", zh: "导出设置" },
};

export function t(lang: Lang, key: string): string {
  return STRINGS[key][lang];
}

/** Static part names, English → Chinese. */
export const PART_NAMES_ZH: Record<string, string> = {
  "Key lever pivot rod": "按键杠杆枢轴杆",
  "Typebar segment": "字杆导槽弧座",
  "Typebar rest": "字杆枕轨",
  "Universal bar": "共用横杆",
  "Escapement wheel": "逃逸轮",
  "Escapement pawls": "逃逸棘爪组",
  "Backspace pawl": "退格棘爪",
  Carriage: "滑架",
  Platen: "压纸滚筒",
  "Left platen knob": "左压纸旋钮",
  "Right platen knob": "右压纸旋钮",
  "Line-spacing ratchet": "行距棘轮",
  "Carriage return lever": "回车杆",
  "Paper bail": "压纸架",
  "Feed roller": "送纸辊",
  "Left margin stop": "左页边距挡块",
  "Right margin stop": "右页边距挡块",
  "Margin bell": "页边铃",
  "Paper table": "导纸板",
  "Paper sheet": "纸张",
  "Left ribbon spool": "左色带卷轴",
  "Right ribbon spool": "右色带卷轴",
  "Ribbon vibrator": "色带升降器",
  "Ink ribbon": "油墨色带",
  "Ribbon advance gear": "色带走带齿轮",
  "Ribbon reverse pawl": "色带换向棘爪",
  "Main chassis": "主机架",
  "Left side panel": "左侧外壳板",
  "Right side panel": "右侧外壳板",
  "Rear panel": "后盖板",
  "Front apron": "前围板",
  "Left deck plate": "左顶盖板",
  "Right deck plate": "右顶盖板",
  "Rear deck": "后顶盖板",
  "Rubber foot": "橡胶脚垫",
  "Left shift rod": "左换挡连杆",
  "Right shift rod": "右换挡连杆",
  "Assembly screws": "装配螺丝",
  "Mainspring drum": "主发条鼓",
  "Unicode adapter typebar": "Unicode 适配字杆",
};

/** Dynamic part-name patterns ("Q keycap" → "Q 键帽", …). */
const PART_NAME_PATTERNS: Array<[RegExp, string]> = [
  [/^(.+) keycap$/, "$1 键帽"],
  [/^(.+) key lever$/, "$1 按键杠杆"],
  [/^(.+) link rod$/, "$1 连杆"],
  [/^(.+) typebar$/, "$1 字杆"],
];

export function partName(lang: Lang, name: string): string {
  if (lang === "en") return name;
  const direct = PART_NAMES_ZH[name];
  if (direct) return direct;
  for (const [pattern, replacement] of PART_NAME_PATTERNS) {
    if (pattern.test(name)) return name.replace(pattern, replacement);
  }
  return name;
}

/** Part function descriptions, English → Chinese. */
export const PART_FUNCTIONS_ZH: Record<string, string> = {
  "Finger key: starts the strike chain": "手指键：整条击打链的起点",
  "Spacebar: escapement only, no typebar": "空格杆：只释放逃逸机构，不触发字杆",
  "Backspace key: drives the pawl back": "退格键：驱动棘爪使滑架后退",
  "Shift key: lifts the whole type basket": "换挡键：抬起整个字篮",
  "Tab key: releases carriage to next stop": "制表键：释放滑架到下一制表位",
  "Key lever: turns finger force around the pivot rod": "按键杠杆：把手指的力绕枢轴传递",
  "Link rod: pulls the typebar tail upward": "连杆：向上牵引字杆尾部",
  "Typebar: hurls its slug to the print point": "字杆：把字模甩向击打点",
  "Contemporary adapter — not original machinery": "当代适配器 — 并非原机结构",
  "Common axle every key lever swings on": "所有按键杠杆共用的轴",
  "Slotted arc guiding every typebar pivot": "引导每根字杆枢轴的弧槽",
  "Felt rail where idle typebars sleep": "闲置字杆停靠的呢绒轨",
  "Every key trips it to free the escapement": "每个键都通过它释放逃逸机构",
  "Releases exactly one tooth per character": "每个字符精确释放一齿",
  "Loose and rigid dog rocking on each keystroke": "每次击键摆动的活爪与定爪",
  "Backspacer: pushes the rack one tooth back": "退格器：把齿条推回一齿",
  "Carries platen and paper one tooth per character": "携带滚筒与纸，每字符移一齿",
  "Rubber cylinder taking every single impact": "承受每一次撞击的橡胶滚筒",
  "Hand wheel for feeding paper by hand": "手动卷纸的手轮",
  "Turns the platen exactly one line per return": "每次回车精确卷动一行",
  "Throws the carriage home and feeds a line": "把滑架送回原位并进给一行",
  "Holds the sheet flat against the platen": "把纸压平在滚筒上",
  "Pinch roller feeding the sheet through": "夹送纸页的压辊",
  "Sets where the carriage returns to": "决定滑架回位停留的位置",
  "Blocks the carriage at line end": "在行尾阻挡滑架",
  "Rings six characters before the right margin": "右边距前六个字符时鸣响",
  "Guides the sheet behind the platen": "引导纸页绕过滚筒后方",
  "A4 sheet — where impacts become a document": "A4 纸 — 撞击在此成为文稿",
  "Takes up the spent ribbon": "卷收用过的色带",
  "Feeds fresh ribbon per character": "逐字供应新色带",
  "Lifts the ribbon into the strike path": "把色带抬入击打路径",
  "Woven inked fabric between slug and sheet": "字模与纸之间的浸墨织物",
  "Steps the ribbon on every escapement release": "每次逃逸释放时步进色带",
  "Flips the feed direction at spool end": "在卷轴尽头翻转走带方向",
  "Cast iron spine of the whole machine": "整机的铸铁脊梁",
  "Enamel shell — opens in cutaway view": "搪瓷外壳 — 剖视时打开",
  "Enamel back plate of the mechanism bay": "机构舱的搪瓷背板",
  "Enamel brow above the keyboard": "键盘上方的搪瓷眉板",
  "Top deck carrying the ribbon spools": "承载色带卷轴的顶板",
  "Cover over the escapement bay": "逃逸机构舱的盖板",
  "Isolates the machine from the desk": "隔绝机器与桌面的震动",
  "Shift linkage: raises the basket for capitals": "换挡连杆：为大写抬起字篮",
  "Machine screws — exit along their own axes": "机螺丝 — 沿自身轴线退出",
  "Spring motor pulling the carriage leftward": "拉动滑架左行的发条动力",
};

export function partFunction(lang: Lang, fn: string): string {
  return lang === "en" ? fn : PART_FUNCTIONS_ZH[fn] ?? fn;
}

export type PartSystem =
  | "frame"
  | "keyboard"
  | "levers"
  | "links"
  | "basket"
  | "typebars"
  | "escapement"
  | "carriage"
  | "ribbon"
  | "shift"
  | "hardware"
  | "paper";

const SYSTEM_ZH: Record<string, string> = {
  frame: "机架",
  keyboard: "键盘",
  levers: "杠杆",
  links: "连杆",
  basket: "字篮",
  typebars: "字杆",
  escapement: "逃逸机构",
  carriage: "滑架",
  ribbon: "色带",
  shift: "换挡",
  hardware: "五金",
  paper: "纸张",
};

export function systemName(lang: Lang, system: string): string {
  return lang === "en" ? system.toUpperCase() : SYSTEM_ZH[system] ?? system.toUpperCase();
}
