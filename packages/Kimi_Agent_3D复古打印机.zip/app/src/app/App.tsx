import { useEffect, useMemo, useRef, useState } from "react";
import { getCore, wireAudio } from "./core";
import { useStore } from "./store";
import { t } from "./i18n";
import { InputManager } from "../document/draftStorage";
import { TypewriterScene } from "../scene/TypewriterScene";
import { Overlay } from "../ui/Overlay";

function supportsWebGL(): boolean {
  try {
    const canvas = document.createElement("canvas");
    return !!(canvas.getContext("webgl2") ?? canvas.getContext("webgl"));
  } catch {
    return false;
  }
}

/** Dark fallback shown when WebGL is unavailable, in the current language. */
function WebGLFallback() {
  const lang = useStore((s) => s.lang);
  return (
    <div className="webgl-fallback">
      <h1>THE IMPACT No. 01</h1>
      <p className="plaque warn">{t(lang, "webgl.failed")}</p>
      <p>{t(lang, "webgl.advice")}</p>
    </div>
  );
}

/** Keeps <html lang>, document title and meta description in sync. */
function useLanguageMetadata() {
  const lang = useStore((s) => s.lang);
  useEffect(() => {
    document.documentElement.lang = lang === "zh" ? "zh-CN" : "en";
    document.title = t(lang, "meta.title");
    const description = document.querySelector('meta[name="description"]');
    if (description) description.setAttribute("content", t(lang, "meta.description"));
    const og = document.querySelector('meta[property="og:description"]');
    if (og) og.setAttribute("content", t(lang, "meta.description"));
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) ogTitle.setAttribute("content", t(lang, "meta.title"));
  }, [lang]);
}

export default function App() {
  const core = useMemo(() => getCore(), []);
  const [webgl] = useState(supportsWebGL);
  const imeRef = useRef<HTMLTextAreaElement>(null);
  const [manager, setManager] = useState<InputManager | null>(null);
  const lang = useStore((s) => s.lang);
  useLanguageMetadata();

  useEffect(() => {
    wireAudio(core);
    const input = new InputManager(core);
    if (imeRef.current) input.attach(imeRef.current);
    setManager(input);
    if (useStore.getState().unicodeAdapter) input.focusIme();

    const updateStats = () => {
      const m = core.manuscript;
      useStore.getState().setStats({
        chars: m.charCount,
        words: m.wordCount,
        pages: m.pages.length,
        line: m.cursor.line,
        col: m.cursor.col,
        pageFull: m.pageFull,
      });
    };
    const offChanged = core.manuscript.bus.on("changed", updateStats);
    const offStructure = core.manuscript.bus.on("structure", updateStats);
    updateStats();

    const offRejected = core.machine.bus.on("rejected", ({ reason }: { reason: string }) => {
      const state = useStore.getState();
      if (reason === "exploded") state.showPlaqueKey("plaque.assemble");
      else if (reason === "pageFull") state.showPlaqueKey("plaque.pageFullDone");
    });
    const offBell = core.manuscript.bus.on("bell", () => {
      useStore.setState((s) => ({ bellTick: s.bellTick + 1 }));
    });
    const offClash = core.machine.bus.on("clash", () => {
      useStore.setState((s) => ({ jamTick: s.jamTick + 1 }));
      useStore.getState().showPlaqueKey("plaque.clash");
    });
    const offReturnDone = core.machine.bus.on("carriageReturnDone", ({ pageFull }: { pageFull: boolean }) => {
      if (pageFull) useStore.getState().showPlaqueKey("plaque.pageFullDone", 6000);
    });
    // Adapter text that could not be accepted (page full / right margin)
    // is reported with an exact count — never dropped silently.
    const offUnicodeRejected = core.machine.bus.on("unicodeRejected", ({ reason, count }: { reason: string; count: number }) => {
      const state = useStore.getState();
      const key = reason === "pageFull" ? "plaque.unicodeDroppedPage" : "plaque.unicodeDroppedMargin";
      state.showPlaque(t(state.lang, key).replace("{count}", String(count)), 6000);
    });

    if (InputManager.loadDraft()) useStore.getState().setDraftExists(true);

    const offStore = useStore.subscribe((state, prev) => {
      if (state.unicodeAdapter && !prev.unicodeAdapter) input.focusIme();
      // Any overlay closing (export drawer, clear confirm, draft restore,
      // part info, slow-motion trace) hands focus back to the IME field on
      // the next frame — form controls keep their focus.
      const overlayClosed =
        (prev.exportOpen && !state.exportOpen) ||
        (prev.clearConfirm && !state.clearConfirm) ||
        (prev.selectedPart && !state.selectedPart) ||
        (prev.trace && !state.trace);
      if (overlayClosed) input.scheduleImeFocusRestore();
    });

    return () => {
      input.detach();
      offChanged();
      offStructure();
      offRejected();
      offBell();
      offClash();
      offReturnDone();
      offUnicodeRejected();
      offStore();
    };
  }, [core]);

  if (!webgl) return <WebGLFallback />;

  return (
    <div className="app">
      <TypewriterScene />
      <Overlay manager={manager} />
      <textarea
        ref={imeRef}
        className="ime-input"
        aria-label={t(lang, "aria.imeField")}
        autoComplete="off"
        autoCorrect="off"
        autoCapitalize="off"
        spellCheck={false}
      />
    </div>
  );
}
