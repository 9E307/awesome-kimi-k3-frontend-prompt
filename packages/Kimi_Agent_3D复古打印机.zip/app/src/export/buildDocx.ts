import { Document, LineRuleType, Packer, PageBreak, Paragraph, TextRun } from "docx";
import JSZip from "jszip";
import { DOCX_LINE_SPACING_PT, FONT_FALLBACKS, FONT_FAMILY } from "../document/constants";
import type { Manuscript } from "../document/Manuscript";

/**
 * In-browser DOCX generation. Every mechanical page maps to a Word page,
 * lines keep their exact 15.8pt spacing, and Courier Prime is embedded
 * (SIL OFL, installable fsType) using the OOXML obfuscated-font scheme.
 */

export type OverstrikeMode = "final" | "annotated";

export interface ExportOptions {
  title: string;
  author: string;
  overstrikeMode: OverstrikeMode;
  embedFont: boolean;
  fontData?: ArrayBuffer;
}

export interface ExportOutcome {
  bytes: Uint8Array;
  fileName: string;
  size: number;
  fontEmbedded: boolean;
  fontNote: string;
  pageCount: number;
  wordCount: number;
  charCount: number;
}

const PAGE_WIDTH = 11906; // A4, twips
const PAGE_HEIGHT = 16838;
const MARGIN_TWIPS = 1440;
const LINE_EXACT = Math.round(DOCX_LINE_SPACING_PT * 20);

/**
 * Courier Prime covers no CJK glyphs, so it is declared only for
 * ascii/hAnsi/cs. East Asian runs use the reader's system font —
 * Microsoft YaHei ships with Windows and Microsoft Office on every
 * platform; Word/WPS substitute PingFang SC / SimSun where needed.
 */
export const EAST_ASIA_FONT = "Microsoft YaHei";

interface RunChunk {
  text: string;
  strike: boolean;
}

/** One manuscript line → spaced text runs; overstrikes optionally kept as struck annotation. */
function lineRuns(manuscript: Manuscript, page: number, line: number, mode: OverstrikeMode): TextRun[] {
  const row = manuscript.pages[page]?.[line] ?? [];
  const chunks: RunChunk[] = [];
  let pending = "";
  let col = 0;
  const flush = () => {
    if (pending) {
      chunks.push({ text: pending, strike: false });
      pending = "";
    }
  };
  for (const glyph of row) {
    if (glyph.col > col) pending += " ".repeat(glyph.col - col);
    if (mode === "annotated" && glyph.history.length > 0) {
      flush();
      chunks.push({ text: glyph.history.join(""), strike: true });
    }
    pending += glyph.char;
    col = glyph.col + 1;
  }
  flush();
  if (chunks.length === 0) chunks.push({ text: "", strike: false });
  return chunks.map((chunk) => new TextRun({ text: chunk.text, strike: chunk.strike }));
}

function buildDocument(manuscript: Manuscript, options: ExportOptions): Document {
  const children: Paragraph[] = [];
  for (let page = 0; page < manuscript.pages.length; page++) {
    const rows = manuscript.pages[page];
    for (let line = 0; line < rows.length; line++) {
      children.push(
        new Paragraph({
          spacing: { before: 0, after: 0, line: LINE_EXACT, lineRule: LineRuleType.EXACT },
          children: lineRuns(manuscript, page, line, options.overstrikeMode),
        }),
      );
    }
    if (page < manuscript.pages.length - 1) children.push(new Paragraph({ children: [new PageBreak()] }));
  }
  return new Document({
    creator: options.author || undefined,
    title: options.title || undefined,
    description: "Written on THE IMPACT No. 01 — a mechanical document editor.",
    styles: {
      default: {
        document: {
          run: {
            font: { ascii: FONT_FAMILY, hAnsi: FONT_FAMILY, cs: FONT_FAMILY, eastAsia: EAST_ASIA_FONT },
            size: 24,
          },
          paragraph: { spacing: { before: 0, after: 0 } },
        },
      },
    },
    sections: [
      {
        properties: {
          page: {
            size: { width: PAGE_WIDTH, height: PAGE_HEIGHT },
            margin: { top: MARGIN_TWIPS, right: MARGIN_TWIPS, bottom: MARGIN_TWIPS, left: MARGIN_TWIPS },
          },
        },
        children,
      },
    ],
  });
}

// ---------------------------------------------------------------- font embed

const ODRTF_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.obfuscatedFont";
const FONT_TABLE_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.wordprocessingml.fontTable+xml";
const FONT_TABLE_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/fontTable";
const FONT_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/font";

type FsType = "installable" | "editable" | "preview-print" | "restricted" | "unknown";

/** Reads fsType from the font's OS/2 table — embedding rights check. */
function readFsType(font: ArrayBuffer): FsType {
  try {
    const view = new DataView(font);
    const tables = view.getUint16(4);
    for (let i = 0; i < tables; i++) {
      const record = 12 + i * 16;
      const tag = String.fromCharCode(view.getUint8(record), view.getUint8(record + 1), view.getUint8(record + 2), view.getUint8(record + 3));
      if (tag === "OS/2") {
        const offset = view.getUint32(record + 8);
        const fsType = view.getUint16(offset + 8) & 15;
        if (fsType === 2) return "restricted";
        if (fsType === 4) return "preview-print";
        if (fsType === 8) return "editable";
        return "installable";
      }
    }
    return "unknown";
  } catch {
    return "unknown";
  }
}

function guidBytes(): Uint8Array {
  const bytes = new Uint8Array(16);
  if (typeof crypto !== "undefined" && crypto.getRandomValues) crypto.getRandomValues(bytes);
  else for (let i = 0; i < 16; i++) bytes[i] = Math.floor(Math.random() * 256);
  return bytes;
}

function guidString(bytes: Uint8Array): string {
  const hex = [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("");
  return `{${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20, 32)}}`.toUpperCase();
}

/** OOXML font obfuscation: first 32 bytes XORed with the reversed GUID. */
function obfuscateFont(font: ArrayBuffer, key: Uint8Array): Uint8Array {
  const bytes = new Uint8Array(font.slice(0));
  for (let i = 0; i < 32 && i < bytes.length; i++) bytes[i] ^= key[15 - (i % 16)];
  return bytes;
}

function fontEntryXml(fontKey: string): string {
  return `<w:font w:name="${FONT_FAMILY}"><w:panose1 w:val="02060509020000020004"/><w:charset w:val="00"/><w:family w:val="modern"/><w:pitch w:val="fixed"/><w:sig w:usb0="00000003" w:usb1="00000000" w:usb2="00000000" w:usb3="00000000" w:csb0="00000001" w:csb1="00000000"/><w:embedRegular r:id="rIdCourierPrimeRegular" w:fontKey="${fontKey}" w:subsetted="false"/></w:font>`;
}

function fontTableXml(fontKey: string): string {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<w:fonts xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">${fontEntryXml(fontKey)}</w:fonts>`;
}

const FONT_REL_XML = `<Relationship Id="rIdCourierPrimeRegular" Type="${FONT_REL}" Target="fonts/CourierPrime-Regular.odttf"/>`;

function appendRelationship(xml: string, relationship: string): string {
  if (xml.includes("</Relationships>")) return xml.replace("</Relationships>", `${relationship}</Relationships>`);
  return xml.replace(/<Relationships([^>]*)\/>/u, `<Relationships$1>${relationship}</Relationships>`);
}

function appendFontEntry(xml: string, entry: string): string {
  if (xml.includes("</w:fonts>")) return xml.replace("</w:fonts>", `${entry}</w:fonts>`);
  return xml.replace(/<w:fonts([^>]*)\/>/u, `<w:fonts$1>${entry}</w:fonts>`);
}

/** Embeds Courier Prime into a finished DOCX package. Returns null when not permitted. */
async function embedFont(docxBytes: Uint8Array, fontData: ArrayBuffer): Promise<Uint8Array | null> {
  const fsType = readFsType(fontData);
  if (fsType === "restricted" || fsType === "unknown") return null;

  const zip = await JSZip.loadAsync(docxBytes);
  const key = guidBytes();
  const fontKey = guidString(key);
  const obfuscated = obfuscateFont(fontData, key);
  zip.file("word/fonts/CourierPrime-Regular.odttf", obfuscated);

  const fontTable = zip.file("word/fontTable.xml");
  if (fontTable) {
    const xml = await fontTable.async("string");
    zip.file("word/fontTable.xml", appendFontEntry(xml, fontEntryXml(fontKey)));
  } else {
    zip.file("word/fontTable.xml", fontTableXml(fontKey));
  }

  const fontTableRels = zip.file("word/_rels/fontTable.xml.rels");
  if (fontTableRels) {
    const xml = await fontTableRels.async("string");
    if (!xml.includes("CourierPrime-Regular.odttf")) {
      zip.file("word/_rels/fontTable.xml.rels", appendRelationship(xml, FONT_REL_XML));
    }
  } else {
    zip.file(
      "word/_rels/fontTable.xml.rels",
      `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${FONT_REL_XML}</Relationships>`,
    );
  }

  const contentTypes = zip.file("[Content_Types].xml");
  if (!contentTypes) return null;
  let ctXml = await contentTypes.async("string");
  if (!ctXml.includes('Extension="odttf"')) {
    ctXml = ctXml.replace("</Types>", `<Default Extension="odttf" ContentType="${ODRTF_CONTENT_TYPE}"/></Types>`);
  }
  if (!ctXml.includes("fontTable.xml")) {
    ctXml = ctXml.replace("</Types>", `<Override PartName="/word/fontTable.xml" ContentType="${FONT_TABLE_CONTENT_TYPE}"/></Types>`);
  }
  zip.file("[Content_Types].xml", ctXml);

  const documentRels = zip.file("word/_rels/document.xml.rels");
  if (!documentRels) return null;
  let relsXml = await documentRels.async("string");
  if (!relsXml.includes("fontTable")) {
    relsXml = appendRelationship(relsXml, `<Relationship Id="rIdFontTable" Type="${FONT_TABLE_REL}" Target="fontTable.xml"/>`);
    zip.file("word/_rels/document.xml.rels", relsXml);
  }

  const settings = zip.file("word/settings.xml");
  if (settings) {
    let settingsXml = await settings.async("string");
    if (!settingsXml.includes("embedTrueTypeFonts")) {
      settingsXml = settingsXml.replace(/(<w:settings[^>]*>)/u, "$1<w:embedTrueTypeFonts/>");
      zip.file("word/settings.xml", settingsXml);
    }
  }

  return zip.generateAsync({ type: "uint8array", mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" });
}

function exportFileName(date = new Date()): string {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `Impact_Manuscript_${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}_${pad(date.getHours())}-${pad(date.getMinutes())}.docx`;
}

/** Builds the DOCX entirely in-browser and reports what happened. */
export async function buildDocx(manuscript: Manuscript, options: ExportOptions): Promise<ExportOutcome> {
  const document = buildDocument(manuscript, options);
  let bytes: Uint8Array;
  if (typeof window === "undefined") {
    bytes = new Uint8Array(await Packer.toBuffer(document));
  } else {
    const blob = await Packer.toBlob(document);
    bytes = new Uint8Array(await blob.arrayBuffer());
  }

  let fontEmbedded = false;
  let fontNote: string;
  if (options.embedFont && options.fontData) {
    const embedded = await embedFont(bytes, options.fontData);
    if (embedded) {
      bytes = embedded;
      fontEmbedded = true;
      fontNote = `Courier Prime embedded (SIL OFL, installable fsType); East Asian runs declared as ${EAST_ASIA_FONT} and rendered by the reader's system fonts.`;
    } else {
      fontNote = `Font embedding unavailable — Courier Prime named for Western runs, ${EAST_ASIA_FONT} for East Asian runs; both fall back to recipient system fonts.`;
    }
  } else {
    fontNote = `Courier Prime named for Western runs (falls back to ${FONT_FALLBACKS.join(", ")}); East Asian runs declared as ${EAST_ASIA_FONT}.`;
  }

  return {
    bytes,
    fileName: exportFileName(),
    size: bytes.byteLength,
    fontEmbedded,
    fontNote,
    pageCount: manuscript.pages.length,
    wordCount: manuscript.wordCount,
    charCount: manuscript.charCount,
  };
}
