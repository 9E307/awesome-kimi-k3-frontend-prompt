import { DRAFT_STORAGE_KEY } from "./constants";
import { EventBus } from "./EventBus";
import { KEY_BY_CODE } from "../machine/keyboardLayout";
import { useStore } from "../app/store";
import type { Core } from "../app/core";
import type { Cursor, Glyph } from "./Manuscript";

interface DraftData {
  pages: Glyph[][][];
  cursor: Cursor;
  pageFull: boolean;
  version?: number;
}

/**
 * Keyboard & IME input manager plus the local draft store. Physical keys
 * drive the machine directly; when the Unicode adapter is enabled, an
 * invisible textarea captures IME compositions and commits them through
 * the adapter typebar. Drafts autosave (debounced) and via Ctrl/Cmd+S.
 */
export class InputManager {
  readonly imeBus = new EventBus();
  private readonly core: Core;
  private ime: HTMLTextAreaElement | null = null;
  private attached = false;
  private composing = false;
  private focusRestoreScheduled = false;
  private readonly detachFns: Array<() => void> = [];
  private autosaveTimer = 0;

  constructor(core: Core) {
    this.core = core;
    this.imeBus.on("commit", ({ text }: { text: string }) => {
      if (useStore.getState().unicodeAdapter) this.core.machine.pressUnicode(text);
    });
  }

  attach(textarea: HTMLTextAreaElement): void {
    this.ime = textarea;
    if (this.attached) return; // StrictMode re-mount: wire once, detach once
    this.attached = true;
    const listen = <K extends keyof WindowEventMap>(type: K, handler: (event: WindowEventMap[K]) => void, options?: AddEventListenerOptions) => {
      window.addEventListener(type, handler, options);
      this.detachFns.push(() => window.removeEventListener(type, handler, options));
    };
    listen("keydown", (event) => this.onKeyDown(event));
    listen("keyup", (event) => this.core.machine.release(event.code));
    listen("blur", () => this.core.machine.releaseAll());
    listen("pointerdown", () => this.core.sound.unlock(), { capture: true });
    // Focus moves on click (after the browser's own focus settling), so the
    // IME field reliably ends up focused without fighting default behavior.
    listen("click", (event) => this.maybeRestoreImeFocus(event.target as HTMLElement | null));

    const onVisibility = () => {
      this.core.machine.paused = document.hidden;
      if (document.hidden) this.core.machine.releaseAll();
    };
    document.addEventListener("visibilitychange", onVisibility);
    this.detachFns.push(() => document.removeEventListener("visibilitychange", onVisibility));

    listen("beforeunload", (event) => {
      if (!this.core.manuscript.isEmpty) {
        event.preventDefault();
        event.returnValue = "";
      }
    });

    const onCompStart = () => {
      this.composing = true;
    };
    const onCompUpdate = (event: Event) => {
      this.imeBus.emit("preview", { text: (event as CompositionEvent).data ?? "" });
    };
    const onCompEnd = (event: Event) => {
      this.composing = false;
      // Lossless capture: real IMEs may deliver the final segment with an
      // EMPTY compositionend.data while the text only exists in the field
      // value (observed with segmented auto-commits). Take whichever side
      // actually carries text — never clear the field before reading both.
      const data = (event as CompositionEvent).data;
      const text = data || textarea.value;
      textarea.value = "";
      this.imeBus.emit("preview", { text: "" });
      if (text) this.imeBus.emit("commit", { text });
    };
    const onInput = () => {
      // While composing, input events are composition updates — the commit
      // arrives via compositionend (or the blur flush below), never here.
      if (this.composing) return;
      // After our compositionend handler ran, the trailing browser
      // insertCompositionText event finds an empty field — no double commit.
      if (!textarea.value) return;
      const text = textarea.value;
      textarea.value = "";
      this.imeBus.emit("commit", { text });
    };
    // Safety flush: if a composition is interrupted (focus theft, IME
    // crash, cancelled session) its text would otherwise strand inside the
    // hidden field forever. On blur we commit whatever is still there.
    const onBlurFlush = () => {
      this.composing = false;
      this.imeBus.emit("preview", { text: "" });
      if (textarea.value) {
        const text = textarea.value;
        textarea.value = "";
        this.imeBus.emit("commit", { text });
      }
    };
    textarea.addEventListener("compositionstart", onCompStart);
    textarea.addEventListener("compositionupdate", onCompUpdate);
    textarea.addEventListener("compositionend", onCompEnd);
    textarea.addEventListener("input", onInput);
    textarea.addEventListener("blur", onBlurFlush);
    this.detachFns.push(() => {
      textarea.removeEventListener("compositionstart", onCompStart);
      textarea.removeEventListener("compositionupdate", onCompUpdate);
      textarea.removeEventListener("compositionend", onCompEnd);
      textarea.removeEventListener("input", onInput);
      textarea.removeEventListener("blur", onBlurFlush);
    });

    // Debounced local autosave — silent, never leaves the device.
    const scheduleAutosave = () => {
      window.clearTimeout(this.autosaveTimer);
      this.autosaveTimer = window.setTimeout(() => this.autosave(), 900);
    };
    const offChanged = this.core.manuscript.bus.on("changed", scheduleAutosave);
    const offStructure = this.core.manuscript.bus.on("structure", scheduleAutosave);
    this.detachFns.push(offChanged, offStructure);
  }

  focusIme(): void {
    this.ime?.focus({ preventScroll: true });
  }

  /**
   * With the Unicode adapter on, any pointer interaction with the canvas
   * or a non-form control (dialogs, drawer buttons, language toggle,
   * machine controls) hands focus back to the hidden IME textarea so
   * Chinese input keeps flowing. Form fields keep their focus.
   */
  private maybeRestoreImeFocus(target: HTMLElement | null): void {
    if (!useStore.getState().unicodeAdapter || !this.ime) return;
    if (target?.closest("input, textarea, select, [contenteditable]")) return;
    if (document.activeElement === this.ime) return;
    this.scheduleImeFocusRestore();
  }

  /**
   * Restores IME focus on the NEXT FRAME. Used whenever an overlay closes
   * (export drawer, clear confirm, draft restore, part info, Escape):
   * the closing component unmounts first, then focus lands on the hidden
   * IME field. Never steals focus from a form control (title, author,
   * select) and never fires while an overlay is still open.
   */
  scheduleImeFocusRestore(): void {
    if (this.focusRestoreScheduled) return;
    this.focusRestoreScheduled = true;
    requestAnimationFrame(() => {
      this.focusRestoreScheduled = false;
      const state = useStore.getState();
      if (!state.unicodeAdapter || !this.ime) return;
      if (state.exportOpen || state.clearConfirm || state.selectedPart || state.trace) return;
      const active = document.activeElement as HTMLElement | null;
      if (active === this.ime) return;
      if (active && active !== document.body && active.closest("input, textarea, select, [contenteditable]")) return;
      this.focusIme();
    });
  }

  /** Called by UI code when dialogs/drawers close without a pointerdown. */
  restoreImeFocus(): void {
    this.scheduleImeFocusRestore();
  }

  private autosave(): void {
    try {
      if (this.core.manuscript.isEmpty) {
        localStorage.removeItem(DRAFT_STORAGE_KEY);
        useStore.getState().setDraftExists(false);
        return;
      }
      localStorage.setItem(DRAFT_STORAGE_KEY, JSON.stringify(this.core.manuscript.toJSON()));
      useStore.getState().setDraftExists(true);
      useStore.getState().bumpSaveTick();
    } catch {
      /* storage full or blocked — typing still works */
    }
  }

  onKeyDown(event: KeyboardEvent): void {
    this.core.sound.unlock();
    const state = useStore.getState();
    const { machine } = this.core;

    // Escape stays global: it closes overlays even from inside a form.
    if (event.code === "Escape" && !event.metaKey && !event.ctrlKey) {
      state.setExportOpen(false);
      state.selectPart(null);
      state.setClearConfirm(false);
      // The closing overlay unmounts first; focus returns to the IME field
      // on the next frame (never yanking focus out of a form control).
      this.scheduleImeFocusRestore();
      return;
    }

    // A form control outside the IME field (export title/author, selects)
    // owns the rest of its keys — printable input, Enter, Backspace, Tab
    // and its own editing shortcuts are never hijacked into the machine.
    const activeEl = document.activeElement as HTMLElement | null;
    if (activeEl !== this.ime && !!activeEl?.closest("input, textarea, select, [contenteditable]")) return;

    if (event.metaKey || event.ctrlKey) {
      const key = event.key.toLowerCase();
      if (key === "z" && !event.shiftKey) {
        event.preventDefault();
        machine.requestHistoryOp("undo");
        return;
      }
      if ((key === "z" && event.shiftKey) || key === "y") {
        event.preventDefault();
        machine.requestHistoryOp("redo");
        return;
      }
      if (key === "s") {
        event.preventDefault();
        this.saveDraft();
        return;
      }
      if (event.code === "Enter") {
        event.preventDefault();
        machine.newSheet();
        return;
      }
      return;
    }

    if (this.composing) return;
    if (event.code === "Enter") {
      event.preventDefault();
      machine.carriageReturn();
      return;
    }
    if (event.code === "CapsLock") {
      event.preventDefault();
      machine.press("CapsLock");
      return;
    }
    const def = KEY_BY_CODE[event.code];
    if (def) {
      // With the adapter on and the IME field focused, printable keys flow
      // into the textarea and commit through exactly one path (composition
      // for IME, plain input otherwise) — no double submissions.
      const adapterFocused = state.unicodeAdapter && document.activeElement === this.ime;
      if (adapterFocused && (def.kind === "char" || def.kind === "space")) return;
      event.preventDefault();
      machine.press(event.code, { repeat: event.repeat, key: event.key, shiftKey: event.shiftKey });
    }
  }

  saveDraft(): void {
    try {
      localStorage.setItem(DRAFT_STORAGE_KEY, JSON.stringify(this.core.manuscript.toJSON()));
      const state = useStore.getState();
      state.setDraftExists(true);
      state.bumpSaveTick();
      state.showPlaqueKey("plaque.draftSaved");
    } catch {
      useStore.getState().showPlaqueKey("plaque.draftFailed");
    }
  }

  static loadDraft(): DraftData | null {
    try {
      const raw = localStorage.getItem(DRAFT_STORAGE_KEY);
      return raw ? (JSON.parse(raw) as DraftData) : null;
    } catch {
      return null;
    }
  }

  static discardDraft(): void {
    try {
      localStorage.removeItem(DRAFT_STORAGE_KEY);
    } catch {
      /* ignore */
    }
  }

  detach(): void {
    window.clearTimeout(this.autosaveTimer);
    for (const fn of this.detachFns) fn();
    this.detachFns.length = 0;
    this.attached = false;
  }
}
