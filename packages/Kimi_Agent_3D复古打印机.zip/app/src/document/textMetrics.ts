/**
 * Word counting for Chinese text. Whitespace splitting counts a run of
 * Han characters as one "word", which is wrong for Chinese; Intl.Segmenter
 * (with a compatibility fallback) gives a real word count.
 */

interface SegmenterLike {
  segment(input: string): Iterable<{ segment: string; isWordLike?: boolean }>;
}

interface SegmenterCtor {
  new (locale: string, options: { granularity: "word" }): SegmenterLike;
}

function getSegmenter(): SegmenterLike | null {
  const ctor = (Intl as unknown as { Segmenter?: SegmenterCtor }).Segmenter;
  if (!ctor) return null;
  try {
    return new ctor("zh-CN", { granularity: "word" });
  } catch {
    return null;
  }
}

/**
 * Chinese-aware word count: Intl.Segmenter word granularity, falling back
 * to whitespace splitting when Segmenter is unavailable.
 */
export function wordCountZh(text: string): number {
  const clean = text.replace(/\f/g, " ").trim();
  if (!clean) return 0;
  const segmenter = getSegmenter();
  if (!segmenter) return clean.split(/\s+/u).length;
  let count = 0;
  for (const part of segmenter.segment(clean)) {
    if (part.isWordLike !== false && part.segment.trim()) count++;
  }
  return count;
}
