/**
 * Shared mechanical & document constants for THE IMPACT No. 01.
 * All timings are milliseconds, all 3D units are scene units.
 */

/** Character cells per line. */
export const COLS = 72;
/** Lines per page. */
export const LINES = 44;
/** Word line spacing base (also exported to DOCX as exact line spacing). */
export const DOCX_LINE_SPACING_PT = 15.8;
/** Left margin column. */
export const LEFT_MARGIN = 0;
/** Right margin column — typing is rejected from here on. */
export const RIGHT_MARGIN = 72;
/** Column at which the margin bell rings (6 before the right margin). */
export const BELL_COL = 66;

/** Type slug hits the ribbon ~100ms after the keystroke. */
export const IMPACT_MS = 100;
/** Full typebar round trip. */
export const TYPEBAR_ROUND_TRIP_MS = 240;
/** Full mechanical carriage return. */
export const CARRIAGE_RETURN_MS = 720;
/** Collision look-ahead window for typebar clash detection. */
export const CLASH_WINDOW_MS = 40;
/** Delay applied to the later typebar when a clash is detected. */
export const CLASH_DELAY_MS = 70;
/**
 * Minimum gap between consecutive strikes. The escapement releases one
 * tooth at a time, so keystrokes always strike in the order they were
 * pressed — a later key can never land before an earlier one, even when
 * their typebars would not physically clash.
 */
export const STRIKE_MIN_GAP_MS = 30;

/** Ribbon advance per character (radians of ribbon travel). */
export const RIBBON_STEP = 0.011;
/** Spool rotation ratio relative to ribbon travel. */
export const SPOOL_STEP = 0.05;
/** Characters of ribbon travel before the feed direction flips. */
export const RIBBON_REVERSE_CHARS = 900;

/** Above this explode amount typing is blocked. */
export const EXPLODE_TYPE_THRESHOLD = 0.08;

export const FONT_FAMILY = "Courier Prime";
export const FONT_FALLBACKS = ["Courier New", "Liberation Mono", "monospace"];

/** localStorage keys. */
export const LANG_STORAGE_KEY = "impact-lang";
export const DRAFT_STORAGE_KEY = "impact-no-01-draft";
export const ADAPTER_STORAGE_KEY = "impact-unicode-adapter";
