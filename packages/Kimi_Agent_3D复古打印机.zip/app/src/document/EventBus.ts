/**
 * Minimal synchronous event bus. All machine and document events flow
 * through bus instances so audio, paper, UI and telemetry stay decoupled.
 */
export class EventBus<Payload = unknown> {
  private handlers = new Map<string, Set<(payload: never) => void>>();

  on<T = Payload>(event: string, handler: (payload: T) => void): () => void {
    let set = this.handlers.get(event);
    if (!set) {
      set = new Set();
      this.handlers.set(event, set);
    }
    set.add(handler as (payload: never) => void);
    return () => set.delete(handler as (payload: never) => void);
  }

  emit<T = Payload>(event: string, payload: T): void {
    const set = this.handlers.get(event);
    if (!set) return;
    for (const handler of [...set]) handler(payload as never);
  }

  clear(): void {
    this.handlers.clear();
  }
}
