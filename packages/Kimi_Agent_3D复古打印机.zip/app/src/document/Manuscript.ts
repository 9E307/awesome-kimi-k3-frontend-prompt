import {
  BELL_COL,
  COLS,
  LEFT_MARGIN,
  LINES,
  RIGHT_MARGIN,
} from "./constants";
import { EventBus } from "./EventBus";

export interface Cursor {
  page: number;
  line: number;
  col: number;
}

export interface Glyph {
  char: string;
  code: string;
  page: number;
  line: number;
  col: number;
  timestamp: number;
  inkOpacity: number;
  xJitter: number;
  yJitter: number;
  overstrikeCount: number;
  history: string[];
  viaUnicodeAdapter: boolean;
}

export interface ApplyResult {
  accepted: boolean;
  blockedByMargin?: boolean;
  blockedByPageFull?: boolean;
  pageFull?: boolean;
  autoReturned?: boolean;
  bell?: boolean;
}

export type ManuscriptEvent =
  | { type: "TYPE_CHAR"; char: string; code: string; timestamp: number; viaUnicodeAdapter?: boolean }
  | { type: "SPACE"; timestamp: number }
  | { type: "TAB"; timestamp: number }
  | { type: "BACKSPACE"; timestamp: number }
  | { type: "CARRIAGE_RETURN"; timestamp: number }
  | { type: "NEW_SHEET"; timestamp: number };

type UndoEntry =
  | { kind: "glyph"; cursorBefore: Cursor; before: Glyph | null; after: Glyph }
  | { kind: "cursor"; cursorBefore: Cursor; cursorAfter: Cursor }
  | { kind: "sheet"; cursorBefore: Cursor; pageAdded: number };

/** FNV-style multiplicative hash over 16-bit chunks. Deterministic. */
function hashWords(...words: number[]): number {
  let h = 2166136261;
  for (const w of words) {
    h ^= (w >>> 0) & 65535;
    h = Math.imul(h, 16777619);
    h ^= (w >>> 16) & 65535;
    h = Math.imul(h, 16777619);
  }
  h ^= h >>> 13;
  h = Math.imul(h, 1540483477);
  h ^= h >>> 15;
  return h >>> 0;
}

/** Deterministic PRNG (mulberry-ish) seeded by the hash above. */
function prng(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 1831565813) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export interface StrikeStyle {
  inkOpacity: number;
  xJitter: number;
  yJitter: number;
  variant: number;
}

/**
 * Reproducible per-strike style: same page/line/col/char/strike always
 * yields the same ink density and jitter, so repaints never shimmer.
 */
export function strikeStyle(page: number, line: number, col: number, char: string, strike: number): StrikeStyle {
  const rand = prng(hashWords(page, line, col, char.charCodeAt(0), strike));
  return {
    inkOpacity: 0.88 + rand() * 0.12,
    xJitter: (rand() - 0.5) * 0.8,
    yJitter: (rand() - 0.5) * 0.8,
    variant: Math.floor(rand() * 6),
  };
}

/**
 * The manuscript: pages of glyph cells, a mechanical cursor, margin rules,
 * overstrike history and undo/redo. Pure data — no rendering here.
 */
export class Manuscript {
  pages: Glyph[][][] = [Array.from({ length: LINES }, () => [])];
  cursor: Cursor = { page: 0, line: 0, col: 0 };
  pageFull = false;
  autoReturn = false;
  readonly bus = new EventBus();
  private undoStack: UndoEntry[] = [];
  private redoStack: UndoEntry[] = [];
  private strikeCounter = 0;

  glyphAt(page: number, line: number, col: number): Glyph | null {
    const row = this.pages[page]?.[line];
    if (!row) return null;
    for (const g of row) if (g.col === col) return g;
    return null;
  }

  lineText(page: number, line: number): string {
    const cells = new Array<string>(COLS).fill(" ");
    for (const g of this.pages[page]?.[line] ?? []) cells[g.col] = g.char;
    return cells.join("").replace(/\s+$/u, "");
  }

  pageText(page: number): string {
    const out: string[] = [];
    const p = this.pages[page] ?? [];
    for (let i = 0; i < p.length; i++) out.push(this.lineText(page, i));
    return out.join("\n").replace(/\n+$/u, "");
  }

  /** Multi-page text uses form feed as the page separator. */
  getText(): string {
    return this.pages.map((_, i) => this.pageText(i)).join("\f");
  }

  get charCount(): number {
    let n = 0;
    for (const p of this.pages) for (const row of p) n += row.length;
    return n;
  }

  /** Words split on Unicode whitespace. */
  get wordCount(): number {
    const text = this.getText().replace(/\f/g, " ").trim();
    return text ? text.split(/\s+/u).length : 0;
  }

  get isEmpty(): boolean {
    return this.charCount === 0 && this.cursor.page === 0 && this.cursor.line === 0 && this.cursor.col === 0;
  }

  get canUndo(): boolean {
    return this.undoStack.length > 0;
  }

  get canRedo(): boolean {
    return this.redoStack.length > 0;
  }

  apply(event: ManuscriptEvent): ApplyResult {
    switch (event.type) {
      case "TYPE_CHAR":
        return this.typeChar(event.char, event.code, event.timestamp, event.viaUnicodeAdapter === true);
      case "SPACE":
        return this.advanceCursor(1, event.timestamp);
      case "TAB": {
        const next = Math.min(RIGHT_MARGIN, (Math.floor(this.cursor.col / 8) + 1) * 8);
        return this.advanceCursor(next - this.cursor.col, event.timestamp);
      }
      case "BACKSPACE":
        return this.backspace(event.timestamp);
      case "CARRIAGE_RETURN":
        return this.carriageReturn(event.timestamp);
      case "NEW_SHEET":
        return this.newSheet(event.timestamp);
    }
  }

  private typeChar(char: string, code: string, timestamp: number, viaUnicodeAdapter: boolean): ApplyResult {
    if (this.pageFull) {
      this.bus.emit("rejected", { reason: "pageFull" });
      return { accepted: false, blockedByPageFull: true };
    }
    if (this.cursor.col >= RIGHT_MARGIN) {
      if (this.autoReturn) {
        const ret = this.carriageReturn(timestamp);
        if (!ret.accepted) return ret;
        const again = this.typeChar(char, code, timestamp, viaUnicodeAdapter);
        again.autoReturned = true;
        return again;
      }
      this.bus.emit("rejected", { reason: "margin" });
      return { accepted: false, blockedByMargin: true };
    }
    const { page, line, col } = this.cursor;
    const style = strikeStyle(page, line, col, char, this.strikeCounter++);
    const existing = this.glyphAt(page, line, col);
    let glyph: Glyph;
    if (existing) {
      const count = existing.overstrikeCount + 1;
      glyph = {
        ...existing,
        char,
        code,
        timestamp,
        overstrikeCount: count,
        history: [...existing.history, existing.char],
        inkOpacity: Math.min(1, Math.max(existing.inkOpacity, style.inkOpacity) + 0.06 * count),
        xJitter: existing.xJitter + style.xJitter * (0.5 + 0.5 * count),
        yJitter: existing.yJitter + style.yJitter * (0.5 + 0.5 * count),
        viaUnicodeAdapter,
      };
      const row = this.pages[page][line];
      row[row.indexOf(existing)] = glyph;
    } else {
      glyph = {
        char,
        code,
        page,
        line,
        col,
        timestamp,
        inkOpacity: style.inkOpacity,
        xJitter: style.xJitter,
        yJitter: style.yJitter,
        overstrikeCount: 0,
        history: [],
        viaUnicodeAdapter,
      };
      const row = this.pages[page][line];
      let at = 0;
      while (at < row.length && row[at].col < col) at++;
      row.splice(at, 0, glyph);
    }
    const cursorBefore = { ...this.cursor };
    this.undoStack.push({ kind: "glyph", cursorBefore, before: existing, after: glyph });
    this.redoStack.length = 0;
    const bell = this.cursor.col === BELL_COL - 1;
    this.cursor.col++;
    this.bus.emit("changed", { page });
    if (bell) this.bus.emit("bell", {});
    return { accepted: true, bell };
  }

  private advanceCursor(cells: number, timestamp: number): ApplyResult {
    if (this.pageFull) {
      this.bus.emit("rejected", { reason: "pageFull" });
      return { accepted: false, blockedByPageFull: true };
    }
    if (cells <= 0) return { accepted: false };
    if (this.cursor.col >= RIGHT_MARGIN) {
      if (this.autoReturn) {
        const ret = this.carriageReturn(timestamp);
        if (ret.accepted) ret.autoReturned = true;
        return ret;
      }
      this.bus.emit("rejected", { reason: "margin" });
      return { accepted: false, blockedByMargin: true };
    }
    const cursorBefore = { ...this.cursor };
    const bell = this.cursor.col < BELL_COL && this.cursor.col + cells >= BELL_COL;
    this.cursor.col = Math.min(RIGHT_MARGIN, this.cursor.col + cells);
    this.undoStack.push({ kind: "cursor", cursorBefore, cursorAfter: { ...this.cursor } });
    this.redoStack.length = 0;
    this.bus.emit("changed", { page: this.cursor.page });
    if (bell) this.bus.emit("bell", {});
    return { accepted: true, bell };
  }

  private backspace(_timestamp: number): ApplyResult {
    if (this.pageFull) return { accepted: false, blockedByPageFull: true };
    if (this.cursor.col <= LEFT_MARGIN) return { accepted: false };
    const cursorBefore = { ...this.cursor };
    this.cursor.col--;
    this.undoStack.push({ kind: "cursor", cursorBefore, cursorAfter: { ...this.cursor } });
    this.redoStack.length = 0;
    this.bus.emit("changed", { page: this.cursor.page });
    return { accepted: true };
  }

  private carriageReturn(_timestamp: number): ApplyResult {
    if (this.pageFull) {
      this.bus.emit("rejected", { reason: "pageFull" });
      return { accepted: false, blockedByPageFull: true };
    }
    const cursorBefore = { ...this.cursor };
    if (this.cursor.line >= LINES - 1) {
      this.pageFull = true;
      this.bus.emit("rejected", { reason: "pageFull" });
      return { accepted: false, blockedByPageFull: true, pageFull: true };
    }
    this.cursor.line++;
    this.cursor.col = LEFT_MARGIN;
    this.undoStack.push({ kind: "cursor", cursorBefore, cursorAfter: { ...this.cursor } });
    this.redoStack.length = 0;
    this.bus.emit("changed", { page: this.cursor.page });
    return { accepted: true };
  }

  private newSheet(_timestamp: number): ApplyResult {
    const cursorBefore = { ...this.cursor };
    this.pages.push(Array.from({ length: LINES }, () => []));
    this.cursor = { page: this.pages.length - 1, line: 0, col: LEFT_MARGIN };
    this.pageFull = false;
    this.undoStack.push({ kind: "sheet", cursorBefore, pageAdded: this.cursor.page });
    this.redoStack.length = 0;
    this.bus.emit("structure", {});
    return { accepted: true };
  }

  undo(): boolean {
    const entry = this.undoStack.pop();
    if (!entry) return false;
    switch (entry.kind) {
      case "glyph": {
        const { page, line, col } = entry.after;
        const row = this.pages[page][line];
        const at = row.findIndex((g) => g.col === col);
        if (at >= 0) {
          if (entry.before) row[at] = entry.before;
          else row.splice(at, 1);
        }
        this.cursor = { ...entry.cursorBefore };
        this.pageFull = false;
        break;
      }
      case "cursor":
        this.cursor = { ...entry.cursorBefore };
        this.pageFull = false;
        break;
      case "sheet":
        this.pages.splice(entry.pageAdded, 1);
        this.cursor = { ...entry.cursorBefore };
        this.pageFull = false;
        break;
    }
    this.redoStack.push(entry);
    this.bus.emit("changed", { page: this.cursor.page });
    this.bus.emit("structure", {});
    return true;
  }

  redo(): boolean {
    const entry = this.redoStack.pop();
    if (!entry) return false;
    switch (entry.kind) {
      case "glyph": {
        const { page, line, col } = entry.after;
        const row = this.pages[page][line];
        const at = row.findIndex((g) => g.col === col);
        if (at >= 0) row[at] = entry.after;
        else {
          let i = 0;
          while (i < row.length && row[i].col < col) i++;
          row.splice(i, 0, entry.after);
        }
        this.cursor = { page, line, col: col + 1 };
        break;
      }
      case "cursor":
        this.cursor = { ...entry.cursorAfter };
        break;
      case "sheet":
        this.pages.splice(entry.pageAdded, 0, Array.from({ length: LINES }, () => []));
        this.cursor = { page: entry.pageAdded, line: 0, col: LEFT_MARGIN };
        this.pageFull = false;
        break;
    }
    this.undoStack.push(entry);
    this.bus.emit("changed", { page: this.cursor.page });
    this.bus.emit("structure", {});
    return true;
  }

  clear(): void {
    this.pages = [Array.from({ length: LINES }, () => [])];
    this.cursor = { page: 0, line: 0, col: LEFT_MARGIN };
    this.pageFull = false;
    this.undoStack.length = 0;
    this.redoStack.length = 0;
    this.bus.emit("structure", {});
    this.bus.emit("changed", { page: this.cursor.page });
  }

  /**
   * Bulk-loads text: "\f" separates pages, "\n" is a carriage return.
   * Used by the sample manuscript. History is cleared afterwards.
   */
  loadText(text: string, timestamp: number): void {
    this.clear();
    let pageIndex = 0;
    for (const pageText of text.split("\f")) {
      if (pageIndex > 0) this.newSheet(timestamp);
      if (this.pageFull) break;
      for (const line of pageText.split("\n")) {
        for (const char of line.slice(0, RIGHT_MARGIN)) {
          this.typeChar(char, "SAMPLE", timestamp, false);
        }
        this.carriageReturn(timestamp);
        if (this.pageFull) break;
      }
      this.pageFull = false;
      pageIndex++;
    }
    this.undoStack.length = 0;
    this.redoStack.length = 0;
    this.cursor = { page: 0, line: 0, col: LEFT_MARGIN };
    this.pageFull = false;
    this.bus.emit("structure", {});
    this.bus.emit("changed", { page: 0 });
  }

  toJSON(): { pages: Glyph[][][]; cursor: Cursor; pageFull: boolean; version: number } {
    return { pages: this.pages, cursor: this.cursor, pageFull: this.pageFull, version: 1 };
  }

  restore(data: { pages: Glyph[][][]; cursor: Cursor; pageFull: boolean }): void {
    this.pages = data.pages;
    this.cursor = data.cursor;
    this.pageFull = data.pageFull;
    this.undoStack.length = 0;
    this.redoStack.length = 0;
    this.bus.emit("structure", {});
    this.bus.emit("changed", { page: this.cursor.page });
  }

  static fromJSON(data: { pages: Glyph[][][]; cursor: Cursor; pageFull: boolean }): Manuscript {
    const m = new Manuscript();
    m.restore(data);
    return m;
  }
}
