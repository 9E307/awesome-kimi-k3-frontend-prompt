import { COLS, LINES } from "./constants";
import type { Glyph, Manuscript } from "./Manuscript";

/**
 * Paper canvas: an aged A4 sheet painted once (warm vertical gradient,
 * deterministic fibres, darkened edges) and repainted with glyphs only
 * when the manuscript changes.
 */

export const PAPER = {
  W: 1488,
  H: 2104,
  MARGIN_X: 180,
  MARGIN_TOP: 180,
  FONT_PX: 30,
  get TEXT_W() {
    return this.W - this.MARGIN_X * 2;
  },
  get TEXT_H() {
    return this.H - this.MARGIN_TOP * 2;
  },
  get CELL_W() {
    return this.TEXT_W / COLS;
  },
  get LINE_H() {
    return this.TEXT_H / LINES;
  },
} as const;

function paintFibreLayer(): HTMLCanvasElement {
  const canvas = document.createElement("canvas");
  canvas.width = PAPER.W;
  canvas.height = PAPER.H;
  const ctx = canvas.getContext("2d")!;

  const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
  gradient.addColorStop(0, "#f6f0e1");
  gradient.addColorStop(0.5, "#f3ecdb");
  gradient.addColorStop(1, "#efe7d4");
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Deterministic fibres (LCG) — the sheet never changes between sessions.
  let seed = 7;
  const rand = () => ((seed = (seed * 16807) % 2147483647), seed / 2147483647);
  ctx.strokeStyle = "rgba(120, 105, 80, 0.05)";
  ctx.lineWidth = 0.7;
  for (let i = 0; i < 2600; i++) {
    const x = rand() * canvas.width;
    const y = rand() * canvas.height;
    const angle = rand() * Math.PI;
    const length = 1.5 + rand() * 4;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + Math.cos(angle) * length, y + Math.sin(angle) * length);
    ctx.stroke();
  }

  const edges = ctx.createLinearGradient(0, 0, canvas.width, 0);
  edges.addColorStop(0, "rgba(60, 50, 35, 0.10)");
  edges.addColorStop(0.04, "rgba(60, 50, 35, 0)");
  edges.addColorStop(0.96, "rgba(60, 50, 35, 0)");
  edges.addColorStop(1, "rgba(60, 50, 35, 0.10)");
  ctx.fillStyle = edges;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  return canvas;
}

export class PaperTexture {
  readonly canvas: HTMLCanvasElement;
  private readonly ctx: CanvasRenderingContext2D;
  private readonly fibre: HTMLCanvasElement;
  private readonly manuscript: Manuscript;
  fontReady = false;
  onRepaint: (() => void) | null = null;

  constructor(manuscript: Manuscript) {
    this.manuscript = manuscript;
    this.canvas = document.createElement("canvas");
    this.canvas.width = PAPER.W;
    this.canvas.height = PAPER.H;
    this.ctx = this.canvas.getContext("2d")!;
    this.fibre = paintFibreLayer();
    this.repaint();
    if (typeof document !== "undefined" && document.fonts) {
      document.fonts
        .load(`${PAPER.FONT_PX}px "Courier Prime"`)
        .then(() => {
          this.fontReady = true;
          this.repaint();
        })
        .catch(() => {});
    }
    manuscript.bus.on("changed", () => this.repaint());
    manuscript.bus.on("structure", () => this.repaint());
  }

  private drawGlyph(glyph: Glyph): void {
    const ctx = this.ctx;
    const x = PAPER.MARGIN_X + glyph.col * PAPER.CELL_W + PAPER.CELL_W * 0.08 + glyph.xJitter;
    const y = PAPER.MARGIN_TOP + glyph.line * PAPER.LINE_H + PAPER.LINE_H * 0.72 + glyph.yJitter;
    ctx.font = `${PAPER.FONT_PX}px "Courier Prime", "Courier New", monospace`;
    ctx.textBaseline = "alphabetic";
    const layers = [...glyph.history, glyph.char];
    layers.forEach((char, index) => {
      const isFinal = index === layers.length - 1;
      const opacity = isFinal ? glyph.inkOpacity : Math.min(0.95, glyph.inkOpacity * 0.82);
      const ox = isFinal ? 0 : (index % 2 === 0 ? 0.5 : -0.4) * (1 + index * 0.3);
      const oy = isFinal ? 0 : (index % 2 === 0 ? -0.4 : 0.5) * (1 + index * 0.3);
      // Main strike plus a faint ghost for the uneven inking of a real slug.
      ctx.fillStyle = `rgba(24, 21, 18, ${opacity.toFixed(3)})`;
      ctx.fillText(char, x + ox, y + oy);
      ctx.fillStyle = `rgba(24, 21, 18, ${(opacity * 0.16).toFixed(3)})`;
      ctx.fillText(char, x + ox + 0.7, y + oy + 0.4);
    });
  }

  repaint(): void {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    ctx.drawImage(this.fibre, 0, 0);
    const page = Math.min(this.manuscript.cursor.page, this.manuscript.pages.length - 1);
    for (const row of this.manuscript.pages[page] ?? []) {
      for (const glyph of row) this.drawGlyph(glyph);
    }
    this.onRepaint?.();
  }
}
