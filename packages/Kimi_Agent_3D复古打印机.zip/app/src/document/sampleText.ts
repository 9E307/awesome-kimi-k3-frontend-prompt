/**
 * The sample manuscript exactly as the reference ships it.
 * "\f" separates pages, "\n" is a carriage return.
 */
export const SAMPLE_TEXT = `THE IMPACT No. 01\fBefore words became data, they were impact.\f\fEvery letter on this page arrived the slow way:
a finger fell, a lever turned, a steel bar rose
from the basket, and a small block of type struck
a ribbon against rubber and bone-white paper.

The machine did not remember anything.
The paper did.`;
