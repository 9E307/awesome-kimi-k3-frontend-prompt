import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { useThree } from "@react-three/fiber";
import { useStore } from "../app/store";
import { getMachineBuild } from "./machineBuildRegistry";

/**
 * Raycast part picking. Active only where picking makes sense (inspect
 * mode, exploded view, cutaway); a small drag threshold keeps orbit
 * gestures from selecting parts.
 */
export function PartPicker() {
  const { camera, gl } = useThree();
  const raycaster = useMemo(() => new THREE.Raycaster(), []);
  const pointer = useMemo(() => new THREE.Vector2(), []);
  const downAt = useRef<{ x: number; y: number } | null>(null);

  useEffect(() => {
    const element = gl.domElement;
    const onPointerDown = (event: PointerEvent) => {
      downAt.current = { x: event.clientX, y: event.clientY };
    };
    const onPointerUp = (event: PointerEvent) => {
      const start = downAt.current;
      downAt.current = null;
      if (!start || Math.hypot(event.clientX - start.x, event.clientY - start.y) > 6) return;
      const state = useStore.getState();
      if (!(state.explodeCurrent > 0.04 || state.cutaway || state.cameraMode === "inspect")) return;
      const rect = element.getBoundingClientRect();
      pointer.set(((event.clientX - rect.left) / rect.width) * 2 - 1, -((event.clientY - rect.top) / rect.height) * 2 + 1);
      raycaster.setFromCamera(pointer, camera);
      const build = getMachineBuild();
      if (!build) return;
      const hits = raycaster.intersectObject(build.root, true);
      for (const hit of hits) {
        let obj: THREE.Object3D | null = hit.object;
        while (obj && !obj.userData.partId) obj = obj.parent;
        if (obj?.userData.partId) {
          const id = obj.userData.partId as string;
          state.selectPart(state.selectedPart === id ? null : id);
          return;
        }
      }
      state.selectPart(null);
    };
    element.addEventListener("pointerdown", onPointerDown);
    element.addEventListener("pointerup", onPointerUp);
    return () => {
      element.removeEventListener("pointerdown", onPointerDown);
      element.removeEventListener("pointerup", onPointerUp);
    };
  }, [camera, gl, raycaster, pointer]);

  return null;
}
