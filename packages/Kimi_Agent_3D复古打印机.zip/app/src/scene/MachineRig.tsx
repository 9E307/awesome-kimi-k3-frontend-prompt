import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { useStore } from "../app/store";
import { getCore } from "../app/core";
import { createMaterials } from "./Materials";
import { buildMachine, stretchRibbon, type MachineBuild } from "../machine/buildMachine";
import { KEYS } from "../machine/keyboardLayout";
import { easeInOutCubic, lerpPose, staggeredProgress } from "../machine/animations";
import { setMachineBuild } from "./machineBuildRegistry";
import { LAYOUT } from "../machine/machineParts";

type HighlightMode = "none" | "selected" | "related" | "dim";

const materialCache = new WeakMap<THREE.Mesh, THREE.Material | THREE.Material[]>();

function setHighlight(part: MachineBuild["parts"][number], mode: HighlightMode): void {
  part.partGroup.traverse((obj) => {
    if (!(obj instanceof THREE.Mesh)) return;
    const mesh = obj as THREE.Mesh;
    if (mode !== "none") {
      if (!materialCache.has(mesh)) materialCache.set(mesh, mesh.material);
      const original = materialCache.get(mesh)!;
      const source = Array.isArray(original) ? original[0] : original;
      const clone = source.clone() as THREE.MeshStandardMaterial;
      const hasEmissive = clone.emissive !== undefined;
      if (mode === "selected") {
        if (hasEmissive) {
          clone.emissive = new THREE.Color(0xb08d57);
          clone.emissiveIntensity = 0.55;
        } else {
          clone.color = new THREE.Color(0xffd9a0);
        }
      } else if (mode === "related") {
        if (hasEmissive) {
          clone.emissive = new THREE.Color(0x8a7a5a);
          clone.emissiveIntensity = 0.16;
        } else {
          clone.color = new THREE.Color(0xd8cba8);
        }
      } else {
        clone.transparent = true;
        clone.opacity = 0.22;
      }
      mesh.material = clone;
    } else {
      const original = materialCache.get(mesh);
      if (original) {
        mesh.material = original;
        materialCache.delete(mesh);
      }
    }
  });
}

function clearHighlights(build: MachineBuild): void {
  for (const part of build.parts) setHighlight(part, "none");
}

/**
 * The machine inside the Canvas: builds once, then drives every moving
 * subsystem from the machine clock each frame — keys, typebars, basket,
 * vibrator, escapement, carriage, platen, ribbon, bell, explode poses,
 * cutaway fade and selection highlighting.
 */
export function MachineRig() {
  const core = getCore();
  const materials = useMemo(() => createMaterials(), []);
  const build = useMemo(() => buildMachine(materials, core.paper), [materials, core.paper]);
  const explodeCurrent = useRef(0);
  const paperLine = useRef(0);
  const screwProgress = useRef(-1);

  const selectedPart = useStore((s) => s.selectedPart);
  const trace = useStore((s) => s.trace);

  useEffect(() => {
    setMachineBuild(build);
    window.__impactBuild = build;
  }, [build]);

  useEffect(() => {
    clearHighlights(build);
    if (trace) {
      const id = trace.chain[trace.index];
      const part = build.byId.get(id);
      if (part) setHighlight(part, "selected");
      return;
    }
    if (selectedPart) {
      const part = build.byId.get(selectedPart);
      if (part) {
        const related = new Set([...part.upstream, ...part.downstream]);
        for (const other of build.parts) {
          if (other.id === selectedPart) setHighlight(other, "selected");
          else if (related.has(other.id)) setHighlight(other, "related");
          else setHighlight(other, "dim");
        }
      }
    }
    return () => clearHighlights(build);
  }, [selectedPart, trace, build]);

  useEffect(() => {
    if (!trace) return;
    const timer = window.setInterval(() => useStore.getState().advanceTrace(), 550);
    return () => window.clearInterval(timer);
  }, [trace]);

  useFrame((_, delta) => {
    const { machine, manuscript, sound } = core;
    const state = useStore.getState();
    const dtMs = Math.min(delta * 1000, 100);

    machine.timeScale = state.slowMotion ? 0.15 : 1;
    machine.update(dtMs);

    // Sync live machine status into the store (only on change) so the
    // undo/redo buttons can show busy/queued states with ARIA feedback.
    const pendingOps = machine.pendingHistoryOps;
    const status = {
      machineBusy: machine.machineBusy,
      historyPending: machine.historyPending,
      pendingUndoCount: pendingOps.filter((op) => op === "undo").length,
      pendingRedoCount: pendingOps.filter((op) => op === "redo").length,
      canUndo: manuscript.canUndo,
      canRedo: manuscript.canRedo,
    };
    if (
      state.machineBusy !== status.machineBusy ||
      state.historyPending !== status.historyPending ||
      state.pendingUndoCount !== status.pendingUndoCount ||
      state.pendingRedoCount !== status.pendingRedoCount ||
      state.canUndo !== status.canUndo ||
      state.canRedo !== status.canRedo
    ) {
      state.setMachineStatus(status);
    }

    // --- explode easing -----------------------------------------------------
    const rateScale = state.motionReduced ? 3 : 1;
    const target = state.explodeTarget;
    let current = explodeCurrent.current;
    if (current !== target) {
      const step = (dtMs / 3200) * rateScale;
      const next = current < target ? Math.min(target, current + step) : Math.max(target, current - step);
      sound.play(next > current ? "explodeMove" : "assembleMove");
      current = next;
      explodeCurrent.current = current;
      state.setExplodeCurrent(current);
    }
    machine.setExplode(current);

    if (current > 0 || screwProgress.current !== -1) {
      for (const part of build.parts) {
        const progress = easeInOutCubic(staggeredProgress(current, part.stagger));
        if (part.id === "hardware.screws") {
          if (Math.abs(progress - screwProgress.current) > 0.002 || progress === 0) {
            screwProgress.current = progress;
            const instanced = part.partGroup.userData.instanced as THREE.InstancedMesh;
            const screwData = part.partGroup.userData.screwData as Array<{ p: THREE.Vector3; n: THREE.Vector3 }>;
            const matrix = new THREE.Matrix4();
            const quaternion = new THREE.Quaternion();
            const up = new THREE.Vector3(0, 1, 0);
            screwData.forEach((screw, i) => {
              quaternion.setFromUnitVectors(up, screw.n);
              matrix.compose(screw.p.clone().addScaledVector(screw.n, 3.2 * progress), quaternion, new THREE.Vector3(1, 1, 1));
              instanced.setMatrixAt(i, matrix);
            });
            instanced.instanceMatrix.needsUpdate = true;
          }
          continue;
        }
        const pose = lerpPose(part.assembled, part.exploded, progress);
        part.partGroup.position.set(pose.px, pose.py, pose.pz);
        part.partGroup.rotation.set(pose.rx, pose.ry, pose.rz);
      }
      if (current === 0) screwProgress.current = -1;
    }

    // --- keystroke linkage ---------------------------------------------------
    for (const key of KEYS) {
      const dip = machine.keyDip(key.code);
      const actions = build.refs.keyActions.get(key.code);
      if (!actions) continue;
      actions.cap.position.y = -dip * 0.32;
      if (actions.lever) actions.lever.rotation.x = -dip * 0.16;
    }
    for (let i = 0; i < build.refs.typebarActions.length; i++) {
      const action = build.refs.typebarActions[i];
      if (!action) continue;
      const swing = machine.typebarSwing(i);
      const rest = build.refs.typebarRestAngles[i];
      const strike = build.refs.typebarStrikeAngles[i];
      action.rotation.x = -swing * (rest - strike);
    }

    build.refs.basketGroup.position.y = machine.basketShift * 0.85;

    const lift = machine.vibratorLift();
    build.refs.vibratorAction.position.y = lift * 0.65;
    build.refs.vibratorAction.position.z = -lift * 0.18;
    build.refs.universalBarAction.position.y = -machine.universalBarDip() * 0.14;

    build.refs.carriageGroup.position.x = LAYOUT.CARRIAGE_HOME_X - machine.carriageCols * LAYOUT.CARRIAGE_UNIT;
    build.refs.platenAction.rotation.x = machine.platenRotation;
    build.refs.ratchetAction.rotation.x = machine.platenRotation;
    build.refs.escapeWheelAction.rotation.z = -machine.escapeWheelAngle;
    build.refs.spoolL.rotation.y = -machine.spoolAngle;
    build.refs.spoolR.rotation.y = machine.spoolAngle;
    build.refs.returnLeverAction.rotation.x = machine.returnLeverPull * 0.55;

    const flash = machine.bellFlash;
    build.refs.bellAction.scale.setScalar(1 + flash * 0.08);

    const tipL = build.refs.ribbonTipL;
    const tipR = build.refs.ribbonTipR;
    tipL.set(-0.8, 13.2 + lift * 0.65, -1.55 - lift * 0.12);
    tipR.set(0.8, 13.2 + lift * 0.65, -1.55 - lift * 0.12);
    stretchRibbon(build.refs.ribbonSideL, new THREE.Vector3(-6.1, 13.2, -1.45), tipL);
    stretchRibbon(build.refs.ribbonSideR, tipR, new THREE.Vector3(6.1, 13.2, -1.45));

    // --- paper feed -----------------------------------------------------------
    const line = manuscript.cursor.line;
    paperLine.current += (line - paperLine.current) * Math.min(1, dtMs / 90);
    if (Math.abs(paperLine.current - line) < 0.002) paperLine.current = line;
    build.refs.updatePaper(paperLine.current);

    // --- cutaway fade -----------------------------------------------------------
    const targetOpacity = state.cutaway ? 0.13 : 1;
    if (Math.abs(materials.enamelPanel.opacity - targetOpacity) > 0.01) {
      materials.enamelPanel.transparent = true;
      materials.enamelPanel.opacity += (targetOpacity - materials.enamelPanel.opacity) * Math.min(1, dtMs / 120);
    }
  });

  return <primitive object={build.root} />;
}
