import { useRef } from "react";
import type * as THREE from "three";

/**
 * Programmatic lighting: one warm key spot with shadows over the machine,
 * a soft fill from camera right, a cool rim from behind and a faint desk
 * glow. No HDRI, no environment maps.
 */
export function Lighting() {
  const keySpot = useRef<THREE.SpotLight>(null);
  return (
    <group>
      <ambientLight intensity={0.5} color={0x4a443a} />
      <spotLight
        ref={keySpot}
        position={[-14.8, 24.9, 2.5]}
        angle={0.72}
        penumbra={0.6}
        intensity={5200}
        color={0xffd9a6}
        castShadow
        shadow-mapSize={[1024, 1024]}
        shadow-bias={-0.0004}
        target-position={[0, 10, 0]}
      />
      <spotLight position={[26, 17, 32]} angle={0.9} penumbra={0.9} intensity={1100} color={0xffe9c9} target-position={[0, 9, 0]} />
      <directionalLight position={[18, 16, -26]} intensity={0.9} color={0xa9bed8} />
      <pointLight position={[0, 26, 30]} intensity={60} color={0x40382c} />
    </group>
  );
}
