import { useMemo } from "react";
import * as THREE from "three";
import { createMaterials } from "./Materials";

/**
 * The exhibition setting: wooden desk slab, dark floor plane and a small
 * banker lamp glowing in the upper-left darkness.
 */
export function DeskScene() {
  const materials = useMemo(() => createMaterials(), []);
  return (
    <group>
      <mesh position={[0, 1.2, 0]} receiveShadow>
        <boxGeometry args={[110, 2.4, 64]} />
        <primitive object={materials.wood} attach="material" />
      </mesh>
      <mesh position={[0, -0.02, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[300, 300]} />
        <meshStandardMaterial color={0x0a0908} roughness={0.95} />
      </mesh>
      <group position={[-24, 2.4, 8]}>
        <mesh position={[0, 1.2, 0]}>
          <cylinderGeometry args={[2.6, 3.2, 2.4, 20]} />
          <meshStandardMaterial color={0x151517} roughness={0.4} metalness={0.7} />
        </mesh>
        <mesh position={[3.5, 12, -2]} rotation={[0, 0, -0.5]}>
          <cylinderGeometry args={[0.35, 0.35, 22, 10]} />
          <meshStandardMaterial color={0x1a1a1d} roughness={0.35} metalness={0.8} />
        </mesh>
        <group position={[9.2, 22.5, -5.5]} rotation={[0.5, 0, -0.35]}>
          <mesh>
            <coneGeometry args={[4.6, 5.5, 24, 1, true]} />
            <meshStandardMaterial color={0x1d1d23} roughness={0.3} metalness={0.85} side={THREE.DoubleSide} />
          </mesh>
          <mesh position={[0, -2, 0]}>
            <sphereGeometry args={[1, 14, 10]} />
            <meshStandardMaterial color={0xffd9a0} emissive={0xffc883} emissiveIntensity={2.6} />
          </mesh>
        </group>
      </group>
    </group>
  );
}
