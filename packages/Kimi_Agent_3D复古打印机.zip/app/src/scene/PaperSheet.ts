import * as THREE from "three";
import { LAYOUT } from "../machine/machineParts";
import type { PaperTexture } from "../document/PaperTexture";

/**
 * The A4 sheet: a 2×73-vertex strip that leaves the print line flat,
 * wraps around the platen and trails behind it. Rewritten per frame with
 * a smoothed line offset so carriage returns roll the sheet visibly.
 */
export function buildPaperSheet(paper: PaperTexture): { mesh: THREE.Mesh; update: (lineOffset: number) => void } {
  const platenR = LAYOUT.PLATEN.r;
  const printPoint = LAYOUT.PRINT_POINT.clone();
  const tilt = THREE.MathUtils.degToRad(12);
  const feedDir = new THREE.Vector3(0, Math.cos(tilt), -Math.sin(tilt));

  const geometry = new THREE.BufferGeometry();
  const positions = new Float32Array(2 * 73 * 3);
  const uvs = new Float32Array(2 * 73 * 2);
  const indices: number[] = [];
  for (let i = 0; i < 72; i++) {
    const a = i * 2;
    indices.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
  }
  geometry.setIndex(indices);
  geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute("uv", new THREE.BufferAttribute(uvs, 2));

  const texture = new THREE.CanvasTexture(paper.canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 4;
  paper.onRepaint = () => {
    texture.needsUpdate = true;
  };

  const material = new THREE.MeshStandardMaterial({ map: texture, side: THREE.DoubleSide, roughness: 0.92, metalness: 0 });
  const mesh = new THREE.Mesh(geometry, material);
  mesh.castShadow = true;
  mesh.receiveShadow = true;

  const update = (lineOffset: number) => {
    const printS = 26.87 - lineOffset * LAYOUT.LINE_FEED;
    const wrapStart = 1.15;
    const wrapEnd = Math.PI + 0.8;
    const wrapLength = platenR * (wrapEnd - wrapStart);
    const posAttr = geometry.getAttribute("position") as THREE.BufferAttribute;
    const uvAttr = geometry.getAttribute("uv") as THREE.BufferAttribute;
    const wrapEndPoint = new THREE.Vector3(
      0,
      LAYOUT.PLATEN.y - platenR * 1.02 * Math.cos(wrapEnd),
      LAYOUT.PLATEN.z + platenR * 1.02 * Math.sin(wrapEnd),
    );
    const wrapEndDir = new THREE.Vector3(0, Math.sin(wrapEnd), Math.cos(wrapEnd)).normalize();

    for (let i = 0; i <= 72; i++) {
      const along = (i / 72) * 29.7;
      for (let j = 0; j <= 1; j++) {
        const across = (j - 0.5) * 21;
        const vi = i * 2 + j;
        uvAttr.setXY(vi, j, along / 29.7);
        let point: THREE.Vector3;
        if (along <= printS) {
          point = printPoint.clone().addScaledVector(feedDir, printS - along);
        } else {
          const past = along - printS;
          if (past <= wrapLength) {
            const angle = wrapStart + past / platenR;
            point = new THREE.Vector3(
              0,
              LAYOUT.PLATEN.y - platenR * 1.02 * Math.cos(angle),
              LAYOUT.PLATEN.z + platenR * 1.02 * Math.sin(angle),
            );
          } else {
            point = wrapEndPoint.clone().addScaledVector(wrapEndDir, past - wrapLength);
          }
        }
        point.x = across;
        posAttr.setXYZ(vi, point.x, point.y, point.z);
      }
    }
    posAttr.needsUpdate = true;
    uvAttr.needsUpdate = true;
    geometry.computeVertexNormals();
    geometry.computeBoundingSphere();
  };

  update(0);
  return { mesh, update };
}
