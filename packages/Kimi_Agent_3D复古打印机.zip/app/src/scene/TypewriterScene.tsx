import * as THREE from "three";
import { Canvas } from "@react-three/fiber";
import { Lighting } from "./Lighting";
import { DeskScene } from "./DeskScene";
import { MachineRig } from "./MachineRig";
import { CameraController } from "./CameraController";
import { PartPicker } from "./PartPicker";

const CAMERA_WRITE_POS: [number, number, number] = [17, 25, 38];

/**
 * Canvas root: ACES tone mapping, warm-black background with fog,
 * software-friendly pixel ratios (1.5 on coarse pointers, 2 on desktop).
 */
export function TypewriterScene() {
  const coarse = typeof window !== "undefined" && window.matchMedia?.("(pointer: coarse)").matches;
  return (
    <Canvas
      shadows={{ type: THREE.PCFShadowMap }}
      dpr={coarse ? [1, 1.5] : [1, 2]}
      camera={{ fov: 38, near: 0.5, far: 400, position: CAMERA_WRITE_POS }}
      gl={{ antialias: true, powerPreference: "high-performance" }}
      onCreated={({ gl, camera }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping;
        gl.toneMappingExposure = 1.3;
        gl.outputColorSpace = THREE.SRGBColorSpace;
        window.__impactGL = gl;
        window.__impactCamera = camera;
      }}
    >
      <color attach="background" args={[0x050505]} />
      <fog attach="fog" args={[0x050505, 90, 220]} />
      <Lighting />
      <DeskScene />
      <MachineRig />
      <CameraController />
      <PartPicker />
    </Canvas>
  );
}
