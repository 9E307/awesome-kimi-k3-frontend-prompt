import { useEffect, useRef } from "react";
import * as THREE from "three";
import { useFrame, useThree } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import { useStore, type CameraMode } from "../app/store";
import { getMachineBuild } from "./machineBuildRegistry";

const VIEWS: Record<CameraMode, { pos: THREE.Vector3; target: THREE.Vector3 }> = {
  write: { pos: new THREE.Vector3(17, 25, 38), target: new THREE.Vector3(0, 10.5, 1) },
  mechanism: { pos: new THREE.Vector3(8.5, 13.5, 13), target: new THREE.Vector3(0, 11.8, -1.8) },
  inspect: { pos: new THREE.Vector3(30, 22, 34), target: new THREE.Vector3(0, 9.5, 0) },
};

/**
 * Camera mode state machine: write / mechanism / inspect with smooth
 * interpolation, portrait re-framing, part focus on selection and orbit
 * controls unlocked in inspect mode.
 */
export function CameraController() {
  const { camera, size } = useThree();
  const controls = useRef<OrbitControlsImpl>(null);
  const mode = useStore((s) => s.cameraMode);
  const selectedPart = useStore((s) => s.selectedPart);
  const desired = useRef({ pos: VIEWS.write.pos.clone(), target: VIEWS.write.target.clone() });
  const transitioning = useRef(false);

  useEffect(() => {
    const view = VIEWS[mode];
    desired.current.pos.copy(view.pos);
    desired.current.target.copy(view.target);
    const aspect = size.width / size.height;
    if (aspect < 1) {
      desired.current.pos.sub(view.target).multiplyScalar(1 / Math.max(0.55, aspect * 0.9)).add(view.target);
    }
    transitioning.current = true;
  }, [mode, size]);

  useEffect(() => {
    if (!selectedPart || mode === "write") return;
    const build = getMachineBuild();
    const part = build?.byId.get(selectedPart);
    if (!part) return;
    const bounds = new THREE.Box3().setFromObject(part.partGroup);
    if (bounds.isEmpty()) return;
    const center = bounds.getCenter(new THREE.Vector3());
    desired.current.target.copy(center);
    const dir = camera.position.clone().sub(center).normalize();
    const distance = Math.max(14, bounds.getSize(new THREE.Vector3()).length() * 2.2);
    desired.current.pos.copy(center).addScaledVector(dir, distance);
    transitioning.current = true;
  }, [selectedPart, mode, camera]);

  useFrame((_, delta) => {
    const c = controls.current;
    if (!c) return;
    const motionReduced = useStore.getState().motionReduced;
    c.enableRotate = mode === "inspect";
    c.enablePan = mode === "inspect";
    c.enableZoom = true;
    if (transitioning.current) {
      const t = motionReduced ? 1 : Math.min(1, delta * 3.2);
      camera.position.lerp(desired.current.pos, t);
      c.target.lerp(desired.current.target, t);
      if (camera.position.distanceTo(desired.current.pos) < 0.08 && c.target.distanceTo(desired.current.target) < 0.08) {
        transitioning.current = false;
      }
    }
    c.update();
  });

  return (
    <OrbitControls
      ref={controls}
      makeDefault
      enableDamping
      dampingFactor={0.08}
      minDistance={12}
      maxDistance={85}
      minPolarAngle={0.12}
      maxPolarAngle={1.42}
      target={VIEWS.write.target.toArray()}
    />
  );
}
