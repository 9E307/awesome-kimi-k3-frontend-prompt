import type { MachineBuild } from "../machine/buildMachine";

/**
 * The machine build is created once inside the Canvas tree but is needed
 * by UI code outside it (part cards, trace, camera focus). A tiny module
 * registry avoids prop drilling and global window fields.
 */
let current: MachineBuild | null = null;

export function setMachineBuild(build: MachineBuild): void {
  current = build;
}

export function getMachineBuild(): MachineBuild | null {
  return current;
}
