import * as THREE from "three";

/**
 * Procedural materials. No external textures — the desk wood grain is a
 * deterministic canvas, everything else is MeshStandardMaterial.
 */

export interface MachineMaterials {
  enamel: THREE.MeshStandardMaterial;
  enamelPanel: THREE.MeshStandardMaterial;
  nickel: THREE.MeshStandardMaterial;
  steelDark: THREE.MeshStandardMaterial;
  brass: THREE.MeshStandardMaterial;
  keyRim: THREE.MeshStandardMaterial;
  keyTop: THREE.MeshStandardMaterial;
  rubber: THREE.MeshStandardMaterial;
  ribbon: THREE.MeshStandardMaterial;
  bellMetal: THREE.MeshStandardMaterial;
  wood: THREE.MeshStandardMaterial;
  felt: THREE.MeshStandardMaterial;
  paperEdge: THREE.MeshStandardMaterial;
}

function woodTexture(): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext("2d")!;
  ctx.fillStyle = "#241a11";
  ctx.fillRect(0, 0, 512, 512);
  let seed = 3;
  const rand = () => ((seed = (seed * 16807) % 2147483647), seed / 2147483647);
  for (let i = 0; i < 90; i++) {
    const y = rand() * 512;
    const width = 0.6 + rand() * 2.2;
    const tone = 18 + rand() * 30;
    ctx.strokeStyle = `rgba(${tone + 20}, ${tone + 8}, ${tone * 0.5}, ${0.25 + rand() * 0.3})`;
    ctx.lineWidth = width;
    ctx.beginPath();
    ctx.moveTo(0, y);
    for (let x = 0; x <= 512; x += 32) ctx.lineTo(x, y + Math.sin(x * 0.02 + i) * 3 * rand());
    ctx.stroke();
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(3, 2);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export function createMaterials(): MachineMaterials {
  return {
    enamel: new THREE.MeshStandardMaterial({ color: 0x111114, roughness: 0.58, metalness: 0.35 }),
    enamelPanel: new THREE.MeshStandardMaterial({ color: 0x141417, roughness: 0.52, metalness: 0.4 }),
    nickel: new THREE.MeshStandardMaterial({ color: 0xc9c5bc, roughness: 0.3, metalness: 0.92 }),
    steelDark: new THREE.MeshStandardMaterial({ color: 0x5f6266, roughness: 0.45, metalness: 0.88 }),
    brass: new THREE.MeshStandardMaterial({ color: 0xa8894f, roughness: 0.38, metalness: 0.9 }),
    keyRim: new THREE.MeshStandardMaterial({ color: 0x1b1b1e, roughness: 0.35, metalness: 0.7 }),
    keyTop: new THREE.MeshStandardMaterial({ color: 0xe9e0c8, roughness: 0.18, metalness: 0.05 }),
    rubber: new THREE.MeshStandardMaterial({ color: 0x26262a, roughness: 0.93, metalness: 0 }),
    ribbon: new THREE.MeshStandardMaterial({ color: 0x17141a, roughness: 0.86, metalness: 0, side: THREE.DoubleSide }),
    bellMetal: new THREE.MeshStandardMaterial({ color: 0xd3c184, roughness: 0.25, metalness: 0.95 }),
    wood: new THREE.MeshStandardMaterial({ map: woodTexture(), roughness: 0.82, metalness: 0 }),
    felt: new THREE.MeshStandardMaterial({ color: 0x3a2f2a, roughness: 0.98, metalness: 0 }),
    paperEdge: new THREE.MeshStandardMaterial({ color: 0xe7dfcc, roughness: 0.9, metalness: 0 }),
  };
}
