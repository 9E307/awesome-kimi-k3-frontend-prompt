import {
  CARRIAGE_RETURN_MS,
  CLASH_DELAY_MS,
  CLASH_WINDOW_MS,
  EXPLODE_TYPE_THRESHOLD,
  IMPACT_MS,
  LEFT_MARGIN,
  RIGHT_MARGIN,
  RIBBON_REVERSE_CHARS,
  RIBBON_STEP,
  SPOOL_STEP,
  STRIKE_MIN_GAP_MS,
  TYPEBAR_ROUND_TRIP_MS,
} from "../document/constants";
import { EventBus } from "../document/EventBus";
import type { Manuscript } from "../document/Manuscript";
import {
  adjacentTypebars,
  IME_TYPEBAR,
  KEY_BY_CODE,
  resolveChar,
} from "./keyboardLayout";
import { clamp01, easeInOutQuad, easeInQuad, easeOutQuad } from "./animations";

export type ActorKind = "char" | "space" | "backspace" | "tab";

export interface Actor {
  id: number;
  code: string;
  kind: ActorKind;
  char: string | null;
  typebar: number;
  /** Scheduled start on the machine clock (ms). */
  start: number;
  impacted: boolean;
  applied: boolean;
  linked: boolean;
  escaped: boolean;
  rested: boolean;
  clashDelayed: boolean;
  viaUnicodeAdapter: boolean;
}

interface QueuedKey {
  code: string;
  kind: ActorKind;
  char: string | null;
  typebar: number;
  viaUnicodeAdapter: boolean;
}

export interface PressOptions {
  repeat?: boolean;
  key?: string;
  shiftKey?: boolean;
  viaAdapter?: boolean;
}

interface CarriageAnim {
  from: number;
  to: number;
  start: number;
  dur: number;
}

interface ReturnAnim {
  start: number;
  docApplied: boolean;
}

/**
 * The machine: keystroke actors, timing curves, escapement, carriage,
 * ribbon, shift basket and the mechanical carriage return. Runs on its own
 * millisecond clock, advanced by the render loop (scaled for slow motion).
 */
export class MachineState {
  readonly manuscript: Manuscript;
  readonly bus = new EventBus();

  now = 0;
  timeScale = 1;
  paused = false;

  actors: Actor[] = [];
  pressed = new Set<string>();
  capsLock = false;
  explode = 0;

  carriageCols = LEFT_MARGIN;
  basketShift = 0;
  platenRotation = 0;
  ribbonAngle = 0;
  ribbonDirection = 1;
  escapeWheelAngle = 0;
  returnLeverPull = 0;
  bellFlash = 0;

  private carriageTarget = LEFT_MARGIN;
  private carriageAnim: CarriageAnim | null = null;
  private returnAnim: ReturnAnim | null = null;
  private shiftTarget = 0;
  private shiftDownCount = 0;
  private actorId = 1;
  private ribbonCharsSinceReverse = 0;
  private bellFlashUntil = 0;
  private escapeWheelTarget = 0;
  private platenBase = 0;
  private readonly platenStep = 0.28;
  /**
   * Undo/redo requests run through the same queue as keystrokes, so a
   * history op never lands between an accepted keystroke and its
   * committed glyph (which previously corrupted the redo stack).
   */
  private historyOps: Array<"undo" | "redo"> = [];
  /**
   * Reliable FIFO for committed IME text. The whole commit is banked here
   * atomically BEFORE any mechanics run; the machine then serves exactly
   * one character per completed IME typebar round trip (see pumpUnicode).
   * New commits append to the tail; spaces, newlines and page feeds are
   * processed in order. Text in this queue can never be lost by frame
   * throttling, slow clocks or actor-scheduler bookkeeping.
   */
  private pendingUnicode: string[] = [];
  /** The IME actor currently in flight (null once it has rested). */
  private imeActor: Actor | null = null;

  constructor(manuscript: Manuscript) {
    this.manuscript = manuscript;
    this.manuscript.bus.on("bell", () => this.ringBell());
  }

  get shiftEngaged(): boolean {
    return this.shiftDownCount > 0 || this.capsLock;
  }

  get returnInProgress(): boolean {
    return this.returnAnim !== null;
  }

  get canType(): boolean {
    return this.explode <= EXPLODE_TYPE_THRESHOLD;
  }

  /** Column the cursor will occupy once all queued actors have escaped. */
  projectedCol(): number {
    let col = this.manuscript.cursor.col;
    for (const actor of this.actors) {
      if (actor.impacted || actor.escaped) continue;
      if (actor.kind === "char" || actor.kind === "space") col++;
      else if (actor.kind === "backspace") col = Math.max(LEFT_MARGIN, col - 1);
      else if (actor.kind === "tab") col = Math.min(RIGHT_MARGIN, (Math.floor(col / 8) + 1) * 8);
    }
    return col;
  }

  press(code: string, options: PressOptions = {}): boolean {
    if (options.repeat) return false;
    if (code === "CapsLock") {
      if (this.canType) {
        this.capsLock = !this.capsLock;
        this.bus.emit("shiftChange", { engaged: this.shiftEngaged });
      }
      return this.canType;
    }
    if (!this.canType) {
      this.bus.emit("rejected", { reason: "exploded" });
      return false;
    }
    const def = KEY_BY_CODE[code];
    if (!def) return false;
    this.pressed.add(code);
    switch (def.kind) {
      case "shift":
        this.shiftDownCount++;
        this.bus.emit("shiftChange", { engaged: this.shiftEngaged });
        return true;
      case "space":
        return this.enqueueActor({ code, kind: "space", char: null, typebar: -1, viaUnicodeAdapter: false }) !== null;
      case "backspace":
        return this.enqueueActor({ code, kind: "backspace", char: null, typebar: -1, viaUnicodeAdapter: false }) !== null;
      case "tab":
        return this.enqueueActor({ code, kind: "tab", char: null, typebar: -1, viaUnicodeAdapter: false }) !== null;
      case "char": {
        let char = resolveChar(def, this.shiftDownCount > 0 || options.shiftKey === true, this.capsLock);
        if (!char) return false;
        const raw = options.key;
        if (raw && raw.length === 1 && raw !== char && (raw === def.lower || raw === def.upper)) char = raw;
        return this.enqueueActor({ code, kind: "char", char, typebar: def.typebar, viaUnicodeAdapter: options.viaAdapter === true }) !== null;
      }
    }
  }

  /**
   * Routes committed IME text through the fictional Unicode adapter bar.
   * The commit is first banked ATOMICALLY in the reliable FIFO — never
   * burst-scheduled into the actor queue — so any length of text survives
   * regardless of mechanical pacing. The machine then types it out one
   * character at a time; returns true once the text is safely queued.
   */
  pressUnicode(text: string): boolean {
    if (!this.canType) {
      this.bus.emit("rejected", { reason: "exploded" });
      return false;
    }
    const chars = Array.from(text.replace(/\r\n?/g, "\n"));
    if (chars.length === 0) return false;
    this.pendingUnicode.push(...chars);
    this.pumpUnicode();
    return true;
  }

  /** Number of committed characters still waiting for the adapter bar. */
  get pendingUnicodeCount(): number {
    return this.pendingUnicode.length;
  }

  /** Drops un-typed adapter text (used when the manuscript is wiped). */
  clearPendingUnicode(): void {
    this.pendingUnicode.length = 0;
  }

  /**
   * Cancels keystroke actors that have not yet impacted, so a wipe or
   * bulk reload never sees ghost characters land on the fresh sheet.
   * Actors that already struck the paper finish their return trip.
   */
  cancelInFlight(): void {
    this.actors = this.actors.filter((a) => a.impacted);
    if (this.imeActor && !this.imeActor.impacted) this.imeActor = null;
  }

  /**
   * Serves the Unicode FIFO one character at a time: the next character
   * is scheduled only after the previous IME typebar has completed its
   * full round trip and any carriage return has finished. Margin and
   * page-full stops report the exact number of unaccepted characters —
   * nothing is ever dropped silently.
   */
  private pumpUnicode(): void {
    if (this.pendingUnicode.length === 0) return;
    if (this.imeActor) {
      if (!this.imeActor.rested) return; // adapter bar still travelling
      this.imeActor = null;
    }
    if (this.returnAnim) return; // carriage mid-return: queue waits in order
    if (!this.canType) return; // exploded: text stays banked, resumes later

    const char = this.pendingUnicode[0];
    if (char === "\n") {
      this.pendingUnicode.shift();
      this.carriageReturn();
      return;
    }
    if (char === "\f") {
      this.pendingUnicode.shift();
      this.newSheet();
      return;
    }
    if (this.manuscript.pageFull) {
      this.rejectPendingUnicode("pageFull");
      return;
    }
    if (this.projectedCol() >= RIGHT_MARGIN && !this.manuscript.autoReturn) {
      this.rejectPendingUnicode("margin");
      return;
    }

    this.pendingUnicode.shift();
    const key: QueuedKey =
      char === " "
        ? { code: "Space", kind: "space", char: null, typebar: -1, viaUnicodeAdapter: true }
        : { code: "IME", kind: "char", char, typebar: IME_TYPEBAR, viaUnicodeAdapter: true };
    const actor = this.enqueueActor(key);
    if (!actor) {
      // enqueue's own margin/pageFull double-guard refused: count this
      // character plus everything still queued as unaccepted.
      this.rejectPendingUnicode(this.manuscript.pageFull ? "pageFull" : "margin", 1);
      return;
    }
    this.imeActor = actor;
  }

  /** Emits a loud, counted rejection for adapter text that cannot land. */
  private rejectPendingUnicode(reason: "pageFull" | "margin", extra = 0): void {
    const count = this.pendingUnicode.length + extra;
    this.pendingUnicode.length = 0;
    if (reason === "margin") this.ringBell();
    this.bus.emit("rejected", { reason, dropped: count });
    this.bus.emit("unicodeRejected", { reason, count });
  }

  release(code: string): void {
    this.pressed.delete(code);
    const def = KEY_BY_CODE[code];
    if (def?.kind === "shift") {
      this.shiftDownCount = Math.max(0, this.shiftDownCount - 1);
      this.bus.emit("shiftChange", { engaged: this.shiftEngaged });
    }
  }

  releaseAll(): void {
    this.pressed.clear();
    if (this.shiftDownCount > 0) {
      this.shiftDownCount = 0;
      this.bus.emit("shiftChange", { engaged: this.shiftEngaged });
    }
  }

  carriageReturn(): boolean {
    if (!this.canType) {
      this.bus.emit("rejected", { reason: "exploded" });
      return false;
    }
    if (this.returnAnim) return false;
    this.returnAnim = { start: this.now, docApplied: false };
    this.bus.emit("carriageReturnStart", {});
    return true;
  }

  newSheet(): boolean {
    const result = this.manuscript.apply({ type: "NEW_SHEET", timestamp: this.now });
    if (result.accepted) this.bus.emit("paperFeed", {});
    return result.accepted;
  }

  setExplode(value: number): void {
    this.explode = value;
  }

  private enqueueActor(key: QueuedKey): Actor | null {
    if (key.kind === "char" || key.kind === "space") {
      if (this.manuscript.pageFull) {
        this.bus.emit("rejected", { reason: "pageFull", dropped: 1 });
        return null;
      }
      if (this.projectedCol() >= RIGHT_MARGIN && !this.manuscript.autoReturn) {
        this.bus.emit("rejected", { reason: "margin", dropped: 1 });
        this.ringBell();
        return null;
      }
    }
    let start = this.now;
    // Keystrokes queued during a carriage return land after it completes.
    if (this.returnAnim) start = this.returnAnim.start + CARRIAGE_RETURN_MS;

    // Serial strike order: the escapement releases one tooth at a time, so
    // keystrokes strike strictly in press order — a later key never lands
    // before an earlier one that is still waiting for its strike.
    let lastStrike = Number.NEGATIVE_INFINITY;
    for (const other of this.actors) {
      if (!other.impacted && other.start > lastStrike) lastStrike = other.start;
    }
    if (lastStrike !== Number.NEGATIVE_INFINITY && start < lastStrike + STRIKE_MIN_GAP_MS) {
      start = lastStrike + STRIKE_MIN_GAP_MS;
    }

    // Typebar clash detection: same or adjacent bar inside the collision
    // window gets staggered; the character is never dropped.
    let clashed = false;
    if (key.typebar >= 0) {
      for (let attempt = 0; attempt < 4; attempt++) {
        let pushed = false;
        for (const other of this.actors) {
          if (other.typebar < 0) continue;
          const same = other.typebar === key.typebar;
          const near = !same && adjacentTypebars(key.typebar).includes(other.typebar);
          if (!same && !near) continue;
          if (start < other.start + CLASH_WINDOW_MS && start + CLASH_WINDOW_MS > other.start) {
            const delayed = other.start + CLASH_DELAY_MS;
            if (delayed > start) {
              start = delayed;
              pushed = true;
              clashed = true;
            }
          }
        }
        if (!pushed) break;
      }
    }

    const actor: Actor = {
      id: this.actorId++,
      code: key.code,
      kind: key.kind,
      char: key.char,
      typebar: key.typebar,
      start,
      impacted: false,
      applied: false,
      linked: false,
      escaped: false,
      rested: false,
      clashDelayed: clashed,
      viaUnicodeAdapter: key.viaUnicodeAdapter,
    };
    this.actors.push(actor);
    if (clashed) this.bus.emit("clash", { code: key.code, delayMs: CLASH_DELAY_MS });
    if (start <= this.now) this.bus.emit("keyTravel", { code: key.code, kind: key.kind });
    return actor;
  }

  ringBell(): void {
    this.bellFlashUntil = this.now + 600;
    this.bus.emit("bell", {});
  }

  update(deltaMs: number): void {
    if (this.paused) return;
    const dt = Math.min(deltaMs, 100) * this.timeScale;
    this.now += dt;

    // --- Carriage return sequence (~720ms) -------------------------------
    if (this.returnAnim) {
      const t = clamp01((this.now - this.returnAnim.start) / CARRIAGE_RETURN_MS);
      this.returnLeverPull = t < 0.25 ? easeOutQuad(t / 0.25) : t > 0.55 ? Math.max(0, 1 - (t - 0.55) / 0.3) : 1;
      if (t >= 0.2 && t < 0.7) {
        const fly = easeInOutQuad((t - 0.2) / 0.5);
        this.carriageCols = this.carriageTarget + (LEFT_MARGIN - this.carriageTarget) * fly;
      }
      if (t >= 0.6 && t < 1) {
        const roll = easeOutQuad((t - 0.6) / 0.4);
        this.platenRotation = this.platenBase + roll * this.platenStep;
      }
      if (t >= 0.65 && !this.returnAnim.docApplied) {
        this.returnAnim.docApplied = true;
        const result = this.manuscript.apply({ type: "CARRIAGE_RETURN", timestamp: this.now });
        this.carriageTarget = LEFT_MARGIN;
        this.carriageCols = LEFT_MARGIN;
        this.platenBase += this.platenStep;
        if (result.blockedByPageFull) this.platenBase -= this.platenStep;
      }
      if (t >= 1) {
        this.returnLeverPull = 0;
        this.returnAnim = null;
        this.bus.emit("carriageReturnDone", { pageFull: this.manuscript.pageFull });
      }
    }

    // --- Actor timeline ----------------------------------------------------
    for (const actor of this.actors) {
      const elapsed = this.now - actor.start;
      if (elapsed < 0) continue;
      if (!actor.linked && elapsed >= 20 && actor.typebar >= 0) {
        actor.linked = true;
        this.bus.emit("linkage", { code: actor.code, typebar: actor.typebar });
      }
      if (!actor.impacted && elapsed >= IMPACT_MS) {
        actor.impacted = true;
        this.onImpact(actor);
      }
      if (!actor.escaped && elapsed >= 120) {
        actor.escaped = true;
        this.onEscape(actor);
      }
      if (!actor.rested && elapsed >= TYPEBAR_ROUND_TRIP_MS) {
        actor.rested = true;
        if (actor.typebar >= 0) this.bus.emit("typebarRest", { code: actor.code, typebar: actor.typebar });
      }
    }
    if (this.actors.length > 64 || (this.actors.length > 0 && this.actors[0].rested)) {
      this.actors = this.actors.filter((a) => !a.rested || this.now - a.start < TYPEBAR_ROUND_TRIP_MS + 400);
    }

    // Serve the reliable Unicode FIFO — one character per completed
    // typebar trip. Safe under background throttling and slow frames:
    // un-served text simply waits in the queue, it cannot be lost.
    this.pumpUnicode();

    // Queued history ops apply only once the machine is mechanically idle
    // AND the Unicode FIFO has fully landed, keeping document state and
    // undo/redo stacks atomically consistent and predictable.
    if (this.historyOps.length > 0 && !this.returnAnim && !this.hasPendingActors && this.pendingUnicode.length === 0) {
      const ops = this.historyOps.splice(0);
      for (const op of ops) {
        if (op === "undo") this.manuscript.undo();
        else this.manuscript.redo();
      }
    }

    // --- Shift basket ------------------------------------------------------
    this.shiftTarget = this.shiftEngaged ? 1 : 0;
    const shiftStep = dt / 120;
    if (this.basketShift < this.shiftTarget) this.basketShift = Math.min(this.shiftTarget, this.basketShift + shiftStep);
    else if (this.basketShift > this.shiftTarget) this.basketShift = Math.max(this.shiftTarget, this.basketShift - shiftStep);

    // --- Carriage stepper ---------------------------------------------------
    if (this.carriageAnim) {
      const t = clamp01((this.now - this.carriageAnim.start) / this.carriageAnim.dur);
      this.carriageCols = this.carriageAnim.from + (this.carriageAnim.to - this.carriageAnim.from) * easeOutQuad(t);
      if (t >= 1) this.carriageAnim = null;
    }

    this.escapeWheelAngle += (this.escapeWheelTarget - this.escapeWheelAngle) * Math.min(1, dt / 60);
    this.bellFlash = this.now < this.bellFlashUntil ? 1 : Math.max(0, this.bellFlash - dt / 300);
  }

  private onImpact(actor: Actor): void {
    if (actor.kind === "char" && actor.char !== null) {
      const result = this.manuscript.apply({
        type: "TYPE_CHAR",
        char: actor.char,
        code: actor.code,
        timestamp: this.now,
        viaUnicodeAdapter: actor.viaUnicodeAdapter,
      });
      actor.applied = result.accepted;
      if (result.accepted) {
        this.bus.emit("impact", {
          char: actor.char,
          code: actor.code,
          typebar: actor.typebar,
          viaUnicodeAdapter: actor.viaUnicodeAdapter,
        });
      } else if (result.blockedByMargin) {
        this.bus.emit("rejected", { reason: "margin" });
      } else if (result.blockedByPageFull) {
        this.bus.emit("rejected", { reason: "pageFull" });
      }
    } else if (actor.kind === "space") {
      const result = this.manuscript.apply({ type: "SPACE", timestamp: this.now });
      actor.applied = result.accepted;
      if (!result.accepted && result.blockedByMargin) this.bus.emit("rejected", { reason: "margin" });
    }
  }

  private onEscape(actor: Actor): void {
    switch (actor.kind) {
      case "char":
        if (!actor.applied) return;
        this.releaseEscapement(1);
        break;
      case "space":
        if (actor.applied) this.releaseEscapement(1);
        break;
      case "backspace": {
        const result = this.manuscript.apply({ type: "BACKSPACE", timestamp: this.now });
        if (result.accepted) this.releaseEscapement(-1);
        break;
      }
      case "tab": {
        const before = this.manuscript.cursor.col;
        const result = this.manuscript.apply({ type: "TAB", timestamp: this.now });
        if (result.accepted) this.releaseEscapement(this.manuscript.cursor.col - before);
        break;
      }
    }
  }

  private releaseEscapement(teeth: number): void {
    if (teeth === 0) return;
    this.bus.emit("escapement", { kind: teeth > 0 ? "char" : "backspace" });
    this.escapeWheelTarget += teeth * 0.35;
    const from = this.carriageCols;
    const to = Math.max(LEFT_MARGIN, Math.min(RIGHT_MARGIN, this.carriageTarget + teeth));
    this.carriageTarget = to;
    this.carriageAnim = { from, to, start: this.now, dur: 110 };
    if (teeth > 0) {
      this.ribbonAngle += RIBBON_STEP * this.ribbonDirection;
      this.ribbonCharsSinceReverse++;
      if (this.ribbonCharsSinceReverse > RIBBON_REVERSE_CHARS) {
        this.ribbonDirection *= -1;
        this.ribbonCharsSinceReverse = 0;
      }
    }
  }

  // --- Pose queries used by the renderer -----------------------------------

  keyDip(code: string): number {
    let dip = 0;
    for (const actor of this.actors) {
      if (actor.code !== code) continue;
      const elapsed = this.now - actor.start;
      if (elapsed < 0) continue;
      let v: number;
      if (elapsed < 35) v = easeOutQuad(elapsed / 35);
      else if (elapsed < 115) v = 1;
      else if (elapsed < 210) v = 1 - easeInOutQuad((elapsed - 115) / 95);
      else v = 0;
      dip = Math.max(dip, v);
    }
    return dip;
  }

  typebarSwing(typebar: number): number {
    let swing = 0;
    for (const actor of this.actors) {
      if (actor.typebar !== typebar) continue;
      const elapsed = this.now - actor.start;
      if (elapsed < 20) continue;
      let v: number;
      if (elapsed < 100) v = easeInQuad((elapsed - 20) / 80) * 1.08;
      else if (elapsed < 115) v = 1.08 - 0.08 * easeOutQuad((elapsed - 100) / 15);
      else if (elapsed < 210) v = 1 - easeInOutQuad((elapsed - 115) / 95);
      else v = 0;
      swing = Math.max(swing, v);
    }
    return swing;
  }

  vibratorLift(): number {
    let lift = 0;
    for (const actor of this.actors) {
      if (actor.typebar < 0) continue;
      const elapsed = this.now - actor.start;
      let v = 0;
      if (elapsed >= 55 && elapsed < 100) v = easeOutQuad((elapsed - 55) / 45);
      else if (elapsed >= 100 && elapsed < 130) v = 1;
      else if (elapsed >= 130 && elapsed < 175) v = 1 - easeInQuad((elapsed - 130) / 45);
      lift = Math.max(lift, v);
    }
    return lift;
  }

  universalBarDip(): number {
    for (const actor of this.actors) {
      const elapsed = this.now - actor.start;
      if (elapsed >= 30 && elapsed < 120) return 1;
    }
    return 0;
  }

  get spoolAngle(): number {
    return this.ribbonAngle * (SPOOL_STEP / RIBBON_STEP);
  }

  get jamActive(): boolean {
    const now = this.now;
    return this.actors.some((a) => a.clashDelayed && now - a.start < 200);
  }

  /** True while any accepted keystroke is still travelling mechanically. */
  get hasPendingActors(): boolean {
    return this.actors.some((a) => !a.rested);
  }

  /**
   * True while the machine cannot instantly reflect a new user action:
   * a carriage return is flying, typebars are travelling, or committed
   * adapter text is still waiting in the reliable FIFO.
   */
  get machineBusy(): boolean {
    return this.returnInProgress || this.hasPendingActors || this.pendingUnicode.length > 0;
  }

  /** True while undo/redo requests are queued waiting for the machine. */
  get historyPending(): boolean {
    return this.historyOps.length > 0;
  }

  /** Queued history ops, exposed for UI feedback (read-only copy). */
  get pendingHistoryOps(): ReadonlyArray<"undo" | "redo"> {
    return this.historyOps;
  }

  /** Serializes history ops with in-flight keystrokes; applied in update(). */
  requestHistoryOp(op: "undo" | "redo"): void {
    this.historyOps.push(op);
  }
}
