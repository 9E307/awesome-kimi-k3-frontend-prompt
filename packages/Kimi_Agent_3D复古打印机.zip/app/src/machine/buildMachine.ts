import * as THREE from "three";
import { IME_TYPEBAR, KEYS, TYPEBAR_COUNT } from "./keyboardLayout";
import {
  box,
  capturePose,
  keyPosition,
  keycapTexture,
  LAYOUT,
  rodBetween,
  slugTexture,
  type BuiltPart,
  type PartDef,
} from "./machineParts";
import type { MachineMaterials } from "../scene/Materials";
import { buildPaperSheet } from "../scene/PaperSheet";
import type { PaperTexture } from "../document/PaperTexture";
import type { Pose } from "./animations";

/**
 * Procedural machine builder. Every functional group becomes a registered
 * part with assembled/exploded poses, stagger and transmission metadata,
 * so the explode view, cutaway, raycast picking and slow-motion trace all
 * share one source of truth.
 */

export interface KeyActions {
  cap: THREE.Group;
  lever: THREE.Group | null;
}

export interface MachineRefs {
  basketGroup: THREE.Group;
  carriageGroup: THREE.Group;
  keyActions: Map<string, KeyActions>;
  typebarActions: THREE.Group[];
  typebarRestAngles: number[];
  typebarStrikeAngles: number[];
  universalBarAction: THREE.Group;
  vibratorAction: THREE.Group;
  spoolL: THREE.Group;
  spoolR: THREE.Group;
  escapeWheelAction: THREE.Group;
  platenAction: THREE.Group;
  ratchetAction: THREE.Group;
  returnLeverAction: THREE.Group;
  bellAction: THREE.Group;
  ribbonSideL: THREE.Mesh;
  ribbonSideR: THREE.Mesh;
  ribbonTipL: THREE.Vector3;
  ribbonTipR: THREE.Vector3;
  paperMesh: THREE.Mesh;
  updatePaper: (lineOffset: number) => void;
}

export interface MachineBuild {
  root: THREE.Group;
  parts: BuiltPart[];
  byId: Map<string, BuiltPart>;
  refs: MachineRefs;
}

type PartContentBuilder = (group: THREE.Group) => THREE.Group | null;

export function buildMachine(materials: MachineMaterials, paper: PaperTexture): MachineBuild {
  const root = new THREE.Group();
  const parts: BuiltPart[] = [];
  const byId = new Map<string, BuiltPart>();

  function addPart(parent: THREE.Group, def: PartDef, build: PartContentBuilder): { partGroup: THREE.Group; action: THREE.Group | null } {
    const partGroup = new THREE.Group();
    parent.add(partGroup);
    const action = build(partGroup);
    const assembled = capturePose(partGroup);
    const off = def.offset;
    const exploded: Pose = {
      px: assembled.px + (off.px ?? 0),
      py: assembled.py + (off.py ?? 0),
      pz: assembled.pz + (off.pz ?? 0),
      rx: assembled.rx + (off.rx ?? 0),
      ry: assembled.ry + (off.ry ?? 0),
      rz: assembled.rz + (off.rz ?? 0),
    };
    const part: BuiltPart = {
      id: def.id,
      label: def.label,
      fn: def.fn,
      system: def.system,
      stagger: def.stagger,
      parentId: def.parentId ?? null,
      cutawayFade: def.cutawayFade === true,
      upstream: def.upstream ?? [],
      downstream: def.downstream ?? [],
      partGroup,
      assembled,
      exploded,
    };
    partGroup.traverse((obj) => {
      obj.userData.partId = def.id;
    });
    parts.push(part);
    byId.set(def.id, part);
    return { partGroup, action };
  }

  const basketGroup = new THREE.Group();
  root.add(basketGroup);
  const carriageGroup = new THREE.Group();
  root.add(carriageGroup);

  const refs: MachineRefs = {
    basketGroup,
    carriageGroup,
    keyActions: new Map(),
    typebarActions: [],
    typebarRestAngles: [],
    typebarStrikeAngles: [],
    universalBarAction: new THREE.Group(),
    vibratorAction: new THREE.Group(),
    spoolL: new THREE.Group(),
    spoolR: new THREE.Group(),
    escapeWheelAction: new THREE.Group(),
    platenAction: new THREE.Group(),
    ratchetAction: new THREE.Group(),
    returnLeverAction: new THREE.Group(),
    bellAction: new THREE.Group(),
    ribbonSideL: new THREE.Mesh(),
    ribbonSideR: new THREE.Mesh(),
    ribbonTipL: new THREE.Vector3(),
    ribbonTipR: new THREE.Vector3(),
    paperMesh: new THREE.Mesh(),
    updatePaper: () => {},
  };

  // ---------------------------------------------------------------- keyboard
  const rimGeo = new THREE.CylinderGeometry(0.85, 0.92, 0.55, 24);
  const topGeo = new THREE.CylinderGeometry(0.68, 0.68, 0.1, 24);
  const labelGeo = new THREE.PlaneGeometry(1.15, 1.15);

  for (const key of KEYS) {
    const pos = keyPosition(key);
    const stagger = 0 + key.row * 0.012;
    const { action } = addPart(root, {
      id: `key.${key.code}`,
      label: `${key.labelTop || key.code} keycap`,
      fn:
        key.kind === "char"
          ? "Finger key: starts the strike chain"
          : key.kind === "space"
            ? "Spacebar: escapement only, no typebar"
            : key.kind === "backspace"
              ? "Backspace key: drives the pawl back"
              : key.kind === "shift"
                ? "Shift key: lifts the whole type basket"
                : "Tab key: releases carriage to next stop",
      system: "keyboard",
      stagger,
      offset: { pz: 5.5 + key.row * 1.4, py: -2.2 - key.row * 0.9 },
      downstream: [`lever.${key.code}`],
    }, (group) => {
      group.position.copy(pos);
      const content = new THREE.Group();
      group.add(content);
      const rim = new THREE.Mesh(rimGeo, materials.keyRim);
      if (key.w > 1.3) {
        rim.scale.x = key.w * LAYOUT.KEY_UNIT - 0.6;
        rim.scale.z = 0.75;
      }
      rim.position.y = 0.28;
      rim.castShadow = true;
      content.add(rim);
      const top = new THREE.Mesh(topGeo, materials.keyTop);
      top.scale.x = rim.scale.x * 0.92;
      top.scale.z = rim.scale.z * 0.92;
      top.position.y = 0.56;
      content.add(top);
      if (key.labelTop || key.labelBottom) {
        const label = new THREE.Mesh(labelGeo, new THREE.MeshBasicMaterial({ map: keycapTexture(key.labelTop, key.labelBottom), transparent: true }));
        label.scale.x = top.scale.x;
        label.scale.z = top.scale.z;
        label.rotation.x = -Math.PI / 2;
        label.position.y = 0.62;
        content.add(label);
      }
      return content;
    });
    refs.keyActions.set(key.code, { cap: action!, lever: null });
  }

  // ------------------------------------------------------------------ levers
  for (const key of KEYS) {
    const keyPos = keyPosition(key);
    const isChar = key.kind === "char";
    const { action } = addPart(root, {
      id: `lever.${key.code}`,
      label: `${key.labelTop || key.code} key lever`,
      fn: "Key lever: turns finger force around the pivot rod",
      system: "levers",
      stagger: 0.14 + key.row * 0.012,
      offset: { py: -4.2, pz: 1.6 },
      upstream: [`key.${key.code}`],
      downstream: isChar ? [`link.${key.code}`] : key.kind === "space" ? ["universalBar"] : [],
    }, (group) => {
      group.position.set(keyPos.x, LAYOUT.LEVER_PIVOT.y, LAYOUT.LEVER_PIVOT.z);
      const content = new THREE.Group();
      group.add(content);
      const toward = new THREE.Vector3(0, keyPos.y - 0.7 - LAYOUT.LEVER_PIVOT.y, keyPos.z - LAYOUT.LEVER_PIVOT.z);
      const arm = rodBetween(new THREE.Vector3(0, 0, 0), toward, 0.09, materials.steelDark);
      arm.castShadow = true;
      content.add(arm);
      const tail = rodBetween(new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, 0.18, -1.9), 0.09, materials.steelDark);
      content.add(tail);
      const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.5, 12), materials.nickel);
      collar.rotation.z = Math.PI / 2;
      content.add(collar);
      return content;
    });
    refs.keyActions.get(key.code)!.lever = action;
  }

  addPart(root, {
    id: "frame.pivotRod",
    label: "Key lever pivot rod",
    fn: "Common axle every key lever swings on",
    system: "frame",
    stagger: 0.86,
    offset: { py: -2.5, pz: -1.5 },
  }, (group) => {
    group.position.set(0, LAYOUT.LEVER_PIVOT.y, LAYOUT.LEVER_PIVOT.z);
    const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 31, 12), materials.nickel);
    rod.rotation.z = Math.PI / 2;
    group.add(rod);
    return null;
  });

  // ----------------------------------------------------------------- typebars
  const barAngle = (index: number): number =>
    index === IME_TYPEBAR
      ? THREE.MathUtils.degToRad(14)
      : THREE.MathUtils.degToRad(20 + (index * 140) / (TYPEBAR_COUNT - 1));

  const barPivot = (index: number): THREE.Vector3 => {
    const angle = barAngle(index);
    return new THREE.Vector3(
      LAYOUT.SEGMENT.cx + LAYOUT.SEGMENT.r * Math.cos(angle),
      LAYOUT.SEGMENT.cy,
      LAYOUT.SEGMENT.cz + LAYOUT.SEGMENT.r * Math.sin(angle),
    );
  };

  const makeTypebar = (
    index: number,
    labelTop: string,
    lower: string,
    upper: string,
    isAdapter: boolean,
  ): { pivot: THREE.Vector3; restAngle: number; yaw: number } => {
    const pivot = barPivot(index);
    const toPrint = LAYOUT.PRINT_POINT.clone().sub(pivot);
    const length = toPrint.length();
    toPrint.normalize();
    const flat = Math.hypot(toPrint.x, toPrint.z);
    const yaw = Math.atan2(toPrint.x, toPrint.z);
    const strikeAngle = Math.atan2(flat, toPrint.y);
    const restAngle = strikeAngle + THREE.MathUtils.degToRad(72);
    const code = isAdapter ? "IME" : KEYS.find((k) => k.typebar === index)!.code;
    const { action } = addPart(basketGroup, {
      id: `typebar.${index}`,
      label: isAdapter ? "Unicode adapter typebar" : `${labelTop} typebar`,
      fn: isAdapter ? "Contemporary adapter — not original machinery" : "Typebar: hurls its slug to the print point",
      system: "typebars",
      stagger: 0.44 + index * 0.0018,
      offset: {
        px: Math.cos(barAngle(index)) * 3.2,
        py: 1.8,
        pz: Math.sin(barAngle(index)) * 3.2,
        ry: (barAngle(index) - Math.PI / 2) * 0.35,
      },
      parentId: null,
      upstream: isAdapter ? [] : [`link.${code}`],
      downstream: ["vibrator", "escapement.starWheel"],
    }, (group) => {
      group.position.copy(pivot);
      group.rotation.order = "YXZ";
      group.rotation.y = yaw;
      group.rotation.x = restAngle;
      const content = new THREE.Group();
      group.add(content);
      const bar = box(0.2, length, 0.4, isAdapter ? materials.brass : materials.nickel);
      bar.position.y = length / 2;
      bar.castShadow = true;
      content.add(bar);
      const tailPiece = box(0.18, 1.4, 0.36, materials.steelDark);
      tailPiece.position.y = -0.7;
      content.add(tailPiece);
      const slug = box(0.52, 0.72, 0.34, materials.steelDark);
      slug.position.y = length + 0.2;
      slug.rotation.x = -1.15;
      content.add(slug);
      const face = new THREE.Mesh(new THREE.PlaneGeometry(0.44, 0.6), new THREE.MeshBasicMaterial({ map: slugTexture(lower, upper) }));
      face.position.set(0, length + 0.2, 0.18);
      face.rotation.x = -1.15;
      content.add(face);
      return content;
    });
    refs.typebarActions[index] = action!;
    refs.typebarRestAngles[index] = restAngle;
    refs.typebarStrikeAngles[index] = strikeAngle;
    return { pivot, restAngle, yaw };
  };

  const typebarInfo: Array<{ pivot: THREE.Vector3; restAngle: number; yaw: number } | undefined> = [];
  for (const key of KEYS) {
    if (key.kind !== "char") continue;
    typebarInfo[key.typebar] = makeTypebar(key.typebar, key.labelTop, key.lower!, key.upper!, false);
  }
  typebarInfo[IME_TYPEBAR] = makeTypebar(IME_TYPEBAR, "U", "u●", "U●", true);

  // -------------------------------------------------------------------- links
  for (const key of KEYS) {
    if (key.kind !== "char") continue;
    const info = typebarInfo[key.typebar]!;
    const tailDir = new THREE.Vector3(0, -Math.cos(info.restAngle), -Math.sin(info.restAngle)).applyAxisAngle(
      new THREE.Vector3(0, 1, 0),
      info.yaw,
    );
    const tailPos = info.pivot.clone().addScaledVector(tailDir, 1.4);
    const keyPos = keyPosition(key);
    const leverEnd = new THREE.Vector3(keyPos.x, LAYOUT.LEVER_PIVOT.y + 0.2, LAYOUT.LEVER_PIVOT.z - 1.9);
    addPart(root, {
      id: `link.${key.code}`,
      label: `${key.labelTop} link rod`,
      fn: "Link rod: pulls the typebar tail upward",
      system: "links",
      stagger: 0.3 + key.row * 0.012,
      offset: { py: -3, pz: 3 },
      upstream: [`lever.${key.code}`],
      downstream: [`typebar.${key.typebar}`],
    }, (group) => {
      const rod = rodBetween(leverEnd, tailPos, 0.055, materials.nickel, 6);
      group.add(rod);
      const joint = rodBetween(tailPos.clone().add(new THREE.Vector3(0, -0.5, 0)), tailPos, 0.09, materials.brass, 6);
      group.add(joint);
      return null;
    });
  }

  // ------------------------------------------------------------------ basket
  addPart(basketGroup, {
    id: "basket.segment",
    label: "Typebar segment",
    fn: "Slotted arc guiding every typebar pivot",
    system: "basket",
    stagger: 0.56,
    offset: { py: -2.2 },
    downstream: ["typebars"],
  }, (group) => {
    group.position.set(LAYOUT.SEGMENT.cx, LAYOUT.SEGMENT.cy - 0.3, LAYOUT.SEGMENT.cz);
    const arc = Math.PI * 0.95;
    const segment = new THREE.Mesh(new THREE.TorusGeometry(LAYOUT.SEGMENT.r, 0.3, 10, 48, arc), materials.enamel);
    segment.rotation.x = Math.PI / 2;
    segment.rotation.z = Math.PI - arc / 2 - Math.PI * 0.475 + Math.PI * 0.475;
    group.add(segment);
    return null;
  });

  addPart(basketGroup, {
    id: "basket.rest",
    label: "Typebar rest",
    fn: "Felt rail where idle typebars sleep",
    system: "basket",
    stagger: 0.57,
    offset: { py: -2.6 },
  }, (group) => {
    group.position.set(LAYOUT.SEGMENT.cx, LAYOUT.SEGMENT.cy - 1.6, LAYOUT.SEGMENT.cz + 1.2);
    const arc = Math.PI * 0.9;
    const rest = new THREE.Mesh(new THREE.TorusGeometry(LAYOUT.SEGMENT.r - 0.8, 0.24, 8, 40, arc), materials.felt);
    rest.rotation.x = Math.PI / 2;
    group.add(rest);
    return null;
  });

  const { action: universalBar } = addPart(root, {
    id: "universalBar",
    label: "Universal bar",
    fn: "Every key trips it to free the escapement",
    system: "basket",
    stagger: 0.58,
    offset: { pz: 3.2, py: -1.2 },
    upstream: ["levers"],
    downstream: ["escapement.starWheel"],
  }, (group) => {
    group.position.set(0, 10.9, 0.3);
    const content = new THREE.Group();
    group.add(content);
    const bar = box(17, 0.32, 0.5, materials.nickel);
    bar.castShadow = true;
    content.add(bar);
    return content;
  });
  refs.universalBarAction = universalBar!;

  // --------------------------------------------------------------- escapement
  const { action: escapeWheel } = addPart(root, {
    id: "escapement.starWheel",
    label: "Escapement wheel",
    fn: "Releases exactly one tooth per character",
    system: "escapement",
    stagger: 0.8,
    offset: { py: -1.6, pz: 2.6 },
    upstream: ["universalBar"],
    downstream: ["carriage.body"],
  }, (group) => {
    group.position.set(0, 11.7, -3.3);
    const content = new THREE.Group();
    group.add(content);
    const wheel = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 0.9, 0.3, 16), materials.brass);
    wheel.rotation.x = Math.PI / 2;
    content.add(wheel);
    for (let i = 0; i < 12; i++) {
      const tooth = box(0.16, 0.34, 0.28, materials.brass);
      const angle = (i / 12) * Math.PI * 2;
      tooth.position.set(Math.cos(angle) * 1, Math.sin(angle) * 1, 0);
      tooth.rotation.z = angle;
      content.add(tooth);
    }
    return content;
  });
  refs.escapeWheelAction = escapeWheel!;

  addPart(root, {
    id: "escapement.pawls",
    label: "Escapement pawls",
    fn: "Loose and rigid dog rocking on each keystroke",
    system: "escapement",
    stagger: 0.81,
    offset: { pz: 2.2, py: -1.2 },
    upstream: ["universalBar"],
    downstream: ["escapement.starWheel"],
  }, (group) => {
    group.position.set(0, 11.15, -2.6);
    const loose = box(0.16, 1.1, 0.2, materials.steelDark);
    loose.position.set(-0.35, 0.4, 0);
    loose.rotation.z = 0.35;
    group.add(loose);
    const rigid = box(0.16, 1.1, 0.2, materials.steelDark);
    rigid.position.set(0.35, 0.4, 0);
    rigid.rotation.z = -0.35;
    group.add(rigid);
    return null;
  });

  addPart(root, {
    id: "escapement.backspacePawl",
    label: "Backspace pawl",
    fn: "Backspacer: pushes the rack one tooth back",
    system: "escapement",
    stagger: 0.82,
    offset: { pz: 2, py: -1.4 },
    upstream: ["lever.Backspace"],
    downstream: ["escapement.starWheel"],
  }, (group) => {
    group.position.set(2.2, 11.2, -2.7);
    const pawl = box(0.2, 1.4, 0.22, materials.steelDark);
    pawl.rotation.z = 0.5;
    group.add(pawl);
    return null;
  });

  // ----------------------------------------------------------------- carriage
  addPart(carriageGroup, {
    id: "carriage.body",
    label: "Carriage",
    fn: "Carries platen and paper one tooth per character",
    system: "carriage",
    stagger: 0.7,
    offset: { py: 7.5, pz: -3.5 },
    upstream: ["escapement.starWheel"],
    downstream: ["platen"],
  }, (group) => {
    const rail = box(34, 0.5, 0.7, materials.nickel);
    rail.position.set(0, 12.15, -3.4);
    rail.castShadow = true;
    group.add(rail);
    const bed = box(24.5, 1.1, 3.4, materials.enamel);
    bed.position.set(0, 12.85, -3.7);
    bed.castShadow = true;
    group.add(bed);
    for (const side of [-1, 1]) {
      const cheek = box(0.6, 3.6, 4.4, materials.enamel);
      cheek.position.set(side * 11.5, 13.9, -3.6);
      cheek.castShadow = true;
      group.add(cheek);
    }
    const rack = box(21, 0.4, 0.5, materials.steelDark);
    rack.position.set(0, 12.35, -3.05);
    group.add(rack);
    for (let i = 0; i < 42; i++) {
      const tooth = box(0.12, 0.22, 0.3, materials.steelDark);
      tooth.position.set(-10.25 + i * 0.5, 12.18, -3.05);
      group.add(tooth);
    }
    return null;
  });

  const { action: platenAction } = addPart(carriageGroup, {
    id: "platen",
    label: "Platen",
    fn: "Rubber cylinder taking every single impact",
    system: "carriage",
    stagger: 0.74,
    offset: { py: 3.6 },
    parentId: "carriage.body",
    upstream: ["carriage.body"],
    downstream: ["paper.sheet"],
  }, (group) => {
    group.position.set(0, LAYOUT.PLATEN.y, LAYOUT.PLATEN.z);
    const content = new THREE.Group();
    group.add(content);
    const roller = new THREE.Mesh(new THREE.CylinderGeometry(LAYOUT.PLATEN.r, LAYOUT.PLATEN.r, LAYOUT.PLATEN.len, 36), materials.rubber);
    roller.rotation.z = Math.PI / 2;
    roller.castShadow = true;
    content.add(roller);
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, LAYOUT.PLATEN.len + 3.4, 12), materials.nickel);
    shaft.rotation.z = Math.PI / 2;
    content.add(shaft);
    return content;
  });
  refs.platenAction = platenAction!;

  for (const side of [-1, 1]) {
    addPart(carriageGroup, {
      id: `platen.knob${side < 0 ? "L" : "R"}`,
      label: side < 0 ? "Left platen knob" : "Right platen knob",
      fn: "Hand wheel for feeding paper by hand",
      system: "carriage",
      stagger: 0.76,
      offset: { px: side * 2.6 },
      parentId: "carriage.body",
      upstream: [],
      downstream: ["platen"],
    }, (group) => {
      group.position.set(side * (LAYOUT.PLATEN.len / 2 + 1.2), LAYOUT.PLATEN.y, LAYOUT.PLATEN.z);
      const knob = new THREE.Mesh(new THREE.CylinderGeometry(1.05, 1.15, 0.9, 20), materials.keyRim);
      knob.rotation.z = Math.PI / 2;
      knob.castShadow = true;
      group.add(knob);
      return null;
    });
  }

  const { action: ratchetAction } = addPart(carriageGroup, {
    id: "platen.ratchet",
    label: "Line-spacing ratchet",
    fn: "Turns the platen exactly one line per return",
    system: "carriage",
    stagger: 0.77,
    offset: { px: -2.2 },
    parentId: "carriage.body",
    upstream: ["carriage.returnLever"],
    downstream: ["platen"],
  }, (group) => {
    group.position.set(-(LAYOUT.PLATEN.len / 2 + 0.7), LAYOUT.PLATEN.y, LAYOUT.PLATEN.z);
    const content = new THREE.Group();
    group.add(content);
    const wheel = new THREE.Mesh(new THREE.CylinderGeometry(1.25, 1.25, 0.35, 24), materials.brass);
    wheel.rotation.z = Math.PI / 2;
    content.add(wheel);
    for (let i = 0; i < 18; i++) {
      const tooth = box(0.36, 0.16, 0.3, materials.brass);
      const angle = (i / 18) * Math.PI * 2;
      tooth.position.set(0, Math.cos(angle) * 1.35, Math.sin(angle) * 1.35);
      tooth.rotation.x = angle;
      content.add(tooth);
    }
    return content;
  });
  refs.ratchetAction = ratchetAction!;

  const { action: returnLeverAction } = addPart(carriageGroup, {
    id: "carriage.returnLever",
    label: "Carriage return lever",
    fn: "Throws the carriage home and feeds a line",
    system: "carriage",
    stagger: 0.78,
    offset: { px: -2.8, py: 1.4 },
    parentId: "carriage.body",
    upstream: [],
    downstream: ["platen.ratchet", "carriage.body"],
  }, (group) => {
    group.position.set(-11.6, 14.9, -2.6);
    const content = new THREE.Group();
    group.add(content);
    const arm = rodBetween(new THREE.Vector3(0, 0, 0), new THREE.Vector3(-2.4, 3.2, 0.6), 0.14, materials.nickel);
    arm.castShadow = true;
    content.add(arm);
    const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 1.6, 12), materials.keyRim);
    grip.position.set(-2.55, 3.4, 0.65);
    grip.rotation.x = Math.PI / 2;
    content.add(grip);
    return content;
  });
  refs.returnLeverAction = returnLeverAction!;

  addPart(carriageGroup, {
    id: "carriage.paperBail",
    label: "Paper bail",
    fn: "Holds the sheet flat against the platen",
    system: "carriage",
    stagger: 0.79,
    offset: { py: 1.6, pz: 1.6 },
    parentId: "carriage.body",
    upstream: [],
    downstream: ["paper.sheet"],
  }, (group) => {
    group.position.set(0, 16.15, -2.05);
    const rail = box(18, 0.28, 0.36, materials.nickel);
    group.add(rail);
    for (const x of [-5.5, 5.5]) {
      const roller = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.9, 14), materials.rubber);
      roller.position.set(x, -0.25, -0.15);
      roller.rotation.x = Math.PI / 2;
      group.add(roller);
    }
    return null;
  });

  for (const x of [-7, 7]) {
    addPart(carriageGroup, {
      id: `carriage.feedRoller${x < 0 ? "L" : "R"}`,
      label: "Feed roller",
      fn: "Pinch roller feeding the sheet through",
      system: "carriage",
      stagger: 0.8,
      offset: { py: -1.4 },
      parentId: "carriage.body",
      upstream: [],
      downstream: ["paper.sheet"],
    }, (group) => {
      group.position.set(x, 12.35, -3.4);
      const roller = new THREE.Mesh(new THREE.CylinderGeometry(0.65, 0.65, 1.4, 14), materials.rubber);
      roller.rotation.z = Math.PI / 2;
      group.add(roller);
      return null;
    });
  }

  for (const x of [-8.6, 8.6]) {
    addPart(carriageGroup, {
      id: `carriage.marginStop${x < 0 ? "L" : "R"}`,
      label: x < 0 ? "Left margin stop" : "Right margin stop",
      fn: x < 0 ? "Sets where the carriage returns to" : "Blocks the carriage at line end",
      system: "carriage",
      stagger: 0.81,
      offset: { py: -1.8 },
      parentId: "carriage.body",
      upstream: [],
      downstream: ["carriage.body"],
    }, (group) => {
      group.position.set(x, 12.75, -2.35);
      group.add(box(0.5, 1, 0.5, materials.brass));
      return null;
    });
  }

  const { action: bellAction } = addPart(carriageGroup, {
    id: "carriage.bell",
    label: "Margin bell",
    fn: "Rings six characters before the right margin",
    system: "carriage",
    stagger: 0.82,
    offset: { px: -1.6, py: 1.2 },
    parentId: "carriage.body",
    upstream: ["carriage.body"],
    downstream: [],
  }, (group) => {
    group.position.set(-9.6, 15.9, -5);
    const content = new THREE.Group();
    group.add(content);
    const dome = new THREE.Mesh(new THREE.SphereGeometry(0.85, 20, 12, 0, Math.PI * 2, 0, Math.PI / 2), materials.bellMetal);
    dome.castShadow = true;
    content.add(dome);
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 1.05, 0.25, 20), materials.steelDark);
    base.position.y = -0.1;
    content.add(base);
    return content;
  });
  refs.bellAction = bellAction!;

  addPart(carriageGroup, {
    id: "carriage.paperTable",
    label: "Paper table",
    fn: "Guides the sheet behind the platen",
    system: "carriage",
    stagger: 0.75,
    offset: { pz: -2.4, py: 1.2 },
    parentId: "carriage.body",
    upstream: [],
    downstream: ["paper.sheet"],
  }, (group) => {
    group.position.set(0, 15.9, -6.8);
    const table = box(21, 0.25, 5.5, materials.enamel);
    table.rotation.x = 0.5;
    group.add(table);
    return null;
  });

  const paperSheet = buildPaperSheet(paper);
  addPart(carriageGroup, {
    id: "paper.sheet",
    label: "Paper sheet",
    fn: "A4 sheet — where impacts become a document",
    system: "paper",
    stagger: 0.72,
    offset: { py: 4.5, pz: 2.5 },
    parentId: "carriage.body",
    upstream: ["platen"],
    downstream: [],
  }, (group) => {
    group.add(paperSheet.mesh);
    return null;
  });
  refs.paperMesh = paperSheet.mesh;
  refs.updatePaper = paperSheet.update;

  // -------------------------------------------------------------------- ribbon
  const spoolY = 13.2;
  const spoolX = 7.6;
  for (const side of [-1, 1]) {
    const { action } = addPart(root, {
      id: `ribbon.spool${side < 0 ? "L" : "R"}`,
      label: side < 0 ? "Left ribbon spool" : "Right ribbon spool",
      fn: side < 0 ? "Takes up the spent ribbon" : "Feeds fresh ribbon per character",
      system: "ribbon",
      stagger: 0.62,
      offset: { px: side * 5.5, py: 1.2 },
      upstream: ["escapement.starWheel"],
      downstream: ["ribbon.strip"],
    }, (group) => {
      group.position.set(side * spoolX, spoolY, -1.35);
      const content = new THREE.Group();
      group.add(content);
      const wound = new THREE.Mesh(new THREE.CylinderGeometry(2.1, 2.1, 0.42, 28), materials.ribbon);
      wound.castShadow = true;
      content.add(wound);
      for (const y of [-0.3, 0.3]) {
        const flange = new THREE.Mesh(new THREE.CylinderGeometry(2.3, 2.3, 0.08, 28), materials.steelDark);
        flange.position.y = y;
        content.add(flange);
      }
      const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 1, 10), materials.nickel);
      content.add(hub);
      return content;
    });
    if (side < 0) refs.spoolL = action!;
    else refs.spoolR = action!;
  }

  const { action: vibratorAction } = addPart(root, {
    id: "vibrator",
    label: "Ribbon vibrator",
    fn: "Lifts the ribbon into the strike path",
    system: "ribbon",
    stagger: 0.63,
    offset: { pz: 4.2, py: 0.8 },
    upstream: ["typebars"],
    downstream: ["paper.sheet"],
  }, (group) => {
    group.position.set(0, 12.9, -1.6);
    const content = new THREE.Group();
    group.add(content);
    const bridge = box(1.7, 0.5, 0.24, materials.nickel);
    bridge.position.y = 0.55;
    content.add(bridge);
    const postL = box(0.18, 1.1, 0.2, materials.nickel);
    postL.position.set(-0.75, 0, 0);
    content.add(postL);
    const postR = box(0.18, 1.1, 0.2, materials.nickel);
    postR.position.set(0.75, 0, 0);
    content.add(postR);
    const windowMesh = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.55), materials.ribbon);
    windowMesh.position.set(0, 0.55, 0.13);
    content.add(windowMesh);
    return content;
  });
  refs.vibratorAction = vibratorAction!;

  const makeRibbonSide = (): THREE.Mesh => {
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(1, 0.55), materials.ribbon);
    mesh.userData.partId = "ribbon.strip";
    root.add(mesh);
    return mesh;
  };
  addPart(root, {
    id: "ribbon.strip",
    label: "Ink ribbon",
    fn: "Woven inked fabric between slug and sheet",
    system: "ribbon",
    stagger: 0.64,
    offset: { py: 2.2 },
    upstream: ["ribbon.spoolL", "ribbon.spoolR", "vibrator"],
    downstream: ["paper.sheet"],
  }, () => null);
  refs.ribbonSideL = makeRibbonSide();
  refs.ribbonSideR = makeRibbonSide();
  refs.ribbonTipL = new THREE.Vector3(-0.8, spoolY, -1.6);
  refs.ribbonTipR = new THREE.Vector3(0.8, spoolY, -1.6);

  addPart(root, {
    id: "ribbon.advance",
    label: "Ribbon advance gear",
    fn: "Steps the ribbon on every escapement release",
    system: "ribbon",
    stagger: 0.65,
    offset: { py: -1.8 },
    upstream: ["escapement.starWheel"],
    downstream: ["ribbon.spoolR"],
  }, (group) => {
    group.position.set(4.6, 12, -1.3);
    const gear = new THREE.Mesh(new THREE.CylinderGeometry(0.8, 0.8, 0.3, 14), materials.brass);
    group.add(gear);
    for (let i = 0; i < 10; i++) {
      const tooth = box(0.14, 0.26, 0.26, materials.brass);
      const angle = (i / 10) * Math.PI * 2;
      tooth.position.set(Math.cos(angle) * 0.9, 0, Math.sin(angle) * 0.9);
      group.add(tooth);
    }
    return null;
  });

  addPart(root, {
    id: "ribbon.reverse",
    label: "Ribbon reverse pawl",
    fn: "Flips the feed direction at spool end",
    system: "ribbon",
    stagger: 0.66,
    offset: { py: -1.8, px: -1.5 },
    upstream: ["ribbon.spoolL"],
    downstream: ["ribbon.advance"],
  }, (group) => {
    group.position.set(-4.6, 12, -1.3);
    const pawl = box(0.22, 1.6, 0.24, materials.steelDark);
    pawl.rotation.z = -0.4;
    group.add(pawl);
    return null;
  });

  // --------------------------------------------------------------------- frame
  addPart(root, {
    id: "frame.chassis",
    label: "Main chassis",
    fn: "Cast iron spine of the whole machine",
    system: "frame",
    stagger: 0.94,
    offset: {},
  }, (group) => {
    group.position.set(0, 4.8, 0);
    const chassis = box(43, 2.6, 26, materials.enamel);
    chassis.castShadow = true;
    chassis.receiveShadow = true;
    group.add(chassis);
    return null;
  });

  for (const side of [-1, 1]) {
    addPart(root, {
      id: `frame.sidePanel${side < 0 ? "L" : "R"}`,
      label: side < 0 ? "Left side panel" : "Right side panel",
      fn: "Enamel shell — opens in cutaway view",
      system: "frame",
      stagger: 0.86,
      offset: { px: side * 6.5, ry: side * 0.35 },
      cutawayFade: true,
    }, (group) => {
      group.position.set(side * 21.2, 8.6, 0);
      const panel = box(1.1, 8.2, 25.6, materials.enamelPanel);
      panel.castShadow = true;
      group.add(panel);
      return null;
    });
  }

  addPart(root, {
    id: "frame.rearPanel",
    label: "Rear panel",
    fn: "Enamel back plate of the mechanism bay",
    system: "frame",
    stagger: 0.87,
    offset: { pz: -5.5 },
    cutawayFade: true,
  }, (group) => {
    group.position.set(0, 8.6, -12.4);
    group.add(box(43, 8.2, 1.1, materials.enamelPanel));
    return null;
  });

  addPart(root, {
    id: "frame.apron",
    label: "Front apron",
    fn: "Enamel brow above the keyboard",
    system: "frame",
    stagger: 0.88,
    offset: { pz: 5, py: -1.2 },
    cutawayFade: true,
  }, (group) => {
    group.position.set(0, 7.6, 12.6);
    const brow = box(41, 3.4, 1, materials.enamelPanel);
    brow.rotation.x = 0.18;
    group.add(brow);
    const plate = box(10.5, 1.5, 0.22, materials.brass);
    plate.position.set(0, 0.4, 0.62);
    plate.rotation.x = 0.18;
    group.add(plate);
    const nameplate = new THREE.Mesh(
      new THREE.PlaneGeometry(9.8, 1.1),
      new THREE.MeshBasicMaterial({ map: keycapTexture("THE IMPACT No. 01", ""), transparent: true }),
    );
    nameplate.position.set(0, 0.4, 0.74);
    nameplate.rotation.x = 0.18;
    group.add(nameplate);
    return null;
  });

  for (const side of [-1, 1]) {
    addPart(root, {
      id: `frame.deckPlate${side < 0 ? "L" : "R"}`,
      label: side < 0 ? "Left deck plate" : "Right deck plate",
      fn: "Top deck carrying the ribbon spools",
      system: "frame",
      stagger: 0.89,
      offset: { py: 3.2, px: side * 2.5 },
      cutawayFade: true,
    }, (group) => {
      group.position.set(side * 14.5, 12.15, -1);
      const plate = box(13.5, 0.45, 15, materials.enamelPanel);
      plate.castShadow = true;
      plate.receiveShadow = true;
      group.add(plate);
      return null;
    });
  }

  addPart(root, {
    id: "frame.rearDeck",
    label: "Rear deck",
    fn: "Cover over the escapement bay",
    system: "frame",
    stagger: 0.9,
    offset: { py: 3, pz: -2.5 },
    cutawayFade: true,
  }, (group) => {
    group.position.set(0, 12.15, -9.2);
    group.add(box(29, 0.45, 6.5, materials.enamelPanel));
    return null;
  });

  for (const [x, z] of [[-18, -10], [18, -10], [-18, 10], [18, 10]] as const) {
    addPart(root, {
      id: `frame.foot.${x}.${z}`,
      label: "Rubber foot",
      fn: "Isolates the machine from the desk",
      system: "frame",
      stagger: 0.95,
      offset: { py: -2.2 },
    }, (group) => {
      group.position.set(x, 3, z);
      group.add(new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.3, 1.1, 14), materials.rubber));
      return null;
    });
  }

  // --------------------------------------------------------------------- shift
  for (const side of [-1, 1]) {
    addPart(basketGroup, {
      id: `shift.rod${side < 0 ? "L" : "R"}`,
      label: side < 0 ? "Left shift rod" : "Right shift rod",
      fn: "Shift linkage: raises the basket for capitals",
      system: "shift",
      stagger: 0.6,
      offset: { px: side * 2, py: -1.6 },
      upstream: [`lever.Shift${side < 0 ? "Left" : "Right"}`],
      downstream: ["basket.segment"],
    }, (group) => {
      group.position.set(side * 11.8, 7.6, 2.2);
      group.add(rodBetween(new THREE.Vector3(0, -2.4, 2.4), new THREE.Vector3(0, 2, -0.2), 0.1, materials.steelDark));
      return null;
    });
  }

  // ------------------------------------------------------------------ hardware
  const screwData: Array<{ p: THREE.Vector3; n: THREE.Vector3 }> = [];
  for (const side of [-1, 1]) {
    for (let i = 0; i < 8; i++) {
      screwData.push({
        p: new THREE.Vector3(side * 21.85, 5.6 + (i % 4) * 2, -9 + Math.floor(i / 4) * 18),
        n: new THREE.Vector3(side, 0, 0),
      });
    }
  }
  for (let i = 0; i < 6; i++) {
    screwData.push({ p: new THREE.Vector3(-15 + i * 6, 8.6, -13), n: new THREE.Vector3(0, 0, -1) });
    screwData.push({ p: new THREE.Vector3(-15 + i * 6, 7.6, 13.2), n: new THREE.Vector3(0, 0, 1) });
  }
  addPart(root, {
    id: "hardware.screws",
    label: "Assembly screws",
    fn: "Machine screws — exit along their own axes",
    system: "hardware",
    stagger: 0.92,
    offset: {},
  }, (group) => {
    const screwGeo = new THREE.CylinderGeometry(0.22, 0.22, 0.5, 10);
    const instanced = new THREE.InstancedMesh(screwGeo, materials.nickel, screwData.length);
    const matrix = new THREE.Matrix4();
    const quaternion = new THREE.Quaternion();
    const up = new THREE.Vector3(0, 1, 0);
    screwData.forEach((screw, i) => {
      quaternion.setFromUnitVectors(up, screw.n);
      matrix.compose(screw.p, quaternion, new THREE.Vector3(1, 1, 1));
      instanced.setMatrixAt(i, matrix);
    });
    instanced.instanceMatrix.needsUpdate = true;
    group.add(instanced);
    group.userData.screwData = screwData;
    group.userData.instanced = instanced;
    return null;
  });

  addPart(root, {
    id: "carriage.spring",
    label: "Mainspring drum",
    fn: "Spring motor pulling the carriage leftward",
    system: "carriage",
    stagger: 0.83,
    offset: { py: -2, pz: 2 },
    upstream: [],
    downstream: ["carriage.body"],
  }, (group) => {
    group.position.set(10.5, 10.6, -3.2);
    group.add(new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.5, 1.2, 20), materials.steelDark));
    const strap = box(0.5, 0.08, 8, materials.brass);
    strap.position.set(-1.2, 0.8, 2.5);
    group.add(strap);
    return null;
  });

  root.traverse((obj) => {
    if (obj instanceof THREE.Mesh) {
      obj.castShadow = obj.castShadow || false;
      obj.receiveShadow = true;
    }
  });

  return { root, parts, byId, refs };
}

/** Stretches a ribbon plane between two points (per-frame ribbon shape). */
export function stretchRibbon(mesh: THREE.Mesh, from: THREE.Vector3, to: THREE.Vector3): void {
  const delta = to.clone().sub(from);
  const length = delta.length();
  mesh.position.copy(from).addScaledVector(delta, 0.5);
  mesh.scale.set(length, 1, 1);
  mesh.quaternion.setFromUnitVectors(new THREE.Vector3(1, 0, 0), delta.normalize());
  mesh.rotateX(Math.PI / 2);
}
