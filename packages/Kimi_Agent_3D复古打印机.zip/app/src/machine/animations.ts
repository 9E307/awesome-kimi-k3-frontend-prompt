/**
 * Easing and pose-interpolation helpers shared by the machine builder
 * (explode poses) and the keystroke animation curves.
 */

export const clamp01 = (v: number): number => (v < 0 ? 0 : v > 1 ? 1 : v);

export const easeInQuad = (v: number): number => v * v;

export const easeOutQuad = (v: number): number => 1 - (1 - v) * (1 - v);

export const easeInOutQuad = (v: number): number => (v < 0.5 ? 2 * v * v : 1 - Math.pow(-2 * v + 2, 2) / 2);

export const easeInOutCubic = (v: number): number =>
  v < 0.5 ? 4 * v * v * v : 1 - Math.pow(-2 * v + 2, 3) / 2;

export interface Pose {
  px: number;
  py: number;
  pz: number;
  rx: number;
  ry: number;
  rz: number;
}

export function lerpPose(a: Pose, b: Pose, t: number): Pose {
  if (t <= 0) return { ...a };
  if (t >= 1) return { ...b };
  return {
    px: a.px + (b.px - a.px) * t,
    py: a.py + (b.py - a.py) * t,
    pz: a.pz + (b.pz - a.pz) * t,
    rx: a.rx + (b.rx - a.rx) * t,
    ry: a.ry + (b.ry - a.ry) * t,
    rz: a.rz + (b.rz - a.rz) * t,
  };
}

/**
 * Staggered explode progress: each part starts moving at `stagger * 0.5`
 * of the global progress and finishes half a range later.
 */
export function staggeredProgress(global: number, stagger: number): number {
  const start = stagger * 0.5;
  return clamp01((global - start) / 0.5);
}
