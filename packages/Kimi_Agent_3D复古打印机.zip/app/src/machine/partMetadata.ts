import { KEY_BY_CODE } from "./keyboardLayout";

/**
 * Slow-motion trace chains: the ordered part ids a keystroke travels
 * through, per key kind. Used both by the part card's "follow" button
 * and by exploded-view key selection.
 */
export function traceChainFor(code: string): string[] {
  const def = KEY_BY_CODE[code];
  if (!def) return [];
  switch (def.kind) {
    case "char":
      return [
        `key.${code}`,
        `lever.${code}`,
        `link.${code}`,
        `typebar.${def.typebar}`,
        "vibrator",
        "platen",
        "escapement.starWheel",
        "carriage.body",
      ];
    case "space":
      return [`key.${code}`, `lever.${code}`, "universalBar", "escapement.starWheel", "carriage.body"];
    case "backspace":
      return [`key.${code}`, `lever.${code}`, "escapement.backspacePawl", "escapement.starWheel", "carriage.body"];
    case "shift":
      return [`key.${code}`, `lever.${code}`, code === "ShiftLeft" ? "shift.rodL" : "shift.rodR", "basket.segment"];
    case "tab":
      return [`key.${code}`, `lever.${code}`, "escapement.starWheel", "carriage.body"];
  }
}
