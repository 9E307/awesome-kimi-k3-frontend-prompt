import * as THREE from "three";
import type { Pose } from "./animations";
import type { PartSystem } from "../app/i18n";

/**
 * Part registry types and low-level geometry helpers shared by the
 * machine builder: canvas-drawn keycap legends, type-slug faces,
 * rod-between-points cylinders and box shorthand.
 */

export interface PartOffset {
  px?: number;
  py?: number;
  pz?: number;
  rx?: number;
  ry?: number;
  rz?: number;
}

export interface PartDef {
  id: string;
  label: string;
  fn: string;
  system: PartSystem;
  stagger: number;
  offset: PartOffset;
  parentId?: string | null;
  cutawayFade?: boolean;
  upstream?: string[];
  downstream?: string[];
}

export interface BuiltPart {
  id: string;
  label: string;
  fn: string;
  system: PartSystem;
  stagger: number;
  parentId: string | null;
  cutawayFade: boolean;
  upstream: string[];
  downstream: string[];
  partGroup: THREE.Group;
  assembled: Pose;
  exploded: Pose;
}

/** Machine layout constants (scene units). */
export const LAYOUT = {
  KEY_UNIT: 1.9,
  KEY_ROWS: [
    { z: 2.4, y: 8.7 },
    { z: 4.35, y: 8 },
    { z: 6.3, y: 7.4 },
    { z: 8.25, y: 6.85 },
    { z: 10.3, y: 6.3 },
  ],
  KEY_CENTER_COL: 7.4,
  PRINT_POINT: new THREE.Vector3(0, 13.83, -1.66),
  PLATEN: { y: 14.6, z: -3.4, r: 1.9, len: 22.4 },
  SEGMENT: { cx: 0, cy: 9.6, cz: -2, r: 6.3 },
  LEVER_PIVOT: { y: 5, z: -2.8 },
  CARRIAGE_UNIT: 0.2211,
  LINE_FEED: 24.62 / 44,
  CARRIAGE_HOME_X: 7.96,
} as const;

export function keyPosition(def: { row: number; col: number }): THREE.Vector3 {
  const row = LAYOUT.KEY_ROWS[def.row];
  return new THREE.Vector3((def.col - LAYOUT.KEY_CENTER_COL) * LAYOUT.KEY_UNIT, row.y, row.z);
}

const textureCache = new Map<string, THREE.CanvasTexture>();

/** Keycap legend: upper glyph above lower glyph, Courier Prime. */
export function keycapTexture(top: string, bottom: string): THREE.CanvasTexture {
  const cacheKey = `${top}|${bottom}`;
  const cached = textureCache.get(cacheKey);
  if (cached) return cached;
  const canvas = document.createElement("canvas");
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext("2d")!;
  ctx.clearRect(0, 0, 128, 128);
  ctx.fillStyle = "#332e24";
  ctx.textAlign = "center";
  if (bottom && top !== bottom) {
    ctx.font = '600 44px "Courier Prime", monospace';
    ctx.fillText(top, 64, 54);
    ctx.font = '400 36px "Courier Prime", monospace';
    ctx.fillText(bottom, 64, 98);
  } else {
    const label = top || bottom;
    ctx.font = label.length > 4 ? '600 26px "Courier Prime", monospace' : '600 46px "Courier Prime", monospace';
    ctx.fillText(label, 64, label.length > 4 ? 58 : 76);
    if (top && bottom && top === bottom) {
      ctx.font = '400 32px "Courier Prime", monospace';
      ctx.fillText(bottom, 64, 100);
    }
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  textureCache.set(cacheKey, texture);
  return texture;
}

/** Type-slug face: raised upper/lower glyphs on the steel block. */
export function slugTexture(lower: string, upper: string): THREE.CanvasTexture {
  const cacheKey = `slug|${lower}|${upper}`;
  const cached = textureCache.get(cacheKey);
  if (cached) return cached;
  const canvas = document.createElement("canvas");
  canvas.width = 64;
  canvas.height = 96;
  const ctx = canvas.getContext("2d")!;
  ctx.fillStyle = "#20201f";
  ctx.fillRect(0, 0, 64, 96);
  ctx.fillStyle = "#b8b2a4";
  ctx.textAlign = "center";
  ctx.font = '600 30px "Courier Prime", monospace';
  ctx.fillText(upper, 32, 36);
  ctx.fillText(lower, 32, 76);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  textureCache.set(cacheKey, texture);
  return texture;
}

/** Cylinder stretched between two points (rods, links, arms). */
export function rodBetween(a: THREE.Vector3, b: THREE.Vector3, radius: number, material: THREE.Material, segments = 8): THREE.Mesh {
  const delta = b.clone().sub(a);
  const length = delta.length();
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, length, segments), material);
  mesh.position.copy(a).addScaledVector(delta, 0.5);
  mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), delta.normalize());
  return mesh;
}

/** Box mesh shorthand. */
export function box(w: number, h: number, d: number, material: THREE.Material): THREE.Mesh {
  return new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
}

export function capturePose(group: THREE.Group): Pose {
  return {
    px: group.position.x,
    py: group.position.y,
    pz: group.position.z,
    rx: group.rotation.x,
    ry: group.rotation.y,
    rz: group.rotation.z,
  };
}
