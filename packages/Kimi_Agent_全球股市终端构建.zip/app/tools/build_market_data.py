#!/usr/bin/env python3
"""GMT 真实行情快照构建脚本
================================
全部数值取自 Yahoo Finance 数据源（agent-gw 插件:
get_stock_info / get_historical_stock_prices / get_yahoo_finance_news）。
本脚本不含任何手写价格；若取数文件缺失会直接报错退出。

取数步骤（需先运行，输出到 /tmp/mkt/）:
  info/<T>.csv    — get_stock_info, 59 个标的（清单见 SECTORS/IDX/TAPE_EXTRA）
  hist/AAPL.csv, hist/GC=F.csv ... — get_historical_stock_prices(period=3mo, interval=1d)
  hist/intraday_XLK.csv ...        — get_historical_stock_prices(period=1d, interval=5m)
  news/<T>.csv    — get_yahoo_finance_news

内置断言（对应验收第 1 类）:
  * 每只个股: |marketCap/last - shares|/shares < 2%（多股类按隐含总股本）
  * 每条历史序列: series[-1]==展示 last 且 series[-1]/series[-2]-1==展示 pct
  * AAPL 个股行与其 60 日序列同源同交易日
  * 全站同一标的同一价格（跑马灯 XAU 直接复用贵金属序列末值）
"""
import pandas as pd, json, os, datetime
import numpy as np
from zoneinfo import ZoneInfo

INFO = '/tmp/mkt/info/'; HIST = '/tmp/mkt/hist/'
def info(t):
    f = INFO + t.replace('/', '_').replace('^', '_').replace('.', '_') + '.csv'
    return pd.read_csv(f).iloc[0].to_dict()
def num(x):
    try:
        v = float(x); return None if v != v else v
    except Exception: return None
def ts_local(epoch, tzname):
    try:
        dt = datetime.datetime.fromtimestamp(int(epoch), tz=ZoneInfo(tzname))
        return dt.strftime('%Y-%m-%d %H:%M'), dt
    except Exception: return None, None
def load_hist(t):
    f = HIST + t.replace('/', '_').replace('^', '_').replace('.', '_') + '.csv'
    return pd.read_csv(f).dropna(subset=['Close'])

SECTORS = {
 "AI-TECH": ["NVDA","MSFT","AAPL","GOOGL","AMZN","META","AVGO","AMD","PLTR","CRM","TSM","ORCL","INTC","SMCI"],
 "ENERGY": ["XOM","CVX","COP","SLB","EOG","OXY","MPC","PSX","WMB","LNG","FSLR"],
 "FINANCIALS": ["JPM","BRK-B","V","MA","BAC","GS","MS","WFC","BLK","SCHW","AXP"]}
CN_NAME = {"NVDA":"英伟达","MSFT":"微软","AAPL":"苹果","GOOGL":"谷歌A","AMZN":"亚马逊","META":"Meta","AVGO":"博通",
 "AMD":"AMD","PLTR":"Palantir","CRM":"赛富时","TSM":"台积电ADR","ORCL":"甲骨文","INTC":"英特尔","SMCI":"超微电脑",
 "XOM":"埃克森美孚","CVX":"雪佛龙","COP":"康菲石油","SLB":"斯伦贝谢","EOG":"EOG资源","OXY":"西方石油",
 "MPC":"马拉松石油","PSX":"Phillips 66","WMB":"威廉姆斯","LNG":"Cheniere能源","FSLR":"第一太阳能",
 "JPM":"摩根大通","BRK-B":"伯克希尔B","V":"Visa","MA":"万事达","BAC":"美国银行","GS":"高盛","MS":"摩根士丹利",
 "WFC":"富国银行","BLK":"贝莱德","SCHW":"嘉信理财","AXP":"美国运通"}
IDX = [("SPX","标普500","^GSPC","美洲","CBOE"),("IXIC","纳斯达克综合","^IXIC","美洲","NASDAQ"),
 ("DJI","道琼斯工业","^DJI","美洲","NYSE"),("GSPTSE","标普/TSX综合","^GSPTSE","美洲","TSX"),
 ("BVSP","圣保罗IBOVESPA","^BVSP","美洲","B3"),("SX5E","欧洲斯托克50","^STOXX50E","欧洲","Euronext"),
 ("UKX","富时100","^FTSE","欧洲","LSE"),("DAX","德国DAX","^GDAXI","欧洲","Xetra"),
 ("CAC","法国CAC40","^FCHI","欧洲","Euronext Paris"),("FTSEMIB","富时MIB","FTSEMIB.MI","欧洲","Borsa Italiana"),
 ("N225","日经225","^N225","亚太","TSE"),("HSI","恒生指数","^HSI","亚太","HKEX"),
 ("SHCOMP","上证综合","000001.SS","亚太","SSE"),("KOSPI","韩国KOSPI","^KS11","亚太","KRX"),
 ("AXJO","澳洲ASX200","^AXJO","亚太","ASX"),("NIFTY","印度NIFTY50","^NSEI","亚太","NSE")]
TAPE_EXTRA = [("WTI","WTI原油","CL=F"),("DXY","美元指数","DX-Y.NYB")]
METS = [("XAU","黄金 GC=F","GC=F"),("XAG","白银 SI=F","SI=F"),("XPT","铂金 PL=F","PL=F"),("XPD","钯金 PA=F","PA=F")]
NEWS_SRC = [("AAPL","TECH"),("NVDA","AI"),("MSFT","AI"),("META","AI"),("XOM","ENERGY"),
            ("JPM","FINANCE"),("GC=F","METALS"),("_GSPC","MACRO")]
MULTI_CLASS = {'GOOGL','META','PLTR','BRK-B','V','BLK'}

a = info('AAPL')
aapl_h = load_hist('AAPL').tail(60).reset_index(drop=True)
assert abs(aapl_h.iloc[-1]['Close'] - a['currentPrice']) < 0.02, 'AAPL 历史序列与报价不一致'

stocks = []; missing = []
for g, members in SECTORS.items():
    for t in members:
        try: r = info(t)
        except Exception: missing.append((t, '接口无返回')); continue
        last = num(r.get('currentPrice')) or num(r.get('regularMarketPrice'))
        prev = num(r.get('previousClose')) or num(r.get('regularMarketPreviousClose'))
        if t == 'AAPL':
            last = float(aapl_h.iloc[-1]['Close']); prev = float(aapl_h.iloc[-2]['Close'])
            o = float(aapl_h.iloc[-1]['Open']); h = float(aapl_h.iloc[-1]['High'])
            l = float(aapl_h.iloc[-1]['Low']);  vol = int(aapl_h.iloc[-1]['Volume'])
        else:
            o = num(r.get('open')); h = num(r.get('dayHigh')); l = num(r.get('dayLow'))
            vol = int(num(r.get('volume')) or 0)
        if not last or not prev: missing.append((t, '缺少现价或前收')); continue
        chg = round(last - prev, 2); pct = round(chg / prev * 100, 2)
        mcap = num(r.get('marketCap'))
        sh = num(r.get('impliedSharesOutstanding')) or num(r.get('sharesOutstanding'))
        if mcap and sh and last:
            err = abs(mcap / last - sh) / sh
            assert err < 0.02, (t, '隐含股本校验失败', err)
        asof, _ = ts_local(r.get('regularMarketTime'), r.get('exchangeTimezoneName', 'America/New_York'))
        stocks.append({"t": 'BRK.B' if t == 'BRK-B' else t, "n": CN_NAME[t], "g": g,
          "last": round(last, 2), "prev": round(prev, 2), "chg": chg, "pct": pct,
          "o": round(o, 2) if o else None, "h": round(h, 2) if h else None, "l": round(l, 2) if l else None,
          "vol": vol, "mcap": round(mcap) if mcap else None, "shares": int(sh) if sh else None,
          "ccy": r.get('currency', 'USD'), "tz": r.get('exchangeTimezoneName'), "mstate": r.get('marketState'),
          "asof": asof,
          "capNote": '市值=现价×隐含总股本(含多股类)' if t in MULTI_CLASS else '市值=现价×流通股本'})

indices = []
for code, name, tk, region, exch in IDX:
    try: r = info(tk)
    except Exception: missing.append((code, '接口无返回')); continue
    last = num(r.get('regularMarketPrice')) or num(r.get('currentPrice'))
    prev = num(r.get('previousClose')) or num(r.get('regularMarketPreviousClose'))
    if not last or not prev: missing.append((code, '缺少现价或前收')); continue
    chg = round(last - prev, 2); pct = round(chg / prev * 100, 2)
    asof, _ = ts_local(r.get('regularMarketTime'), r.get('exchangeTimezoneName', 'UTC'))
    indices.append({"s": code, "n": name, "ex": exch, "region": region, "last": round(last, 2),
      "chg": chg, "pct": pct, "tz": r.get('exchangeTimezoneName'),
      "mstate": r.get('marketState'), "asof": asof})

metals = {}
for code, name, tk in METS:
    df = load_hist(tk).tail(60).reset_index(drop=True)
    closes = [round(float(x), 2) for x in df['Close']]
    last = closes[-1]; prev = closes[-2]
    chg = round(last - prev, 2); pct = round(chg / prev * 100, 2)
    assert closes[-1] == last and abs((closes[-1] / closes[-2] - 1) * 100 - pct) < 0.005
    metals[code] = {"name": name, "last": last, "prev": prev, "chg": chg, "pct": pct,
      "unit": "USD/t oz", "ccy": "USD", "spark": closes[-24:], "s60": closes,
      "dates": [str(x)[:10] for x in df['Date']], "r60": [round(min(closes), 2), round(max(closes), 2)],
      "asof": str(df.iloc[-1]['Date'])[:10], "venue": "COMEX/NYMEX 期货"}

tape_extra = []
for code, name, tk in TAPE_EXTRA:
    r = info(tk)
    last = num(r.get('regularMarketPrice')) or num(r.get('currentPrice'))
    prev = num(r.get('previousClose')) or num(r.get('regularMarketPreviousClose'))
    chg = round(last - prev, 2); pct = round(chg / prev * 100, 2)
    asof, _ = ts_local(r.get('regularMarketTime'), r.get('exchangeTimezoneName', 'America/New_York'))
    tape_extra.append({"s": code, "n": name, "last": round(last, 2), "chg": chg, "pct": pct, "asof": asof})
mx = metals["XAU"]  # 跑马灯 XAU 与贵金属组件同源同价
tape_extra.insert(0, {"s": "XAU", "n": "黄金(COMEX期货)", "last": mx["last"], "chg": mx["chg"],
                      "pct": mx["pct"], "asof": mx["asof"], "note": "期货口径"})

aapl_rows = [{"date": str(r['Date'])[:10], "o": round(float(r['Open']), 2), "h": round(float(r['High']), 2),
              "l": round(float(r['Low']), 2), "c": round(float(r['Close']), 2), "v": int(r['Volume'])}
             for _, r in aapl_h.iterrows()]
w52 = [num(a['fiftyTwoWeekLow']), num(a['fiftyTwoWeekHigh'])]

sector_intra = {}
for g, etf in {"AI-TECH": "XLK", "ENERGY": "XLE", "FINANCIALS": "XLF"}.items():
    df = pd.read_csv(HIST + 'intraday_%s.csv' % etf).dropna(subset=['Close'])
    base = float(df.iloc[0]['Open']); closes = df['Close'].astype(float).values
    idxs = np.linspace(0, len(closes) - 1, 24).round().astype(int)
    pts = [round((closes[i] / base - 1) * 100, 2) for i in idxs]
    members = [s for s in stocks if s['g'] == g]
    sector_intra[g] = {"pts": pts, "avg": round(sum(s['pct'] for s in members) / len(members), 2),
      "n": len(members), "proxy": etf, "session": "2026-07-27 美东常规时段",
      "finalPct": round((closes[-1] / base - 1) * 100, 2)}

fetched_dt = datetime.datetime.now(ZoneInfo('Asia/Shanghai'))
seen = set(); news = []
for f, cat in NEWS_SRC:
    p = '/tmp/mkt/news/%s.csv' % f
    if not os.path.exists(p): continue
    for _, r in pd.read_csv(p).iterrows():
        title = str(r.get('title', '')).strip()
        if not title or title == 'nan' or title in seen: continue
        seen.add(title)
        news.append({"cat": cat, "h": title,
          "sum": '' if str(r.get('summary', '')) == 'nan' else str(r.get('summary', '')).strip(),
          "url": str(r.get('url', '')).strip(), "src": "Yahoo Finance",
          "tk": [f.replace('_GSPC', '^GSPC')]})
all_tk = [s['t'] for s in stocks] + ['SPX', 'IXIC', 'DJI', 'N225', 'HSI', 'KOSPI']
for n in news:
    mentioned = [t for t in all_tk if (t + ' ') in (n['h'] + ' ') or (t + ',') in n['h'] or (t + ':') in n['h'] or t in n['tk']]
    n['tk'] = sorted(set(mentioned))
    n['t'] = fetched_dt.strftime('%H:%M:%S')
    n['ts'] = fetched_dt.strftime('%Y-%m-%d %H:%M:%S') + ' 北京时间(取得时刻)'
news = news[:30]

fetched_iso = fetched_dt.strftime('%Y-%m-%d %H:%M:%S %Z')
tape = [{"s": i['s'], "n": i['n'], "last": i['last'], "chg": i['chg'], "pct": i['pct'], "asof": i['asof']}
        for i in indices[:8]] + tape_extra
dataset = {
 "meta": {"name": "GMT//全球市场终端", "mode": "REAL", "fetchedAt": fetched_iso,
   "source": "Yahoo Finance（经 agent-gw 数据源接口）",
   "caliber": "个股/指数：现价对前收；多股类公司市值按隐含总股本。金属：COMEX/NYMEX 期货日线，序列末值即最新价。板块日内：XLK/XLE/XLF 5 分钟线归一化(开盘=0%)。新闻时间戳为抓取时刻(源未提供发布时间)。",
   "missing": missing},
 "tape": tape, "stocks": stocks, "sectorIntraday": sector_intra,
 "aapl": {"symbol": "AAPL", "name": "苹果", "rows": aapl_rows, "w52": w52,
   "caliber": "最近 60 个交易日 OHLCV（Yahoo Finance 日线，未复权 Close；成交量为股数）。52 周区间来自同一数据源。"},
 "metals": {"items": metals,
   "derived": {"gsr": {"v": round(metals['XAU']['last'] / metals['XAG']['last'], 2), "formula": "XAU 最新 ÷ XAG 最新", "unit": "倍"},
               "gps": {"v": round(metals['XAU']['last'] - metals['XPT']['last'], 2), "formula": "XAU 最新 − XPT 最新", "unit": "USD/t oz"}},
   "caliber": "四种金属均为 COMEX/NYMEX 期货日线（USD/t oz），同源同期，未混用现货/期货口径。"},
 "indexList": [{"region": r, "rows": [i for i in indices if i['region'] == r]} for r in ["美洲", "欧洲", "亚太"]],
 "news": news}
js = "/* GMT 真实行情快照 — 全部数值取自 Yahoo Finance 数据源（agent-gw）。\n"
js += "   抓取时刻: %s\n   生成: tools/build_market_data.py — 禁止手工编辑数值。 */\n" % fetched_iso
js += "window.GMT_DATA = " + json.dumps(dataset, ensure_ascii=False, separators=(',', ':')) + ";\n"
out = os.path.join(os.path.dirname(__file__), '..', 'js', 'market-data.js')
open(out, 'w').write(js)
print('wrote', os.path.abspath(out), len(js), 'bytes; missing:', missing)
