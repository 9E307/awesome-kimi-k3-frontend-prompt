# -*- coding: utf-8 -*-
"""GMT 缓存版本串自动注入（缺陷 5 修复）
=====================================
index.html 中所有本地 js/css 引用携带 ?v=<HASH>，HASH = 全部被引用文件
内容拼接后的 md5 前 10 位。任何 js/css 内容变化 → HASH 必然变化 →
重新运行本脚本即可自动更新 index.html，无需人工记忆。

用法：
    python3 tools/bust_cache.py          # 在 app/ 目录内任意位置运行均可
    python3 tools/bust_cache.py --check  # 只校验版本串是否最新（CI 用），不同则退出码 1

规则（README §9）：修改任何 js/css 后必须运行本脚本一次。
"""
import hashlib, os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HTML = os.path.join(ROOT, 'index.html')

src = open(HTML, encoding='utf-8').read()
refs = re.findall(r'(?:src|href)="((?:js|css)/[^"?]+)\?v=([A-Za-z0-9]+)"', src)
if not refs:
    print('未找到带版本串的 js/css 引用'); sys.exit(2)

h = hashlib.md5()
for path, _ in refs:
    fp = os.path.join(ROOT, path)
    if not os.path.exists(fp):
        print('引用文件缺失: ' + path); sys.exit(2)
    h.update(open(fp, 'rb').read())
new_ver = h.hexdigest()[:10]
old_vers = set(v for _, v in refs)

if '--check' in sys.argv:
    if old_vers == {new_ver}:
        print('版本串已是最新: ' + new_ver); sys.exit(0)
    print('版本串过期: 当前 %s → 应为 %s' % (sorted(old_vers), new_ver)); sys.exit(1)

out = re.sub(r'((?:js|css)/[^"?]+)\?v=[A-Za-z0-9]+', lambda m: m.group(1) + '?v=' + new_ver, src)
open(HTML, 'w', encoding='utf-8').write(out)
print('引用 %d 处；版本串 %s → %s' % (len(refs), sorted(old_vers), new_ver))
