/* ============================================================
   GMT widgets — 组件渲染器（01–09）+ 注册表
   ============================================================ */
(function () {
'use strict';
const GMT = window.GMT;
const U = GMT.U;
const W = GMT.widgets = { registry: {} };

W.setAsof = function (id, text) {
  const el = document.querySelector('#w-' + id + ' [data-asof]');
  if (el) el.textContent = text || '';
};
W.render = function (id, body) {
  const reg = W.registry[id];
  if (!reg) return;
  body.innerHTML = '';
  reg.render(body);
};
W.rerender = function (id) {
  const el = document.getElementById('w-' + id);
  if (el) W.render(id, el.querySelector('.w-body'));
};

/* ---------------- 筛选后的股票样本（热力图与市场宽度共用） ---------------- */
function filteredStocks() {
  const d = GMT.state.data;
  const f = GMT.state.filter;
  let rows = d.stocks.slice();
  if (f.sector !== 'ALL') rows = rows.filter(s => s.g === f.sector);
  if (f.movers === 'UP') rows = rows.filter(s => s.pct > 0);
  if (f.movers === 'DOWN') rows = rows.filter(s => s.pct < 0);
  if (f.search) {
    const q = f.search.trim().toUpperCase();
    rows = rows.filter(s => s.t.toUpperCase().indexOf(q) >= 0 || s.n.toUpperCase().indexOf(q) >= 0);
  }
  return rows;
}
W.filteredStocks = filteredStocks;

W.bindTip = function (el, textFn) {
  el.addEventListener('mousemove', ev => { GMT.ui.tooltip(textFn(), ev.clientX, ev.clientY); });
  el.addEventListener('mouseleave', () => GMT.ui.tooltip(null));
  el.addEventListener('blur', () => GMT.ui.tooltip(null));
};

/* ---------------- 中文时区标注（DST 感知） ---------------- */
const TZ_CN = {
  'Asia/Shanghai': ['北京', 'CST'], 'Asia/Hong_Kong': ['香港', 'HKT'], 'Asia/Tokyo': ['东京', 'JST'],
  'Europe/London': ['伦敦', 'GMT', 'BST'], 'America/New_York': ['美东', 'EST', 'EDT'],
  'America/Toronto': ['多伦多', 'EST', 'EDT'], 'America/Sao_Paulo': ['圣保罗', 'BRT'],
  'Europe/Paris': ['巴黎', 'CET', 'CEST'], 'Europe/Berlin': ['柏林', 'CET', 'CEST'],
  'Europe/Rome': ['罗马', 'CET', 'CEST'], 'Asia/Seoul': ['首尔', 'KST'],
  'Australia/Sydney': ['悉尼', 'AEST', 'AEDT'], 'Asia/Kolkata': ['孟买', 'IST'], 'UTC': ['UTC', 'UTC'],
};
function tzOffsetMin(tz, date) {
  const dtf = new Intl.DateTimeFormat('en-US', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
  const p = {}; dtf.formatToParts(date).forEach(x => { p[x.type] = x.value; });
  const asUtc = Date.UTC(+p.year, +p.month - 1, +p.day, (+p.hour) % 24, +p.minute, +p.second);
  return Math.round((asUtc - date.getTime()) / 60000);
}
W.tzCn = function (tz, date) {
  const e = TZ_CN[tz];
  if (!e) return tz || '';
  if (e.length === 2) return e[0] + ' ' + e[1];
  // 三日制：比较当年 1 月 / 7 月偏移判断 DST（南北半球均适用）
  const d = date || new Date();
  const y = d.getUTCFullYear();
  const offNow = tzOffsetMin(tz, d);
  const offJan = tzOffsetMin(tz, new Date(Date.UTC(y, 0, 1, 12)));
  const offJul = tzOffsetMin(tz, new Date(Date.UTC(y, 6, 1, 12)));
  const isDst = offNow === Math.max(offJan, offJul) && offJan !== offJul;
  return e[0] + ' ' + (isDst ? e[2] : e[1]);
};
W.tzOffsetMin = tzOffsetMin;

/* ---------------- 市场注册表（07 与 08 共用的唯一实现） ---------------- */
const M = (id, name, tz, sess, hours, pre) => ({ id, name, tz, sess, hours, pre });
const MARKET_BY_EX = {
  'SSE': M('SSE', '上海证券交易所', 'Asia/Shanghai', [[570, 690], [780, 900]], '09:30–11:30 13:00–15:00'),
  'HKEX': M('HKEX', '香港交易所', 'Asia/Hong_Kong', [[570, 720], [780, 960]], '09:30–12:00 13:00–16:00'),
  'TSE': M('TSE', '东京证券交易所', 'Asia/Tokyo', [[540, 690], [750, 930]], '09:00–11:30 12:30–15:30'),
  'LSE': M('LSE', '伦敦证券交易所', 'Europe/London', [[480, 990]], '08:00–16:30'),
  'NYSE': M('NYSE', '纽约证券交易所', 'America/New_York', [[570, 960]], '09:30–16:00（盘前 04:00–09:30）', [[240, 570]]),
  'NASDAQ': M('NASDAQ', '纳斯达克', 'America/New_York', [[570, 960]], '09:30–16:00（盘前 04:00–09:30）', [[240, 570]]),
  'CBOE': M('CBOE', '芝加哥期权交易所(指数)', 'America/New_York', [[570, 960]], '09:30–16:00', [[240, 570]]),
  'TSX': M('TSX', '多伦多证券交易所', 'America/Toronto', [[570, 960]], '09:30–16:00'),
  'B3': M('B3', '巴西 B3（圣保罗）', 'America/Sao_Paulo', [[600, 1020]], '10:00–17:00'),
  'Euronext': M('Euronext', 'Euronext（巴黎/阿姆斯特丹等）', 'Europe/Paris', [[540, 1050]], '09:00–17:30'),
  'Euronext Paris': M('Euronext', 'Euronext 巴黎', 'Europe/Paris', [[540, 1050]], '09:00–17:30'),
  'Xetra': M('Xetra', 'Xetra（法兰克福）', 'Europe/Berlin', [[540, 1050]], '09:00–17:30'),
  'Borsa Italiana': M('Borsa Italiana', '意大利证券交易所', 'Europe/Rome', [[540, 1050]], '09:00–17:30'),
  'KRX': M('KRX', '韩国交易所', 'Asia/Seoul', [[540, 930]], '09:00–15:30'),
  'ASX': M('ASX', '澳大利亚证券交易所', 'Australia/Sydney', [[600, 960]], '10:00–16:00'),
  'NSE': M('NSE', '印度国家证券交易所', 'Asia/Kolkata', [[555, 930]], '09:15–15:30'),
};
W.MARKET_BY_EX = MARKET_BY_EX;
W.PULSE_IDS = ['SSE', 'HKEX', 'TSE', 'LSE', 'NYSE'];

function parts(tz, date) {
  const dtf = new Intl.DateTimeFormat('en-US', {
    timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
  });
  const p = {};
  dtf.formatToParts(date).forEach(x => { p[x.type] = x.value; });
  const hh = (+p.hour) % 24;
  const d = new Date(Date.UTC(+p.year, +p.month - 1, +p.day));
  return { y: +p.year, mo: +p.month, d: +p.day, hh, mm: +p.minute, ss: +p.second, dow: d.getUTCDay() };
}
function zonedToUtc(tz, y, mo, d, hh, mm) {
  let t = Date.UTC(y, mo - 1, d, hh, mm);
  for (let i = 0; i < 3; i++) t = Date.UTC(y, mo - 1, d, hh, mm) - tzOffsetMin(tz, new Date(t)) * 60000;
  return t;
}
W.zonedToUtc = zonedToUtc;
W.parts = parts;

/* 07/08 共用：开闭市状态（DST 感知；周末检测；节假日不猜测） */
W.marketStatus = function (mk, now) {
  const w = parts(mk.tz, now);
  const mod = w.hh * 60 + w.mm;
  const weekend = w.dow === 0 || w.dow === 6;
  let status = 'CLOSED', next = null;
  if (!weekend) {
    if (mk.pre && mod >= mk.pre[0][0] && mod < mk.pre[0][1]) status = 'PRE';
    mk.sess.forEach(s => { if (mod >= s[0] && mod < s[1]) status = 'OPEN'; });
    if (status === 'CLOSED' && mk.sess.length > 1 && mod >= mk.sess[0][1] && mod < mk.sess[1][0]) status = 'LUNCH';
    const cands = [];
    (mk.pre || []).forEach(s => cands.push([s[0], 'PRE'], [s[1], 'OPEN']));
    mk.sess.forEach((s, i) => {
      cands.push([s[0], 'OPEN']);
      cands.push([s[1], i < mk.sess.length - 1 ? 'LUNCH' : 'CLOSED']);
    });
    cands.sort((a, b) => a[0] - b[0]);
    for (const c of cands) {
      if (c[0] > mod) { next = { t: zonedToUtc(mk.tz, w.y, w.mo, w.d, Math.floor(c[0] / 60), c[0] % 60), to: c[1] }; break; }
    }
  }
  if (!next) {
    for (let add = 1; add <= 7; add++) {
      const nd = new Date(Date.UTC(w.y, w.mo - 1, w.d + add));
      const dow = nd.getUTCDay();
      if (dow === 0 || dow === 6) continue;
      const openMin = mk.pre ? mk.pre[0][0] : mk.sess[0][0];
      next = {
        t: zonedToUtc(mk.tz, nd.getUTCFullYear(), nd.getUTCMonth() + 1, nd.getUTCDate(), Math.floor(openMin / 60), openMin % 60),
        to: mk.pre ? 'PRE' : 'OPEN',
      };
      break;
    }
  }
  return { status, next, wall: w, weekend };
};
const STATUS_CN = { OPEN: '交易中', PRE: '盘前', LUNCH: '午休', CLOSED: '已收盘', HOLIDAY: '节假日', UNKNOWN: '未知' };
W.statusCn = s => STATUS_CN[s] || s;
W.fmtCountdown = function (ms) {
  if (ms < 0) ms = 0;
  const s = Math.floor(ms / 1000);
  const dd = Math.floor(s / 86400), hh = Math.floor(s % 86400 / 3600), mm = Math.floor(s % 3600 / 60), ss = s % 60;
  if (dd > 0) return dd + ' 天 ' + U.pad(hh) + ' 小时';
  if (hh > 0) return hh + ' 小时 ' + U.pad(mm) + ' 分';
  return U.pad(mm) + ':' + U.pad(ss);
};
const MSTATE_CN = { PREPRE: '未开市', PRE: '盘前', REGULAR: '交易中', POST: '盘后', POSTPOST: '已收盘', CLOSED: '已收盘' };
W.mstateCn = s => MSTATE_CN[s] || s || '—';
const WD_CN = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
W.wdCn = dow => WD_CN[dow] || '';
/* 新闻出版方双语显示：真实出版方（src）+ 聚合层标注。
   有通行中文名 → 《中文》（English）；无 → 英文原名；Yahoo Finance 本身就是出版方时不加聚合后缀 */
W.srcBi = function (s) {
  const c = (window.GMT_SRC_CN || {})[s];
  if (s === 'Yahoo Finance') return c ? c + '（' + s + '）' : s; // 本身即出版方，兼聚合层，不加书名号
  const pub = c ? '《' + c + '》（' + s + '）' : s;
  return pub + ' · 经 Yahoo Finance 聚合';
};

/* ---------------- 热力色阶：红涨 / 绿跌，强度映射 |pct| ---------------- */
function heatColor(pct) {
  const t = Math.min(1, Math.abs(pct) / 4);
  function lerp(a, b) { return Math.round(a + (b - a) * t); }
  if (pct > 0.05) return { bg: 'rgb(' + lerp(42, 255) + ',' + lerp(11, 77) + ',' + lerp(12, 79) + ')', fg: t > 0.55 ? '#000' : '#FFD9DA' };
  if (pct < -0.05) return { bg: 'rgb(' + lerp(11, 0) + ',' + lerp(42, 193) + ',' + lerp(27, 118) + ')', fg: t > 0.55 ? '#000' : '#D7D7D7' };
  return { bg: '#141414', fg: '#8A8A8A' };
}
W.heatColor = heatColor;

/* ---------------- squarified treemap ---------------- */
function squarify(items, x, y, w, h, val) {
  const out = [];
  const total = items.reduce((s, it) => s + val(it), 0);
  if (total <= 0 || w <= 0 || h <= 0) return out;
  const scale = (w * h) / total;
  let row = [], rx = x, ry = y, rw = w, rh = h;
  function worst(r, len) {
    let s = 0, mx = 0, mn = Infinity;
    r.forEach(it => { const a = val(it) * scale; s += a; mx = Math.max(mx, a); mn = Math.min(mn, a); });
    const l2 = len * len, s2 = s * s;
    return Math.max(l2 * mx / s2, s2 / (l2 * mn));
  }
  function layoutRow(r) {
    const s = r.reduce((a, it) => a + val(it) * scale, 0);
    if (rw >= rh) {
      const cw = s / rh; let yy = ry;
      r.forEach(it => { const a = val(it) * scale; const ih = a / cw; out.push({ it, x: rx, y: yy, w: cw, h: ih }); yy += ih; });
      rx += cw; rw -= cw;
    } else {
      const rhh = s / rw; let xx = rx;
      r.forEach(it => { const a = val(it) * scale; const iw = a / rhh; out.push({ it, x: xx, y: ry, w: iw, h: rhh }); xx += iw; });
      ry += rhh; rh -= rhh;
    }
  }
  items.forEach(it => {
    const len = Math.min(rw, rh);
    if (row.length === 0 || worst(row, len) >= worst(row.concat([it]), len)) row.push(it);
    else { layoutRow(row); row = [it]; }
  });
  if (row.length) layoutRow(row);
  return out;
}
W.squarify = squarify;
W.MIN_TILE = 24; // 色块最小边长阈值
})();

/* ================= 01 个股追踪 · 热力矩阵 =================
   双通道编码：面积 = 总市值（可切 成交额），颜色 = 日涨跌幅（红涨绿跌）。
   小于 24px 的色块聚合为「其他 N 只」，点击展开明细。 */
(function () {
'use strict';
const GMT = window.GMT, U = GMT.U, W = GMT.widgets;
const SECT_CN = { 'ALL': '全部', 'AI-TECH': 'AI·科技', 'ENERGY': '能源', 'FINANCIALS': '金融' };

function areaVal(f) {
  return f.area === 'turnover'
    ? (s => Math.max(0.01, (s.vol * s.last) / 1e9))
    : (s => Math.max(0.01, (s.mcap || 0) / 1e9));
}

W.registry.heatmap = {
  num: '01', title: '个股追踪 · 热力矩阵',
  def: { x: 0, y: 0, w: 8, h: 6 }, min: { w: 4, h: 3 },
  render(body) {
    const f = GMT.state.filter;
    if (f.area !== 'mcap' && f.area !== 'turnover') f.area = 'mcap';
    const ctl = U.el('div', 'ctl-row');
    Object.keys(SECT_CN).forEach(s => {
      const b = U.el('button', 'chip' + (f.sector === s ? ' on' : ''), SECT_CN[s]);
      b.addEventListener('click', () => { f.sector = s; GMT.saveFilters(); W.rerender('heatmap'); W.rerender('breadth'); });
      ctl.appendChild(b);
    });
    const mv = U.el('button', 'chip' + (f.movers !== 'ALL' ? ' on' : ''), f.movers === 'ALL' ? '± 涨跌' : f.movers === 'UP' ? '▲ 上涨' : '▼ 下跌');
    mv.title = '切换上涨/下跌筛选';
    mv.addEventListener('click', () => {
      f.movers = f.movers === 'ALL' ? 'UP' : f.movers === 'UP' ? 'DOWN' : 'ALL';
      GMT.saveFilters(); W.rerender('heatmap'); W.rerender('breadth');
    });
    ctl.appendChild(mv);
    const areaB = U.el('button', 'chip', f.area === 'mcap' ? '面积:总市值' : '面积:成交额');
    areaB.title = '色块面积编码';
    areaB.addEventListener('click', () => { f.area = f.area === 'mcap' ? 'turnover' : 'mcap'; GMT.saveFilters(); W.rerender('heatmap'); });
    ctl.appendChild(areaB);
    const listB = U.el('button', 'chip' + (this._list ? ' on' : ''), '≣ 列表');
    listB.title = '切换列表视图';
    listB.addEventListener('click', () => { this._list = !this._list; W.rerender('heatmap'); });
    ctl.appendChild(listB);
    const search = U.el('input');
    search.type = 'search'; search.placeholder = '> 代码'; search.value = f.search || '';
    search.setAttribute('aria-label', '搜索股票代码');
    search.style.marginLeft = 'auto'; search.style.width = '84px';
    search.addEventListener('input', U.debounce(() => { f.search = search.value; GMT.saveFilters(); drawMap(); W.rerender('breadth'); }, 160));
    ctl.appendChild(search);
    body.appendChild(ctl);

    const wrap = U.el('div', 'hm-wrap');
    wrap.style.position = 'relative';
    body.appendChild(wrap);
    const legend = U.el('div', 'legend');
    legend.innerHTML = '<span>-4%</span><span class="legend-bar"></span><span>+4%</span>' +
      '<span style="margin-left:10px">颜色：日涨跌幅（红涨绿跌，强度=幅度）</span>' +
      '<span style="margin-left:10px" data-area-lab></span>';
    body.appendChild(legend);

    const self = this;
    function stockTile(s, tr, parent) {
      const c = W.heatColor(s.pct);
      const t = U.el('div', 'hm-tile');
      t.style.left = tr.x + 'px'; t.style.top = tr.y + 'px';
      t.style.width = Math.max(0, tr.w - 1) + 'px'; t.style.height = Math.max(0, tr.h - 1) + 'px';
      t.style.background = c.bg; t.style.color = c.fg;
      t.tabIndex = 0; t.setAttribute('role', 'button');
      t.setAttribute('aria-label', s.t + ' ' + s.n + ' 最新 ' + U.fmt(s.last) + ' ' + U.pct(s.pct));
      if (tr.w > 58 && tr.h > 34) {
        t.appendChild(U.el('span', 'ht', s.t));
        t.appendChild(U.el('span', 'hp', U.pct(s.pct)));
        if (tr.h > 52 && tr.w > 92) t.appendChild(U.el('span', 'hl', U.fmt(s.last)));
        if (tr.h > 64 && tr.w > 120) t.appendChild(U.el('span', 'hn', s.n));
      } else if (tr.w > 30 && tr.h > 16) {
        t.textContent = s.t;
        t.style.fontSize = '8px'; t.style.fontWeight = '700';
      }
      W.bindTip(t, () => s.t + ' ' + s.n + '\n最新 ' + U.fmt(s.last) + '  ' + U.sign(s.chg) + '（' + U.pct(s.pct) + '）\n成交量 ' + U.fmtCN(s.vol, '股') + ' · 总市值 ' + U.fmtCN(s.mcap, '美元') + '\nas-of ' + (s.asof || '—') + '（' + W.tzCn(s.tz) + '）\n点击查看来源');
      t.addEventListener('click', () => GMT.app.inspect({ type: 'stock', s }));
      t.addEventListener('keydown', ev => { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); GMT.app.inspect({ type: 'stock', s }); } });
      parent.appendChild(t);
    }

    /* 单组布局 + 迭代聚合：普通色块与聚合块都必须 ≥24px；
       聚合块不足 24px 时继续吞并最小的保留块，直至满足或全组聚合 */
    function makeAgg(aggMembers, val) {
      const aggPct = aggMembers.reduce((a, s) => a + s.pct * val(s), 0) / Math.max(0.01, aggMembers.reduce((a, s) => a + val(s), 0));
      const agg = { _agg: true, t: '其他', members: aggMembers.slice(), pct: Math.round(aggPct * 100) / 100 };
      Object.defineProperty(agg, 'mcap', { get: () => agg.members.reduce((a, s) => a + (s.mcap || 0), 0) });
      Object.defineProperty(agg, 'vol', { get: () => agg.members.reduce((a, s) => a + (s.vol || 0), 0) });
      Object.defineProperty(agg, 'last', { get: () => 1 });
      return agg;
    }
    function layoutGroup(members, gx, gy, gw, gh, val) {
      let keep = members.slice();
      let aggMembers = [];
      for (let pass = 0; pass < 12; pass++) {
        const items = aggMembers.length ? keep.concat([makeAgg(aggMembers, val)]) : keep;
        const rects = W.squarify(items, gx, gy, gw, gh, val);
        let aggRect = null;
        const smallIdx = [];
        rects.forEach((r, i) => {
          if (r.it._agg) { aggRect = r; return; }
          /* 判定与渲染同一尺寸：渲染宽/高 = squarify 输出减 1px 缝隙后向下取整，
             必须拿这个值比较（浮点 24.6 渲染为 23.6→23px，不能再放行） */
          if (Math.floor(r.w - 1) < W.MIN_TILE || Math.floor(r.h - 1) < W.MIN_TILE) smallIdx.push(i);
        });
        const aggTooSmall = aggRect && (Math.floor(aggRect.w - 1) < W.MIN_TILE || Math.floor(aggRect.h - 1) < W.MIN_TILE);
        if (!smallIdx.length && !aggTooSmall) return { rects, aggMembers };
        if (smallIdx.length) {
          const smalls = smallIdx.map(i => items[i]);
          aggMembers = aggMembers.concat(smalls);
          keep = items.filter((it, i) => smallIdx.indexOf(i) < 0 && !it._agg);
        } else if (aggTooSmall && keep.length) {
          // 聚合块太小：把当前最小的保留块并入聚合块
          let minI = 0;
          keep.forEach((it, i) => { if (val(it) < val(keep[minI])) minI = i; });
          aggMembers.push(keep[minI]);
          keep.splice(minI, 1);
        } else {
          // 只剩聚合块：全组聚合，占满组区域
          aggMembers = members.slice();
          keep = [];
          const only = [makeAgg(aggMembers, val)];
          return { rects: W.squarify(only, gx, gy, gw, gh, val), aggMembers };
        }
      }
      const items = aggMembers.length ? keep.concat([makeAgg(aggMembers, val)]) : keep;
      return { rects: W.squarify(items, gx, gy, gw, gh, val), aggMembers };
    }

    function drawMap() {
      legend.querySelector('[data-area-lab]').textContent =
        '面积：' + (f.area === 'mcap' ? '总市值（美元）' : '成交额≈量×价（美元）') + ' · 悬停查看报价 · 点击查看来源';
      const rows = W.filteredStocks();
      wrap.innerHTML = '';
      wrap.style.overflow = 'hidden';
      if (self._list) { drawList(rows); return; }
      if (!rows.length) { wrap.appendChild(U.el('div', 'insp-empty', '无匹配标的 — 请清除搜索/筛选。')); return; }
      const rect = wrap.getBoundingClientRect();
      if (rect.width < 40 || rect.height < 40) return;
      const val = areaVal(f);
      const groups = {};
      rows.forEach(s => { (groups[s.g] = groups[s.g] || []).push(s); });
      const gnames = Object.keys(groups).sort();
      const gitems = gnames.map(g => ({ g, sum: groups[g].reduce((a, s) => a + val(s), 0) }));
      const grects = W.squarify(gitems, 1, 1, rect.width - 2, rect.height - 2, it => it.sum);
      grects.forEach(gr => {
        const gEl = U.el('div', 'hm-group');
        gEl.style.left = gr.x + 'px'; gEl.style.top = gr.y + 'px';
        gEl.style.width = Math.max(0, gr.w - 1) + 'px'; gEl.style.height = Math.max(0, gr.h - 1) + 'px';
        const members = groups[gr.it.g];
        const avg = members.reduce((a, s) => a + s.pct, 0) / members.length;
        /* 窄组标题分级降级：优先保住均涨跌幅数值，砍「只」「均」等字，不用 ellipsis 吃数值 */
        const gname = SECT_CN[gr.it.g] || gr.it.g;
        const pctTxt = U.pct(avg);
        const tiers = [
          gname + ' · ' + members.length + ' 只 · 均 ' + pctTxt,
          gname + ' ' + members.length + ' · ' + pctTxt,
          gname + ' ' + pctTxt,
        ];
        const gtEl = U.el('div', 'hm-gtitle', tiers[0]);
        gtEl.title = tiers[0];
        gEl.appendChild(gtEl);
        wrap.appendChild(gEl);
        for (let ti = 1; ti < tiers.length && gtEl.scrollWidth > gtEl.clientWidth; ti++) {
          gtEl.textContent = tiers[ti];
        }
        // 组标题独占 15px 行，色块区自标题下方开始
        const lay = layoutGroup(members, 1, 15, Math.max(1, gr.w - 3), Math.max(1, gr.h - 17), val);
        lay.rects.forEach(tr => {
          if (tr.it._agg) {
            const t = U.el('div', 'hm-tile agg');
            t.style.left = tr.x + 'px'; t.style.top = tr.y + 'px';
            t.style.width = Math.max(0, tr.w - 1) + 'px'; t.style.height = Math.max(0, tr.h - 1) + 'px';
            t.tabIndex = 0; t.setAttribute('role', 'button');
            t.setAttribute('aria-label', '其他 ' + tr.it.members.length + ' 只，点击展开');
            if (tr.w > 44 && tr.h > 24) {
              t.appendChild(U.el('span', 'ht', '其他 ' + tr.it.members.length + ' 只'));
              t.appendChild(U.el('span', 'hp', U.pct(tr.it.pct)));
            } else { t.textContent = '其他'; t.style.fontSize = '8px'; }
            W.bindTip(t, () => '其他 ' + tr.it.members.length + ' 只（' + (SECT_CN[gr.it.g] || gr.it.g) + ' 板块小市值聚合）\n加权均涨跌 ' + U.pct(tr.it.pct) + '\n点击展开明细');
            const open = () => { self._drill = { g: gr.it.g, members: tr.it.members }; drawMap(); };
            t.addEventListener('click', open);
            t.addEventListener('keydown', ev => { if (ev.key === 'Enter') open(); });
            gEl.appendChild(t);
          } else {
            stockTile(tr.it, tr, gEl);
          }
        });
      });
      // 下钻视图
      if (self._drill) {
        const dz = U.el('div', 'hm-drill');
        const back = U.el('button', 'chip', '← 返回热力图');
        back.addEventListener('click', () => { self._drill = null; drawMap(); });
        dz.appendChild(back);
        const tbl = U.el('table', 'hm-list');
        tbl.innerHTML = '<thead><tr><th>代码 · 名称</th><th>最新</th><th>涨跌</th><th>涨跌幅</th><th>总市值</th></tr></thead>';
        const tb = U.el('tbody');
        self._drill.members.slice().sort((a, b) => (b.mcap || 0) - (a.mcap || 0)).forEach(s => {
          const tr = U.el('tr');
          tr.tabIndex = 0;
          tr.innerHTML = '<td>' + U.esc(s.t) + ' <span style="color:var(--fg-dim)">' + U.esc(s.n) + '</span></td>' +
            '<td>' + U.fmt(s.last) + '</td><td class="' + U.cls(s.chg) + '">' + U.sign(s.chg) + '</td>' +
            '<td class="' + U.cls(s.pct) + '">' + U.pct(s.pct) + '</td><td>' + U.fmtCN(s.mcap, '美元') + '</td>';
          tr.addEventListener('click', () => GMT.app.inspect({ type: 'stock', s }));
          tb.appendChild(tr);
        });
        tbl.appendChild(tb);
        dz.appendChild(tbl);
        wrap.appendChild(dz);
      }
    }
    function drawList(rows) {
      const tbl = U.el('table', 'hm-list');
      tbl.innerHTML = '<thead><tr><th>代码 · 名称</th><th>最新</th><th>涨跌</th><th>涨跌幅</th><th>成交量</th><th>总市值</th></tr></thead>';
      const tb = U.el('tbody');
      rows.slice().sort((a, b) => b.pct - a.pct).forEach(s => {
        const tr = U.el('tr');
        tr.tabIndex = 0;
        tr.innerHTML = '<td>' + U.esc(s.t) + ' <span style="color:var(--fg-dim)">' + U.esc(s.n) + '</span></td>' +
          '<td>' + U.fmt(s.last) + '</td><td class="' + U.cls(s.chg) + '">' + U.sign(s.chg) + '</td>' +
          '<td class="' + U.cls(s.pct) + '">' + U.pct(s.pct) + '</td><td>' + U.fmtCN(s.vol, '股') + '</td><td>' + U.fmtCN(s.mcap, '美元') + '</td>';
        tr.addEventListener('click', () => GMT.app.inspect({ type: 'stock', s }));
        tr.addEventListener('keydown', ev => { if (ev.key === 'Enter') GMT.app.inspect({ type: 'stock', s }); });
        tb.appendChild(tr);
      });
      tbl.appendChild(tb);
      wrap.appendChild(tbl);
      wrap.style.overflow = 'auto';
    }
    drawMap();
    this._draw = drawMap;
    W.setAsof('heatmap', 'as-of ' + (GMT.state.data.stocks[0] || {}).asof + '（' + W.tzCn('America/New_York') + '）');
  },
  onResize() { if (this._draw) this._draw(); },
};

/* ================= 02 市场宽度 ================= */
W.registry.breadth = {
  num: '02', title: '市场宽度',
  def: { x: 8, y: 0, w: 4, h: 2 }, min: { w: 3, h: 2 },
  render(body) {
    const rows = W.filteredStocks();
    const up = rows.filter(s => s.pct > 0), down = rows.filter(s => s.pct < 0), flat = rows.filter(s => s.pct === 0);
    const ratio = down.length ? (up.length / down.length) : up.length;
    const sorted = rows.slice().sort((a, b) => b.pct - a.pct);
    const topG = sorted[0], topL = sorted[sorted.length - 1];
    const bySector = {};
    rows.forEach(s => { const o = bySector[s.g] = bySector[s.g] || { vol: 0, n: 0 }; o.vol += s.vol; o.n++; });
    let active = '—', av = -1;
    Object.keys(bySector).forEach(g => { if (bySector[g].vol > av) { av = bySector[g].vol; active = g; } });
    // 中位数：偶数样本取中间两位均值
    const pcts = rows.map(s => s.pct).sort((a, b) => a - b);
    const n = pcts.length;
    const median = n ? (n % 2 ? pcts[(n - 1) / 2] : (pcts[n / 2 - 1] + pcts[n / 2]) / 2) : null;
    const SECT_CN2 = { 'AI-TECH': 'AI·科技', 'ENERGY': '能源', 'FINANCIALS': '金融' };
    const g = U.el('div', 'bd-grid');
    function cell(label, value, cls, sub, onclick, tip) {
      const c = U.el('div', 'bd-cell');
      c.tabIndex = 0; c.setAttribute('role', 'button');
      c.appendChild(U.el('div', 'bl', label));
      c.appendChild(U.el('div', 'bv' + (cls ? ' ' + cls : ''), value));
      if (sub) c.appendChild(U.el('div', 'bs', sub));
      if (onclick) {
        c.addEventListener('click', onclick);
        c.addEventListener('keydown', ev => { if (ev.key === 'Enter') onclick(); });
      }
      if (tip) W.bindTip(c, () => tip);
      return c;
    }
    const f = GMT.state.filter;
    function setMovers(m) { return () => { f.movers = m; GMT.saveFilters(); W.rerender('heatmap'); W.rerender('breadth'); }; }
    g.appendChild(cell('上涨', String(up.length), 'up', '点击：筛选上涨', setMovers('UP')));
    g.appendChild(cell('下跌', String(down.length), 'down', '点击：筛选下跌', setMovers('DOWN')));
    g.appendChild(cell('平盘', String(flat.length), 'flat', '点击：重置', setMovers('ALL')));
    g.appendChild(cell('涨跌比', U.fmt(ratio, 2), '', up.length + '/' + down.length, null, '上涨数 ÷ 下跌数（当前筛选样本）'));
    g.appendChild(cell('领涨', topG ? topG.t + ' ' + U.pct(topG.pct) : '—', 'up', topG ? topG.n : '',
      topG ? () => GMT.app.inspect({ type: 'stock', s: topG }) : null));
    g.appendChild(cell('领跌', topL ? topL.t + ' ' + U.pct(topL.pct) : '—', 'down', topL ? topL.n : '',
      topL ? () => GMT.app.inspect({ type: 'stock', s: topL }) : null));
    g.appendChild(cell('最活跃板块', SECT_CN2[active] || active, '', '按样本合计成交量',
      active !== '—' ? () => { f.sector = active; GMT.saveFilters(); W.rerender('heatmap'); W.rerender('breadth'); } : null,
      '点击：热力图筛选至 ' + (SECT_CN2[active] || active)));
    g.appendChild(cell('样本数', rows.length + ' / ' + GMT.state.data.stocks.length, '', '跟踪标的 — 非全市场'));
    g.appendChild(cell('涨跌幅中位数', median === null ? '—' : U.pct(median), '', '偶数样本取中间两位均值'));
    g.style.height = 'calc(100% - 16px)';
    body.appendChild(g);
    body.appendChild(U.el('div', 'bd-note', '统计仅描述当前筛选下的 ' + rows.length + ' 只跟踪样本，不代表全市场宽度。'));
    W.setAsof('breadth', 'as-of ' + (GMT.state.data.stocks[0] || {}).asof + '（' + W.tzCn('America/New_York') + '）');
  },
};
})();

/* ================= 03 新闻快讯（真实新闻：Yahoo Finance） ================= */
(function () {
'use strict';
const GMT = window.GMT, U = GMT.U, W = GMT.widgets;
const cnOf = n => (window.GMT_NEWS_CN || {})[n.url] || null;
W.registry.news = {
  num: '03', title: '新闻快讯',
  def: { x: 8, y: 2, w: 4, h: 4 }, min: { w: 3, h: 3 },
  render(body) {
    const d = GMT.state.data;
    const st = this._st = this._st || { cat: 'ALL', q: '' };
    const cats = [['ALL', '全部'], ['AI', 'AI'], ['TECH', '科技'], ['ENERGY', '能源'], ['FINANCE', '金融'], ['MACRO', '宏观'], ['METALS', '金属']];
    const ctl = U.el('div', 'ctl-row');
    cats.forEach(([v, l]) => {
      const b = U.el('button', 'chip' + (st.cat === v ? ' on' : ''), l);
      b.addEventListener('click', () => { st.cat = v; W.rerender('news'); });
      ctl.appendChild(b);
    });
    const pause = U.el('button', 'chip' + (GMT.state.newsPaused ? ' on' : ''), GMT.state.newsPaused ? '❚❚ 已暂停' : '▶ 自动');
    pause.title = '暂停 / 继续快讯轮询';
    pause.addEventListener('click', () => { GMT.state.newsPaused = !GMT.state.newsPaused; W.rerender('news'); });
    ctl.appendChild(pause);
    const q = U.el('input');
    q.type = 'search'; q.placeholder = '> 关键词'; q.value = st.q; q.style.width = '76px';
    q.setAttribute('aria-label', '搜索新闻');
    q.addEventListener('input', U.debounce(() => { st.q = q.value; draw(); }, 160));
    ctl.appendChild(q);
    body.appendChild(ctl);

    const list = U.el('div');
    list.style.cssText = 'position:absolute;top:27px;bottom:0;left:0;right:0;overflow:auto;';
    body.appendChild(list);

    const lastSeen = GMT.state.newsLastSeen || '';
    function draw() {
      const old = list.querySelector('.nw-detail');
      list.innerHTML = '';
      let items = d.news.slice();
      if (st.cat !== 'ALL') items = items.filter(n => n.cat === st.cat);
      if (st.q) {
        const qq = st.q.toUpperCase();
        items = items.filter(n => {
          const cn = cnOf(n);
          return (n.h + ' ' + (cn ? cn.h + ' ' + cn.sum : '') + ' ' + n.tk.join(' ')).toUpperCase().indexOf(qq) >= 0;
        });
      }
      if (!items.length) { list.appendChild(U.el('div', 'insp-empty', '无匹配快讯。')); return; }
      items.forEach(n => {
        const cn = cnOf(n);
        const it = U.el('div', 'nw-item' + (n.ts > lastSeen ? ' unread' : ''));
        it.tabIndex = 0;
        it.innerHTML = '<span class="nw-c">' + U.esc(n.cat) + '</span>' +
          '<span class="nw-h"><span class="nw-ht">' + U.esc(cn ? cn.h : n.h) + '</span>' +
          (cn ? '<span class="nw-he">' + U.esc(n.h) + '</span>' : '') + '</span>';
        W.bindTip(it, () => (cn ? cn.h + '\n' + n.h + '\n' : n.h + '\n') + W.srcBi(n.src) + '\n' + n.ts + '\n点击查看详情与原文链接');
        it.addEventListener('click', () => select(n));
        it.addEventListener('keydown', ev => { if (ev.key === 'Enter') select(n); });
        list.appendChild(it);
      });
      if (old) list.insertBefore(old, list.firstChild);
    }
    function select(n) {
      GMT.state.newsLastSeen = n.ts; GMT.store.set('newsLastSeen', n.ts);
      const cn = cnOf(n);
      const det = U.el('div', 'nw-detail');
      det.innerHTML = '<h4>' + U.esc(cn ? cn.h : n.h) + '</h4>' +
        (cn ? '<div class="meta nw-orig">英文原题：' + U.esc(n.h) + '</div>' : '') +
        '<div class="meta">' + U.esc(n.ts) + ' · 来源 ' + U.esc(W.srcBi(n.src)) + '</div>' +
        (cn && cn.sum ? '<p>' + U.esc(cn.sum) + '</p>' : '') +
        (n.sum ? '<p class="nw-orig">' + (cn ? '英文摘要：' : '') + U.esc(n.sum) + '</p>' : '') +
        '<div class="meta">相关代码: <span class="tickers"></span></div>' +
        (n.url ? '<div class="meta">原文链接: <a href="' + U.esc(n.url) + '" target="_blank" rel="noopener" style="color:var(--cyan)">' + U.esc(n.url.slice(0, 64)) + '…</a></div>' : '');
      const tkw = det.querySelector('.tickers');
      if (!n.tk.length) tkw.appendChild(U.el('span', '', '—'));
      n.tk.forEach(t => {
        const s = GMT.state.data.stocks.find(x => x.t === t);
        const sp = U.el('span', '', t + (s ? ' ' + U.pct(s.pct) : ''));
        sp.addEventListener('click', ev => { ev.stopPropagation(); if (s) GMT.app.inspect({ type: 'stock', s }); });
        tkw.appendChild(sp);
      });
      const old = list.querySelector('.nw-detail'); if (old) old.remove();
      list.insertBefore(det, list.firstChild);
      GMT.app.inspect({ type: 'news', n });
    }
    draw();
    W.setAsof('news', (GMT.state.newsPaused ? '已暂停 · ' : '自动 30s · ') + '抓取于 ' + GMT.state.data.meta.fetchedAt.slice(5, 16) + '（北京）');
  },
};

/* ================= 05 板块日内走势 ================= */
W.registry.sector = {
  num: '05', title: '板块日内走势',
  def: { x: 7, y: 6, w: 5, h: 5 }, min: { w: 3, h: 3 },
  render(body) {
    const d = GMT.state.data;
    const names = ['AI-TECH', 'ENERGY', 'FINANCIALS'];
    const CN = { 'AI-TECH': 'AI·科技', 'ENERGY': '能源', 'FINANCIALS': '金融' };
    const colors = ['#F28C00', '#4DD0E1', '#D7D7D7'];
    const leg = U.el('div', 'sector-legend');
    names.forEach((n, i) => {
      const sp = U.el('span');
      const info = d.sectorIntraday[n];
      sp.innerHTML = '<i style="background:' + colors[i] + '"></i>' + CN[n] + '（' + info.proxy + '） <b style="color:' + colors[i] + '">' + U.pct(info.finalPct) + '</b>';
      leg.appendChild(sp);
    });
    body.appendChild(leg);
    const box1 = U.el('div', 'chart-box');
    box1.style.flex = '1.4';
    const c1 = U.el('canvas');
    c1.setAttribute('role', 'img');
    c1.setAttribute('aria-label', '板块日内归一化曲线，开盘为百分之零，24 个采样点');
    box1.appendChild(c1);
    body.appendChild(box1);
    const box2 = U.el('div', 'chart-box');
    const c2 = U.el('canvas');
    c2.setAttribute('role', 'img');
    c2.setAttribute('aria-label', '板块样本股等权平均涨跌幅条形图');
    box2.appendChild(c2);
    body.appendChild(box2);
    body.appendChild(U.el('div', 'chart-note', '曲线：' + d.sectorIntraday[names[0]].session + '，' + names.map(n => d.sectorIntraday[n].proxy).join('/') + ' ETF 5 分钟线归一化（开盘=0%，24 采样）；条形：36 只样本股按板块等权平均（对前收，n 已标注）。两种口径并列展示，不伪装同步；非美市场显示其最近收盘。'));
    function draw() {
      GMT.charts.multiLine(c1, names.map(n => ({ pts: d.sectorIntraday[n].pts })), { colors });
      GMT.charts.hBars(c2, names.map(n => ({ label: CN[n], v: d.sectorIntraday[n].avg, n: d.sectorIntraday[n].n })));
    }
    this._draw = draw; draw();
    W.setAsof('sector', d.sectorIntraday[names[0]].session + ' · 等权');
  },
  onResize() { if (this._draw) this._draw(); },
};
})();

/* ================= 04 AAPL · 近 60 个交易日 ================= */
(function () {
'use strict';
const GMT = window.GMT, U = GMT.U, W = GMT.widgets;
W.registry.aapl = {
  num: '04', title: 'AAPL · 近 60 个交易日',
  def: { x: 0, y: 6, w: 7, h: 5 }, min: { w: 4, h: 3 },
  render(body) {
    const d = GMT.state.data.aapl;
    const rows = d.rows, n = rows.length;
    const last = rows[n - 1], prev = rows[n - 2];
    const chg = Math.round((last.c - prev.c) * 100) / 100;
    const pct = Math.round(chg / prev.c * 10000) / 100;
    const strip = U.el('div', 'stat-strip');
    function st(l, v, cls) {
      const s = U.el('div', 'stat');
      s.appendChild(U.el('div', 'sl', l));
      s.appendChild(U.el('div', 'sv' + (cls ? ' ' + cls : ''), v));
      return s;
    }
    strip.appendChild(st('最新', U.fmt(last.c)));
    strip.appendChild(st('涨跌', U.sign(chg), U.cls(chg)));
    strip.appendChild(st('涨跌幅', U.pct(pct), U.cls(pct)));
    strip.appendChild(st('开盘', U.fmt(last.o)));
    strip.appendChild(st('前收', U.fmt(prev.c)));
    strip.appendChild(st('最高', U.fmt(last.h), 'up'));
    strip.appendChild(st('最低', U.fmt(last.l), 'down'));
    strip.appendChild(st('成交量', U.fmtCN(last.v, '股')));
    strip.appendChild(st('52 周区间', U.fmt(d.w52[0]) + '–' + U.fmt(d.w52[1])));
    body.appendChild(strip);

    const box = U.el('div', 'chart-box');
    const cv = U.el('canvas');
    cv.tabIndex = 0;
    cv.setAttribute('role', 'img');
    cv.setAttribute('aria-label', 'AAPL 近 60 个交易日价格线与成交量柱。用左右方向键移动十字准星。');
    box.appendChild(cv);
    const readout = U.el('div', 'chart-readout');
    readout.textContent = '悬停或用 ← → 查看 — 共 ' + n + ' 个交易日';
    box.appendChild(readout);
    body.appendChild(box);
    body.appendChild(U.el('div', 'chart-note', 'X 轴：' + rows[0].date + ' → ' + rows[n - 1].date + ' · 恰好 60 个交易日 · 未复权价格（不做拆股/分红调整）· 成交量单位为股 · 与 01 号组件 AAPL 同源同交易日'));

    let sel = null;
    const self = this;
    function draw() {
      const m = GMT.charts.priceVolume(cv, rows, { prevClose: prev.c, selected: sel });
      self._geom = m;
      if (sel !== null && rows[sel]) {
        const r = rows[sel];
        readout.textContent = r.date + '  开 ' + U.fmt(r.o) + '  高 ' + U.fmt(r.h) + '  低 ' + U.fmt(r.l) + '  收 ' + U.fmt(r.c) + '  量 ' + U.fmtCN(r.v, '股');
      }
    }
    function idxFromEvent(ev) {
      const r = cv.getBoundingClientRect();
      const m = self._geom; if (!m) return null;
      const t = (ev.clientX - r.left - m.padL) / (r.width - m.padL - m.padR);
      return Math.max(0, Math.min(m.n - 1, Math.round(t * (m.n - 1))));
    }
    cv.addEventListener('mousemove', ev => {
      const i = idxFromEvent(ev);
      if (i === null) return;
      sel = i; draw();
      const r = rows[i];
      GMT.ui.tooltip('AAPL ' + r.date + '\n开 ' + U.fmt(r.o) + ' 高 ' + U.fmt(r.h) + '\n低 ' + U.fmt(r.l) + ' 收 ' + U.fmt(r.c) + '\n量 ' + U.fmtCN(r.v, '股') + '\n点击查看来源', ev.clientX, ev.clientY);
    });
    cv.addEventListener('mouseleave', () => { GMT.ui.tooltip(null); });
    cv.addEventListener('click', () => {
      if (sel !== null && rows[sel]) GMT.app.inspect({ type: 'aapl-point', r: rows[sel], prevClose: prev.c });
    });
    cv.addEventListener('keydown', ev => {
      if (ev.key === 'ArrowLeft' || ev.key === 'ArrowRight') {
        ev.preventDefault();
        sel = sel === null ? rows.length - 1 : Math.max(0, Math.min(rows.length - 1, sel + (ev.key === 'ArrowRight' ? 1 : -1)));
        draw();
      } else if (ev.key === 'Enter' && sel !== null) {
        GMT.app.inspect({ type: 'aapl-point', r: rows[sel], prevClose: prev.c });
      }
    });
    this._draw = draw; draw();
    W.setAsof('aapl', 'as-of ' + rows[n - 1].date + '（' + W.tzCn('America/New_York') + ' 收盘）');
  },
  onResize() { if (this._draw) this._draw(); },
};

/* ================= 06 贵金属 ================= */
W.registry.metals = {
  num: '06', title: '贵金属 · XAU XAG XPT XPD',
  def: { x: 0, y: 11, w: 7, h: 6 }, min: { w: 4, h: 4 },
  render(body) {
    const d = GMT.state.data;
    const M = d.metals.items, drv = d.metals.derived;
    const selKey = GMT.state.selectedMetal;
    const dates = M[selKey].dates;
    const qg = U.el('div', 'met-quotes');
    Object.keys(M).forEach(k => {
      const m = M[k];
      const q = U.el('div', 'met-q' + (k === selKey ? ' sel' : ''));
      q.tabIndex = 0; q.setAttribute('role', 'button');
      q.setAttribute('aria-label', k + ' 最新 ' + U.fmt(m.last) + ' ' + U.pct(m.pct));
      const rangeFull = '60 日 ' + U.fmt(m.r60[0]) + '–' + U.fmt(m.r60[1]) + ' · as-of ' + m.asof;
      q.innerHTML = '<div><span class="mn">' + k + '</span> <span class="mu">' + U.esc(m.name) + ' · ' + U.esc(m.unit) + '</span></div>' +
        '<div class="ml">' + U.fmt(m.last) + '</div>' +
        '<div class="mc ' + U.cls(m.chg) + '">' + U.arrow(m.chg) + ' ' + U.sign(m.chg) + '（' + U.pct(m.pct) + '）</div>' +
        '<div class="mu range" data-full="' + U.esc(rangeFull) + '">' + U.esc(rangeFull) + '</div>';
      const sp = U.el('canvas');
      q.appendChild(sp);
      const select = () => {
        GMT.state.selectedMetal = k; GMT.store.set('metal', k);
        W.rerender('metals');
        GMT.app.inspect({ type: 'metal', k, m });
      };
      q.addEventListener('click', select);
      q.addEventListener('keydown', ev => { if (ev.key === 'Enter') select(); });
      W.bindTip(q, () => m.name + ' ' + m.unit + '\n最新 ' + U.fmt(m.last) + ' ' + U.sign(m.chg) + '（' + U.pct(m.pct) + '）\n' + rangeFull + '\n点击载入 60 日主图');
      qg.appendChild(q);
      requestAnimationFrame(() => GMT.charts.spark(sp, m.spark, m.chg >= 0));
    });
    body.appendChild(qg);
    /* 窄宽降级：<340px 时间轴行折叠为「区间 ▾」，完整值悬停/点击（检查器）可见 */
    const checkNarrow = () => {
      const narrow = body.clientWidth < 340;
      body.classList.toggle('narrow', narrow);
      qg.querySelectorAll('.mu.range').forEach(elm => {
        elm.textContent = narrow ? '区间 ▾（悬停查看）' : elm.getAttribute('data-full');
      });
    };
    this._checkNarrow = checkNarrow;
    checkNarrow();

    const dv = U.el('div', 'met-derived');
    function dcell(label, val, formula) {
      const c = U.el('div', 'met-d');
      c.innerHTML = U.esc(label) + '<b>' + U.esc(val) + '</b><br><span style="color:var(--fg-faint)">' + U.esc(formula) + '</span>';
      return c;
    }
    dv.appendChild(dcell('金银比', U.fmt(drv.gsr.v, 2) + 'x', drv.gsr.formula + ' · ' + drv.gsr.unit));
    dv.appendChild(dcell('金铂价差', U.fmt(drv.gps.v, 2), drv.gps.formula + ' · ' + drv.gps.unit));
    Object.keys(M).forEach(k => {
      dv.appendChild(dcell(k + ' 60 日区间', U.fmt(M[k].r60[0]) + ' – ' + U.fmt(M[k].r60[1]), '60 个交易日收盘价 min–max · ' + M[k].unit));
    });
    body.appendChild(dv);

    const box = U.el('div', 'chart-box');
    const cv = U.el('canvas');
    cv.tabIndex = 0;
    cv.setAttribute('role', 'img');
    cv.setAttribute('aria-label', selKey + ' 近 60 个交易日价格图');
    box.appendChild(cv);
    const readout = U.el('div', 'chart-readout', selKey + ' · 60 个交易日 · 悬停查看数值');
    box.appendChild(readout);
    body.appendChild(box);
    body.appendChild(U.el('div', 'chart-note', d.metals.caliber + ' 衍生指标可合法计算：四种金属均为同一数据源期货日线，序列末值即展示最新价，未混用现货/期货口径。'));

    let sel = null;
    const self = this;
    const pts = M[selKey].s60;
    function draw() {
      const g = GMT.charts.line60(cv, pts, dates, { selected: sel });
      self._geom = g;
      if (sel !== null) readout.textContent = selKey + '  ' + dates[sel] + '  ' + U.fmt(pts[sel]) + ' ' + M[selKey].unit;
    }
    cv.addEventListener('mousemove', ev => {
      const r = cv.getBoundingClientRect(), g = self._geom; if (!g) return;
      const t = (ev.clientX - r.left - 8) / (r.width - 8 - 50);
      sel = Math.max(0, Math.min(g.n - 1, Math.round(t * (g.n - 1))));
      draw();
      GMT.ui.tooltip(selKey + ' ' + dates[sel] + '\n' + U.fmt(pts[sel]) + ' ' + M[selKey].unit + '\n点击查看来源', ev.clientX, ev.clientY);
    });
    cv.addEventListener('mouseleave', () => GMT.ui.tooltip(null));
    cv.addEventListener('click', () => GMT.app.inspect({ type: 'metal', k: selKey, m: M[selKey], point: sel !== null ? { date: dates[sel], v: pts[sel] } : null }));
    cv.addEventListener('keydown', ev => {
      if (ev.key === 'ArrowLeft' || ev.key === 'ArrowRight') {
        ev.preventDefault();
        sel = sel === null ? pts.length - 1 : Math.max(0, Math.min(pts.length - 1, sel + (ev.key === 'ArrowRight' ? 1 : -1)));
        draw();
      }
    });
    this._draw = draw; draw();
    W.setAsof('metals', 'as-of ' + M[selKey].asof + '（期货日线）');
  },
  onResize() { if (this._draw) this._draw(); if (this._checkNarrow) this._checkNarrow(); },
};
})();

/* ================= 07 市场脉搏 · 全球时钟 ================= */
(function () {
'use strict';
const GMT = window.GMT, U = GMT.U, W = GMT.widgets;
const TZ_OPTS = [
  ['local', '本地（浏览器）'], ['UTC', 'UTC'], ['Asia/Shanghai', '北京'], ['Asia/Hong_Kong', '香港'],
  ['Asia/Tokyo', '东京'], ['Europe/London', '伦敦'], ['America/New_York', '纽约'],
];

W.registry.pulse = {
  num: '07', title: '市场脉搏 · 全球时钟',
  def: { x: 7, y: 11, w: 5, h: 5 }, min: { w: 4, h: 4 },
  render(body) {
    if (this._timer) { clearInterval(this._timer); this._timer = null; }
    const top = U.el('div', 'pulse-top');
    const sel = U.el('select');
    sel.setAttribute('aria-label', '显示时区');
    TZ_OPTS.forEach(([v, l]) => { const o = U.el('option', '', l); o.value = v; sel.appendChild(o); });
    sel.value = GMT.state.tz;
    sel.addEventListener('change', () => { GMT.state.tz = sel.value; GMT.store.set('tz', sel.value); });
    top.appendChild(sel);
    const clock = U.el('div', 'big-clock', '--:--:--');
    top.appendChild(clock);
    const datel = U.el('div', 'big-date', '');
    top.appendChild(datel);
    body.appendChild(top);

    const tbl = U.el('table', 'mk-table');
    tbl.innerHTML = '<thead><tr><th>市场</th><th>状态</th><th>当地</th><th>交易时段</th><th>下次切换</th></tr></thead>';
    const tb = U.el('tbody');
    tbl.appendChild(tb);
    body.appendChild(tbl);
    body.appendChild(U.el('div', 'chart-note', '已检测周末；未加载交易所节假日日历 — 工作日场次标注为「节假日状态未核实」。DST 由 IANA 时区库处理。'));
    const mapBox = U.el('div', 'session-box');
    const mapCv = U.el('canvas');
    mapCv.setAttribute('role', 'img');
    mapCv.setAttribute('aria-label', '24 小时全球交易时段图，UTC 轴，含移动 NOW 线');
    mapBox.appendChild(mapCv);
    body.appendChild(mapBox);
    body.appendChild(U.el('div', 'chart-note', '时段以 UTC 绘制（今日，已按 DST 调整）；NOW 线 = 当前 UTC 时刻。'));

    function tick() {
      const now = new Date();
      const tz = GMT.state.tz === 'local' ? undefined : GMT.state.tz;
      let p;
      if (tz) p = W.parts(tz, now);
      else {
        const off = -now.getTimezoneOffset();
        p = { y: now.getFullYear(), mo: now.getMonth() + 1, d: now.getDate(), hh: now.getHours(), mm: now.getMinutes(), ss: now.getSeconds(), dow: now.getDay(), off, local: true };
      }
      clock.textContent = U.pad(p.hh) + ':' + U.pad(p.mm) + ':' + U.pad(p.ss);
      let tzLab;
      if (tz) {
        const o = W.tzOffsetMin(tz, now), s = o >= 0 ? '+' : '-', a = Math.abs(o);
        tzLab = W.tzCn(tz, now) + '（UTC' + s + U.pad(Math.floor(a / 60)) + ':' + U.pad(a % 60) + '）';
      } else {
        const a = Math.abs(p.off);
        tzLab = '本地（UTC' + (p.off >= 0 ? '+' : '-') + U.pad(Math.floor(a / 60)) + ':' + U.pad(a % 60) + '）';
      }
      datel.textContent = W.wdCn(p.dow) + ' ' + p.y + '-' + U.pad(p.mo) + '-' + U.pad(p.d) + ' · ' + tzLab;
      tb.innerHTML = '';
      W.PULSE_IDS.forEach(id => {
        const mk = W.MARKET_BY_EX[id];
        const st = W.marketStatus(mk, now);
        const tr = U.el('tr');
        tr.tabIndex = 0;
        const stTxt = st.weekend ? '已收盘' : W.statusCn(st.status);
        const sub = st.weekend ? '（周末）' : '';
        const cd = st.next ? W.fmtCountdown(st.next.t - now.getTime()) : '—';
        tr.innerHTML = '<td><b>' + mk.id + '</b></td>' +
          '<td><span class="badge ' + (st.weekend ? 'CLOSED' : st.status) + '">' + stTxt + sub + '</span></td>' +
          '<td>' + U.pad(st.wall.hh) + ':' + U.pad(st.wall.mm) + '</td>' +
          '<td style="color:var(--fg-dim)">' + U.esc(mk.hours) + '</td>' +
          '<td>' + (st.next ? '→' + W.statusCn(st.next.to) + ' ' + cd : '—') + '</td>';
        const inspect = () => GMT.app.inspect({ type: 'market', mk, st, cd });
        tr.addEventListener('click', inspect);
        tr.addEventListener('keydown', ev => { if (ev.key === 'Enter') inspect(); });
        tb.appendChild(tr);
      });
      const utcMid = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
      const nowMin = (now.getTime() - utcMid) / 60000;
      const rows = W.PULSE_IDS.map(id => {
        const mk = W.MARKET_BY_EX[id];
        const w = W.parts(mk.tz, now);
        const wins = mk.sess.map(s => {
          const t0 = W.zonedToUtc(mk.tz, w.y, w.mo, w.d, Math.floor(s[0] / 60), s[0] % 60);
          const t1 = W.zonedToUtc(mk.tz, w.y, w.mo, w.d, Math.floor(s[1] / 60), s[1] % 60);
          return [Math.max(0, (t0 - utcMid) / 60000), Math.min(1440, (t1 - utcMid) / 60000)];
        });
        return { short: mk.id, windows: wins };
      });
      GMT.charts.sessionMap(mapCv, rows, Math.min(1439, Math.max(0, nowMin)));
    }
    tick();
    this._timer = setInterval(tick, 1000);
    W.setAsof('pulse', '实时时钟 · IANA 时区 · 节假日未核实');
  },
  onResize() { /* canvas 每秒重绘 */ },
};

/* ================= 08 全球指数一览（状态复用 07 的时区计算） ================= */
W.registry.indexlist = {
  num: '08', title: '全球指数一览',
  def: { x: 7, y: 16, w: 5, h: 6 }, min: { w: 3, h: 3 },
  render(body) {
    if (this._timer) { clearInterval(this._timer); this._timer = null; }
    const d = GMT.state.data;
    const wrap = U.el('div');
    body.appendChild(wrap);
    function draw() {
      const now = new Date();
      wrap.innerHTML = '';
      d.indexList.forEach(reg => {
        wrap.appendChild(U.el('div', 'ix-region', '▸ ' + reg.region));
        const tbl = U.el('table', 'ix-table');
        const tb = U.el('tbody');
        reg.rows.forEach(r => {
          const mk = W.MARKET_BY_EX[r.ex];
          const st = mk ? W.marketStatus(mk, now) : null;
          const stTxt = st ? (st.weekend ? '已收盘' : W.statusCn(st.status)) : '—';
          const stCls = st ? (st.weekend ? 'CLOSED' : st.status) : 'CLOSED';
          const tr = U.el('tr');
          tr.tabIndex = 0;
          tr.innerHTML = '<td><b>' + U.esc(r.n) + '</b> <span style="color:var(--fg-faint)">' + U.esc(r.ex) + '</span></td>' +
            '<td class="r">' + U.fmt(r.last) + '</td>' +
            '<td class="r ' + U.cls(r.pct) + '">' + U.pct(r.pct) + '</td>' +
            '<td><span class="badge ' + stCls + '">' + stTxt + '</span></td>';
          const go = () => GMT.app.inspect({ type: 'index', r, region: reg.region, st, mk });
          tr.addEventListener('click', go);
          tr.addEventListener('keydown', ev => { if (ev.key === 'Enter') go(); });
          tb.appendChild(tr);
        });
        tbl.appendChild(tb);
        wrap.appendChild(tbl);
      });
      wrap.appendChild(U.el('div', 'chart-note', '开闭市状态由 07 号组件的 IANA 时区计算实时驱动（与本行一致，无硬编码）；各地 as-of 见检查器。'));
    }
    draw();
    this._timer = setInterval(draw, 30000);
    W.setAsof('indexlist', '状态实时计算 · 30s 刷新');
  },
};

/* ================= 09 数据状态 · 数据源 ================= */
W.registry.datastatus = {
  num: '09', title: '数据状态 · 数据源',
  def: { x: 0, y: 22, w: 12, h: 3, hidden: true }, min: { w: 4, h: 2 },
  render(body) {
    const wrap = U.el('div');
    wrap.style.padding = '4px 0';
    body.appendChild(wrap);
    function draw() {
      const rows = GMT.dataStatus.list();
      const tbl = U.el('table', 'ds-table');
      tbl.innerHTML = '<thead><tr><th>数据源</th><th>状态</th><th>最后成功</th><th>延迟</th><th>错误</th><th>回退</th></tr></thead>';
      const tb = U.el('tbody');
      rows.forEach(r => {
        const cls = r.status === '正常' || r.status === '已存储' ? 'ds-ok' : r.status === '失败' ? 'ds-fail' : 'ds-warn';
        const tr = U.el('tr');
        tr.innerHTML = '<td>' + U.esc(r.adapter) + '</td><td class="' + cls + '">' + U.esc(r.status) + '</td>' +
          '<td>' + U.esc(r.lastOk || '—') + '</td><td>' + (r.latencyMs ? r.latencyMs + ' ms' : '—') + '</td>' +
          '<td>' + U.esc(r.error || '—') + '</td><td>' + U.esc(r.fallback || '—') + '</td>';
        tb.appendChild(tr);
      });
      tbl.appendChild(tb);
      wrap.innerHTML = '';
      wrap.appendChild(tbl);
      const meta = GMT.state.data.meta;
      const missing = meta.missing || [];
      const missNote = missing.length
        ? '缺失标的（已置灰标注「未取得」）：' + missing.map(m => m[0] + '（' + m[1] + '）').join('、')
        : '本轮取数 59/59 标的全部成功，无缺失。';
      wrap.appendChild(U.el('div', 'chart-note',
        '模式：' + ({ LIVE: '实时 LIVE', SNAPSHOT: '真实快照', FALLBACK: '缓存回退' }[GMT.state.mode] || GMT.state.mode) +
        ' · 来源：' + meta.source + ' · 抓取时刻：' + meta.fetchedAt +
        ' · ' + missNote +
        ' · 口径备注：黄金现货（XAU 即期）该数据源无覆盖，跑马灯与 06 号组件统一采用 GC=F 期货口径并如实标注。' +
        ' · LIVE 配置：localStorage 键 "gmt.v2.livecfg"（见 README）· 源码无密钥。'));
    }
    draw();
    GMT.events.on('datastatus', draw);
    W.setAsof('datastatus', '实时刷新');
  },
};
})();
