/* 新闻中文译文映射（呈现层）——键为 news-data.js 中真实新闻的 URL。
   英文原标题/原文链接一律保留；本文件只追加中文译文与来源中文名，不改动任何行情数值。
   GMT_SRC_CN：仅收录有通行中文名的出版方；其余保留英文原名（v2.2 起 src 为真实出版方，
   聚合层 Yahoo Finance 在呈现层单独标注）。 */
window.GMT_NEWS_CN = {
 "https://finance.yahoo.com/markets/live/earnings-live-lvmh-sales-grow-as-us-luxury-shoppers-boost-results-115207214.html": {
  "h": "财报直播：美国奢侈品消费者提振业绩，LVMH 销售额增长",
  "sum": "财报季本周进入高潮。"
 },
 "https://www.wsj.com/livecoverage/stock-market-today-dow-sp-500-nasdaq-07-28-2026/card/tech-earnings-fed-rate-decision-what-to-watch-this-week-vAmRtjs9MVjLnKiNblP5?siteid=yhoof2&yptr=yahoo": {
  "h": "科技股财报与美联储利率决议：本周关注要点",
  "sum": "今日财报（盘前）：可口可乐、UPS、波音、宣伟、希尔顿、Centene、PayPal、标普全球；（盘后）：Visa、福特汽车、亿滋国际、废物管理、PPG 工业、Bloom Energy、安飞士、希捷科技。经济数据：消费者信心指数、Johnson Redbook 零售销售指数等。"
 },
 "https://stocktwits.com/news-articles/markets/equity/sndk-nvda-skhy-asml-stocks-extend-slide-overnight-amid-china-ai-challenge-tech-rotation/cZZCeckR766": {
  "h": "中国 AI 挑战与板块轮动下，SNDK、英伟达、SK 海力士、阿斯麦隔夜延续跌势",
  "sum": "中国 AI 新技术亮相，加之该国最大存储芯片厂商上市表现异常强劲，令美国半导体板块情绪承压。"
 },
 "https://stocktwits.com/news-articles/markets/equity/why-did-aapl-fbrx-rtx-stocks-surge-to-52-week-highs-today/cZZC4XQR76C": {
  "h": "苹果、FBRX、RTX 今日为何齐创 52 周新高？",
  "sum": "投资者乐观情绪由 AI 前景、一笔数十亿美元级收购及强劲的财报执行共同推动。"
 },
 "https://beincrypto.com/dan-niles-apple-incompetent-ai-stock/": {
  "h": "Dan Niles 称苹果在 AI 上“无能”，股价为何仍创历史新高？",
  "sum": "Dan Niles 认为，苹果的 AI 失误反而让它避开了资本开支陷阱，但他警告其估值在财报前存在风险。"
 },
 "https://247wallst.com/personal-finance/social-security/2026/07/27/only-14-of-gen-x-has-a-pension-for-a-53-year-old-riding-an-ai-heavy-sp-500-social-security-is-the-only-floor-left/": {
  "h": "仅 14% 的 X 世代拥有养老金：对一位重仓 AI 股标普 500 的 53 岁投资者而言，社保成了最后的保底",
  "sum": "一位 53 岁、二十年来顶格缴纳 401(k) 的投资者以为自己构建了多元化退休组合——她可能无意中把筹码高度集中于 AI，而她忽略的那张安全网，价值或许远超想象。"
 },
 "https://247wallst.com/investing/2026/07/27/alphabet-capex-concerns-are-bogus-but-theres-an-internal-hedge-against-them-regardless/": {
  "h": "对 Alphabet 资本开支的担忧站不住脚——而其内部本就藏着对冲",
  "sum": "华尔街被 Alphabet 不断膨胀的资本开支账单吓到，但财报中埋藏的一个数字重构了整个看空逻辑，并指向多数投资者完全忽略的第二次 AI 押注。"
 },
 "https://finance.yahoo.com/technology/ai/articles/sk-hynix-rebound-470-billion-233004396.html": {
  "h": "SK 海力士能否从 4700 亿美元暴跌中反弹，取决于 AI 支出",
  "sum": "（彭博）——短短一个多月内 4700 亿美元的暴跌，让 SK 海力士从全球最热门的 AI 交易沦为投资组合中最大的问号之一。"
 },
 "https://finance.yahoo.com/markets/article/semiconductor-stock-charts-just-formed-this-bearish-shape-that-signals-more-potential-losses-145440205.html": {
  "h": "半导体股走势图刚形成这一看跌形态，或预示进一步下跌",
  "sum": "半导体板块小心下行？"
 },
 "https://www.fool.com/investing/2026/07/28/intel-just-broke-a-15-year-old-company-record-is-t/": {
  "h": "英特尔刚刚打破一项 15 年公司纪录：这次复苏是真的吗？",
  "sum": "英特尔的营收增速刚达到十多年来未见的水平。"
 },
 "https://www.fool.com/investing/2026/07/28/chipotle-mexican-grills-next-earnings-report-on-july-29-could-send-the-stock-soaring-heres-why/": {
  "h": "Chipotle 7 月 29 日的下一份财报可能拖累股价下滑，原因如下",
  "sum": "Chipotle 能否重回有意义的增长？"
 },
 "https://www.fool.com/investing/2026/07/28/my-3-favorite-artificial-intelligence-ai-stocks-to/": {
  "h": "我当前最看好的 3 只人工智能（AI）股票",
  "sum": "我们或许仍处在 AI 革命的早期阶段，这些公司可能成为最大赢家。"
 },
 "https://finance.yahoo.com/news/ai-anxiety-sparks-tech-rout-023132715.html": {
  "h": "AI 焦虑引发科技股抛售，亚洲市场普跌",
  "sum": "（路透社 7 月 28 日新加坡电）——受中国竞争威胁及“谁来为 AI 买单”的担忧影响，周二亚洲芯片股全线大跌。"
 },
 "https://www.fool.com/investing/2026/07/28/tesla-is-down-30-this-year-heres-why-im-still-wait/": {
  "h": "特斯拉今年已跌 30%：我为何仍在场外观望",
  "sum": "该股的定价依然没有给失误留下多少空间。"
 },
 "https://www.fool.com/investing/2026/07/28/prediction-spacex-stock-will-fall-after-aug-4/": {
  "h": "预测：SpaceX 股价将在 8 月 4 日后下跌",
  "sum": "这只新近 IPO 股票的“蜜月期”终于要结束了吗？"
 },
 "https://www.fool.com/investing/2026/07/28/ford-yields-41-and-lost-61-billion-over-the-past-y/": {
  "h": "福特股息率 4.1%，过去一年亏损 61 亿美元：财报将于周二盘后公布",
  "sum": "亏损走会计口径，分红靠真金白银。"
 },
 "https://www.fool.com/investing/2026/07/28/rocket-lab-debuts-a-breakthrough-technology-invest/": {
  "h": "Rocket Lab 发布突破性技术，值得投资者关注",
  "sum": "一项被低估的能力，或帮助 Rocket Lab 在未来航天与国防任务中拿下更大份额。"
 },
 "https://finance.yahoo.com/technology/ai/articles/anthropic-amodei-rejects-open-model-015132572.html": {
  "h": "Anthropic 首席执行官 Amodei 反对封禁开放模型，但呼吁加强测试",
  "sum": "（彭博）——包括 Anthropic CEO Dario Amodei 与英伟达 CEO 黄仁勋在内的硅谷领袖警告：不应以一款挑战美国领先地位的中国 AI 模型突破为由，对开放权重 AI 系统实施大规模政府打压。"
 },
 "https://www.trefis.com/articles/608928/intu-down-60-is-intuits-proven-price-floor-about-to-break/2026-07-27": {
  "h": "INTU 暴跌 60%：Intuit 屡经验证的价格底部要被击穿了吗？",
  "sum": "TurboTax 背后的软件巨头跌回了一个曾多次发动大反弹的价格底部，但其商业模式上一道新裂痕正在考验投资者的信念。"
 },
 "https://finance.yahoo.com/markets/stocks/articles/microsoft-amazon-earnings-cloud-results-235700353.html": {
  "h": "微软与亚马逊财报：云业务成焦点",
  "sum": "云业务业绩将再次成为影响亚马逊与微软财报市场情绪的主要力量。"
 },
 "https://www.barrons.com/articles/stocks-today-oil-prices-tech-85809730?siteid=yhoof2&yptr=yahoo": {
  "h": "回顾与前瞻：系好安全带",
  "sum": "在油价下跌主导的动荡交易日之后，投资者的注意力即将转回财报。"
 },
 "https://finance.yahoo.com/technology/ai/articles/ibm-ibm-joins-nvidia-microsoft-231225259.html": {
  "h": "IBM 加入英伟达、微软等发起的“开放安全 AI 联盟”",
  "sum": "IBM 与英伟达、微软、Palantir 等共同发起开放安全 AI 联盟，旨在推动开源 AI 发展并提升 AI 系统的网络安全。"
 },
 "https://finance.yahoo.com/markets/article/zynga-founder-mark-pincus-on-his-early-advice-for-meta-ceo-mark-zuckerberg-142023551.html": {
  "h": "Zynga 创始人 Mark Pincus 谈当年给 Meta CEO 扎克伯格的建议",
  "sum": "Facebook 早期投资人 Mark Pincus 生动回忆了他初见创始人扎克伯格的情景。"
 },
 "https://finance.yahoo.com/markets/article/4-big-tech-earnings-reports-a-fed-meeting-and-100-oil-its-the-busiest-week-of-the-quarter-100000261.html": {
  "h": "四份大型科技股财报、一次美联储会议、100 美元油价：本季度最繁忙的一周",
  "sum": "投资者迎来本季度最繁忙的一周：超大规模云厂商财报、6 月美联储会议与中东局势升级同聚焦点。"
 },
 "https://www.wsj.com/tech/meta-is-fighting-a-mountain-of-social-media-lawsuitsat-just-the-wrong-time-0b7d12a3?siteid=yhoof2&yptr=yahoo": {
  "h": "Meta 正深陷社交媒体诉讼堆——而且来得正是最糟的时候",
  "sum": "在耗资巨大的 AI 转型之际，该公司还在应对可能令其损失数十亿美元、并被迫做出痛苦改变的诉讼。"
 },
 "https://www.thestreet.com/technology/meta-warns-glasses-instagram-ban-policy-pervert": {
  "h": "Meta 向智能眼镜恶作剧者发出警告",
  "sum": "每项消费技术都是先有了名声、后有规则：拍照手机曾是玩具，直到它成为法庭证物。Meta 花了三年打造第一款真正的硬件……"
 },
 "https://finance.yahoo.com/markets/stocks/articles/exxon-mobil-holdings-xom-stock-214502233.html": {
  "h": "大盘上涨之际埃克森美孚（XOM）逆势下跌：你需要知道的事",
  "sum": "埃克森美孚（XOM）最新交易日收于 154.77 美元，较前一收盘下跌 1.38%。"
 },
 "https://finance.yahoo.com/markets/stocks/articles/wall-street-wavers-oil-slides-204759546.html": {
  "h": "更新：油价走低，华尔街震荡；美联储决议与重磅财报成焦点",
  "sum": "（文末更新全天市场动态。）美股收盘涨跌互现……"
 },
 "https://www.investors.com/news/baker-hughes-stock-oil-air-power-play-surprise-earnings-gain/?src=A00220&yptr=yahoo": {
  "h": "AI 相关订单暴增，贝克休斯上调展望股价大涨",
  "sum": "贝克休斯二季度业绩远超预期，AI 驱动的订单激增；周一股价突破关键位，而石油股普遍下跌。公司同时基于 AI 数据中心相关的关键业务上调了指引。"
 },
 "https://finance.yahoo.com/economy/policy/articles/72-us-companies-expect-stable-201249513.html": {
  "h": "72% 的美国企业预计美欧关系将保持稳定或改善",
  "sum": "美欧达成贸易协定一年后，商业信心有所增强。"
 }
};
window.GMT_SRC_CN = {
 "Yahoo Finance": "雅虎财经",
 "The Wall Street Journal": "华尔街日报",
 "Barron's": "巴伦周刊",
 "Reuters": "路透社",
 "Bloomberg": "彭博"
};
