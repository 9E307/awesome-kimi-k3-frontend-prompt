/* ============================================================
   GMT core — 工具 / 状态 / 存储 / 数据适配器 / 数据状态注册表
   ============================================================ */
(function () {
'use strict';
const GMT = window.GMT = window.GMT || {};

/* ---------------- 工具 ---------------- */
const U = GMT.U = {
  $(s, r) { return (r || document).querySelector(s); },
  $$(s, r) { return Array.from((r || document).querySelectorAll(s)); },
  el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  },
  fmt(n, d) {
    if (n === null || n === undefined || isNaN(n)) return '—';
    return Number(n).toLocaleString('en-US', { minimumFractionDigits: d === undefined ? 2 : d, maximumFractionDigits: d === undefined ? 2 : d });
  },
  fmtInt(n) {
    if (n === null || n === undefined || isNaN(n)) return '—';
    return Math.round(Number(n)).toLocaleString('en-US');
  },
  /* 中文大数：成交量/股本 → 万/亿；市值 → 亿/万亿 */
  fmtCN(n, unit) {
    if (n === null || n === undefined || isNaN(n)) return '—';
    unit = unit || '';
    const a = Math.abs(n);
    if (a >= 1e12) return (n / 1e12).toFixed(2) + ' 万亿' + unit;
    if (a >= 1e8) return (n / 1e8).toFixed(2) + ' 亿' + unit;
    if (a >= 1e4) return (n / 1e4).toFixed(1) + ' 万' + unit;
    return Math.round(n) + ' ' + unit;
  },
  /* 兼容别名：图表库沿用 → 统一走中文大数 */
  fmtBig(n) { return U.fmtCN(n, ''); },
  sign(n, d) { return (n >= 0 ? '+' : '') + U.fmt(n, d); },
  pct(n) { return (n >= 0 ? '+' : '') + U.fmt(n, 2) + '%'; },
  arrow(n) { return n > 0 ? '▲' : n < 0 ? '▼' : '■'; },
  cls(n) { return n > 0.0001 ? 'up' : n < -0.0001 ? 'down' : 'flat'; },
  esc(s) { return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); },
  pad(n) { return n < 10 ? '0' + n : '' + n; },
  debounce(fn, ms) {
    let t; return function () { clearTimeout(t); const a = arguments, s = this; t = setTimeout(() => fn.apply(s, a), ms); };
  },
  reducedMotion() { return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches; },
  isMobile() { return window.innerWidth < 760; },
};

/* ---------------- 存储 ---------------- */
const LS_PREFIX = 'gmt.v2.';
GMT.store = {
  get(key, fallback) {
    try {
      const v = localStorage.getItem(LS_PREFIX + key);
      return v === null ? fallback : JSON.parse(v);
    } catch (e) { return fallback; }
  },
  set(key, val) {
    try { localStorage.setItem(LS_PREFIX + key, JSON.stringify(val)); } catch (e) { /* 忽略配额/禁用 */ }
  },
  del(key) { try { localStorage.removeItem(LS_PREFIX + key); } catch (e) {} },
};

/* ---------------- 共享状态 ---------------- */
GMT.state = {
  data: null,               // 当前数据集（统一 schema）
  mode: 'SNAPSHOT',         // 'LIVE' | 'SNAPSHOT' | 'FALLBACK'
  filter: GMT.store.get('filters', { sector: 'ALL', search: '', area: 'mcap', movers: 'ALL' }),
  focusAsset: null,
  selectedMetal: GMT.store.get('metal', 'XAU'),
  tz: GMT.store.get('tz', 'local'),
  editing: false,
  newsPaused: false,
  newsLastSeen: GMT.store.get('newsLastSeen', ''),
};
GMT.saveFilters = () => GMT.store.set('filters', GMT.state.filter);

/* ---------------- 数据状态注册表 ---------------- */
const adapters = {};
GMT.dataStatus = {
  list() { return Object.values(adapters).map(a => a.status); },
  report(name, patch) { if (adapters[name]) Object.assign(adapters[name].status, patch); GMT.events.emit('datastatus'); },
  register(name, status) { adapters[name] = { status }; },
};

/* ---------------- 事件总线 ---------------- */
GMT.events = {
  _m: {},
  on(ev, fn) { (this._m[ev] = this._m[ev] || []).push(fn); },
  emit(ev, arg) { (this._m[ev] || []).forEach(fn => { try { fn(arg); } catch (e) { console.error('[GMT 监听器]', e); } }); },
};

/* ---------------- 真实快照适配器（随包发布，可离线） ---------------- */
GMT.snapshotAdapter = {
  name: '真实行情快照（Yahoo Finance 抓取）',
  async load() {
    const t0 = performance.now();
    const data = window.GMT_DATA;
    if (!data || !data.stocks) throw new Error('快照数据缺失');
    /* 新闻独立于行情文件（v2.2 拆分）：js/news-data.js → window.GMT_NEWS */
    data.news = window.GMT_NEWS || [];
    await new Promise(r => setTimeout(r, 0));
    GMT.dataStatus.report('snapshot', {
      status: '正常', lastOk: data.meta.fetchedAt,
      latencyMs: Math.round(performance.now() - t0), error: '', fallback: '',
    });
    return data;
  },
};

/* ---------------- LIVE 适配器（可选，用户自行配置） ----------------
   源码不含任何密钥。配置方式：localStorage 'gmt.v2.livecfg'
   {"endpoint":"http://localhost:8787/gmt", "timeoutMs":4000}
   端点须返回与 js/market-data.js 相同的 schema（见 README.md）。
   任何失败 → 抛出异常 → 调用方回退快照。 */
GMT.liveAdapter = {
  name: 'LIVE 适配器（用户配置）',
  config() { return GMT.store.get('livecfg', null); },
  async load() {
    const cfg = this.config();
    if (!cfg || !cfg.endpoint) {
      GMT.dataStatus.report('live', { status: '未配置', error: '未配置 endpoint', fallback: '快照' });
      throw new Error('LIVE 未配置');
    }
    const t0 = performance.now();
    const timeout = cfg.timeoutMs || 4000;
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeout);
    try {
      const res = await fetch(cfg.endpoint, { signal: ctrl.signal, headers: { 'accept': 'application/json' } });
      clearTimeout(timer);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const json = await res.json();
      if (!json || !Array.isArray(json.stocks) || !json.aapl) throw new Error('schema 不符');
      GMT.dataStatus.report('live', {
        status: '正常', lastOk: new Date().toISOString(),
        latencyMs: Math.round(performance.now() - t0), error: '', fallback: '',
      });
      return json;
    } catch (e) {
      clearTimeout(timer);
      const msg = e && e.name === 'AbortError' ? '超时 > ' + timeout + 'ms' : String(e && e.message || e);
      GMT.dataStatus.report('live', { status: '失败', error: msg, fallback: '快照', latencyMs: Math.round(performance.now() - t0) });
      throw e;
    }
  },
};

/* ---------------- 启动加载（带回退与缓存） ---------------- */
GMT.dataStatus.register('live', { adapter: 'LIVE 适配器（用户配置）', status: '初始化', lastOk: '', latencyMs: 0, error: '', fallback: '' });
GMT.dataStatus.register('snapshot', { adapter: '真实行情快照（Yahoo Finance）', status: '初始化', lastOk: '', latencyMs: 0, error: '', fallback: '' });
GMT.dataStatus.register('cache', { adapter: '最近成功缓存', status: '空', lastOk: '', latencyMs: 0, error: '', fallback: '' });

GMT.loadData = async function () {
  let mode = 'SNAPSHOT', data = null;
  try {
    data = await GMT.liveAdapter.load();
    mode = 'LIVE';
  } catch (liveErr) {
    try {
      data = await GMT.snapshotAdapter.load();
      mode = 'SNAPSHOT';
    } catch (snapErr) {
      const cached = GMT.store.get('cache', null);
      if (cached && cached.data) {
        data = cached.data;
        mode = 'FALLBACK';
        GMT.dataStatus.report('cache', { status: '已使用', lastOk: cached.at, fallback: '缓存' });
      } else {
        console.error('[GMT] 全部数据源失败', snapErr);
        GMT.dataStatus.report('snapshot', { status: '失败', error: String(snapErr && snapErr.message || snapErr) });
        return null;
      }
    }
  }
  if (mode === 'LIVE') {
    GMT.store.set('cache', { at: new Date().toISOString(), data });
    GMT.dataStatus.report('cache', { status: '已存储', lastOk: new Date().toISOString() });
  }
  GMT.state.data = data;
  GMT.state.mode = mode;
  return data;
};

/* ---------------- 来源 / 口径描述 ---------------- */
GMT.sourceInfo = function (kind) {
  const d = GMT.state.data, m = d && d.meta || {};
  const modeCN = { LIVE: '实时 LIVE', SNAPSHOT: '真实快照', FALLBACK: '缓存回退' }[GMT.state.mode] || GMT.state.mode;
  const base = {
    source: m.source || 'Yahoo Finance',
    fetched: m.fetchedAt || '—',
    modeCN,
  };
  const calibers = {
    stock: '现价对前收盘价；未复权。多股类公司市值按隐含总股本（源：Yahoo Finance get_stock_info）。',
    index: '指数点位对前收，非 ETF/基金净值（源：Yahoo Finance get_stock_info）。',
    metal: d && d.metals ? d.metals.caliber : '',
    aapl: d && d.aapl ? d.aapl.caliber : '',
    news: '真实新闻标题与链接（Yahoo Finance）。时间戳为终端抓取时刻——源接口未提供发布时间。',
    market: '开闭市状态由本机时钟 + IANA 时区实时计算（DST 感知）。未内置节假日日历——节假日状态未核实。',
    sector: '板块日内为 XLK/XLE/XLF 美股 ETF 代理（5 分钟线，开盘=0%）；平均涨跌为样本股等权均值。',
  };
  return Object.assign(base, { caliber: calibers[kind] || m.caliber || '' });
};
})();
