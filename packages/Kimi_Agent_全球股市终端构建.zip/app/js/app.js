/* ============================================================
   GMT app — 启动 / 命令栏 / 跑马灯 / 检查器 / 工具栏 / 快捷键
   ============================================================ */
(function () {
'use strict';
const GMT = window.GMT;
const U = GMT.U;
const app = GMT.app = {};

/* ---------------- 悬浮提示 ---------------- */
GMT.ui = {
  tooltip(html, x, y) {
    const t = U.$('#tooltip');
    if (!html) { t.hidden = true; return; }
    t.textContent = html;
    t.hidden = false;
    const r = t.getBoundingClientRect();
    let lx = x + 14, ly = y + 12;
    if (lx + r.width > window.innerWidth - 8) lx = x - r.width - 12;
    if (ly + r.height > window.innerHeight - 8) ly = y - r.height - 10;
    t.style.left = lx + 'px'; t.style.top = ly + 'px';
  },
};

/* ---------------- 检查器 ---------------- */
let lastFocus = null;
function kv(rows) {
  return '<table class="kv">' + rows.map(r => '<tr><td>' + U.esc(r[0]) + '</td><td>' + r[1] + '</td></tr>').join('') + '</table>';
}
function srcRows(kind) {
  const s = GMT.sourceInfo(kind);
  const failed = GMT.dataStatus.list().find(a => a.status === '失败');
  return [
    ['数据来源', U.esc(s.source)],
    ['抓取时刻', U.esc(s.fetched)],
    ['实时 / 快照', '<b style="color:var(--amber)">' + U.esc(s.modeCN) + '</b>'],
    ['口径', U.esc(s.caliber)],
    ['错误 / 延迟', U.esc(failed ? failed.error : '无 · 详见 09 号数据状态组件')],
  ];
}
app.inspect = function (obj) {
  if (!obj) return;
  lastFocus = document.activeElement;
  const p = U.$('#inspector'), b = U.$('#insp-body');
  const W = GMT.widgets;
  let html = '';
  if (obj.type === 'stock') {
    const s = obj.s;
    const SECT_CN = { 'AI-TECH': 'AI·科技', 'ENERGY': '能源', 'FINANCIALS': '金融' };
    html = '<div class="insp-name">' + U.esc(s.t) + ' · ' + U.esc(s.n) + '</div>' +
      '<div class="insp-sub">' + U.esc(SECT_CN[s.g] || s.g) + ' · 股票 · ' + U.esc(s.ccy) + '</div>' +
      '<div class="insp-big">' + U.fmt(s.last) + ' <span class="' + U.cls(s.pct) + '" style="font-size:13px">' + U.arrow(s.chg) + ' ' + U.sign(s.chg) + '（' + U.pct(s.pct) + '）</span></div>' +
      kv([
        ['开盘', U.fmt(s.o)], ['前收', U.fmt(s.prev)],
        ['当日最高', U.fmt(s.h)], ['当日最低', U.fmt(s.l)],
        ['成交量', U.fmtCN(s.vol, '股')], ['总市值', U.fmtCN(s.mcap, '美元')],
        ['股本口径', U.esc(s.capNote || '—')],
        ['as-of', U.esc(s.asof || '—') + '（' + U.esc(W.tzCn(s.tz)) + '）'],
        ['市场状态（抓取时）', U.esc(W.mstateCn(s.mstate))],
      ].concat(srcRows('stock'))) +
      '<p class="insp-note">可用字段：代码、名称、板块、最新、前收、涨跌、涨跌幅、开、高、低、成交量、总市值、as-of 时区。</p>';
  } else if (obj.type === 'aapl-point') {
    const r = obj.r;
    html = '<div class="insp-name">AAPL · ' + U.esc(r.date) + '</div>' +
      '<div class="insp-sub">图表数据点 · 60 日序列（与 01 号组件同源）</div>' +
      '<div class="insp-big">' + U.fmt(r.c) + '</div>' +
      kv([['开盘', U.fmt(r.o)], ['最高', U.fmt(r.h)], ['最低', U.fmt(r.l)], ['收盘', U.fmt(r.c)], ['成交量', U.fmtCN(r.v, '股')]].concat(srcRows('aapl')));
  } else if (obj.type === 'tape' || obj.type === 'index') {
    const it = obj.type === 'tape'
      ? { n: obj.it.n, last: U.fmt(obj.it.last), pct: U.pct(obj.it.pct), asof: obj.it.asof, ex: obj.it.s, note: obj.it.note }
      : { n: obj.r.n, last: U.fmt(obj.r.last), pct: U.pct(obj.r.pct), asof: obj.r.asof, ex: obj.r.ex, note: '' };
    const extra = [];
    if (obj.st) extra.push(['开闭市（实时计算）', U.esc(obj.st.weekend ? '已收盘（周末）' : W.statusCn(obj.st.status))]);
    if (obj.mk) extra.push(['交易时段', U.esc(obj.mk.hours)], ['时区', U.esc(W.tzCn(obj.mk.tz, new Date())) + ' · ' + obj.mk.tz]);
    if (it.note) extra.push(['口径备注', U.esc(it.note)]);
    html = '<div class="insp-name">' + U.esc(it.n) + '</div>' +
      '<div class="insp-sub">指数 · ' + U.esc(it.ex) + (obj.region ? ' · ' + U.esc(obj.region) : '') + '</div>' +
      '<div class="insp-big">' + U.esc(it.last) + ' <span style="font-size:13px">' + U.esc(it.pct) + '</span></div>' +
      kv([['as-of（当地）', U.esc(it.asof || '—')]].concat(extra, srcRows('index')));
  } else if (obj.type === 'metal') {
    const m = obj.m;
    html = '<div class="insp-name">' + U.esc(m.name) + '</div>' +
      '<div class="insp-sub">贵金属 · ' + U.esc(m.venue || '') + ' · ' + U.esc(m.unit) + '</div>' +
      '<div class="insp-big">' + U.fmt(m.last) + ' <span class="' + U.cls(m.chg) + '" style="font-size:13px">' + U.sign(m.chg) + '（' + U.pct(m.pct) + '）</span></div>' +
      kv([
        ['单位 / 货币', U.esc(m.unit) + ' · ' + m.ccy],
        ['前收（序列）', U.fmt(m.prev)],
        ['60 日区间', U.fmt(m.r60[0]) + ' – ' + U.fmt(m.r60[1])],
        obj.point ? ['选中数据点', U.esc(obj.point.date) + ' · ' + U.fmt(obj.point.v)] : ['选中数据点', '—'],
        ['as-of', U.esc(m.asof) + '（期货日线）'],
        ['序列自洽', '序列末值 = 最新价；末两点隐含涨跌幅 = 展示涨跌幅（已断言）'],
      ].concat(srcRows('metal')));
  } else if (obj.type === 'news') {
    const n = obj.n;
    const cn = (window.GMT_NEWS_CN || {})[n.url] || null;
    html = '<div class="insp-name">' + U.esc(n.cat) + ' 快讯</div>' +
      '<div class="insp-sub">' + U.esc(n.ts) + '</div>' +
      (cn ? '<p style="font-size:11px;margin-bottom:4px">' + U.esc(cn.h) + '</p>' +
        '<p style="font-size:10px;color:var(--fg-dim);margin-bottom:6px">英文原题：' + U.esc(n.h) + '</p>'
        : '<p style="font-size:11px;margin-bottom:6px">' + U.esc(n.h) + '</p>') +
      (cn && cn.sum ? '<p style="color:var(--fg-dim)">' + U.esc(cn.sum) + '</p>' : '') +
      (n.sum ? '<p style="color:var(--fg-dim)">' + (cn ? '英文摘要：' : '') + U.esc(n.sum) + '</p>' : '') +
      kv([['相关代码', U.esc(n.tk.join('、') || '—')], ['来源', U.esc(W.srcBi(n.src))],
        ['原文链接', n.url ? '<a href="' + U.esc(n.url) + '" target="_blank" rel="noopener" style="color:var(--cyan)">打开原文 ↗</a>' : '—'],
      ].concat(srcRows('news')));
  } else if (obj.type === 'market') {
    const mk = obj.mk, st = obj.st;
    html = '<div class="insp-name">' + U.esc(mk.name) + '</div>' +
      '<div class="insp-sub">交易场所状态 · ' + U.esc(mk.tz) + '</div>' +
      '<div class="insp-big"><span class="badge ' + (st.weekend ? 'CLOSED' : st.status) + '" style="font-size:13px">' + (st.weekend ? '已收盘（周末）' : W.statusCn(st.status)) + '</span></div>' +
      kv([
        ['当地时间', U.pad(st.wall.hh) + ':' + U.pad(st.wall.mm)],
        ['时区（DST 感知）', U.esc(W.tzCn(mk.tz, new Date()))],
        ['常规时段', U.esc(mk.hours)],
        ['下次切换', st.next ? '→ ' + W.statusCn(st.next.to) + ' · ' + obj.cd : '—'],
        ['节假日核查', '<span style="color:var(--amber)">节假日状态未核实</span>'],
      ].concat(srcRows('market')));
  }
  if (!html) return;
  b.innerHTML = html;
  p.hidden = false;
  b.focus({ preventScroll: true });
};
function closeInspector() {
  const p = U.$('#inspector');
  if (p.hidden) return;
  p.hidden = true;
  if (lastFocus && lastFocus.focus) lastFocus.focus({ preventScroll: true });
}
U.$('#insp-close').addEventListener('click', closeInspector);

/* ---------------- 跑马灯 ---------------- */
function buildTape() {
  const tape = U.$('#tape');
  tape.innerHTML = '';
  const items = GMT.state.data.tape;
  const make = () => items.forEach(it => {
    const sp = U.el('span', 'tape-item');
    sp.setAttribute('role', 'listitem');
    sp.tabIndex = 0;
    sp.innerHTML = '<span class="ts">' + U.esc(it.s) + '</span>' +
      '<span class="tl">' + U.fmt(it.last) + '</span>' +
      '<span class="tc ' + U.cls(it.chg) + '">' + U.sign(it.chg) + '</span>' +
      '<span class="tp ' + U.cls(it.pct) + '">' + U.pct(it.pct) + '</span>';
    GMT.widgets.bindTip(sp, () => it.n + '（' + it.s + '）\n最新 ' + U.fmt(it.last) + '  ' + U.sign(it.chg) + '（' + U.pct(it.pct) + '）\nas-of ' + (it.asof || '—') + '（当地）\n点击查看来源');
    sp.addEventListener('click', () => app.inspect({ type: 'tape', it }));
    sp.addEventListener('keydown', ev => { if (ev.key === 'Enter') app.inspect({ type: 'tape', it }); });
    tape.appendChild(sp);
  });
  make(); make(); // 两份内容实现无缝 -50% 循环
  if (U.reducedMotion()) tape.classList.add('paused');
}
U.$('#tape-pause').addEventListener('click', function () {
  const tape = U.$('#tape');
  const paused = tape.classList.toggle('paused');
  this.setAttribute('aria-pressed', String(paused));
  this.textContent = paused ? '▶' : '❚❚';
});

/* ---------------- 命令栏时钟与徽章 ---------------- */
function tickClock() {
  const now = new Date();
  const c = U.$('#cmd-clock');
  c.textContent = U.pad(now.getHours()) + ':' + U.pad(now.getMinutes()) + ':' + U.pad(now.getSeconds());
  c.title = now.toString();
}
function setModeBadge() {
  const b = U.$('#mode-badge'), c = U.$('#conn-status');
  const m = GMT.state.mode;
  const map = {
    LIVE: ['实时 LIVE', '● 已连接', 'live'],
    SNAPSHOT: ['真实快照', '● 快照·离线', ''],
    FALLBACK: ['缓存回退', '● 缓存·回退', 'stale'],
  };
  const cfg = map[m] || map.SNAPSHOT;
  b.className = 'mode-badge' + (cfg[2] ? ' ' + cfg[2] : '');
  b.textContent = cfg[0];
  b.title = '快照抓取时刻：' + (GMT.state.data ? GMT.state.data.meta.fetchedAt : '—');
  c.textContent = cfg[1];
}

/* ---------------- 工具栏 ---------------- */
function setEditing(on) {
  GMT.state.editing = on;
  document.body.classList.toggle('editing', on);
  U.$('#btn-edit').setAttribute('aria-pressed', String(on));
  U.$('#btn-edit').classList.toggle('on', on);
  U.$('#edit-hint').hidden = !on;
  GMT.store.set('editing', on);
}
app.setEditing = setEditing;
app.refreshAddMenu = function () {
  const menu = U.$('#add-menu');
  menu.innerHTML = '';
  Object.keys(GMT.widgets.registry).forEach(id => {
    const reg = GMT.widgets.registry[id];
    const it = GMT.grid.layout.items[id];
    const b = U.el('button');
    b.innerHTML = '<span>' + reg.num + ' ' + U.esc(reg.title) + '</span><span>' + (it.visible ? '● 已显示' : '+ 添加') + '</span>';
    b.disabled = !!it.visible;
    b.setAttribute('role', 'menuitem');
    b.addEventListener('click', () => {
      it.visible = true; GMT.grid.save(); GMT.grid.applyLayout();
      app.refreshAddMenu();
      const body = document.querySelector('#w-' + id + ' .w-body');
      if (reg.onResize) reg.onResize(body);
      menu.hidden = true; U.$('#btn-add').setAttribute('aria-expanded', 'false');
    });
    menu.appendChild(b);
  });
};
U.$('#btn-edit').addEventListener('click', () => setEditing(!GMT.state.editing));
U.$('#btn-add').addEventListener('click', () => {
  const menu = U.$('#add-menu');
  menu.hidden = !menu.hidden;
  U.$('#btn-add').setAttribute('aria-expanded', String(!menu.hidden));
});
U.$$('#toolbar .preset').forEach(b => b.addEventListener('click', () => GMT.grid.applyPreset(b.dataset.preset)));
U.$('#btn-reset').addEventListener('click', () => {
  if (window.confirm('将布局、显隐与顺序恢复为默认？')) {
    GMT.store.del('layout'); GMT.grid.load(); GMT.grid.build(); app.refreshAddMenu();
  }
});

/* ---------------- 命令栏按钮 / 浮层 ---------------- */
function toggleDataStatus() {
  const it = GMT.grid.layout.items.datastatus;
  it.visible = !it.visible;
  GMT.grid.save(); GMT.grid.applyLayout(); app.refreshAddMenu();
}
let helpTrigger = null;
function toggleHelp() {
  const o = U.$('#help-overlay');
  const opening = o.hidden;
  o.hidden = !opening;
  if (opening) { helpTrigger = document.activeElement; U.$('#help-close').focus(); }
  else if (helpTrigger && helpTrigger.focus) helpTrigger.focus({ preventScroll: true });
}
U.$$('.cmd-btn').forEach(b => b.addEventListener('click', () => {
  const c = b.dataset.cmd;
  if (c === 'help') toggleHelp();
  else if (c === 'edit') setEditing(!GMT.state.editing);
  else if (c === 'inspector') {
    if (U.$('#inspector').hidden) app.inspect({ type: 'news', n: GMT.state.data.news[0] }); else closeInspector();
  }
  else if (c === 'data') toggleDataStatus();
}));
U.$('#help-close').addEventListener('click', toggleHelp);
U.$('#help-overlay').addEventListener('click', ev => { if (ev.target === ev.currentTarget) toggleHelp(); });

/* 模态框 Tab 焦点陷阱（与检查器同一套模式） */
U.$('#help-overlay').addEventListener('keydown', ev => {
  if (ev.key !== 'Tab') return;
  const box = ev.currentTarget.querySelector('.overlay-box');
  const focusables = Array.from(box.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'))
    .filter(el => !el.disabled && el.offsetParent !== null);
  if (!focusables.length) return;
  const first = focusables[0], last = focusables[focusables.length - 1];
  if (ev.shiftKey && document.activeElement === first) { ev.preventDefault(); last.focus(); }
  else if (!ev.shiftKey && document.activeElement === last) { ev.preventDefault(); first.focus(); }
});

/* ---------------- 全局快捷键 ---------------- */
document.addEventListener('keydown', ev => {
  // 不吞浏览器组合键（Cmd/Ctrl/Alt + 任意键一律放行）
  if (ev.metaKey || ev.ctrlKey || ev.altKey) return;
  if (ev.key === 'Escape') {
    closeInspector();
    if (!U.$('#help-overlay').hidden) toggleHelp();
    U.$('#add-menu').hidden = true;
    return;
  }
  const t = ev.target;
  const tag = (t && t.tagName) || '';
  const typing = tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA' || (t && t.isContentEditable);
  if (typing) return;
  if (ev.key === 'F1') { ev.preventDefault(); toggleHelp(); }
  else if (ev.key === 'e' || ev.key === 'E') setEditing(!GMT.state.editing);
  else if (ev.key === 'd' || ev.key === 'D') toggleDataStatus();
  else if (ev.key === 'i' || ev.key === 'I') {
    const p = U.$('#inspector');
    if (p.hidden) app.inspect({ type: 'news', n: GMT.state.data.news[0] }); else closeInspector();
  }
});

/* ---------------- 窗口缩放 ---------------- */
window.addEventListener('resize', U.debounce(() => {
  GMT.grid.setRowH();
  GMT.grid.applyLayout();
}, 150));

/* 点击其他区域时收起添加菜单 */
document.addEventListener('click', ev => {
  const menu = U.$('#add-menu');
  if (!menu.hidden && !ev.target.closest('.tb-group')) { menu.hidden = true; U.$('#btn-add').setAttribute('aria-expanded', 'false'); }
});

/* ---------------- 启动 ---------------- */
async function boot() {
  const data = await GMT.loadData();
  if (!data) {
    document.getElementById('grid').innerHTML =
      '<p style="color:#FF4D4F;padding:20px;font-family:monospace">致命错误：无可用数据源。请确认 js/market-data.js 与 index.html 同目录。</p>';
    return;
  }
  GMT.grid.setRowH();
  GMT.grid.load();
  GMT.grid.build();
  buildTape();
  app.refreshAddMenu();
  setModeBadge();
  tickClock();
  setInterval(tickClock, 1000);
  setInterval(() => {
    if (GMT.state.newsPaused) return;
    if (GMT.grid.layout.items.news && GMT.grid.layout.items.news.visible) GMT.widgets.rerender('news');
  }, 30000);
  if (GMT.store.get('editing', false)) setEditing(true);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) tickClock(); });
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
})();
