/* ============================================================
   GMT grid — 12-col window system: drag / resize / snap /
   collision / minimize / zoom / lock / presets / persistence
   ============================================================ */
(function () {
'use strict';
const GMT = window.GMT;
const U = GMT.U;

const COLS = 12, GAP = 8;
let ROWH = 84;

const grid = GMT.grid = {
  layout: null,
  els: {},       // id -> widget DOM
  observers: {},
};

/* ---------------- layout model ---------------- */
function defaultItems() {
  const items = {};
  Object.keys(GMT.widgets.registry).forEach(id => {
    const d = GMT.widgets.registry[id].def;
    items[id] = { x: d.x, y: d.y, w: d.w, h: d.h, visible: !d.hidden, minimized: false, locked: false };
  });
  return items;
}
function defaultMobileOrder() {
  return Object.keys(GMT.widgets.registry).sort((a, b) => {
    const A = GMT.widgets.registry[a].def, B = GMT.widgets.registry[b].def;
    return (A.y - B.y) || (A.x - B.x);
  });
}
grid.load = function () {
  const saved = GMT.store.get('layout', null);
  const items = defaultItems();
  if (saved && saved.items) {
    Object.keys(items).forEach(id => {
      if (saved.items[id]) Object.assign(items[id], saved.items[id]);
    });
  }
  grid.layout = {
    items,
    mobileOrder: (saved && Array.isArray(saved.mobileOrder) && saved.mobileOrder.length === Object.keys(items).length)
      ? saved.mobileOrder : defaultMobileOrder(),
  };
};
grid.save = function () {
  GMT.store.set('layout', grid.layout);
};

/* ---------------- geometry ---------------- */
function metrics() {
  const gw = U.$('#grid').clientWidth - GAP * 2;
  const colW = (gw - GAP * (COLS - 1)) / COLS;
  return { colW };
}
function pxRect(it) {
  const { colW } = metrics();
  return {
    left: GAP + it.x * (colW + GAP),
    top: GAP + it.y * (ROWH + GAP),
    width: it.w * colW + (it.w - 1) * GAP,
    height: it.h * ROWH + (it.h - 1) * GAP,
  };
}
function collides(id, r) {
  const items = grid.layout.items;
  return Object.keys(items).some(other => {
    if (other === id) return false;
    const o = items[other];
    if (!o.visible) return false;
    return r.x < o.x + o.w && r.x + r.w > o.x && r.y < o.y + o.h && r.y + r.h > o.y;
  });
}
function boundsOk(r) { return r.x >= 0 && r.y >= 0 && r.x + r.w <= COLS; }

/* ---------------- DOM build ---------------- */
grid.build = function () {
  const root = U.$('#grid');
  // 先断开上一轮的 ResizeObserver，避免游离 DOM 与监听器泄漏
  Object.keys(grid.observers).forEach(id => { try { grid.observers[id].disconnect(); } catch (e) {} });
  grid.observers = {};
  root.innerHTML = '';
  grid.els = {};
  Object.keys(GMT.widgets.registry).forEach(id => {
    const reg = GMT.widgets.registry[id];
    const w = U.el('section', 'widget');
    w.id = 'w-' + id;
    w.setAttribute('role', 'region');
    w.setAttribute('aria-label', reg.title);
    const head = U.el('div', 'w-head');
    head.innerHTML =
      '<span class="w-num">' + reg.num + '</span>' +
      '<span class="w-title">' + U.esc(reg.title) + '</span>' +
      '<span class="w-asof" data-asof></span>' +
      '<span class="w-order"><button class="w-btn" data-act="up" title="上移" aria-label="上移组件">▲</button>' +
      '<button class="w-btn" data-act="down" title="下移" aria-label="下移组件">▼</button></span>' +
      '<button class="w-btn" data-act="lock" title="锁定位置" aria-label="锁定位置">🔓</button>' +
      '<button class="w-btn" data-act="min" title="最小化" aria-label="最小化">—</button>' +
      '<button class="w-btn" data-act="zoom" title="放大" aria-label="放大组件">⤢</button>' +
      '<button class="w-btn" data-act="close" title="移除组件" aria-label="移除组件">✕</button>';
    const drag = U.el('div', 'w-drag');
    drag.setAttribute('aria-hidden', 'true');
    head.appendChild(drag);
    const body = U.el('div', 'w-body');
    const rz = U.el('div', 'w-resize');
    rz.setAttribute('aria-hidden', 'true');
    w.appendChild(head); w.appendChild(body); w.appendChild(rz);
    root.appendChild(w);
    grid.els[id] = w;
    wireWidget(id, w, head, drag, rz);
    // content
    GMT.widgets.render(id, body);
    // redraw charts on resize
    const ro = new ResizeObserver(U.debounce(() => {
      if (GMT.widgets.registry[id].onResize) GMT.widgets.registry[id].onResize(body);
    }, 120));
    ro.observe(body);
    grid.observers[id] = ro;
  });
  grid.applyLayout();
};

U.debounce = function (fn, ms) {
  let t; return function () { clearTimeout(t); const a = arguments, s = this; t = setTimeout(() => fn.apply(s, a), ms); };
};

/* ---------------- apply layout to DOM ---------------- */
grid.applyLayout = function () {
  const root = U.$('#grid');
  const mobile = U.isMobile();
  let maxBottom = 0;
  const items = grid.layout.items;
  Object.keys(items).forEach(id => {
    const it = items[id], el = grid.els[id];
    if (!el) return;
    el.style.display = it.visible ? '' : 'none';
    if (!it.visible) return;
    el.classList.toggle('min', !!it.minimized);
    el.classList.toggle('locked', !!it.locked);
    const lockBtn = el.querySelector('[data-act="lock"]');
    if (lockBtn) { lockBtn.textContent = it.locked ? '🔒' : '🔓'; lockBtn.title = it.locked ? '解锁位置' : '锁定位置'; lockBtn.setAttribute('aria-label', lockBtn.title); }
    if (mobile) {
      el.style.left = el.style.top = el.style.width = '';
      el.style.height = it.minimized ? '24px' : Math.min(560, Math.max(180, pxRect(it).height)) + 'px';
      el.style.position = 'static';
    } else {
      const r = pxRect(it);
      el.style.position = 'absolute';
      el.style.left = r.left + 'px';
      el.style.top = r.top + 'px';
      el.style.width = r.width + 'px';
      el.style.height = it.minimized ? '24px' : r.height + 'px';
      maxBottom = Math.max(maxBottom, r.top + (it.minimized ? 24 : r.height));
    }
  });
  if (mobile) {
    // reorder by mobileOrder
    grid.layout.mobileOrder.forEach(id => { const el = grid.els[id]; if (el) root.appendChild(el); });
    root.style.height = '';
  } else {
    root.style.height = (maxBottom + GAP) + 'px';
  }
};

/* ---------------- widget chrome actions ---------------- */
function wireWidget(id, el, head, drag, rz) {
  const it = () => grid.layout.items[id];
  head.addEventListener('click', ev => {
    const act = ev.target && ev.target.getAttribute && ev.target.getAttribute('data-act');
    if (!act) return;
    ev.stopPropagation();
    const item = it();
    if (act === 'close') {
      item.visible = false; grid.save(); grid.applyLayout(); GMT.app.refreshAddMenu();
      GMT.events.emit('widget-visibility', id);
    } else if (act === 'min') {
      item.minimized = !item.minimized; grid.save(); grid.applyLayout();
      if (!item.minimized && GMT.widgets.registry[id].onResize) GMT.widgets.registry[id].onResize(el.querySelector('.w-body'));
    } else if (act === 'lock') {
      item.locked = !item.locked; grid.save(); grid.applyLayout();
    } else if (act === 'zoom') {
      toggleZoom(id, el);
    } else if (act === 'up' || act === 'down') {
      moveMobile(id, act === 'up' ? -1 : 1);
    }
  });
  // drag to move (desktop, edit mode)
  drag.addEventListener('pointerdown', ev => {
    if (!GMT.state.editing || U.isMobile() || it().locked) return;
    ev.preventDefault();
    startMove(id, el, ev);
  });
  // resize (desktop, edit mode)
  rz.addEventListener('pointerdown', ev => {
    if (!GMT.state.editing || U.isMobile() || it().locked) return;
    ev.preventDefault();
    startResize(id, el, ev);
  });
}

function moveMobile(id, dir) {
  const ord = grid.layout.mobileOrder;
  const i = ord.indexOf(id), j = i + dir;
  if (i < 0 || j < 0 || j >= ord.length) return;
  ord.splice(i, 1); ord.splice(j, 0, id);
  grid.save(); grid.applyLayout();
}

function toggleZoom(id, el) {
  const zoomed = el.classList.toggle('zoomed');
  if (zoomed) { el.dataset.prevStyle = el.style.cssText; }
  else {
    el.style.cssText = el.dataset.prevStyle || '';
    if (GMT.widgets.registry[id].onResize) setTimeout(() => GMT.widgets.registry[id].onResize(el.querySelector('.w-body')), 30);
  }
  if (GMT.widgets.registry[id].onResize) setTimeout(() => GMT.widgets.registry[id].onResize(el.querySelector('.w-body')), 30);
}

/* ---------------- drag & resize engine ---------------- */
function ghost() { return U.$('#ghost'); }
function showGhost(r, ok) {
  const g = ghost();
  g.hidden = false;
  g.classList.toggle('bad', !ok);
  g.style.left = r.left + 'px'; g.style.top = r.top + 'px';
  g.style.width = r.width + 'px'; g.style.height = r.height + 'px';
}
function hideGhost() { ghost().hidden = true; }

function startMove(id, el, ev0) {
  const item = grid.layout.items[id];
  const orig = { x: item.x, y: item.y };
  const { colW } = metrics();
  const rootRect = U.$('#grid').getBoundingClientRect();
  const dx = ev0.clientX, dy = ev0.clientY;
  const startLeft = pxRect(item).left, startTop = pxRect(item).top;
  el.classList.add('dragging');
  el.setPointerCapture && dragCapture(el, ev0);
  function dragCapture(e, ev) { try { e.setPointerCapture(ev.pointerId); } catch (err) {} }
  let last = { x: orig.x, y: orig.y, ok: true };
  function onMove(ev) {
    const dLeft = startLeft + (ev.clientX - dx);
    const dTop = startTop + (ev.clientY - dy);
    let gx = Math.round((dLeft - GAP) / (colW + GAP));
    let gy = Math.round((dTop - GAP) / (ROWH + GAP));
    gx = Math.max(0, Math.min(COLS - item.w, gx));
    gy = Math.max(0, gy);
    const cand = { x: gx, y: gy, w: item.w, h: item.h };
    const ok = boundsOk(cand) && !collides(id, cand);
    last = { x: gx, y: gy, ok };
    const pr = pxRect({ x: gx, y: gy, w: item.w, h: item.h });
    showGhost(pr, ok);
  }
  function onUp() {
    window.removeEventListener('pointermove', onMove);
    window.removeEventListener('pointerup', onUp);
    el.classList.remove('dragging');
    hideGhost();
    if (last.ok && (last.x !== orig.x || last.y !== orig.y)) {
      item.x = last.x; item.y = last.y;
      grid.save();
    }
    grid.applyLayout();
  }
  window.addEventListener('pointermove', onMove);
  window.addEventListener('pointerup', onUp);
}

function startResize(id, el, ev0) {
  const item = grid.layout.items[id];
  const reg = GMT.widgets.registry[id];
  const minW = (reg.min && reg.min.w) || 2, minH = (reg.min && reg.min.h) || 2;
  const orig = { w: item.w, h: item.h };
  const { colW } = metrics();
  const startR = pxRect(item);
  const sx = ev0.clientX, sy = ev0.clientY;
  let last = { w: orig.w, h: orig.h, ok: true };
  function onMove(ev) {
    const pw = startR.width + (ev.clientX - sx);
    const ph = startR.height + (ev.clientY - sy);
    let gw = Math.round((pw + GAP) / (colW + GAP));
    let gh = Math.round((ph + GAP) / (ROWH + GAP));
    gw = Math.max(minW, Math.min(COLS - item.x, gw));
    gh = Math.max(minH, Math.min(14, gh));
    const cand = { x: item.x, y: item.y, w: gw, h: gh };
    const ok = boundsOk(cand) && !collides(id, cand);
    last = { w: gw, h: gh, ok };
    showGhost(pxRect(cand), ok);
  }
  function onUp() {
    window.removeEventListener('pointermove', onMove);
    window.removeEventListener('pointerup', onUp);
    hideGhost();
    if (last.ok && (last.w !== orig.w || last.h !== orig.h)) {
      item.w = last.w; item.h = last.h;
      grid.save(); grid.applyLayout();
      if (reg.onResize) reg.onResize(el.querySelector('.w-body'));
    } else {
      grid.applyLayout();
    }
  }
  window.addEventListener('pointermove', onMove);
  window.addEventListener('pointerup', onUp);
}

/* ---------------- presets ---------------- */
const PRESETS = {
  GLOBAL: null, // default
  EQUITIES: {
    heatmap: { x: 0, y: 0, w: 8, h: 7, visible: true },
    breadth: { x: 8, y: 0, w: 4, h: 2, visible: true },
    news:    { x: 8, y: 2, w: 4, h: 5, visible: true },
    aapl:    { x: 0, y: 7, w: 7, h: 5, visible: true },
    sector:  { x: 7, y: 7, w: 5, h: 5, visible: true },
    metals:  { visible: false }, pulse: { visible: false }, indexlist: { visible: false }, datastatus: { visible: false },
  },
  METALS: {
    metals:  { x: 0, y: 0, w: 8, h: 7, visible: true },
    pulse:   { x: 8, y: 0, w: 4, h: 4, visible: true },
    indexlist:{ x: 8, y: 4, w: 4, h: 3, visible: true },
    news:    { x: 0, y: 7, w: 5, h: 4, visible: true },
    breadth: { x: 5, y: 7, w: 7, h: 4, visible: true },
    heatmap: { visible: false }, aapl: { visible: false }, sector: { visible: false }, datastatus: { visible: false },
  },
  NEWS: {
    news:    { x: 0, y: 0, w: 7, h: 8, visible: true },
    breadth: { x: 7, y: 0, w: 5, h: 3, visible: true },
    heatmap: { x: 7, y: 3, w: 5, h: 5, visible: true },
    indexlist:{ x: 0, y: 8, w: 6, h: 4, visible: true },
    pulse:   { x: 6, y: 8, w: 6, h: 4, visible: true },
    aapl: { visible: false }, sector: { visible: false }, metals: { visible: false }, datastatus: { visible: false },
  },
};
grid.applyPreset = function (name) {
  const items = grid.layout.items;
  if (name === 'GLOBAL') {
    grid.layout.items = defaultItems();
  } else {
    const p = PRESETS[name];
    Object.keys(items).forEach(id => {
      const patch = p[id];
      if (!patch) return;
      if (patch.visible === false) { items[id].visible = false; return; }
      ['x', 'y', 'w', 'h'].forEach(k => { if (patch[k] !== undefined) items[id][k] = patch[k]; });
      if (patch.visible !== undefined) items[id].visible = patch.visible;
    });
  }
  grid.layout.mobileOrder = defaultMobileOrder();
  grid.save(); grid.applyLayout(); GMT.app.refreshAddMenu();
  Object.keys(GMT.widgets.registry).forEach(id => {
    const reg = GMT.widgets.registry[id];
    if (grid.layout.items[id].visible && reg.onResize) reg.onResize(grid.els[id].querySelector('.w-body'));
  });
};

grid.reset = function () {
  grid.layout = { items: defaultItems(), mobileOrder: defaultMobileOrder() };
  grid.save(); grid.applyLayout(); GMT.app.refreshAddMenu();
  Object.keys(GMT.widgets.registry).forEach(id => {
    const reg = GMT.widgets.registry[id];
    if (grid.layout.items[id].visible && reg.onResize) reg.onResize(grid.els[id].querySelector('.w-body'));
  });
};

grid.setRowH = function () {
  ROWH = U.isMobile() ? 80 : 84;
};
})();
