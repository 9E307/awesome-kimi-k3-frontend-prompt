/* ============================================================
   GMT charts — crisp canvas renderers (DPR aware, no deps)
   ============================================================ */
(function () {
'use strict';
const GMT = window.GMT;
const U = GMT.U;
const C = GMT.charts = {};

/* 中式配色：红涨（up）/ 绿跌（down） */
const COL = {
  grid: '#292929', gridStrong: '#3A3A3A', fg: '#D7D7D7', dim: '#8A8A8A', faint: '#5A5A5A',
  amber: '#F28C00', up: '#FF4D4F', down: '#00C176', cyan: '#4DD0E1', flat: '#6E6E6E',
};

C.setup = function (canvas) {
  const dpr = Math.max(1, Math.min(3, window.devicePixelRatio || 1));
  const r = canvas.getBoundingClientRect();
  const w = Math.max(10, r.width), h = Math.max(10, r.height);
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);
  return { ctx, w, h };
};

function niceTicks(min, max, n) {
  if (!(isFinite(min) && isFinite(max)) || min === max) { max = min + 1; }
  const span = max - min, step0 = span / Math.max(1, n);
  const mag = Math.pow(10, Math.floor(Math.log10(step0)));
  let step = mag;
  for (const m of [1, 2, 2.5, 5, 10]) { if (step0 <= m * mag) { step = m * mag; break; } }
  const t0 = Math.ceil(min / step) * step, out = [];
  for (let v = t0; v <= max + 1e-9; v += step) out.push(v);
  return { ticks: out, step };
}
function decFor(step) { const s = String(step); const i = s.indexOf('.'); return i < 0 ? 0 : Math.min(4, s.length - i - 1); }

/* ---- price + volume (AAPL 60 sessions) ---- */
C.priceVolume = function (canvas, rows, opt) {
  opt = opt || {};
  const { ctx, w, h } = C.setup(canvas);
  const padL = 8, padR = 46, padT = 8, padB = 18;
  const volH = Math.round((h - padT - padB) * 0.22);
  const priceB = h - padB - volH - 6;
  const n = rows.length;
  let lo = Infinity, hi = -Infinity, vmax = 0;
  rows.forEach(r => { lo = Math.min(lo, r.l); hi = Math.max(hi, r.h); vmax = Math.max(vmax, r.v); });
  const pad = (hi - lo) * 0.06 || 1; lo -= pad; hi += pad;
  const x = i => padL + (w - padL - padR) * (n === 1 ? 0.5 : i / (n - 1));
  const y = v => padT + (priceB - padT) * (1 - (v - lo) / (hi - lo));
  const vy = v => (h - padB) - volH * (v / vmax);

  // grid + price axis
  const tk = niceTicks(lo, hi, 5);
  ctx.font = '9px "IBM Plex Mono",monospace'; ctx.textBaseline = 'middle';
  tk.ticks.forEach(v => {
    const yy = y(v);
    ctx.strokeStyle = COL.grid; ctx.beginPath(); ctx.moveTo(padL, yy); ctx.lineTo(w - padR, yy); ctx.stroke();
    ctx.fillStyle = COL.dim; ctx.textAlign = 'left';
    ctx.fillText(U.fmt(v, decFor(tk.step)), w - padR + 4, yy);
  });
  // volume bars
  rows.forEach((r, i) => {
    const bw = Math.max(1, (w - padL - padR) / n * 0.62);
    ctx.fillStyle = r.c >= r.o ? 'rgba(242,140,0,.72)' : 'rgba(242,140,0,.38)';
    ctx.fillRect(x(i) - bw / 2, vy(r.v), bw, (h - padB) - vy(r.v));
  });
  ctx.fillStyle = COL.faint; ctx.textAlign = 'left';
  ctx.fillText('VOL ' + U.fmtBig(vmax), padL + 2, h - padB - volH + 8);
  // price area + line
  ctx.beginPath();
  rows.forEach((r, i) => { const xx = x(i), yy = y(r.c); i ? ctx.lineTo(xx, yy) : ctx.moveTo(xx, yy); });
  ctx.strokeStyle = COL.amber; ctx.lineWidth = 1.2; ctx.stroke();
  ctx.lineTo(x(n - 1), priceB); ctx.lineTo(x(0), priceB); ctx.closePath();
  ctx.fillStyle = 'rgba(242,140,0,.06)'; ctx.fill();
  // prev close dashed
  const pc = opt.prevClose;
  if (pc && pc > lo && pc < hi) {
    ctx.setLineDash([3, 3]); ctx.strokeStyle = COL.faint;
    ctx.beginPath(); ctx.moveTo(padL, y(pc)); ctx.lineTo(w - padR, y(pc)); ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle = COL.faint; ctx.textAlign = 'left'; ctx.fillText('PC', padL + 2, y(pc) - 6);
  }
  // x dates
  ctx.fillStyle = COL.faint; ctx.textAlign = 'center';
  const labelEvery = Math.ceil(n / 6);
  rows.forEach((r, i) => {
    if (i % labelEvery === 0 || i === n - 1) ctx.fillText(r.date.slice(5), x(i), h - padB + 9);
  });
  // crosshair
  const sel = opt.selected;
  if (sel !== null && sel !== undefined && rows[sel]) {
    const xx = x(sel);
    ctx.strokeStyle = COL.amber; ctx.setLineDash([2, 2]);
    ctx.beginPath(); ctx.moveTo(xx, padT); ctx.lineTo(xx, h - padB); ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle = COL.amber;
    ctx.beginPath(); ctx.arc(xx, y(rows[sel].c), 2.6, 0, 7); ctx.fill();
  }
  return { x, y, padL, padR, n };
};

/* ---- generic multi-line (sector intraday) ---- */
C.multiLine = function (canvas, series, opt) {
  opt = opt || {};
  const { ctx, w, h } = C.setup(canvas);
  const padL = 8, padR = 44, padT = 8, padB = 16;
  let lo = 0, hi = 0;
  series.forEach(s => s.pts.forEach(v => { lo = Math.min(lo, v); hi = Math.max(hi, v); }));
  const pad = (hi - lo) * 0.12 || 1; lo -= pad; hi += pad;
  const N = series[0] ? series[0].pts.length : 0;
  const x = i => padL + (w - padL - padR) * (N === 1 ? 0.5 : i / (N - 1));
  const y = v => padT + (h - padB - padT) * (1 - (v - lo) / (hi - lo));
  const tk = niceTicks(lo, hi, 4);
  ctx.font = '9px "IBM Plex Mono",monospace'; ctx.textBaseline = 'middle';
  tk.ticks.forEach(v => {
    const yy = y(v);
    ctx.strokeStyle = Math.abs(v) < 1e-9 ? COL.gridStrong : COL.grid;
    ctx.beginPath(); ctx.moveTo(padL, yy); ctx.lineTo(w - padR, yy); ctx.stroke();
    ctx.fillStyle = COL.dim; ctx.textAlign = 'left';
    ctx.fillText(U.fmt(v, 1) + '%', w - padR + 4, yy);
  });
  const colors = opt.colors || [COL.amber, COL.cyan, COL.fg];
  series.forEach((s, si) => {
    ctx.beginPath();
    s.pts.forEach((v, i) => { const xx = x(i), yy = y(v); i ? ctx.lineTo(xx, yy) : ctx.moveTo(xx, yy); });
    ctx.strokeStyle = colors[si % colors.length]; ctx.lineWidth = 1.2; ctx.stroke();
    const lv = s.pts[s.pts.length - 1];
    ctx.fillStyle = colors[si % colors.length];
    ctx.beginPath(); ctx.arc(x(N - 1), y(lv), 2, 0, 7); ctx.fill();
  });
  ctx.fillStyle = COL.faint; ctx.textAlign = 'center';
  ctx.fillText('OPEN', x(0), h - 6);
  ctx.fillText('LAST', x(N - 1), h - 6);
};

/* ---- horizontal bars (sector averages) ---- */
C.hBars = function (canvas, items, opt) {
  opt = opt || {};
  const { ctx, w, h } = C.setup(canvas);
  const rowH = h / items.length;
  let max = 0; items.forEach(it => max = Math.max(max, Math.abs(it.v)));
  max = max || 1;
  const cx = w / 2, half = (w / 2 - 70);
  ctx.font = '10px "IBM Plex Mono",monospace'; ctx.textBaseline = 'middle';
  ctx.strokeStyle = COL.gridStrong; ctx.beginPath(); ctx.moveTo(cx, 0); ctx.lineTo(cx, h); ctx.stroke();
  items.forEach((it, i) => {
    const yy = rowH * i + rowH / 2;
    const bw = Math.abs(it.v) / max * half;
    ctx.fillStyle = it.v >= 0 ? COL.up : COL.down;
    if (it.v >= 0) ctx.fillRect(cx, yy - 5, bw, 10); else ctx.fillRect(cx - bw, yy - 5, bw, 10);
    ctx.fillStyle = COL.fg; ctx.textAlign = 'right'; ctx.fillText(it.label, cx - half - 8, yy);
    ctx.fillStyle = it.v >= 0 ? COL.up : COL.down;
    ctx.textAlign = it.v >= 0 ? 'left' : 'right';
    ctx.fillText(U.pct(it.v), it.v >= 0 ? cx + bw + 5 : cx - bw - 5, yy);
    ctx.fillStyle = COL.faint; ctx.textAlign = 'left';
    ctx.fillText('n=' + it.n, cx + half + 8, yy);
  });
};

/* ---- sparkline ---- */
C.spark = function (canvas, pts, up) {
  const { ctx, w, h } = C.setup(canvas);
  let lo = Math.min.apply(null, pts), hi = Math.max.apply(null, pts);
  if (lo === hi) { lo -= 1; hi += 1; }
  const x = i => 1 + (w - 2) * i / (pts.length - 1);
  const y = v => 1 + (h - 2) * (1 - (v - lo) / (hi - lo));
  ctx.beginPath();
  pts.forEach((v, i) => { i ? ctx.lineTo(x(i), y(v)) : ctx.moveTo(x(i), y(v)); });
  ctx.strokeStyle = up === undefined ? COL.amber : (up ? COL.up : COL.down);
  ctx.lineWidth = 1; ctx.stroke();
};

/* ---- single line (metals 60d) ---- */
C.line60 = function (canvas, pts, dates, opt) {
  opt = opt || {};
  const { ctx, w, h } = C.setup(canvas);
  const padL = 8, padR = 50, padT = 8, padB = 16;
  let lo = Math.min.apply(null, pts), hi = Math.max.apply(null, pts);
  const pad = (hi - lo) * 0.08 || 1; lo -= pad; hi += pad;
  const x = i => padL + (w - padL - padR) * i / (pts.length - 1);
  const y = v => padT + (h - padB - padT) * (1 - (v - lo) / (hi - lo));
  const tk = niceTicks(lo, hi, 4);
  ctx.font = '9px "IBM Plex Mono",monospace'; ctx.textBaseline = 'middle';
  tk.ticks.forEach(v => {
    const yy = y(v);
    ctx.strokeStyle = COL.grid; ctx.beginPath(); ctx.moveTo(padL, yy); ctx.lineTo(w - padR, yy); ctx.stroke();
    ctx.fillStyle = COL.dim; ctx.textAlign = 'left'; ctx.fillText(U.fmt(v, decFor(tk.step)), w - padR + 4, yy);
  });
  ctx.beginPath();
  pts.forEach((v, i) => { i ? ctx.lineTo(x(i), y(v)) : ctx.moveTo(x(i), y(v)); });
  ctx.strokeStyle = opt.color || COL.amber; ctx.lineWidth = 1.2; ctx.stroke();
  ctx.lineTo(x(pts.length - 1), h - padB); ctx.lineTo(x(0), h - padB); ctx.closePath();
  ctx.fillStyle = 'rgba(242,140,0,.06)'; ctx.fill();
  if (dates && dates.length) {
    ctx.fillStyle = COL.faint; ctx.textAlign = 'center';
    const every = Math.ceil(pts.length / 6);
    for (let i = 0; i < pts.length; i += every) ctx.fillText(dates[i].slice(5), x(i), h - 6);
  }
  const sel = opt.selected;
  if (sel !== null && sel !== undefined && pts[sel] !== undefined) {
    const xx = x(sel);
    ctx.strokeStyle = COL.amber; ctx.setLineDash([2, 2]);
    ctx.beginPath(); ctx.moveTo(xx, padT); ctx.lineTo(xx, h - padB); ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle = COL.amber; ctx.beginPath(); ctx.arc(xx, y(pts[sel]), 2.4, 0, 7); ctx.fill();
  }
  return { x, n: pts.length };
};

/* ---- 24h session map ---- */
C.sessionMap = function (canvas, markets, nowUtcMin) {
  const { ctx, w, h } = C.setup(canvas);
  const padL = 64, padR = 10, padT = 12, padB = 14;
  const iw = w - padL - padR;
  const rows = markets.length;
  const rh = (h - padT - padB) / rows;
  const x = min => padL + iw * min / 1440;
  ctx.font = '8px "IBM Plex Mono",monospace'; ctx.textBaseline = 'middle';
  // hour grid
  for (let hh = 0; hh <= 24; hh += 4) {
    const xx = x(hh * 60);
    ctx.strokeStyle = COL.grid; ctx.beginPath(); ctx.moveTo(xx, padT); ctx.lineTo(xx, h - padB); ctx.stroke();
    ctx.fillStyle = COL.faint; ctx.textAlign = 'center'; ctx.fillText(U.pad(hh % 24) + ':00', xx, h - 7);
  }
  markets.forEach((m, i) => {
    const yy = padT + rh * i + rh / 2;
    ctx.fillStyle = COL.dim; ctx.textAlign = 'right'; ctx.fillText(m.short, padL - 6, yy);
    m.windows.forEach(wn => {
      const x0 = x(Math.max(0, wn[0])), x1 = x(Math.min(1440, wn[1]));
      ctx.fillStyle = 'rgba(242,140,0,.30)';
      ctx.fillRect(x0, yy - rh * 0.28, Math.max(1, x1 - x0), rh * 0.56);
      ctx.strokeStyle = 'rgba(242,140,0,.8)'; ctx.strokeRect(x0 + .5, yy - rh * 0.28 + .5, Math.max(1, x1 - x0) - 1, rh * 0.56 - 1);
    });
  });
  // NOW 线（当前时刻，非涨跌语义 → 用青色）
  const nx = x(nowUtcMin);
  ctx.strokeStyle = COL.cyan; ctx.setLineDash([3, 2]);
  ctx.beginPath(); ctx.moveTo(nx, padT - 4); ctx.lineTo(nx, h - padB); ctx.stroke(); ctx.setLineDash([]);
  ctx.fillStyle = COL.cyan; ctx.textAlign = 'center'; ctx.fillText('NOW', nx, 6);
};
})();
