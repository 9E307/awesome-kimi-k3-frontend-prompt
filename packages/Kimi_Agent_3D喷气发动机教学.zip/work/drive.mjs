import puppeteer from 'puppeteer-core';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const OUT = '/mnt/agents/output/work';

const browser = await puppeteer.launch({
  executablePath: '/usr/bin/chromium',
  headless: 'new',
  args: ['--no-sandbox', '--disable-gpu', '--use-angle=swiftshader', '--window-size=1280,720'],
  defaultViewport: { width: 1280, height: 720 },
});
const page = await browser.newPage();
const errors = [];
page.on('console', (m) => {
  if (m.type() === 'error') errors.push(m.text());
});
page.on('pageerror', (e) => errors.push('PAGEERROR: ' + e.message));

await page.goto('http://localhost:4173', { waitUntil: 'domcontentloaded', timeout: 60000 });
await sleep(5000);
await page.screenshot({ path: `${OUT}/t0_idle.png` });

async function clickByText(text, tag = 'button') {
  const ok = await page.evaluate((text, tag) => {
    const els = [...document.querySelectorAll(tag)];
    const el = els.find((e) => e.textContent.trim().includes(text) && !e.disabled);
    if (el) { el.click(); return true; }
    return false;
  }, text, tag);
  console.log('click', text, ok ? 'OK' : 'MISS');
  return ok;
}

async function setSlider(idx, val) {
  await page.evaluate((idx, val) => {
    const sliders = [...document.querySelectorAll('input[type=range]')];
    const s = sliders[idx];
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    setter.call(s, val);
    s.dispatchEvent(new Event('input', { bubbles: true }));
    s.dispatchEvent(new Event('change', { bubbles: true }));
  }, idx, val);
}

// 1. 启动发动机
await clickByText('启动');
await sleep(4500);
await page.screenshot({ path: `${OUT}/t1_starting.png` });
await sleep(4000);
await page.screenshot({ path: `${OUT}/t2_idle.png` });
console.log('state after start:', await page.evaluate(() => document.querySelector('.state-chip')?.textContent));

// 2. 油门 100%
await setSlider(0, '100');
await sleep(6000);
console.log('full throttle readout:', await page.evaluate(() =>
  [...document.querySelectorAll('.readout-pair b')].map((x) => x.textContent).join(' | ')));
await page.screenshot({ path: `${OUT}/t3_full.png` });

// 3. 温度层 + 跟随空气
await clickByText('温度');
await clickByText('跟随空气');
await sleep(2500);
await page.screenshot({ path: `${OUT}/t4_trace.png` });
await sleep(6000);
await page.screenshot({ path: `${OUT}/t5_trace_end.png` });

// 4. 布雷顿图
await clickByText('布雷顿循环图');
await sleep(1200);
await page.screenshot({ path: `${OUT}/t6_cycle.png` });

// 5. 爆炸 60%
await setSlider(2, '60');
await sleep(2500);
await page.screenshot({ path: `${OUT}/t7_explode.png` });
console.log('state when exploded:', await page.evaluate(() => document.querySelector('.state-chip')?.textContent));

// 6. 组装 + 剖切
await setSlider(2, '0');
await sleep(1200);
await clickByText('剖切');
await sleep(1800);
await page.screenshot({ path: `${OUT}/t8_cutaway.png` });

// 7. 故障挑战（喘振）
await clickByText('故障挑战');
await sleep(600);
await clickByText('压气机喘振');
await sleep(3500);
await page.screenshot({ path: `${OUT}/t9_surge.png` });

// 8. 关机：先断油再惰转
await clickByText('×');
await clickByText('关机');
await sleep(1200);
console.log('shutdown phase:', await page.evaluate(() => document.querySelector('.state-chip')?.textContent));
await sleep(9000);
console.log('after spooldown:', await page.evaluate(() => document.querySelector('.state-chip')?.textContent));
await page.screenshot({ path: `${OUT}/t10_off.png` });

console.log('CONSOLE ERRORS:', errors.length ? errors.slice(0, 10) : 'none');
await browser.close();
