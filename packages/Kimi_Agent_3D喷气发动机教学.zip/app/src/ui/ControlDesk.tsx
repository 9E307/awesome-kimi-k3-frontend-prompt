// 左侧控制面板：发动机 / 环境 / 模型 / 气流 / 视角 / 学习
import { useLab } from '../app/store';
import type { FlowLayer, CameraMode } from '../app/store';
import { useSimSnapshot } from './useSim';
import { engineAudio } from '../audio/EngineAudio';
import { KIMI_DEEP_LINK } from '../app/engineConfig';

const PHASE_KEY = {
  OFF: 'stOff', STARTING: 'stStarting', IGNITION: 'stIgnition', IDLE: 'stIdle',
  SPOOLING: 'stSpooling', RUNNING: 'stRunning', SHUTDOWN: 'stShutdown', SURGE: 'stSurge',
} as const;

const LAYERS: { id: FlowLayer; key: 'layerVelocity' | 'layerPressure' | 'layerTemp' | 'layerComposition' }[] = [
  { id: 'velocity', key: 'layerVelocity' },
  { id: 'pressure', key: 'layerPressure' },
  { id: 'temperature', key: 'layerTemp' },
  { id: 'composition', key: 'layerComposition' },
];

const CAMS: { id: CameraMode; key: 'camGlobal' | 'camCutaway' | 'camCombustor' | 'camNozzle' | 'camFree' }[] = [
  { id: 'global', key: 'camGlobal' },
  { id: 'cutaway', key: 'camCutaway' },
  { id: 'combustor', key: 'camCombustor' },
  { id: 'nozzle', key: 'camNozzle' },
  { id: 'free', key: 'camFree' },
];

export function ControlDesk() {
  const lab = useLab();
  const t = lab.t;
  const snap = useSimSnapshot();
  const open = lab.isControlPanelOpen;

  const running = lab.phase !== 'OFF';
  const locked = lab.explodeTarget > 0.08 || lab.explodeCurrent > 0.08;

  return (
    <>
      <div id="control-desk-panel" className={`control-desk ${open ? 'open' : 'closed'}`}>
        {/* 手机端收起态紧凑控制条（桌面端不显示） */}
        <button
          className="desk-bar"
          onClick={() => lab.setControlPanelOpen(true)}
          aria-expanded={open}
          aria-controls="control-desk-panel"
          aria-label={t('openPanelBar')}
          tabIndex={open ? -1 : 0}
        >
          <span className="desk-bar-label">{t('openPanelBar')}</span>
          <span className="desk-bar-status">
            {t(PHASE_KEY[lab.phase])} · {t('throttle')} {Math.round(lab.throttleTarget * 100)}%
          </span>
          <span className="desk-bar-icon" aria-hidden="true">⌃</span>
        </button>

        <div className="desk-head">
          <button
            className="drawer-handle"
            onClick={() => lab.setControlPanelOpen(false)}
            aria-expanded={open}
            aria-controls="control-desk-panel"
            aria-label={t('hideControlPanel')}
            tabIndex={open ? 0 : -1}
          >
            <span />
          </button>
          <h2 className="desk-title">
            <span className="txt-d">{t('panelTitle')}</span>
            <span className="txt-m">{t('panelTitleMobile')}</span>
          </h2>
          <button
            className="panel-hide-btn"
            onClick={() => lab.setControlPanelOpen(false)}
            aria-expanded={open}
            aria-controls="control-desk-panel"
            aria-label={t('hideControlPanel')}
            title={t('hideControlPanel')}
            tabIndex={open ? 0 : -1}
          >
            <span aria-hidden="true">⌃</span>
            <em className="txt-d">{t('hidePanel')}</em>
            <em className="txt-m">{t('collapsePanel')}</em>
          </button>
        </div>

        <div className="desk-body">
        {/* 发动机 */}
        <section className="desk-group" aria-label={t('grpEngine')}>
          <h3>{t('grpEngine')}</h3>
          <div className="row">
            <button
              className={`btn-primary ${running ? 'btn-danger' : ''}`}
              onClick={() => {
                engineAudio.ensure();
                if (running) lab.shutdownEngine();
                else lab.startEngine();
              }}
              disabled={locked && !running}
              aria-label={running ? t('shutdown') : t('startEngine')}
            >
              {running ? t('shutdown') : t('startEngine')}
            </button>
            <div className="state-chip" data-phase={lab.phase}>
              {t(PHASE_KEY[lab.phase])}
            </div>
          </div>
          <label className="slider-row">
            <span>{t('throttle')}</span>
            <input
              type="range" min={0} max={100} step={1}
              value={Math.round(lab.throttleTarget * 100)}
              onChange={(e) => lab.setThrottle(Number(e.target.value) / 100)}
              disabled={locked}
              aria-label={t('throttle')}
            />
            <em>{Math.round(lab.throttleTarget * 100)}%</em>
          </label>
          <div className="readout-pair">
            <div>
              <small>{t('spoolSpeed')}</small>
              <b>≈ {Math.round(snap.n1 * 100)}%</b>
            </div>
            <div>
              <small>{t('thrust')}</small>
              <b>≈ {snap.thrust.toFixed(2)} <i>({lab.lang === 'zh' ? '归一化' : 'norm.'})</i></b>
            </div>
          </div>
        </section>

        {/* 环境 */}
        <section className="desk-group" aria-label={t('grpEnv')}>
          <h3>{t('grpEnv')}</h3>
          <label className="slider-row">
            <span>{t('altitude')}</span>
            <input
              type="range" min={0} max={12} step={0.5}
              value={lab.altitudeKm}
              onChange={(e) => lab.setAltitude(Number(e.target.value))}
              aria-label={t('altitude')}
            />
            <em>{lab.altitudeKm.toFixed(1)} km</em>
          </label>
          <div className="readout-pair">
            <div>
              <small>{t('density')}</small>
              <b>≈ {Math.round(snap.density * 100)}%</b>
            </div>
            <button className="btn-ghost" onClick={() => lab.resetAltitude()} aria-label={t('resetSeaLevel')}>
              {t('resetSeaLevel')}
            </button>
          </div>
        </section>

        {/* 模型 */}
        <section className="desk-group" aria-label={t('grpModel')}>
          <h3>{t('grpModel')}</h3>
          <label className="slider-row">
            <span>{t('explode')}</span>
            <input
              type="range" min={0} max={100} step={1}
              value={Math.round(lab.explodeTarget * 100)}
              onChange={(e) => lab.setExplode(Number(e.target.value) / 100)}
              aria-label={t('explodeSlider')}
            />
            <em>{Math.round(lab.explodeTarget * 100)}%</em>
          </label>
          <div className="row">
            <button
              className="btn-toggle"
              aria-pressed={lab.cutaway}
              onClick={() => lab.setCutaway(!lab.cutaway)}
            >
              {t('cutaway')}
            </button>
            <label className="slider-row inline">
              <span>{t('casingOpacity')}</span>
              <input
                type="range" min={12} max={100} step={1}
                value={Math.round(lab.casingOpacity * 100)}
                onChange={(e) => lab.setCasingOpacity(Number(e.target.value) / 100)}
                aria-label={t('casingOpacity')}
              />
            </label>
          </div>
        </section>

        {/* 气流 */}
        <section className="desk-group" aria-label={t('grpFlow')}>
          <h3>{t('grpFlow')}</h3>
          <div className="btn-grid four" role="group" aria-label={t('grpFlow')}>
            {LAYERS.map((l) => (
              <button
                key={l.id}
                className="btn-toggle"
                aria-pressed={lab.flowLayer === l.id}
                onClick={() => lab.setFlowLayer(l.id)}
              >
                {t(l.key)}
              </button>
            ))}
          </div>
          <div className="row">
            <button
              className="btn-toggle wide"
              aria-pressed={lab.traceAir}
              onClick={() => lab.toggleTraceAir()}
            >
              {t('followAir')}
            </button>
            <button
              className="btn-toggle wide"
              aria-pressed={lab.traceTorque}
              onClick={() => lab.toggleTraceTorque()}
            >
              {t('followTorque')}
            </button>
          </div>
        </section>

        {/* 视角 */}
        <section className="desk-group" aria-label={t('grpView')}>
          <h3>{t('grpView')}</h3>
          <div className="btn-grid three" role="group" aria-label={t('grpView')}>
            {CAMS.map((c) => (
              <button
                key={c.id}
                className="btn-toggle"
                aria-pressed={lab.cameraMode === c.id}
                onClick={() => lab.setCameraMode(c.id)}
              >
                {t(c.key)}
              </button>
            ))}
            <button
              className="btn-toggle"
              aria-pressed={lab.soundOn}
              onClick={() => {
                engineAudio.ensure();
                lab.toggleSound();
              }}
            >
              {t('sound')}
            </button>
          </div>
        </section>

        {/* 学习 */}
        <section className="desk-group" aria-label={t('grpLearn')}>
          <h3>{t('grpLearn')}</h3>
          <div className="row">
            <button className="btn-ghost" onClick={() => lab.prevChapter()} disabled={lab.chapter === 0} aria-label={t('prevChapter')}>
              ‹ {t('prevChapter')}
            </button>
            <button className="btn-ghost" onClick={() => lab.nextChapter()} disabled={lab.chapter === 4} aria-label={t('nextChapter')}>
              {t('nextChapter')} ›
            </button>
          </div>
          <div className="btn-grid two">
            <button className="btn-toggle" aria-pressed={lab.cycleOpen} onClick={() => lab.setCycleOpen(!lab.cycleOpen)}>
              {t('brayton')}
            </button>
            <button className="btn-toggle" aria-pressed={lab.faultOpen} onClick={() => lab.setFaultOpen(!lab.faultOpen)}>
              {t('faultChallenge')}
            </button>
            <button className="btn-toggle" aria-pressed={lab.resultCardOpen} onClick={() => lab.setResultCardOpen(true)}>
              {t('resultCard')}
            </button>
            <a className="btn-cta" href={KIMI_DEEP_LINK} target="_blank" rel="noreferrer">
              {t('kimiCta')}
            </a>
          </div>
        </section>
        </div>
      </div>

      {/* 桌面端收起后的恢复入口（手机端由紧凑控制条替代） */}
      <button
        className={`desk-rail ${open ? 'hidden' : ''}`}
        onClick={() => lab.setControlPanelOpen(true)}
        aria-expanded={open}
        aria-controls="control-desk-panel"
        aria-label={t('showControlPanel')}
        title={t('showControlPanel')}
        tabIndex={open ? -1 : 0}
      >
        <span aria-hidden="true">＋</span>
      </button>
    </>
  );
}
