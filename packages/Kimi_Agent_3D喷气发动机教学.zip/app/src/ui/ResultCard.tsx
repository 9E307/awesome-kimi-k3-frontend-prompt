// 结果卡：浏览器内生成 1080×1440 PNG 并下载
import { useEffect, useRef } from 'react';
import { useLab } from '../app/store';
import { useSimSnapshot } from './useSim';

const W = 1080;
const H = 1440;

function drawEngineSection(ctx: CanvasRenderingContext2D, x0: number, y0: number, w: number) {
  // 简化剖面：进气—压气机—燃烧室—涡轮—喷管
  const h = w * 0.18;
  ctx.save();
  ctx.translate(x0, y0);
  ctx.strokeStyle = '#8e979e';
  ctx.lineWidth = 3;
  // 机匣上轮廓
  ctx.beginPath();
  ctx.moveTo(0, -h * 0.95);
  ctx.lineTo(w * 0.28, -h * 0.8);
  ctx.lineTo(w * 0.42, -h * 0.62);
  ctx.lineTo(w * 0.58, -h * 0.8);
  ctx.lineTo(w * 0.66, -h * 0.62);
  ctx.lineTo(w * 0.78, -h * 0.6);
  ctx.lineTo(w, -h * 0.42);
  ctx.stroke();
  // 机匣下轮廓
  ctx.beginPath();
  ctx.moveTo(0, h * 0.95);
  ctx.lineTo(w * 0.28, h * 0.8);
  ctx.lineTo(w * 0.42, h * 0.62);
  ctx.lineTo(w * 0.58, h * 0.8);
  ctx.lineTo(w * 0.66, h * 0.62);
  ctx.lineTo(w * 0.78, h * 0.6);
  ctx.lineTo(w, h * 0.42);
  ctx.stroke();
  // 中心线
  ctx.strokeStyle = 'rgba(232,224,204,0.4)';
  ctx.lineWidth = 1.5;
  ctx.setLineDash([14, 10]);
  ctx.beginPath();
  ctx.moveTo(-w * 0.04, 0);
  ctx.lineTo(w * 1.04, 0);
  ctx.stroke();
  ctx.setLineDash([]);
  // 主轴
  ctx.strokeStyle = '#4c545b';
  ctx.lineWidth = 8;
  ctx.beginPath();
  ctx.moveTo(w * 0.2, 0);
  ctx.lineTo(w * 0.72, 0);
  ctx.stroke();
  // 压气机级
  ctx.strokeStyle = '#c3ccd2';
  ctx.lineWidth = 4;
  for (let i = 0; i < 6; i++) {
    const x = w * (0.24 + i * 0.032);
    const r = h * (0.62 - i * 0.03);
    ctx.beginPath();
    ctx.moveTo(x, -r);
    ctx.lineTo(x, r);
    ctx.stroke();
  }
  // 燃烧室衬套
  ctx.strokeStyle = '#b08d57';
  ctx.lineWidth = 4;
  ctx.strokeRect(w * 0.45, -h * 0.42, w * 0.13, h * 0.84);
  // 火焰
  ctx.fillStyle = '#f2c45f';
  for (let i = 0; i < 4; i++) {
    const fx = w * (0.47 + i * 0.028);
    ctx.beginPath();
    ctx.moveTo(fx, -h * 0.14);
    ctx.quadraticCurveTo(fx + w * 0.012, -h * 0.02, fx + w * 0.02, 0);
    ctx.quadraticCurveTo(fx + w * 0.012, h * 0.02, fx, h * 0.14);
    ctx.fill();
  }
  // 涡轮级
  ctx.strokeStyle = '#b08d57';
  ctx.lineWidth = 5;
  [0.64, 0.685].forEach((f) => {
    ctx.beginPath();
    ctx.moveTo(w * f, -h * 0.48);
    ctx.lineTo(w * f, h * 0.48);
    ctx.stroke();
  });
  // 标注
  ctx.fillStyle = '#9d978a';
  ctx.font = '22px Georgia, serif';
  ctx.textAlign = 'center';
  ctx.fillText('INTAKE', w * 0.08, h * 1.35);
  ctx.fillText('COMPRESSOR', w * 0.29, h * 1.35);
  ctx.fillText('COMBUSTOR', w * 0.53, h * 1.35);
  ctx.fillText('TURBINE', w * 0.7, h * 1.35);
  ctx.fillText('NOZZLE', w * 0.9, h * 1.35);
  ctx.restore();
}

export function generateResultCard(): HTMLCanvasElement {
  const lab = useLab.getState();
  const zh = lab.lang === 'zh';
  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d')!;

  // 背景
  ctx.fillStyle = '#05070a';
  ctx.fillRect(0, 0, W, H);
  ctx.strokeStyle = 'rgba(232,224,204,0.25)';
  ctx.lineWidth = 2;
  ctx.strokeRect(40, 40, W - 80, H - 80);

  // 标题
  ctx.fillStyle = '#e8e0cc';
  ctx.textAlign = 'center';
  ctx.font = 'bold 52px Georgia, "Songti SC", serif';
  ctx.fillText(zh ? 'KIMI 立体课本 · 学习结果卡' : 'KIMI Living Textbook · Result Card', W / 2, 130);
  ctx.font = '26px monospace';
  ctx.fillStyle = '#9d978a';
  ctx.fillText('THE THRUST ENGINE No. 01', W / 2, 176);

  // 分隔线
  ctx.strokeStyle = 'rgba(232,224,204,0.3)';
  ctx.beginPath();
  ctx.moveTo(120, 210);
  ctx.lineTo(W - 120, 210);
  ctx.stroke();

  // 发动机剖面
  drawEngineSection(ctx, 110, 370, W - 220);

  // 顿悟
  ctx.font = '34px Georgia, "Songti SC", serif';
  ctx.fillStyle = '#f2c45f';
  ctx.textAlign = 'center';
  const aha = zh
    ? '我终于看懂：涡轮负责养活压气机，'
    : 'Now I see it: the turbine feeds the compressor;';
  const aha2 = zh ? '喷管负责把气流变成推力。' : 'the nozzle turns flow into thrust.';
  ctx.fillText(aha, W / 2, 690);
  ctx.fillText(aha2, W / 2, 738);

  // 数据区
  const left = 140;
  let y = 820;
  ctx.textAlign = 'left';
  ctx.font = '30px Georgia, "Songti SC", serif';
  ctx.fillStyle = '#e8e0cc';
  ctx.fillText(zh ? '已完成章节' : 'Chapters completed', left, y);
  y += 46;
  ctx.font = '26px "Avenir Next", "PingFang SC", sans-serif';
  const chTitles = zh
    ? ['空气为什么要先被压缩？', '燃烧室为什么没有把火喷向前面？', '涡轮拿走了什么？', '真正的推力在哪里产生？', '跟着一团空气走完全程']
    : ['Why compress air first?', 'Why no fire forwards?', 'What does the turbine take?', 'Where is thrust made?', 'Follow one parcel of air'];
  chTitles.forEach((c, i) => {
    const done = lab.chaptersDone[i];
    ctx.fillStyle = done ? '#6fc7e8' : 'rgba(157,151,138,0.5)';
    ctx.fillText(`${done ? '✓' : '○'} 第 ${i + 1} 章 · ${c}`, left + 20, y);
    y += 40;
  });

  y += 30;
  ctx.font = '30px Georgia, "Songti SC", serif';
  ctx.fillStyle = '#e8e0cc';
  const layerNames: Record<string, string> = zh
    ? { velocity: '速度', pressure: '压力', temperature: '温度', composition: '气体组成' }
    : { velocity: 'Velocity', pressure: 'Pressure', temperature: 'Temperature', composition: 'Composition' };
  ctx.fillText(`${zh ? '当前可视化层' : 'Active flow layer'}：${layerNames[lab.flowLayer]}`, left, y);

  y += 66;
  ctx.fillText(zh ? '故障挑战结果' : 'Fault challenge results', left, y);
  y += 46;
  ctx.font = '26px "Avenir Next", "PingFang SC", sans-serif';
  const faultNames = zh
    ? { surge: '压气机喘振', flameout: '燃烧室熄火', nozzleBlock: '喷管受阻' }
    : { surge: 'Compressor surge', flameout: 'Combustor flameout', nozzleBlock: 'Blocked nozzle' };
  (Object.keys(faultNames) as (keyof typeof faultNames)[]).forEach((f) => {
    const r = lab.faultResults[f];
    ctx.fillStyle = r.done ? '#6fc7e8' : 'rgba(157,151,138,0.5)';
    const status = r.done
      ? zh ? '✓ 已诊断正确' : '✓ Diagnosed'
      : r.attempts > 0
        ? zh ? `○ ${r.attempts} 次尝试` : `○ ${r.attempts} attempt(s)`
        : zh ? '○ 未挑战' : '○ Not attempted';
    ctx.fillText(`${faultNames[f]} — ${status}`, left + 20, y);
    y += 40;
  });

  // 二维码占位（右下，避开左列文字）
  const qrX = W - 320;
  const qrY = 1130;
  ctx.strokeStyle = '#9d978a';
  ctx.lineWidth = 2;
  ctx.strokeRect(qrX, qrY, 140, 140);
  ctx.fillStyle = 'rgba(157,151,138,0.35)';
  for (let i = 0; i < 7; i++) {
    for (let j = 0; j < 7; j++) {
      if ((i * 7 + j * 3) % 3 === 0) ctx.fillRect(qrX + 10 + i * 17, qrY + 10 + j * 17, 11, 11);
    }
  }
  ctx.fillStyle = '#9d978a';
  ctx.font = '20px "Avenir Next", "PingFang SC", sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(zh ? '扫码回到实验台（占位）' : 'Scan to return (placeholder)', qrX + 70, qrY + 172);

  // 底部标识
  ctx.strokeStyle = 'rgba(232,224,204,0.3)';
  ctx.beginPath();
  ctx.moveTo(120, 1352);
  ctx.lineTo(W - 120, 1352);
  ctx.stroke();
  ctx.textAlign = 'left';
  ctx.fillStyle = '#e8e0cc';
  ctx.font = 'bold 34px Georgia, "Songti SC", serif';
  ctx.fillText('KIMI 立体课本', 140, 1410);
  ctx.font = '22px "Avenir Next", "PingFang SC", sans-serif';
  ctx.fillStyle = '#9d978a';
  ctx.fillText(zh ? '喷气发动机实验台 · 教学示意模型' : 'Turbojet Test Bench · Teaching model', 420, 1410);

  ctx.textAlign = 'center';
  ctx.fillStyle = 'rgba(157,151,138,0.6)';
  ctx.font = '19px monospace';
  ctx.fillText(zh ? '趋势可信，数值不用于设计' : 'Trends only — not for design', W - 250, 1430);

  return canvas;
}

export function ResultCard() {
  const lab = useLab();
  const t = lab.t;
  useSimSnapshot(); // 保持数据新鲜
  const previewRef = useRef<HTMLImageElement>(null);
  const open = lab.resultCardOpen;

  const generate = () => {
    const canvas = generateResultCard();
    if (previewRef.current) previewRef.current.src = canvas.toDataURL('image/png');
  };

  // 打开时自动生成预览
  useEffect(() => {
    if (!open) return;
    const id = requestAnimationFrame(() => generate());
    return () => cancelAnimationFrame(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  if (!open) return null;

  const download = () => {
    const canvas = generateResultCard();
    const a = document.createElement('a');
    a.href = canvas.toDataURL('image/png');
    a.download = lab.lang === 'zh' ? 'KIMI立体课本-学习结果卡.png' : 'kimi-living-textbook-result-card.png';
    a.click();
  };

  return (
    <div className="result-modal" role="dialog" aria-label={t('cardTitle')}>
      <div className="result-card-panel">
        <button className="close-btn" onClick={() => lab.setResultCardOpen(false)} aria-label={t('closePanel')}>
          ×
        </button>
        <h3>{t('cardTitle')}</h3>
        <div className="result-preview">
          <img ref={previewRef} alt={t('cardTitle')} onLoad={() => undefined} />
        </div>
        <div className="row">
          <button className="btn-ghost" onClick={generate}>
            {t('resultCard')}
          </button>
          <button className="btn-primary" onClick={download} aria-label={t('cardDownload')}>
            {t('cardDownload')}
          </button>
        </div>
      </div>
    </div>
  );
}
