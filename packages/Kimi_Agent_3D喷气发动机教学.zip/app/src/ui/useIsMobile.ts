// 响应式移动端判断（≤768px 竖屏，或手机横屏），与 CSS 媒体查询保持一致
import { useSyncExternalStore } from 'react';

const QUERIES = [
  '(max-width: 768px)',
  '(max-width: 940px) and (max-height: 500px) and (orientation: landscape)',
];

function subscribe(callback: () => void): () => void {
  const mqs = QUERIES.map((q) => window.matchMedia(q));
  mqs.forEach((mq) => mq.addEventListener('change', callback));
  return () => mqs.forEach((mq) => mq.removeEventListener('change', callback));
}

function getSnapshot(): boolean {
  return QUERIES.some((q) => window.matchMedia(q).matches);
}

export function useIsMobile(): boolean {
  return useSyncExternalStore(subscribe, getSnapshot, () => false);
}
