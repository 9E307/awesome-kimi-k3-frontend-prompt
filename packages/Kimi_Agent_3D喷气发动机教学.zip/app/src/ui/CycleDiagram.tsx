// 布雷顿循环图抽屉：T–s / P–V 切换，与 3D 双向高亮
import { useEffect, useMemo, useState } from 'react';
import { computeStations } from '../flow/stationModel';
import { computeCycle } from '../flow/braytonModel';
import type { CycleShape } from '../flow/braytonModel';
import { sim } from '../engine/engineState';
import { useLab } from '../app/store';

const SEG_PARTS: Record<number, string> = {
  0: 'compRotor3',
  1: 'combOuterLiner',
  2: 'turbineRotor1',
  3: 'nozzle',
};
const SEG_KEY = ['seg12', 'seg23', 'seg34', 'seg41'] as const;
const SEG_COLOR = ['#6fc7e8', '#f2c45f', '#f08a4b', '#9d978a'];

export function CycleDiagram() {
  const lab = useLab();
  const t = lab.t;
  const [shape, setShape] = useState<CycleShape | null>(null);
  const altitudeKm = useLab((s) => s.altitudeKm);

  useEffect(() => {
    if (!lab.cycleOpen) return;
    const update = () => setShape(computeCycle(computeStations(sim, altitudeKm), lab.cycleMode));
    update();
    const id = window.setInterval(update, 400);
    return () => window.clearInterval(id);
  }, [lab.cycleOpen, lab.cycleMode, altitudeKm]);

  const W = 300;
  const H = 220;
  const PAD = 34;

  const paths = useMemo(() => {
    if (!shape) return [];
    return shape.segments.map((seg) => {
      const pts = seg.pts.map(
        (p) => `${PAD + p.x * (W - PAD * 1.6)},${10 + p.y * (H - PAD - 10)}`,
      );
      return { id: seg.id, d: `M${pts.join(' L')}` };
    });
  }, [shape]);

  if (!lab.cycleOpen) return null;

  return (
    <aside className="cycle-drawer" role="complementary" aria-label={t('brayton')}>
      <div className="cycle-head">
        <h3>{t('brayton')}</h3>
        <div className="row">
          {/* 手机端抽屉关闭按钮（桌面端不显示） */}
          <button
            className="panel-hide-btn cycle-close-m"
            onClick={() => lab.setCycleOpen(false)}
            aria-label={t('collapsePanel')}
            title={t('collapsePanel')}
          >
            <span aria-hidden="true">×</span>
            <em>{t('collapsePanel')}</em>
          </button>
          <button className="btn-toggle" aria-pressed={lab.cycleMode === 'ts'} onClick={() => lab.setCycleMode('ts')}>
            {t('tsDiagram')}
          </button>
          <button className="btn-toggle" aria-pressed={lab.cycleMode === 'pv'} onClick={() => lab.setCycleMode('pv')}>
            {t('pvDiagram')}
          </button>
        </div>
      </div>

      <svg viewBox={`0 0 ${W} ${H}`} className="cycle-svg" role="img" aria-label={t('brayton')}>
        {/* 坐标轴 */}
        <line x1={PAD} y1={10} x2={PAD} y2={H - PAD} stroke="rgba(232,224,204,0.3)" />
        <line x1={PAD} y1={H - PAD} x2={W - 6} y2={H - PAD} stroke="rgba(232,224,204,0.3)" />
        <text x={W - 16} y={H - PAD + 16} className="axis-label">
          {lab.cycleMode === 'ts' ? 's' : 'V'}
        </text>
        <text x={PAD - 16} y={18} className="axis-label">
          {lab.cycleMode === 'ts' ? 'T' : 'P'}
        </text>

        {paths.map((p) => (
          <path
            key={p.id}
            d={p.d}
            fill="none"
            stroke={SEG_COLOR[p.id]}
            strokeWidth={lab.activeCycleSeg === p.id ? 5 : 2}
            strokeOpacity={lab.activeCycleSeg === null || lab.activeCycleSeg === p.id ? 1 : 0.3}
            className="cycle-seg"
            onClick={() => {
              const seg = lab.activeCycleSeg === p.id ? null : p.id;
              lab.setActiveCycleSeg(seg);
              lab.setHighlightedPart(seg === null ? null : SEG_PARTS[seg]);
            }}
          />
        ))}

        {shape?.points.map((pt) => (
          <g key={pt.label}>
            <circle
              cx={PAD + pt.x * (W - PAD * 1.6)}
              cy={10 + pt.y * (H - PAD - 10)}
              r={3.4}
              fill="#e8e0cc"
            />
            <text
              x={PAD + pt.x * (W - PAD * 1.6) + 7}
              y={10 + pt.y * (H - PAD - 10) - 5}
              className="point-label"
            >
              {pt.label}
            </text>
          </g>
        ))}
      </svg>

      <div className="cycle-legend">
        {SEG_KEY.map((k, i) => (
          <button
            key={k}
            className={`legend-item ${lab.activeCycleSeg === i ? 'active' : ''}`}
            onClick={() => {
              const seg = lab.activeCycleSeg === i ? null : i;
              lab.setActiveCycleSeg(seg);
              lab.setHighlightedPart(seg === null ? null : SEG_PARTS[seg]);
            }}
            aria-pressed={lab.activeCycleSeg === i}
          >
            <i style={{ background: SEG_COLOR[i] }} />
            {t(k)}
          </button>
        ))}
      </div>
      <p className="cycle-note">{t('openCycleNote')}</p>
    </aside>
  );
}
