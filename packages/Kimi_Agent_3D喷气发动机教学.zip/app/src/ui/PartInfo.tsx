// 部件检查面板：因果链、当前状态、高亮气流 / 跟随能量
import { useLab } from '../app/store';
import { PART_MAP, SYSTEM_NAMES } from '../engine/partMetadata';
import { useSimSnapshot } from './useSim';

export function PartInfo() {
  const lab = useLab();
  const t = lab.t;
  const snap = useSimSnapshot();
  const id = lab.selectedPartId;
  if (!id) return null;
  const meta = PART_MAP.get(id);
  if (!meta) return null;

  const running = snap.n1 > 0.02;
  const flameOn = snap.fuelFlow > 0.05;
  const lang = lab.lang;

  // 部件当前工作状态（定性）
  const stateText = (() => {
    switch (meta.system) {
      case 'compressor':
        return running
          ? lang === 'zh' ? `随主轴转动 ≈ ${Math.round(snap.n1 * 100)}%，正在对空气做功` : `Spinning ≈ ${Math.round(snap.n1 * 100)}%, doing work on the air`
          : lang === 'zh' ? '静止，等待启动' : 'At rest, waiting for start';
      case 'combustor':
        return flameOn
          ? lang === 'zh' ? '火焰稳定，持续加热气流' : 'Flame stable, heating the flow'
          : lang === 'zh' ? '无火焰，仅空气流通' : 'No flame, air passing only';
      case 'turbine':
        return flameOn
          ? lang === 'zh' ? '正在从热气中取功并输出扭矩' : 'Extracting work, delivering torque'
          : running
            ? lang === 'zh' ? '被气流带动空转' : 'Windmilling'
            : lang === 'zh' ? '静止' : 'At rest';
      case 'exhaust':
        return running
          ? lang === 'zh' ? `排气速度 ≈ ${snap.thrust > 0 ? '高速' : '低速'}，推力 ≈ ${snap.thrust.toFixed(2)}` : `Jet active, thrust ≈ ${snap.thrust.toFixed(2)}`
          : lang === 'zh' ? '无排气流动' : 'No exhaust flow';
      case 'shaft':
        return running
          ? lang === 'zh' ? `传递扭矩中，转速 ≈ ${Math.round(snap.n1 * 100)}%` : `Carrying torque at ≈ ${Math.round(snap.n1 * 100)}%`
          : lang === 'zh' ? '静止' : 'At rest';
      default:
        return lab.explodeCurrent > 0.08
          ? lang === 'zh' ? '已分解，便于检查' : 'Exploded for inspection'
          : lang === 'zh' ? '在位' : 'In place';
    }
  })();

  return (
    <aside className="part-info" role="dialog" aria-label={lang === 'zh' ? meta.zh : meta.en}>
      <button className="close-btn" onClick={() => lab.selectPart(null)} aria-label={t('closePanel')}>
        ×
      </button>
      <div className="part-system">{SYSTEM_NAMES[meta.system][lang]}</div>
      <h2>
        {lang === 'zh' ? meta.zh : meta.en}
        <small>{lang === 'zh' ? meta.en : meta.zh}</small>
      </h2>
      <dl>
        <dt>{t('partFunction')}</dt>
        <dd>{meta.fn[lang]}</dd>
        <dt>{t('partUpstream')}</dt>
        <dd>{meta.upstream[lang]}</dd>
        <dt>{t('partDownstream')}</dt>
        <dd>{meta.downstream[lang]}</dd>
        <dt>{t('partState')}</dt>
        <dd className="part-state-live">{stateText}</dd>
      </dl>
      <div className="row">
        <button
          className="btn-toggle wide"
          aria-pressed={lab.traceAir}
          onClick={() => lab.toggleTraceAir()}
        >
          {t('highlightFlow')}
        </button>
        <button
          className="btn-toggle wide"
          aria-pressed={lab.traceTorque}
          onClick={() => lab.toggleTraceTorque()}
        >
          {t('followEnergy')}
        </button>
      </div>
    </aside>
  );
}
