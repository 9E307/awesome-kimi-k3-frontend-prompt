// 手机端轻量提示：建议使用电脑端打开；仅 ≤768px（或手机横屏）渲染
import { useState } from 'react';
import { useLab } from '../app/store';
import { useIsMobile } from './useIsMobile';

const TIP_KEY = 'thrust-lab-mobile-tip-dismissed';

export function MobileTip() {
  const isMobile = useIsMobile();
  const t = useLab((s) => s.t);
  const [dismissed, setDismissed] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem(TIP_KEY) === '1';
    } catch {
      return false;
    }
  });

  // 桌面端不渲染，不占位；本次浏览关闭后不再显示
  if (!isMobile || dismissed) return null;

  return (
    <div className="mobile-tip" role="note">
      <span className="mobile-tip-text">{t('mobileTip')}</span>
      <button
        className="mobile-tip-close"
        onClick={() => {
          try {
            sessionStorage.setItem(TIP_KEY, '1');
          } catch {
            /* ignore */
          }
          setDismissed(true);
        }}
        aria-label={t('closeMobileTip')}
      >
        ×
      </button>
    </div>
  );
}
