// 故障诊断挑战：三个确定性教学题（概念诊断，不含维修指导）
import { useEffect, useState } from 'react';
import { useLab } from '../app/store';
import type { FaultId } from '../app/store';

type Region = 'compressor' | 'combustor' | 'turbine' | 'nozzle';

interface FaultDef {
  id: FaultId;
  titleKey: 'faultSurge' | 'faultFlameout' | 'faultNozzle';
  region: Region;
  causes: { id: string; zh: string; en: string; ok: boolean; whyZh: string; whyEn: string }[];
  symptomZh: string;
  symptomEn: string;
}

const FAULTS: FaultDef[] = [
  {
    id: 'surge',
    titleKey: 'faultSurge',
    region: 'compressor',
    symptomZh: '现象：前级气流不稳定、转速波动、出现短暂反向粒子与闷响。',
    symptomEn: 'Symptoms: unsteady front-stage flow, speed oscillation, brief reversed particles, muffled bangs.',
    causes: [
      {
        id: 'a', ok: true,
        zh: '压气机工作点进入不稳定区域，气流无法维持单向通过。',
        en: 'The compressor operating point entered the unstable region; flow can no longer stay one-way.',
        whyZh: '', whyEn: '',
      },
      {
        id: 'b', ok: false,
        zh: '涡轮从热气中取走了太多能量。',
        en: 'The turbine extracted too much energy from the gas.',
        whyZh: '涡轮取功过强会拖慢主轴，但不会造成前级反向流动——不稳定源于压气机工作点。',
        whyEn: 'Over-extraction would slow the spool, but cannot reverse front-stage flow — the instability lives in the compressor operating point.',
      },
      {
        id: 'c', ok: false,
        zh: '喷管喉部面积过大，排气速度不足。',
        en: 'The nozzle throat is too large, so exit velocity is too low.',
        whyZh: '喷管影响的是出口速度，与压气机前级倒流无关。',
        whyEn: 'The nozzle sets exit velocity; it cannot drive reversed flow in the front compressor stages.',
      },
    ],
  },
  {
    id: 'flameout',
    titleKey: 'faultFlameout',
    region: 'combustor',
    symptomZh: '现象：火焰与燃油中断，涡轮前温度下降，主轴转速衰减。',
    symptomEn: 'Symptoms: flame and fuel lost, turbine inlet temperature drops, spool decays.',
    causes: [
      {
        id: 'a', ok: true,
        zh: '涡轮失去能量来源，无法继续维持压气机功。',
        en: 'The turbine loses its energy source and can no longer sustain compressor work.',
        whyZh: '', whyEn: '',
      },
      {
        id: 'b', ok: false,
        zh: '压气机压比突然升高，把火焰“吹灭”了。',
        en: 'Compressor pressure ratio spiked and blew the flame out.',
        whyZh: '熄火后压气机失去驱动、压比只会下降；因果方向反了。',
        whyEn: 'After flameout the compressor loses drive and pressure ratio falls — the causality is reversed.',
      },
      {
        id: 'c', ok: false,
        zh: '进气唇口结冰堵住了进气道。',
        en: 'Ice on the intake lip blocked the duct.',
        whyZh: '本挑战没有设置结冰条件；直接现象是燃油与火焰同时消失。',
        whyEn: 'No icing is modelled here; the direct observation is fuel and flame vanishing together.',
      },
    ],
  },
  {
    id: 'nozzleBlock',
    titleKey: 'faultNozzle',
    region: 'nozzle',
    symptomZh: '现象：出口速度下降、背压改变、推力下降。',
    symptomEn: 'Symptoms: exit velocity falls, back pressure rises, thrust decays.',
    causes: [
      {
        id: 'a', ok: true,
        zh: '喷管无法把剩余能量转化为高速射流，动量增量减小。',
        en: 'The nozzle can no longer turn remaining energy into a fast jet, so momentum gain shrinks.',
        whyZh: '', whyEn: '',
      },
      {
        id: 'b', ok: false,
        zh: '燃烧室温度太高，把推力“烧掉”了。',
        en: 'The combustor runs too hot and burns the thrust away.',
        whyZh: '温度升高通常提高排气能量；本现象的关键是出口速度下降而非温度异常。',
        whyEn: 'Higher temperature usually adds exhaust energy; the key symptom here is falling exit velocity, not temperature.',
      },
      {
        id: 'c', ok: false,
        zh: '主轴扭矩不足，拖不动压气机。',
        en: 'Shaft torque is too low to drive the compressor.',
        whyZh: '主轴问题会影响转速与压比，但题目中转速稳定、只有出口速度下降。',
        whyEn: 'A shaft problem would show up in speed and pressure ratio; here speed is steady and only exit velocity falls.',
      },
    ],
  },
];

const REGION_KEYS: Record<Region, 'regCompressor' | 'regCombustor' | 'regTurbine' | 'regNozzle'> = {
  compressor: 'regCompressor',
  combustor: 'regCombustor',
  turbine: 'regTurbine',
  nozzle: 'regNozzle',
};

export function FaultChallenge() {
  const lab = useLab();
  const t = lab.t;
  const [region, setRegion] = useState<Region | null>(null);
  const [cause, setCause] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [solved, setSolved] = useState(false);

  const fault = FAULTS.find((f) => f.id === lab.activeFault) ?? null;

  useEffect(() => {
    setRegion(null);
    setCause(null);
    setFeedback(null);
    setSolved(false);
  }, [lab.activeFault, lab.faultOpen]);

  // 关闭面板时清除故障
  useEffect(() => {
    if (!lab.faultOpen) {
      setRegion(null);
      setCause(null);
      setFeedback(null);
      setSolved(false);
    }
  }, [lab.faultOpen]);

  if (!lab.faultOpen) return null;

  const selectFault = (id: FaultId) => {
    lab.setActiveFault(id);
    if (lab.phase === 'OFF' || lab.phase === 'SHUTDOWN') {
      lab.setExplode(0);
      lab.startEngine();
    }
  };

  const submit = () => {
    if (!fault || !region || !cause) return;
    const causeDef = fault.causes.find((c) => c.id === cause)!;
    if (region === fault.region && causeDef.ok) {
      setSolved(true);
      setFeedback(t('faultCorrect'));
      lab.markFaultResult(fault.id, true);
      // 自动恢复安全教学状态
      window.setTimeout(() => lab.setActiveFault(null), 900);
    } else {
      lab.markFaultResult(fault.id, false);
      const why = lab.lang === 'zh' ? causeDef.whyZh : causeDef.whyEn;
      setFeedback(
        region !== fault.region
          ? lab.lang === 'zh'
            ? '责任区域不对：直接异常发生在别处。'
            : 'Wrong region: the primary anomaly is elsewhere.'
          : why,
      );
    }
  };

  return (
    <div className="fault-panel" role="dialog" aria-label={t('faultChallenge')}>
      <button className="close-btn" onClick={() => lab.setFaultOpen(false)} aria-label={t('closePanel')}>
        ×
      </button>
      <h3>{t('faultChallenge')}</h3>
      <p className="fault-intro">{t('faultIntro')}</p>

      <div className="fault-list">
        {FAULTS.map((f) => (
          <button
            key={f.id}
            className={`fault-item ${lab.activeFault === f.id ? 'active' : ''} ${lab.faultResults[f.id].done ? 'done' : ''}`}
            onClick={() => selectFault(f.id)}
            aria-pressed={lab.activeFault === f.id}
          >
            {t(f.titleKey)}
            {lab.faultResults[f.id].done && <span className="done-tag">{t('faultDone')}</span>}
          </button>
        ))}
      </div>

      {fault && (
        <div className="fault-quiz">
          <p className="fault-symptom">{lab.lang === 'zh' ? fault.symptomZh : fault.symptomEn}</p>

          <h4>{t('faultQ1')}</h4>
          <div className="btn-grid four">
            {(Object.keys(REGION_KEYS) as Region[]).map((r) => (
              <button
                key={r}
                className="btn-toggle"
                aria-pressed={region === r}
                onClick={() => setRegion(r)}
              >
                {t(REGION_KEYS[r])}
              </button>
            ))}
          </div>

          <h4>{t('faultQ2')}</h4>
          <div className="cause-list">
            {fault.causes.map((c) => (
              <button
                key={c.id}
                className="cause-item"
                aria-pressed={cause === c.id}
                onClick={() => setCause(c.id)}
              >
                {lab.lang === 'zh' ? c.zh : c.en}
              </button>
            ))}
          </div>

          <button
            className="btn-primary"
            disabled={!region || !cause}
            onClick={submit}
            aria-label={t('faultCheck')}
          >
            {t('faultCheck')}
          </button>

          {feedback && (
            <p className={`fault-feedback ${solved ? 'ok' : 'bad'}`} aria-live="polite">
              {feedback}
            </p>
          )}
        </div>
      )}
    </div>
  );
}
