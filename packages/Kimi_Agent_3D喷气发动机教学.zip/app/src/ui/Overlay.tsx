// 顶部覆盖层：标题、铭牌、当前教学问题、语言切换
import { useLab } from '../app/store';
import { MobileTip } from './MobileTip';

const CHAPTER_TITLE_KEYS = ['ch1Title', 'ch2Title', 'ch3Title', 'ch4Title', 'ch5Title'] as const;
const CHAPTER_GOAL_KEYS = ['ch1Goal', 'ch2Goal', 'ch3Goal', 'ch4Goal', 'ch5Goal'] as const;

export function Overlay() {
  const t = useLab((s) => s.t);
  const lang = useLab((s) => s.lang);
  const setLang = useLab((s) => s.setLang);
  const chapter = useLab((s) => s.chapter);
  const chaptersDone = useLab((s) => s.chaptersDone);

  return (
    <header className="overlay-top">
      <div className="title-block">
        <div className="plaque-mini">{t('plaque')}</div>
        <h1>{t('appTitle')}</h1>
        <p className="subtitle">{t('subtitle')}</p>
        <div className="chapter-line">
          <span className="chapter-tag">
            {t('chapter', { n: chapter + 1 })}
            {chaptersDone[chapter] ? ' ✓' : ''}
          </span>
          <span className="chapter-title">{t(CHAPTER_TITLE_KEYS[chapter])}</span>
        </div>
        <p className="chapter-goal">{t(CHAPTER_GOAL_KEYS[chapter])}</p>
        {chapter === 4 && <p className="aha-final">{t('ahaFinal')}</p>}
        {chapter === 3 && <p className="formula">F ≈ ṁ(V<sub>e</sub> − V<sub>0</sub>)</p>}
        <MobileTip />
      </div>
      <button
        className="lang-toggle"
        onClick={() => setLang(lang === 'zh' ? 'en' : 'zh')}
        aria-label={lang === 'zh' ? 'Switch to English' : '切换为中文'}
      >
        {lang === 'zh' ? 'EN' : '中'}
      </button>
    </header>
  );
}
