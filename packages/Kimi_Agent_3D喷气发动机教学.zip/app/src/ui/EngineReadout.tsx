// 右侧实时站位读数面板
// 桌面端：六张站位卡纵列（保持现状）
// 手机端：收起态为单个按钮；展开态为横向站位标签条 + 当前选中站位详情
import { useEffect, useState } from 'react';
import { computeStations, STATION_META, STATION_ORDER, fmt } from '../flow/stationModel';
import type { StationData, StationId } from '../flow/stationModel';
import { stationToSegment } from '../flow/braytonModel';
import { sim } from '../engine/engineState';
import { useLab } from '../app/store';

export function EngineReadout() {
  const t = useLab((s) => s.t);
  const lang = useLab((s) => s.lang);
  const altitudeKm = useLab((s) => s.altitudeKm);
  const activeStation = useLab((s) => s.activeStation);
  const setActiveStation = useLab((s) => s.setActiveStation);
  const setActiveCycleSeg = useLab((s) => s.setActiveCycleSeg);
  const open = useLab((s) => s.isReadoutOpen);
  const setReadoutOpen = useLab((s) => s.setReadoutOpen);
  const [stations, setStations] = useState<StationData[]>(() => computeStations(sim, 0));

  useEffect(() => {
    const id = window.setInterval(() => {
      setStations(computeStations(sim, altitudeKm));
    }, 250);
    return () => window.clearInterval(id);
  }, [altitudeKm]);

  // 手机端详情站位：沿用当前选中站位；未选中时以 0 号进气作视觉默认（不写入 store，不清除任何联动）
  const detailId = (activeStation ?? 0) as StationId;
  const detail = stations.find((x) => x.id === detailId) ?? stations[0];
  const detailMeta = STATION_META[detailId];

  const pickStation = (sid: StationId, active: boolean) => {
    const next = active ? null : sid;
    setActiveStation(next);
    setActiveCycleSeg(next === null ? null : stationToSegment(sid));
  };

  return (
    <>
      <aside id="engine-readout-panel" className={`engine-readout ${open ? 'open' : 'closed'}`} aria-label={t('readoutTitle')}>
        {/* 手机端收起态按钮（桌面端不显示） */}
        <button
          className="readout-bar"
          onClick={() => setReadoutOpen(true)}
          aria-expanded={open}
          aria-controls="engine-readout-panel"
          tabIndex={open ? -1 : 0}
        >
          <span className="readout-bar-label">
            {t('stationData')} · {detailMeta.name[lang].replace(' · ', ' ')}
          </span>
          <span aria-hidden="true">⌄</span>
        </button>

        <div className="readout-head">
          <h2>
            <span className="txt-d">{t('readoutTitle')}</span>
            <span className="txt-m">{detailMeta.name[lang]}</span>
          </h2>
          <button
            className="panel-hide-btn"
            onClick={() => setReadoutOpen(false)}
            aria-expanded={open}
            aria-controls="engine-readout-panel"
            aria-label={t('hideReadout')}
            title={t('hideReadout')}
            tabIndex={open ? 0 : -1}
          >
            <span aria-hidden="true">⌃</span>
            <em className="txt-d">{t('hidePanel')}</em>
            <em className="txt-m">{t('collapsePanel')}</em>
          </button>
        </div>

        {/* 桌面端：六张站位卡纵列 */}
        <div className="readout-scroll">
          {STATION_ORDER.map((sid) => {
            const st = stations.find((x) => x.id === sid)!;
            const meta = STATION_META[sid];
            const active = activeStation === sid;
            return (
              <button
                key={sid}
                className={`station-card ${active ? 'active' : ''}`}
                onClick={() => pickStation(sid, active)}
                aria-pressed={active}
                aria-label={meta.name[lang]}
                tabIndex={open ? 0 : -1}
              >
                <div className="station-name">{meta.name[lang]}</div>
                <div className="station-values">
                  <span>
                    {t('pressureRatio')} <b>≈ {fmt(st.pRatio)}</b>
                  </span>
                  <span>
                    {t('tempNorm')} <b>≈ {fmt(st.tRatio)}</b>
                  </span>
                  <span>
                    {t('axialVel')} <b>≈ {fmt(st.velocity)}</b>
                  </span>
                </div>
                <div className="station-note">
                  {t('energyNote')}：{meta.note[lang]}
                </div>
              </button>
            );
          })}
        </div>

        {/* 手机端：横向站位标签条 + 当前站位详情（不同时展示六张完整卡） */}
        <div className="readout-mobile">
          <div className="station-tabs" role="group" aria-label={t('readoutTitle')}>
            {STATION_ORDER.map((sid) => {
              const meta = STATION_META[sid];
              const active = detailId === sid;
              return (
                <button
                  key={sid}
                  className={`station-tab ${active ? 'active' : ''}`}
                  onClick={() => pickStation(sid, activeStation === sid)}
                  aria-pressed={activeStation === sid}
                  aria-label={meta.name[lang]}
                  tabIndex={open ? 0 : -1}
                >
                  {meta.name[lang].replace(' · ', ' ')}
                </button>
              );
            })}
          </div>
          <div className="station-detail">
            <div className="station-name">{detailMeta.name[lang]}</div>
            <div className="station-values">
              <span>
                {t('pressureRatio')} <b>≈ {fmt(detail.pRatio)}</b>
              </span>
              <span>
                {t('tempNorm')} <b>≈ {fmt(detail.tRatio)}</b>
              </span>
              <span>
                {t('axialVel')} <b>≈ {fmt(detail.velocity)}</b>
              </span>
            </div>
            <div className="station-note">
              {t('energyNote')}：{detailMeta.note[lang]}
            </div>
          </div>
        </div>
      </aside>

      {/* 桌面端收起后的恢复入口（手机端由收起态按钮替代） */}
      <button
        className={`readout-rail ${open ? 'hidden' : ''}`}
        onClick={() => setReadoutOpen(true)}
        aria-expanded={open}
        aria-controls="engine-readout-panel"
        aria-label={t('showReadout')}
        title={t('showReadout')}
        tabIndex={open ? -1 : 0}
      >
        <span aria-hidden="true">＋</span>
        <em>{t('readoutTitle')}</em>
      </button>
    </>
  );
}
