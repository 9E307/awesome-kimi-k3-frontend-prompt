// 节流读取仿真数值（避免 60fps 触发 React 渲染）
import { useEffect, useState } from 'react';
import { sim } from '../engine/engineState';
import { densityRatio } from '../app/engineConfig';
import { useLab } from '../app/store';

export interface SimSnapshot {
  n1: number;
  thrust: number;
  fuelFlow: number;
  t3: number;
  egt: number;
  massFlow: number;
  density: number;
}

export function useSimSnapshot(intervalMs = 200): SimSnapshot {
  const altitudeKm = useLab((s) => s.altitudeKm);
  const [snap, setSnap] = useState<SimSnapshot>({
    n1: 0, thrust: 0, fuelFlow: 0, t3: 1, egt: 1, massFlow: 0, density: 1,
  });
  useEffect(() => {
    const id = window.setInterval(() => {
      setSnap({
        n1: sim.n1,
        thrust: sim.thrust,
        fuelFlow: sim.fuelFlow,
        t3: sim.t3,
        egt: sim.egt,
        massFlow: sim.massFlow,
        density: densityRatio(useLab.getState().altitudeKm),
      });
    }, intervalMs);
    return () => window.clearInterval(id);
  }, [intervalMs, altitudeKm]);
  return snap;
}
