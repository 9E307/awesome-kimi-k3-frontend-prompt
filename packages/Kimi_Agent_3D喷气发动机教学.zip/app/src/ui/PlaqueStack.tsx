// 博物馆铭牌式提示栈（含状态/故障 aria-live）
import { useLab } from '../app/store';

export function PlaqueStack() {
  const plaques = useLab((s) => s.plaques);
  const t = useLab((s) => s.t);
  const dismiss = useLab((s) => s.dismissPlaque);
  const phase = useLab((s) => s.phase);

  const phaseKey = {
    OFF: 'stOff', STARTING: 'stStarting', IGNITION: 'stIgnition', IDLE: 'stIdle',
    SPOOLING: 'stSpooling', RUNNING: 'stRunning', SHUTDOWN: 'stShutdown', SURGE: 'stSurge',
  } as const;

  return (
    <>
      <div className="plaque-stack" aria-live="polite">
        {plaques.map((p) => (
          <button
            key={p.id}
            className={`plaque plaque-${p.tone ?? 'info'}`}
            onClick={() => dismiss(p.id)}
            aria-label={p.key ? t(p.key) : p.text}
          >
            <span className="plaque-rivet" aria-hidden="true" />
            {p.key ? t(p.key) : p.text}
          </button>
        ))}
      </div>
      {/* 状态转换的无障碍播报 */}
      <div className="sr-only" aria-live="polite">
        {t(phaseKey[phase])}
      </div>
    </>
  );
}
