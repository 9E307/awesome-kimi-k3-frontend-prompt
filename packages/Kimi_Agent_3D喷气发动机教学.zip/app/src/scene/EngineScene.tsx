// 3D 场景入口：Canvas、WebGL 降级、页面隐藏降载
import { useEffect, useMemo, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import * as THREE from 'three';
import { Turbojet } from '../engine/Turbojet';
import { AirflowSystem } from '../flow/AirflowSystem';
import { Lighting } from './Lighting';
import { HangarEnvironment } from './HangarEnvironment';
import { CameraController } from './CameraController';
import { useLab } from '../app/store';

function detectWebGL(): boolean {
  try {
    const c = document.createElement('canvas');
    return !!(c.getContext('webgl2') || c.getContext('webgl'));
  } catch {
    return false;
  }
}

export function EngineScene() {
  const [webgl] = useState(detectWebGL);
  const t = useLab((s) => s.t);
  const selectPart = useLab((s) => s.selectPart);
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    const onVis = () => setHidden(document.hidden);
    document.addEventListener('visibilitychange', onVis);
    return () => document.removeEventListener('visibilitychange', onVis);
  }, []);

  const isMobile = useMemo(() => window.innerWidth <= 768, []);

  if (!webgl) {
    return (
      <div className="webgl-fallback" role="alert">
        <FallbackSvg />
        <p>{t('webglFail')}</p>
      </div>
    );
  }

  return (
    <Canvas
      className="engine-canvas"
      frameloop={hidden ? 'never' : 'always'}
      dpr={isMobile ? 1.5 : [1, 2]}
      camera={{ position: [0.6, 2.8, 17.4], fov: 38, near: 0.1, far: 80 }}
      gl={{
        antialias: true,
        toneMapping: THREE.ACESFilmicToneMapping,
        toneMappingExposure: 1.05,
        localClippingEnabled: true,
      }}
      shadows
      onPointerMissed={() => selectPart(null)}
      aria-label={t('appTitle')}
    >
      <color attach="background" args={['#05070a']} />
      <Lighting />
      <HangarEnvironment />
      <Turbojet />
      <AirflowSystem />
      <CameraController />
    </Canvas>
  );
}

// WebGL 不可用时的静态 SVG 剖面示意
function FallbackSvg() {
  return (
    <svg viewBox="0 0 900 300" width="100%" height="auto" aria-hidden="true">
      <rect width="900" height="300" fill="#05070a" />
      <g stroke="#8e979e" fill="none" strokeWidth="2">
        <path d="M40 90 L200 96 L200 204 L40 210" />
        <path d="M200 96 L430 120 L430 180 L200 204" />
        <rect x="430" y="110" width="120" height="80" stroke="#b08d57" />
        <path d="M550 118 L640 124 L640 176 L550 182" stroke="#b08d57" />
        <path d="M640 124 L780 138 L780 162 L640 176" stroke="#b08d57" />
        <line x1="30" y1="150" x2="870" y2="150" stroke="#9d978a" strokeDasharray="8 6" strokeWidth="1" />
      </g>
      <g fill="#6fc7e8" fontSize="13" fontFamily="monospace">
        <text x="80" y="80">进气 Intake</text>
        <text x="260" y="80">压气机 Compressor</text>
        <text x="450" y="100" fill="#f08a4b">燃烧室</text>
        <text x="565" y="110" fill="#f08a4b">涡轮</text>
        <text x="700" y="120" fill="#f08a4b">喷管</text>
      </g>
    </svg>
  );
}
