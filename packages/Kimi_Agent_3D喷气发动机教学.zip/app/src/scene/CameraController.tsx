// 相机控制：模式预设 + 平滑过渡 + 空气追踪跟随
import { useEffect, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import type { OrbitControls as OrbitControlsImpl } from 'three-stdlib';
import { useLab } from '../app/store';
import { traceState } from '../flow/AirflowSystem';

interface Preset { pos: THREE.Vector3; target: THREE.Vector3 }

const PRESETS: Record<string, Preset> = {
  global: {
    pos: new THREE.Vector3(0.6, 2.8, 17.4),
    target: new THREE.Vector3(0.3, 0.5, 0),
  },
  cutaway: {
    pos: new THREE.Vector3(0.4, 4.6, 9.2),
    target: new THREE.Vector3(0.2, 0.1, 0),
  },
  combustor: {
    pos: new THREE.Vector3(0.2, 1.7, 5.4),
    target: new THREE.Vector3(0.1, 0.05, 0),
  },
  nozzle: {
    pos: new THREE.Vector3(6.2, 1.5, 5.0),
    target: new THREE.Vector3(3.6, 0, 0),
  },
};

const goalPos = new THREE.Vector3();
const goalTgt = new THREE.Vector3();

export function CameraController() {
  const controlsRef = useRef<OrbitControlsImpl>(null);
  const camera = useThree((s) => s.camera);
  const size = useThree((s) => s.size);
  const cameraMode = useLab((s) => s.cameraMode);
  const animating = useRef(false);

  const narrow = size.width / size.height < 0.85;

  useEffect(() => {
    const p = PRESETS[cameraMode];
    if (!p) {
      animating.current = false;
      return; // free：保持当前机位
    }
    const dist = narrow ? 1.68 : 1;
    goalPos.copy(p.pos).multiplyScalar(dist);
    goalTgt.copy(p.target);
    // 仅手机端：画面上移，为顶部与底部浮层预留空间（桌面端构图不变）
    if (narrow) goalTgt.y -= 0.55;
    animating.current = true;
  }, [cameraMode, narrow]);

  useFrame((_, dt) => {
    const lab = useLab.getState();
    const controls = controlsRef.current;
    if (!controls) return;

    if (lab.traceAir && traceState.active) {
      // 慢动作跟随空气团
      goalTgt.set(traceState.x, Math.max(0, traceState.y * 0.4), 0);
      goalPos.set(traceState.x + 0.6, 1.15, narrow ? 5.2 : 3.4);
      const k = lab.reducedMotion ? 1 : 2.2;
      camera.position.x = THREE.MathUtils.damp(camera.position.x, goalPos.x, k, dt);
      camera.position.y = THREE.MathUtils.damp(camera.position.y, goalPos.y, k, dt);
      camera.position.z = THREE.MathUtils.damp(camera.position.z, goalPos.z, k, dt);
      controls.target.lerp(goalTgt, 1 - Math.exp(-k * dt));
      controls.update();
      animating.current = false;
      return;
    }

    // 爆炸时自动拉远，保持全部结构在镜头内
    if (!animating.current && lab.explodeCurrent > 0.2 && lab.cameraMode === 'global') {
      const p = PRESETS.global;
      const dist = (narrow ? 1.68 : 1) * (1 + lab.explodeCurrent * 0.55);
      goalPos.copy(p.pos).multiplyScalar(dist);
      goalTgt.copy(p.target);
      if (narrow) goalTgt.y -= 0.55;
      const k = lab.reducedMotion ? 100 : 2.5;
      camera.position.x = THREE.MathUtils.damp(camera.position.x, goalPos.x, k, dt);
      camera.position.y = THREE.MathUtils.damp(camera.position.y, goalPos.y, k, dt);
      camera.position.z = THREE.MathUtils.damp(camera.position.z, goalPos.z, k, dt);
      controls.target.lerp(goalTgt, 1 - Math.exp(-k * dt));
      controls.update();
      return;
    }

    if (animating.current) {
      const k = lab.reducedMotion ? 100 : 3.2;
      camera.position.x = THREE.MathUtils.damp(camera.position.x, goalPos.x, k, dt);
      camera.position.y = THREE.MathUtils.damp(camera.position.y, goalPos.y, k, dt);
      camera.position.z = THREE.MathUtils.damp(camera.position.z, goalPos.z, k, dt);
      controls.target.x = THREE.MathUtils.damp(controls.target.x, goalTgt.x, k, dt);
      controls.target.y = THREE.MathUtils.damp(controls.target.y, goalTgt.y, k, dt);
      controls.target.z = THREE.MathUtils.damp(controls.target.z, goalTgt.z, k, dt);
      controls.update();
      if (camera.position.distanceTo(goalPos) < 0.03) animating.current = false;
    }
  });

  // 手机端：单指旋转 + 双指缩放，并限制最近/最远距离（桌面端参数保持现状）
  return (
    <OrbitControls
      ref={controlsRef}
      enabled
      enableDamping
      dampingFactor={0.08}
      minDistance={narrow ? 6 : 2.2}
      maxDistance={narrow ? 34 : 26}
      maxPolarAngle={Math.PI * 0.72}
      target={[0.2, 0.35, 0]}
      makeDefault
    />
  );
}
