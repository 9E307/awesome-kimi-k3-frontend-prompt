// 黑暗教学机库：地面、接触阴影、远处结构线（全程序化，无 HDRI）
import { useMemo } from 'react';
import * as THREE from 'three';

function makeFloorTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = c.height = 512;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#07090c';
  ctx.fillRect(0, 0, 512, 512);
  ctx.strokeStyle = 'rgba(232,224,204,0.05)';
  ctx.lineWidth = 1;
  for (let i = 0; i <= 8; i++) {
    const p = i * 64;
    ctx.beginPath(); ctx.moveTo(p, 0); ctx.lineTo(p, 512); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, p); ctx.lineTo(512, p); ctx.stroke();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(6, 6);
  return tex;
}

function makeShadowTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const ctx = c.getContext('2d')!;
  const g = ctx.createRadialGradient(128, 128, 20, 128, 128, 126);
  g.addColorStop(0, 'rgba(0,0,0,0.55)');
  g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 256, 256);
  return new THREE.CanvasTexture(c);
}

export function HangarEnvironment() {
  const floorTex = useMemo(makeFloorTexture, []);
  const shadowTex = useMemo(makeShadowTexture, []);

  return (
    <group>
      {/* 地面 */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2.25, 0]} receiveShadow>
        <planeGeometry args={[48, 32]} />
        <meshStandardMaterial map={floorTex} color="#0a0d11" roughness={0.95} metalness={0.05} />
      </mesh>
      {/* 柔和接触阴影 */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2.24, 0]}>
        <planeGeometry args={[13, 4.5]} />
        <meshBasicMaterial map={shadowTex} transparent depthWrite={false} />
      </mesh>
      {/* 后墙与远处立柱轮廓 */}
      <mesh position={[0, 4, -11]}>
        <planeGeometry args={[48, 14]} />
        <meshStandardMaterial color="#06080b" roughness={1} />
      </mesh>
      {[-9, -3, 3, 9].map((x) => (
        <mesh key={x} position={[x, 2.5, -10.6]}>
          <boxGeometry args={[0.3, 11, 0.3]} />
          <meshStandardMaterial color="#0b0e13" roughness={0.9} />
        </mesh>
      ))}
      {/* 顶部横梁 */}
      <mesh position={[0, 8, -10.4]}>
        <boxGeometry args={[24, 0.35, 0.35]} />
        <meshStandardMaterial color="#0b0e13" roughness={0.9} />
      </mesh>
      {/* 展台铭牌条 */}
      <mesh position={[0, -2.05, 2.9]}>
        <boxGeometry args={[4.2, 0.34, 0.06]} />
        <meshStandardMaterial color="#10141a" roughness={0.7} metalness={0.3} />
      </mesh>
      <fog attach="fog" args={['#05070a', 16, 34]} />
    </group>
  );
}
