// 机库灯光：冷色进气侧 + 暖色涡轮侧 + 柔和顶光
export function Lighting() {
  return (
    <group>
      <ambientLight intensity={0.35} color="#8a94a8" />
      {/* 相机方向柔和补光 */}
      <directionalLight position={[0.5, 2, 14]} intensity={0.55} color="#c9d4dc" />
      {/* 冷色轮廓光（进气 / 压气机侧） */}
      <directionalLight position={[-7, 3.5, 4]} intensity={2.2} color="#7fb8dd" castShadow
        shadow-mapSize-width={1024} shadow-mapSize-height={1024}
        shadow-camera-left={-8} shadow-camera-right={8}
        shadow-camera-top={6} shadow-camera-bottom={-6} />
      <pointLight position={[-5, 1.2, -3]} intensity={12} color="#6fc7e8" distance={14} />
      <pointLight position={[-4, 2.5, 6]} intensity={9} color="#9fd4ef" distance={16} />
      {/* 暖色轮廓光（涡轮 / 喷管侧） */}
      <directionalLight position={[7, 2.5, 3.5]} intensity={1.5} color="#e8a56a" />
      <pointLight position={[3.5, 0.8, -2.5]} intensity={10} color="#f08a4b" distance={12} />
      {/* 顶部博物馆射灯 */}
      <spotLight position={[0, 7, 1.5]} angle={0.7} penumbra={0.6} intensity={60}
        color="#e8e0cc" distance={16} />
    </group>
  );
}
