// 确定性站位模型：所有读数、粒子、图表共用同一数据源
import { AXIS } from '../app/engineConfig';
import type { SimState } from '../engine/engineState';
import type { Lang } from '../app/i18n';

export type StationId = 0 | 1 | 2 | 3 | 4 | 8;

export interface StationData {
  id: StationId;
  x: number;
  pRatio: number; // p / p0
  tRatio: number; // T / T0
  velocity: number; // 归一化轴向速度
}

export interface StationMeta {
  name: { zh: string; en: string };
  note: { zh: string; en: string };
}

export const STATION_META: Record<StationId, StationMeta> = {
  0: {
    name: { zh: '0 · 进气', en: '0 · Intake' },
    note: { zh: '空气被吸入，获得少量动能', en: 'Air is drawn in, gaining a little kinetic energy' },
  },
  1: {
    name: { zh: '1 · 压气机进口', en: '1 · Compressor inlet' },
    note: { zh: '气流整流，等待轴功输入', en: 'Flow is conditioned, waiting for shaft work' },
  },
  2: {
    name: { zh: '2 · 压气机出口', en: '2 · Compressor exit' },
    note: { zh: '轴功变成压力与温度：总压、总温显著升高', en: 'Shaft work becomes pressure and heat' },
  },
  3: {
    name: { zh: '3 · 涡轮进口', en: '3 · Turbine inlet' },
    note: { zh: '燃烧加热：温度大幅升高，压力几乎不变', en: 'Heat added: temperature jumps, pressure nearly held' },
  },
  4: {
    name: { zh: '4 · 涡轮出口', en: '4 · Turbine exit' },
    note: { zh: '涡轮取功驱动压气机：温度压力下降', en: 'Turbine extracts work to drive the compressor' },
  },
  8: {
    name: { zh: '8 · 喷管出口', en: '8 · Nozzle exit' },
    note: { zh: '剩余能量变成高速射流：推力的真正来源', en: 'Remaining energy becomes a fast jet — the true source of thrust' },
  },
};

export const STATION_ORDER: StationId[] = [0, 1, 2, 3, 4, 8];

export function stationX(id: StationId): number {
  switch (id) {
    case 0: return AXIS.station.s0;
    case 1: return AXIS.station.s1;
    case 2: return AXIS.station.s2;
    case 3: return AXIS.station.s3;
    case 4: return AXIS.station.s4;
    case 8: return AXIS.station.s8;
  }
}

// 由仿真状态推导全部站位参数（纯函数、确定性）
export function computeStations(simState: SimState, _altKm: number): StationData[] {
  const n = simState.n1;
  const running = n > 0.01;
  const cpr = 1 + 7 * n * n;
  const t2 = Math.pow(cpr, 0.31);
  const p2 = cpr;
  const p3 = p2 * 0.96;
  const t3 = Math.max(simState.t3, running ? t2 * 0.99 : 1);
  const t4 = Math.max(1, t3 - (t2 - 1) * 1.03);
  const p4 = Math.max(1, p3 * Math.pow(t4 / Math.max(t3, 1.001), 4));

  const vIn = 0.25 * n;
  const v1 = 0.34 * n;
  const v2 = 0.3 * n;
  const v3 = 0.14 * n * (simState.flame > 0.5 ? 1.15 : 1);
  const v4 = 0.32 * n;
  const v8 = simState.exhaustVel;

  const g = (p: number, t: number, v: number) => ({
    pRatio: running ? p : 1,
    tRatio: running ? t : 1,
    velocity: running ? v : 0,
  });

  return [
    { id: 0, x: stationX(0), ...g(1, 1, vIn) },
    { id: 1, x: stationX(1), ...g(0.99, 1.0, v1) },
    { id: 2, x: stationX(2), ...g(p2, t2, v2) },
    { id: 3, x: stationX(3), ...g(p3, t3, v3) },
    { id: 4, x: stationX(4), ...g(p4, t4, v4) },
    { id: 8, x: stationX(8), ...g(1, Math.max(1, t4 * 0.82), v8) },
  ];
}

export function fmt(v: number, digits = 2): string {
  if (!isFinite(v) || isNaN(v)) return '—';
  return v.toFixed(digits);
}

export function stationName(id: StationId, lang: Lang): string {
  return STATION_META[id].name[lang];
}
