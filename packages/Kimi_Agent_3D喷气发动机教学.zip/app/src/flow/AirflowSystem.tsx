// 气流粒子系统：池化 InstancedMesh，四种可视化层 + 空气追踪
import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import {
  PARTICLE_COUNT, SPAWN_X, KILL_X, annulusInto, sampleFlowInto, updateFlowTables, detRand,
} from './particlePool';
import { computeStations } from './stationModel';
import { sim } from '../engine/engineState';
import { useLab } from '../app/store';
import { appEvents } from '../app/events';
import { stationToSegment } from './braytonModel';

// 追踪状态（供相机读取）
export const traceState = {
  active: false,
  x: 0,
  y: 0,
  z: 0,
  lastStation: -1,
};

const tmpM = new THREE.Matrix4();
const tmpQ = new THREE.Quaternion();
const tmpP = new THREE.Vector3();
const tmpS = new THREE.Vector3();
const tmpC = new THREE.Color();
const tmpAnn = { inner: 0, outer: 0 };
const tmpFlow = { p: 1, t: 1, v: 0 };

const COLD = new THREE.Color('#3f7fa8');
const AIR = new THREE.Color('#6fc7e8');
const GOLD = new THREE.Color('#e8d9a0');
const HOT = new THREE.Color('#f08a4b');
const PRODUCT = new THREE.Color('#d9a06a');
const FUEL = new THREE.Color('#f2c45f');
const TRACE = new THREE.Color('#ffe9a8');

export function AirflowSystem() {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  // 粒子状态（预分配）
  const px = useMemo(() => new Float32Array(PARTICLE_COUNT), []);
  const prf = useMemo(() => new Float32Array(PARTICLE_COUNT), []);
  const pa = useMemo(() => new Float32Array(PARTICLE_COUNT), []);
  const traced = useMemo(() => new Uint8Array(PARTICLE_COUNT), []);

  const { geometry, material } = useMemo(() => {
    const g = new THREE.SphereGeometry(0.028, 6, 4);
    const m = new THREE.MeshBasicMaterial({
      transparent: true, opacity: 0.85,
      blending: THREE.AdditiveBlending, depthWrite: false,
    });
    return { geometry: g, material: m };
  }, []);

  // 初始化粒子
  useMemo(() => {
    for (let i = 0; i < PARTICLE_COUNT; i++) {
      px[i] = SPAWN_X + detRand(i, 1) * (KILL_X - SPAWN_X);
      prf[i] = 0.15 + detRand(i, 2) * 0.7;
      pa[i] = detRand(i, 3) * Math.PI * 2;
      traced[i] = i % 41 === 0 ? 1 : 0;
    }
  }, [px, prf, pa, traced]);

  useFrame((_, rawDt) => {
    const mesh = meshRef.current;
    if (!mesh) return;
    const lab = useLab.getState();

    const flowOn = sim.n1 > 0.02 && lab.explodeCurrent <= 0.08;
    mesh.visible = flowOn;
    if (!flowOn) {
      traceState.active = false;
      return;
    }

    const dt = Math.min(rawDt, 0.05) * (lab.slowMotion ? 0.22 : 1);
    updateFlowTables(computeStations(sim, lab.altitudeKm));

    const layer = lab.flowLayer;
    const tracing = lab.traceAir;
    let traceXSum = 0, traceYSum = 0, traceZSum = 0, traceN = 0;

    const speedBase = 2.1;
    const surge = sim.surge;

    for (let i = 0; i < PARTICLE_COUNT; i++) {
      sampleFlowInto(px[i], tmpFlow);
      let v = tmpFlow.v * speedBase;
      // 尾流自由膨胀减速
      if (px[i] > 4.4) v *= 0.92;
      // 喘振：前级反向粒子
      if (surge > 0.25 && px[i] > -2.9 && px[i] < -1.0 && i % 3 === 0) {
        v = -Math.abs(v) * (1.2 + detRand(i, 9)) * surge;
      }
      px[i] += v * dt;
      if (px[i] > KILL_X || px[i] < SPAWN_X - 2.5) {
        px[i] = SPAWN_X - detRand(i, 4) * 1.2;
        prf[i] = 0.15 + detRand(i, 2) * 0.7;
        pa[i] = detRand(i, 3 + ((sim.time * 10) | 0)) * Math.PI * 2;
      }

      annulusInto(px[i], tmpAnn);
      const r = tmpAnn.inner + (tmpAnn.outer - tmpAnn.inner) * prf[i];
      const y = Math.sin(pa[i]) * r;
      const z = Math.cos(pa[i]) * r;

      // 尾流轻微扩散
      const spread = px[i] > 4.4 ? 1 + (px[i] - 4.4) * 0.12 : 1;
      tmpP.set(px[i], y * spread, z * spread);

      // 拖尾：速度层拉伸
      const stretch = layer === 'velocity' ? 1 + tmpFlow.v * 7 : 1.6;
      tmpS.set(stretch, 1, 1);
      tmpQ.identity();
      tmpM.compose(tmpP, tmpQ, tmpS);
      mesh.setMatrixAt(i, tmpM);

      // 着色
      const isTraced = traced[i] === 1 && tracing;
      if (isTraced) {
        tmpC.copy(TRACE);
        traceXSum += tmpP.x; traceYSum += tmpP.y; traceZSum += tmpP.z; traceN++;
      } else if (layer === 'velocity') {
        tmpC.copy(AIR).multiplyScalar(0.45 + tmpFlow.v * 1.4);
      } else if (layer === 'pressure') {
        const f = THREE.MathUtils.clamp((tmpFlow.p - 1) / 7, 0, 1);
        tmpC.copy(COLD).lerp(GOLD, Math.pow(f, 0.65));
      } else if (layer === 'temperature') {
        const f = THREE.MathUtils.clamp((tmpFlow.t - 1) / 1.9, 0, 1);
        tmpC.copy(COLD).lerp(HOT, Math.pow(f, 0.8));
      } else {
        // 组成层
        if (px[i] < -0.42) tmpC.copy(AIR);
        else if (px[i] < -0.3) tmpC.copy(i % 4 === 0 ? FUEL : AIR);
        else if (px[i] < 0.55 && sim.flame > 0.4) tmpC.copy(i % 5 === 0 ? FUEL : HOT);
        else tmpC.copy(sim.flame > 0.3 ? PRODUCT : AIR);
      }
      mesh.setColorAt(i, tmpC);
    }

    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;

    // 追踪质心与站位事件
    if (tracing && traceN > 0) {
      const cx = traceXSum / traceN;
      traceState.active = true;
      traceState.x = cx;
      traceState.y = traceYSum / traceN;
      traceState.z = traceZSum / traceN;
      const stationIdx = crossedStation(cx);
      if (stationIdx !== traceState.lastStation && stationIdx >= 0) {
        traceState.lastStation = stationIdx;
        const sid = [0, 1, 2, 3, 4, 8][stationIdx];
        lab.setActiveStation(sid);
        lab.setActiveCycleSeg(stationToSegment(sid));
        appEvents.emit('traceStation', { station: sid });
      }
      if (cx > 4.2) {
        lab.stopTraceAir();
        lab.setActiveStation(null);
        traceState.active = false;
        traceState.lastStation = -1;
      }
    } else {
      traceState.active = false;
      if (!tracing) traceState.lastStation = -1;
    }
  });

  return (
    <instancedMesh
      ref={meshRef}
      args={[geometry, material, PARTICLE_COUNT]}
      frustumCulled={false}
    />
  );
}

function crossedStation(x: number): number {
  const xs = [-4.6, -3.0, -0.7, 0.75, 1.85, 4.1];
  for (let i = xs.length - 1; i >= 0; i--) {
    if (x >= xs[i]) return i;
  }
  return -1;
}
