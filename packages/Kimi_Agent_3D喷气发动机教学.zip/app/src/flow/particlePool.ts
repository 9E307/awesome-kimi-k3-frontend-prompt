// 池化气流粒子：预分配、零每帧分配
import type { StationData } from './stationModel';

export const PARTICLE_COUNT = 850;
export const SPAWN_X = -6.6;
export const KILL_X = 7.4;

// 流道环形截面（inner/outer 半径）分段线性
const PATH_KEYS: { x: number; inner: number; outer: number }[] = [
  { x: -7.0, inner: 0.02, outer: 1.3 },
  { x: -4.7, inner: 0.02, outer: 1.14 },
  { x: -3.0, inner: 0.05, outer: 1.0 },
  { x: -2.85, inner: 0.34, outer: 1.0 },
  { x: -0.85, inner: 0.52, outer: 0.74 },
  { x: -0.55, inner: 0.66, outer: 0.97 },
  { x: 0.62, inner: 0.66, outer: 0.87 },
  { x: 0.9, inner: 0.53, outer: 0.86 },
  { x: 1.9, inner: 0.5, outer: 0.82 },
  { x: 2.6, inner: 0.32, outer: 0.72 },
  { x: 3.4, inner: 0.1, outer: 0.6 },
  { x: 4.1, inner: 0.02, outer: 0.53 },
  { x: 5.5, inner: 0.02, outer: 0.8 },
  { x: 7.4, inner: 0.02, outer: 1.15 },
];

export interface Annulus { inner: number; outer: number }

export function annulusInto(x: number, out: Annulus): Annulus {
  if (x <= PATH_KEYS[0].x) {
    out.inner = PATH_KEYS[0].inner;
    out.outer = PATH_KEYS[0].outer;
    return out;
  }
  for (let i = 0; i < PATH_KEYS.length - 1; i++) {
    const a = PATH_KEYS[i];
    const b = PATH_KEYS[i + 1];
    if (x >= a.x && x <= b.x) {
      const f = (x - a.x) / (b.x - a.x);
      out.inner = a.inner + (b.inner - a.inner) * f;
      out.outer = a.outer + (b.outer - a.outer) * f;
      return out;
    }
  }
  const last = PATH_KEYS[PATH_KEYS.length - 1];
  out.inner = last.inner;
  out.outer = last.outer;
  return out;
}

// 站位参数查找表（每帧填充一次，复用）
export interface FlowTables {
  xs: Float64Array;
  p: Float64Array;
  t: Float64Array;
  v: Float64Array;
}

export const flowTables: FlowTables = {
  xs: new Float64Array(6),
  p: new Float64Array(6),
  t: new Float64Array(6),
  v: new Float64Array(6),
};

export function updateFlowTables(stations: StationData[]) {
  for (let i = 0; i < 6 && i < stations.length; i++) {
    flowTables.xs[i] = stations[i].x;
    flowTables.p[i] = stations[i].pRatio;
    flowTables.t[i] = stations[i].tRatio;
    flowTables.v[i] = stations[i].velocity;
  }
}

export interface FlowSample { p: number; t: number; v: number }

export function sampleFlowInto(x: number, out: FlowSample): FlowSample {
  const { xs, p, t, v } = flowTables;
  if (x <= xs[0]) {
    out.p = p[0]; out.t = t[0]; out.v = v[0];
    return out;
  }
  for (let i = 0; i < xs.length - 1; i++) {
    if (x >= xs[i] && x <= xs[i + 1]) {
      const f = (x - xs[i]) / (xs[i + 1] - xs[i]);
      out.p = p[i] + (p[i + 1] - p[i]) * f;
      out.t = t[i] + (t[i + 1] - t[i]) * f;
      out.v = v[i] + (v[i + 1] - v[i]) * f;
      return out;
    }
  }
  const n = xs.length - 1;
  out.p = p[n]; out.t = t[n]; out.v = v[n];
  return out;
}

// 确定性伪随机（按索引）
export function detRand(i: number, salt: number): number {
  const s = Math.sin(i * 127.1 + salt * 311.7) * 43758.5453;
  return s - Math.floor(s);
}
