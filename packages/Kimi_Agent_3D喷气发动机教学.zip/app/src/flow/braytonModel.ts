// 布雷顿循环模型：从站位数据推导 T–s 与 P–V 图坐标
import type { StationData } from './stationModel';

export interface CyclePoint {
  label: string; // '1'..'4'
  x: number; // 归一化 0..1（SVG 盒内）
  y: number; // 归一化 0..1（已翻转，0 在顶部）
}

export interface CycleShape {
  points: CyclePoint[];
  // 每段的采样折线（4 段，每段含首尾）
  segments: { id: number; pts: { x: number; y: number }[] }[];
}

const CP = 1.0;
const R = 0.286;

function entropy(t: number, p: number): number {
  return CP * Math.log(Math.max(t, 1e-3)) - R * Math.log(Math.max(p, 1e-3));
}

function buildPoints(st: StationData[], mode: 'ts' | 'pv') {
  const s1 = st[1];
  const s2 = st[2];
  const s3 = st[3];
  const s4 = st[4];
  const T = [s1.tRatio, s2.tRatio, s3.tRatio, s4.tRatio];
  const P = [s1.pRatio, s2.pRatio, s3.pRatio, s4.pRatio];
  // 段采样：压缩/膨胀接近等熵微弯，加热/放热沿对数曲线
  const segPts: { x: number; y: number }[][] = [];
  for (let seg = 0; seg < 4; seg++) {
    const a = seg;
    const b = (seg + 1) % 4;
    const pts: { x: number; y: number }[] = [];
    const N = 24;
    for (let k = 0; k <= N; k++) {
      const f = k / N;
      let x: number, y: number;
      if (mode === 'ts') {
        const t = T[a] + (T[b] - T[a]) * f;
        const p = P[a] + (P[b] - P[a]) * f;
        x = entropy(t, p);
        y = t;
      } else {
        const t = T[a] + (T[b] - T[a]) * f;
        const p = P[a] + (P[b] - P[a]) * f;
        x = t / Math.max(p, 1e-3);
        y = p;
      }
      pts.push({ x, y });
    }
    segPts.push(pts);
  }

  // 归一化到 0..1
  const allX = segPts.flat().map((p) => p.x);
  const allY = segPts.flat().map((p) => p.y);
  const minX = Math.min(...allX);
  const maxX = Math.max(...allX);
  const minY = Math.min(...allY);
  const maxY = Math.max(...allY);
  const nx = (x: number) => (maxX - minX < 1e-6 ? 0.5 : (x - minX) / (maxX - minX));
  const ny = (y: number) => (maxY - minY < 1e-6 ? 0.5 : (y - minY) / (maxY - minY));

  const norm = segPts.map((pts) => pts.map((p) => ({ x: nx(p.x), y: 1 - ny(p.y) })));
  const points: CyclePoint[] = [0, 1, 2, 3].map((i) => ({
    label: String(i + 1),
    x: norm[i][0].x,
    y: norm[i][0].y,
  }));
  return { points, segments: norm.map((pts, id) => ({ id, pts })) };
}

export function computeCycle(st: StationData[], mode: 'ts' | 'pv'): CycleShape {
  return buildPoints(st, mode);
}

// 站位 → 循环段索引：站1→段0(压缩)，站2→段0/1，站3→段2，站4→段3
export function stationToSegment(id: number): number | null {
  switch (id) {
    case 1: return 0;
    case 2: return 0;
    case 3: return 1;
    case 4: return 2;
    case 8: return 3;
    default: return null;
  }
}
