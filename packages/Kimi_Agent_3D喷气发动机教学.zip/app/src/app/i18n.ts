// 中英双语文案
export type Lang = 'zh' | 'en';
export const LANG_KEY = 'thrust-lab-lang';

const dict = {
  appTitle: { zh: 'KIMI 立体课本 · 喷气发动机实验台', en: 'KIMI Living Textbook · Turbojet Test Bench' },
  plaque: { zh: 'THE THRUST ENGINE No. 01', en: 'THE THRUST ENGINE No. 01' },
  subtitle: { zh: '拆开一台发动机，跟着一团空气走完全程。', en: 'Take an engine apart. Follow one parcel of air all the way through.' },
  disclaimer: {
    zh: '教学示意模型：趋势与因果关系可信，数值不用于发动机设计或安全计算。',
    en: 'Teaching model: trends and causality are trustworthy; values are not for engine design or safety calculations.',
  },

  // 控制台分组
  grpEngine: { zh: '发动机', en: 'ENGINE' },
  grpEnv: { zh: '环境', en: 'ENVIRONMENT' },
  grpModel: { zh: '模型', en: 'MODEL' },
  grpFlow: { zh: '气流', en: 'AIRFLOW' },
  grpView: { zh: '视角', en: 'CAMERA' },
  grpLearn: { zh: '学习', en: 'LEARN' },

  startEngine: { zh: '启动', en: 'Start' },
  shutdown: { zh: '关机', en: 'Shutdown' },
  throttle: { zh: '油门', en: 'Throttle' },
  state: { zh: '当前状态', en: 'State' },
  spoolSpeed: { zh: '教学转速', en: 'Spool speed' },
  thrust: { zh: '近似推力', en: 'Thrust (approx.)' },
  altitude: { zh: '高度', en: 'Altitude' },
  density: { zh: '环境密度', en: 'Air density' },
  resetSeaLevel: { zh: '恢复标准海平面', en: 'Reset to sea level' },

  explode: { zh: '爆炸 / 组装', en: 'Explode / Assemble' },
  explodeSlider: { zh: '爆炸程度', en: 'Explosion' },
  cutaway: { zh: '剖切', en: 'Cutaway' },
  casingOpacity: { zh: '机匣透明度', en: 'Casing opacity' },

  layerVelocity: { zh: '速度', en: 'Velocity' },
  layerPressure: { zh: '压力', en: 'Pressure' },
  layerTemp: { zh: '温度', en: 'Temperature' },
  layerComposition: { zh: '气体组成', en: 'Composition' },
  followAir: { zh: '跟随空气', en: 'Follow air' },
  followTorque: { zh: '跟随扭矩', en: 'Follow torque' },

  camGlobal: { zh: '全局', en: 'Global' },
  camCutaway: { zh: '剖切', en: 'Cutaway' },
  camCombustor: { zh: '燃烧室', en: 'Combustor' },
  camNozzle: { zh: '喷管', en: 'Nozzle' },
  camFree: { zh: '自由检查', en: 'Free inspect' },
  sound: { zh: '声音', en: 'Sound' },

  prevChapter: { zh: '上一章', en: 'Prev chapter' },
  nextChapter: { zh: '下一章', en: 'Next chapter' },
  brayton: { zh: '布雷顿循环图', en: 'Brayton cycle' },
  faultChallenge: { zh: '故障挑战', en: 'Fault challenge' },
  resultCard: { zh: '结果卡', en: 'Result card' },
  kimiCta: { zh: '让 Kimi 把我的机械图做成 3D 教具', en: 'Let Kimi turn my drawings into a 3D teaching aid' },

  // 状态机
  stOff: { zh: '停机', en: 'OFF' },
  stStarting: { zh: '启动中', en: 'STARTING' },
  stIgnition: { zh: '点火', en: 'IGNITION' },
  stIdle: { zh: '慢车', en: 'IDLE' },
  stSpooling: { zh: '转速调节中', en: 'SPOOLING' },
  stRunning: { zh: '稳定运行', en: 'RUNNING' },
  stShutdown: { zh: '关机惰转', en: 'SHUTDOWN' },
  stSurge: { zh: '喘振演示', en: 'SURGE DEMO' },

  // 提示
  hintNeedAssemble: { zh: '请先组装发动机再启动。', en: 'Assemble the engine before starting.' },
  hintNoIgnition: { zh: '压气机尚未建立稳定气流，暂不能点火。', en: 'Compressor airflow not established — ignition not possible yet.' },
  hintNeedStart: { zh: '发动机尚未启动，油门暂时无效。', en: 'Engine not started — throttle has no effect yet.' },
  hintThrottleInop: { zh: '爆炸拆解状态下油门与启动被锁定。', en: 'Throttle and start are locked while exploded.' },
  hintTraceAir: { zh: '慢动作跟随一团空气穿过发动机。', en: 'Slow motion: following one parcel of air.' },
  hintTraceTorque: { zh: '涡轮扭矩正沿主轴返回压气机。', en: 'Turbine torque travelling back to the compressor along the shaft.' },
  hintSurge: { zh: '警告：压气机工作点进入不稳定区域。', en: 'Warning: compressor operating point entered the unstable region.' },
  hintFlameout: { zh: '燃烧室熄火：涡轮失去能量来源。', en: 'Flameout: the turbine loses its energy source.' },
  hintNozzleBlock: { zh: '喷管受阻：出口速度下降，推力衰减。', en: 'Blocked nozzle: exit velocity and thrust decay.' },

  // 站位
  station0: { zh: '0 · 进气', en: '0 · Intake' },
  station1: { zh: '1 · 压气机进口', en: '1 · Compressor inlet' },
  station2: { zh: '2 · 压气机出口', en: '2 · Compressor exit' },
  station3: { zh: '3 · 涡轮进口', en: '3 · Turbine inlet' },
  station4: { zh: '4 · 涡轮出口', en: '4 · Turbine exit' },
  station8: { zh: '8 · 喷管出口', en: '8 · Nozzle exit' },
  pressureRatio: { zh: '压比', en: 'Pressure ratio' },
  tempNorm: { zh: '归一化温度', en: 'Temp. (norm.)' },
  axialVel: { zh: '轴向速度', en: 'Axial velocity' },
  energyNote: { zh: '能量变化', en: 'Energy change' },

  // 布雷顿
  tsDiagram: { zh: 'T–s 图', en: 'T–s diagram' },
  pvDiagram: { zh: 'P–V 图', en: 'P–V diagram' },
  seg12: { zh: '1 → 2 压缩', en: '1 → 2 Compression' },
  seg23: { zh: '2 → 3 加热', en: '2 → 3 Heat addition' },
  seg34: { zh: '3 → 4 涡轮膨胀', en: '3 → 4 Turbine expansion' },
  seg41: { zh: '4 → 1 放热（开式循环教学闭合）', en: '4 → 1 Heat rejection (teaching closure of an open cycle)' },
  openCycleNote: {
    zh: '真实涡轮喷气发动机是开式系统：空气只经过一次。闭合曲线是理想化热力学教学表达。',
    en: 'A real turbojet is an open system — air passes through once. The closed loop is an idealized thermodynamic teaching device.',
  },

  // 章节
  chapter: { zh: '第 {n} 章', en: 'Chapter {n}' },
  ch1Title: { zh: '空气为什么要先被压缩？', en: 'Why must air be compressed first?' },
  ch2Title: { zh: '燃烧室为什么没有把火喷向前面？', en: 'Why doesn’t the combustor blow fire forwards?' },
  ch3Title: { zh: '涡轮拿走了什么？', en: 'What does the turbine take?' },
  ch4Title: { zh: '真正的推力在哪里产生？', en: 'Where is thrust really made?' },
  ch5Title: { zh: '跟着一团空气走完全程', en: 'Follow one parcel of air end to end' },
  ch1Goal: { zh: '启动发动机，跟踪空气经过多级压气机时的压力变化。', en: 'Start the engine and watch pressure rise stage by stage.' },
  ch2Goal: { zh: '剖开燃烧室，观察已建立的轴向气流、衬套与掺混孔。', en: 'Cut the combustor open: axial flow, liners and dilution holes.' },
  ch3Goal: { zh: '观察热气能量变成转动，并沿主轴回到压气机。', en: 'Watch heat become rotation, travelling back along the shaft.' },
  ch4Goal: { zh: '对比喷管前后的流速：F ≈ ṁ(Ve − V0)。', en: 'Compare velocities across the nozzle: F ≈ ṁ(Ve − V0).' },
  ch5Goal: { zh: '约 6 秒慢动作，镜头、站位与布雷顿图同步跟随。', en: '~6 s of slow motion with camera, stations and cycle in sync.' },
  ahaFinal: {
    zh: '燃烧释放能量，涡轮维持压缩，喷管把剩余能量变成高速射流。',
    en: 'Combustion releases energy, the turbine sustains compression, and the nozzle turns what is left into a high-speed jet.',
  },
  ahaCore: {
    zh: '我终于看懂：涡轮负责养活压气机，喷管负责把气流变成推力。',
    en: 'Now I see it: the turbine feeds the compressor; the nozzle turns flow into thrust.',
  },

  // 部件面板
  partSystem: { zh: '系统', en: 'System' },
  partFunction: { zh: '物理作用', en: 'Physical role' },
  partUpstream: { zh: '上游来源', en: 'Driven by' },
  partDownstream: { zh: '下游驱动对象', en: 'Drives' },
  partState: { zh: '当前工作状态', en: 'Current state' },
  highlightFlow: { zh: '高亮气流', en: 'Highlight flow' },
  followEnergy: { zh: '跟随能量', en: 'Follow energy' },
  closePanel: { zh: '关闭部件面板', en: 'Close part panel' },

  // 故障挑战
  faultIntro: { zh: '观察现象，选出责任区域与因果解释。', en: 'Observe the symptoms, then pick the responsible region and the causal story.' },
  faultSurge: { zh: '压气机喘振', en: 'Compressor surge' },
  faultFlameout: { zh: '燃烧室熄火', en: 'Combustor flameout' },
  faultNozzle: { zh: '喷管受阻', en: 'Blocked nozzle' },
  faultQ1: { zh: '责任区域', en: 'Responsible region' },
  faultQ2: { zh: '因果解释', en: 'Causal explanation' },
  faultCheck: { zh: '提交判断', en: 'Submit diagnosis' },
  faultCorrect: { zh: '判断正确。', en: 'Correct diagnosis.' },
  faultRetry: { zh: '再试一次', en: 'Try again' },
  faultDone: { zh: '已完成', en: 'Completed' },
  regCompressor: { zh: '压气机', en: 'Compressor' },
  regCombustor: { zh: '燃烧室', en: 'Combustor' },
  regNozzle: { zh: '喷管', en: 'Nozzle' },
  regTurbine: { zh: '涡轮', en: 'Turbine' },

  // 结果卡
  cardTitle: { zh: 'KIMI 立体课本 · 学习结果卡', en: 'KIMI Living Textbook · Result Card' },
  cardChapters: { zh: '已完成章节', en: 'Chapters completed' },
  cardLayer: { zh: '当前可视化层', en: 'Active flow layer' },
  cardFaults: { zh: '故障挑战结果', en: 'Fault challenge results' },
  cardDownload: { zh: '生成并下载结果卡', en: 'Generate & download card' },
  cardQrHint: { zh: '扫码回到实验台（占位）', en: 'Scan to return (placeholder)' },

  webglFail: {
    zh: '当前浏览器无法启动喷气发动机实验台，请开启硬件加速或使用支持 WebGL 的现代浏览器。',
    en: 'This browser cannot start the turbojet bench. Enable hardware acceleration or use a modern WebGL-capable browser.',
  },
  assembledFirst: { zh: '已自动组装发动机。', en: 'Engine assembled automatically.' },

  // 面板隐藏 / 显示
  panelTitle: { zh: '控制面板', en: 'CONTROL PANEL' },
  readoutTitle: { zh: '站位信息', en: 'STATIONS' },
  hidePanel: { zh: '隐藏', en: 'Hide' },
  showPanel: { zh: '显示', en: 'Show' },
  hideControlPanel: { zh: '隐藏控制面板', en: 'Hide control panel' },
  showControlPanel: { zh: '显示控制面板', en: 'Show control panel' },
  hideReadout: { zh: '隐藏站位信息', en: 'Hide station info' },
  showReadout: { zh: '显示站位信息', en: 'Show station info' },

  // 手机端专用
  panelTitleMobile: { zh: '实验控制台', en: 'CONTROL BENCH' },
  collapsePanel: { zh: '收起', en: 'Collapse' },
  openPanelBar: { zh: '打开实验控制台', en: 'Open control bench' },
  stationData: { zh: '站位数据', en: 'Stations' },
  disclaimerShort: {
    zh: '教学示意模型，数值不用于工程设计或安全计算。',
    en: 'Teaching model — values not for engineering design or safety calculations.',
  },
  mobileTip: {
    zh: '建议使用电脑端打开，获得更完整的 3D 交互体验。',
    en: 'Open on a desktop for the full 3D interactive experience.',
  },
  closeMobileTip: { zh: '关闭电脑端体验提示', en: 'Dismiss desktop experience tip' },
} as const;

export type I18nKey = keyof typeof dict;

export function translate(lang: Lang, key: I18nKey, vars?: Record<string, string | number>): string {
  let s: string = dict[key][lang];
  if (vars) {
    for (const [k, v] of Object.entries(vars)) s = s.replace(`{${k}}`, String(v));
  }
  return s;
}

export function detectInitialLang(): Lang {
  try {
    const saved = localStorage.getItem(LANG_KEY);
    if (saved === 'zh' || saved === 'en') return saved;
  } catch {
    /* ignore */
  }
  return 'zh';
}
