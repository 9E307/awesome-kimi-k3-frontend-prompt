// 全局教学配置：站位、几何、颜色、教学常数
// 发动机轴向为 X 轴：进气口在 -X（左），喷管在 +X（右）。

export const AXIS = {
  intakeX: -5.2,
  station: {
    s0: -4.6, // 进气
    s1: -3.0, // 压气机进口
    s2: -0.7, // 压气机出口
    s3: 0.75, // 涡轮进口（燃烧室出口）
    s4: 1.85, // 涡轮出口
    s8: 4.1, // 喷管出口
  },
  nozzleEndX: 4.4,
} as const;

export const COMPRESSOR = {
  stages: 6,
  xStart: -2.85,
  xEnd: -0.85,
  hubRadiusFront: 0.34,
  hubRadiusRear: 0.52,
  tipRadiusFront: 1.02,
  tipRadiusRear: 0.72,
  rotorBlades: 26,
  statorBlades: 30,
} as const;

export const COMBUSTOR = {
  xStart: -0.62,
  xEnd: 0.62,
  outerRadius: 0.98,
  innerRadius: 0.55,
  linerOuter: 0.86,
  linerInner: 0.66,
  fuelNozzles: 10,
} as const;

export const TURBINE = {
  stages: 2,
  xStart: 0.9,
  xEnd: 1.75,
  hubRadius: 0.52,
  tipRadius: 0.86,
  bladesPerStage: 34,
  guideVanes: 30,
} as const;

export const NOZZLE = {
  xStart: 2.0,
  xEnd: 4.1,
  radiusIn: 0.82,
  radiusThroat: 0.52,
  radiusOut: 0.56,
} as const;

export const SHAFT = {
  radius: 0.13,
  xStart: -3.1,
  xEnd: 1.9,
} as const;

// 教学转速（归一化）
export const SPEED = {
  starterMax: 0.18, // 启动机带到的转速
  idle: 0.55, // 慢车转速
  max: 1.0,
  lightOffMin: 0.15, // 允许点火的最低转速
} as const;

export const COLORS = {
  void: '#05070a',
  bone: '#e8e0cc',
  boneDim: '#9d978a',
  titanium: '#8e979e',
  nickel: '#b08d57',
  air: '#6fc7e8',
  hot: '#f08a4b',
  flame: '#f2c45f',
  danger: '#d45f49',
} as const;

export const ALTITUDE_MAX_KM = 12;

// 标准大气密度比（简化指数模型），用于定性趋势
export function densityRatio(altKm: number): number {
  return Math.exp(-altKm / 8.4);
}

export const FLOW_PATH_LENGTH = AXIS.station.s8 - AXIS.station.s0;

export const DISCLAIMER_ZH =
  '教学示意模型：趋势与因果关系可信，数值不用于发动机设计或安全计算。';
export const DISCLAIMER_EN =
  'Teaching model: trends and causality are trustworthy; values are not for engine design or safety calculations.';

export const KIMI_DEEP_LINK =
  'https://www.kimi.com/?q=' +
  encodeURIComponent('请把我的机械工程图纸做成一个可交互的 3D 教具网站');
