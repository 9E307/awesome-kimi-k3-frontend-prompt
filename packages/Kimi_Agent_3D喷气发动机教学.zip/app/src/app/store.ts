import { create } from 'zustand';
import { translate, detectInitialLang, LANG_KEY } from './i18n';
import type { Lang, I18nKey } from './i18n';
import { appEvents } from './events';
import { SPEED } from './engineConfig';

export type EnginePhase =
  | 'OFF'
  | 'STARTING'
  | 'IGNITION'
  | 'IDLE'
  | 'SPOOLING'
  | 'RUNNING'
  | 'SHUTDOWN'
  | 'SURGE';

export type FlowLayer = 'velocity' | 'pressure' | 'temperature' | 'composition';
export type CameraMode = 'global' | 'cutaway' | 'combustor' | 'nozzle' | 'free';
export type FaultId = 'surge' | 'flameout' | 'nozzleBlock';
export type CycleMode = 'ts' | 'pv';

export interface Plaque {
  id: number;
  key?: I18nKey;
  text?: string;
  tone?: 'info' | 'warn' | 'danger';
}

export interface FaultResult {
  done: boolean;
  attempts: number;
}

let plaqueSeq = 1;

// 面板展开/收起状态的持久化键
const DESK_OPEN_KEY = 'thrust-lab-desk-open';
const READOUT_OPEN_KEY = 'thrust-lab-readout-open';

function loadBool(key: string, fallback: boolean): boolean {
  try {
    const v = localStorage.getItem(key);
    if (v === '0') return false;
    if (v === '1') return true;
  } catch {
    /* ignore */
  }
  return fallback;
}

function saveBool(key: string, v: boolean): void {
  try {
    localStorage.setItem(key, v ? '1' : '0');
  } catch {
    /* ignore */
  }
}

// 运行时移动端判断：与 CSS 媒体查询保持一致（竖屏 ≤768px，或触屏手机横屏）
export function isMobileViewport(): boolean {
  if (typeof window === 'undefined' || !window.matchMedia) return false;
  return (
    window.matchMedia('(max-width: 768px)').matches ||
    window.matchMedia('(max-width: 940px) and (max-height: 500px) and (orientation: landscape)').matches
  );
}

interface LabState {
  lang: Lang;
  phase: EnginePhase;
  prevPhase: EnginePhase | null;
  throttleTarget: number; // 0..1
  throttleCurrent: number;
  altitudeKm: number;
  cameraMode: CameraMode;
  flowLayer: FlowLayer;
  explodeTarget: number; // 0..1
  explodeCurrent: number;
  explodedLocked: boolean;
  cutaway: boolean;
  casingOpacity: number; // 0.15..1
  selectedPartId: string | null;
  highlightedPartId: string | null;
  activeStation: number | null; // 0,1,2,3,4,8
  activeCycleSeg: number | null; // 0..3
  traceAir: boolean;
  traceTorque: boolean;
  slowMotion: boolean;
  soundOn: boolean;
  cycleOpen: boolean;
  cycleMode: CycleMode;
  faultOpen: boolean;
  activeFault: FaultId | null;
  faultResults: Record<FaultId, FaultResult>;
  resultCardOpen: boolean;
  isControlPanelOpen: boolean;
  isReadoutOpen: boolean;
  plaques: Plaque[];
  chapter: number; // 0..4
  chaptersDone: boolean[];
  reducedMotion: boolean;
  // actions
  t: (key: I18nKey, vars?: Record<string, string | number>) => string;
  setLang: (l: Lang) => void;
  startEngine: () => void;
  shutdownEngine: () => void;
  setPhase: (p: EnginePhase) => void;
  setThrottle: (v: number) => void;
  setThrottleCurrent: (v: number) => void;
  setAltitude: (km: number) => void;
  resetAltitude: () => void;
  setCameraMode: (m: CameraMode) => void;
  setFlowLayer: (l: FlowLayer) => void;
  setExplode: (v: number) => void;
  setExplodeCurrent: (v: number) => void;
  assemble: () => void;
  setCutaway: (b: boolean) => void;
  setCasingOpacity: (v: number) => void;
  selectPart: (id: string | null) => void;
  setHighlightedPart: (id: string | null) => void;
  setActiveStation: (s: number | null) => void;
  setActiveCycleSeg: (s: number | null) => void;
  toggleTraceAir: () => void;
  stopTraceAir: () => void;
  toggleTraceTorque: () => void;
  setSlowMotion: (b: boolean) => void;
  toggleSound: () => void;
  setCycleOpen: (b: boolean) => void;
  setCycleMode: (m: CycleMode) => void;
  setFaultOpen: (b: boolean) => void;
  setActiveFault: (f: FaultId | null) => void;
  markFaultResult: (f: FaultId, ok: boolean) => void;
  setResultCardOpen: (b: boolean) => void;
  setControlPanelOpen: (b: boolean) => void;
  setReadoutOpen: (b: boolean) => void;
  pushPlaque: (p: Omit<Plaque, 'id'>) => void;
  dismissPlaque: (id: number) => void;
  setChapter: (n: number) => void;
  nextChapter: () => void;
  prevChapter: () => void;
  setReducedMotion: (b: boolean) => void;
}

export const useLab = create<LabState>((set, get) => ({
  lang: detectInitialLang(),
  phase: 'OFF',
  prevPhase: null,
  throttleTarget: 0,
  throttleCurrent: 0,
  altitudeKm: 0,
  cameraMode: 'global',
  flowLayer: 'velocity',
  explodeTarget: 0,
  explodeCurrent: 0,
  explodedLocked: false,
  cutaway: false,
  casingOpacity: 1,
  selectedPartId: null,
  highlightedPartId: null,
  activeStation: null,
  activeCycleSeg: null,
  traceAir: false,
  traceTorque: false,
  slowMotion: false,
  soundOn: true,
  cycleOpen: false,
  cycleMode: 'ts',
  faultOpen: false,
  activeFault: null,
  faultResults: {
    surge: { done: false, attempts: 0 },
    flameout: { done: false, attempts: 0 },
    nozzleBlock: { done: false, attempts: 0 },
  },
  resultCardOpen: false,
  // 桌面端默认展开（保持现状），手机端默认都收起；用户操作后按 localStorage 恢复
  isControlPanelOpen: loadBool(DESK_OPEN_KEY, !isMobileViewport()),
  isReadoutOpen: loadBool(READOUT_OPEN_KEY, !isMobileViewport()),
  plaques: [],
  chapter: 0,
  chaptersDone: [false, false, false, false, false],
  reducedMotion:
    typeof window !== 'undefined' &&
    window.matchMedia?.('(prefers-reduced-motion: reduce)').matches,

  t: (key, vars) => translate(get().lang, key, vars),

  setLang: (l) => {
    try {
      localStorage.setItem(LANG_KEY, l);
    } catch {
      /* ignore */
    }
    set({ lang: l });
    document.documentElement.lang = l === 'zh' ? 'zh-CN' : 'en';
  },

  startEngine: () => {
    const s = get();
    if (s.explodeTarget > 0.08) {
      s.pushPlaque({ key: 'hintNeedAssemble', tone: 'warn' });
      return;
    }
    if (s.phase !== 'OFF') return;
    set({ phase: 'STARTING' });
    appEvents.emit('starterEngaged');
    appEvents.emit('stateChanged', { message: 'STARTING' });
  },

  shutdownEngine: () => {
    const s = get();
    if (s.phase === 'OFF' || s.phase === 'SHUTDOWN') return;
    set({ phase: 'SHUTDOWN', throttleTarget: 0 });
    appEvents.emit('shutdownStarted');
    appEvents.emit('stateChanged', { message: 'SHUTDOWN' });
  },

  setPhase: (p) => {
    const prev = get().phase;
    if (prev === p) return;
    set({ prevPhase: prev, phase: p });
    appEvents.emit('stateChanged', { message: p });
    if (p === 'IDLE' && prev !== 'IDLE') appEvents.emit('idleReached');
    if (p === 'OFF') appEvents.emit('engineStopped');
  },

  setThrottle: (v) => {
    const s = get();
    const clamped = Math.min(1, Math.max(0, v));
    if (s.explodeTarget > 0.08) {
      s.pushPlaque({ key: 'hintThrottleInop', tone: 'warn' });
      return;
    }
    const runningLike = ['IDLE', 'SPOOLING', 'RUNNING', 'SURGE'].includes(s.phase);
    if (!runningLike && clamped > 0) {
      s.pushPlaque({ key: 'hintNeedStart', tone: 'info' });
      return;
    }
    set({ throttleTarget: clamped });
    appEvents.emit('throttleChanged', { value: clamped });
  },
  setThrottleCurrent: (v) => set({ throttleCurrent: v }),

  setAltitude: (km) => set({ altitudeKm: Math.min(12, Math.max(0, km)) }),
  resetAltitude: () => set({ altitudeKm: 0 }),

  setCameraMode: (m) => {
    set({ cameraMode: m });
    if (m === 'cutaway') get().setCutaway(true);
  },
  setFlowLayer: (l) => set({ flowLayer: l }),

  setExplode: (v) => {
    const s = get();
    const clamped = Math.min(1, Math.max(0, v));
    set({ explodeTarget: clamped });
    if (clamped > 0.08 && s.phase !== 'OFF' && s.phase !== 'SHUTDOWN') {
      // 爆炸时冻结：先断油停机
      s.shutdownEngine();
    }
    if (clamped > 0.08 && !s.explodedLocked) {
      set({ explodedLocked: true });
      s.pushPlaque({ key: 'hintNeedAssemble', tone: 'info' });
    }
    if (clamped <= 0.02 && s.explodedLocked) set({ explodedLocked: false });
  },
  setExplodeCurrent: (v) => set({ explodeCurrent: v }),
  assemble: () => {
    set({ explodeTarget: 0, explodedLocked: false });
  },

  setCutaway: (b) => {
    const s = get();
    if (b && (s.explodeTarget > 0.02 || s.explodeCurrent > 0.02)) {
      // 剖切前先自动组装
      s.assemble();
      s.pushPlaque({ key: 'assembledFirst', tone: 'info' });
    }
    set({ cutaway: b });
  },
  setCasingOpacity: (v) => set({ casingOpacity: Math.min(1, Math.max(0.12, v)) }),

  selectPart: (id) => {
    set({ selectedPartId: id });
    if (id) appEvents.emit('partSelected', { partId: id });
  },
  setHighlightedPart: (id) => set({ highlightedPartId: id }),
  setActiveStation: (st) => set({ activeStation: st }),
  setActiveCycleSeg: (seg) => set({ activeCycleSeg: seg }),

  toggleTraceAir: () => {
    const s = get();
    if (s.traceAir) {
      set({ traceAir: false, slowMotion: false });
      appEvents.emit('traceCompleted');
    } else {
      if (s.phase === 'OFF' || s.phase === 'STARTING') {
        s.pushPlaque({ key: 'hintNeedStart', tone: 'info' });
        return;
      }
      set({ traceAir: true, slowMotion: true, traceTorque: false });
      s.pushPlaque({ key: 'hintTraceAir', tone: 'info' });
      appEvents.emit('traceStarted');
    }
  },
  stopTraceAir: () => {
    if (get().traceAir) {
      set({ traceAir: false, slowMotion: false });
      appEvents.emit('traceCompleted');
    }
  },
  toggleTraceTorque: () => {
    const s = get();
    if (!s.traceTorque && (s.phase === 'OFF' || s.phase === 'STARTING')) {
      s.pushPlaque({ key: 'hintNeedStart', tone: 'info' });
      return;
    }
    set({ traceTorque: !s.traceTorque });
    if (!s.traceTorque) s.pushPlaque({ key: 'hintTraceTorque', tone: 'info' });
  },
  setSlowMotion: (b) => set({ slowMotion: b }),

  toggleSound: () => set({ soundOn: !get().soundOn }),
  setCycleOpen: (b) => set({ cycleOpen: b }),
  setCycleMode: (m) => set({ cycleMode: m }),

  setFaultOpen: (b) => {
    set({ faultOpen: b });
    if (!b && get().activeFault) set({ activeFault: null });
  },
  setActiveFault: (f) => {
    set({ activeFault: f });
    if (f) appEvents.emit('faultSelected', { partId: f });
  },
  markFaultResult: (f, ok) => {
    const r = get().faultResults;
    set({
      faultResults: {
        ...r,
        [f]: { done: r[f].done || ok, attempts: r[f].attempts + 1 },
      },
    });
    if (ok) appEvents.emit('faultResolved', { partId: f });
  },

  setResultCardOpen: (b) => set({ resultCardOpen: b }),

  setControlPanelOpen: (b) => {
    saveBool(DESK_OPEN_KEY, b);
    // 仅手机端：打开控制面板时自动收起站位卡（互斥）；桌面端不启用
    if (b && isMobileViewport()) {
      saveBool(READOUT_OPEN_KEY, false);
      set({ isControlPanelOpen: true, isReadoutOpen: false });
    } else {
      set({ isControlPanelOpen: b });
    }
  },

  setReadoutOpen: (b) => {
    saveBool(READOUT_OPEN_KEY, b);
    // 仅手机端：打开站位卡时自动收起控制面板（互斥）；桌面端不启用
    if (b && isMobileViewport()) {
      saveBool(DESK_OPEN_KEY, false);
      set({ isReadoutOpen: true, isControlPanelOpen: false });
    } else {
      set({ isReadoutOpen: b });
    }
  },

  pushPlaque: (p) => {
    const id = plaqueSeq++;
    set((s) => ({ plaques: [...s.plaques.slice(-2), { ...p, id }] }));
    window.setTimeout(() => get().dismissPlaque(id), 4200);
  },
  dismissPlaque: (id) =>
    set((s) => ({ plaques: s.plaques.filter((p) => p.id !== id) })),

  setChapter: (n) => {
    const c = Math.min(4, Math.max(0, n));
    set({ chapter: c });
  },
  nextChapter: () => {
    const s = get();
    const done = [...s.chaptersDone];
    done[s.chapter] = true;
    set({ chaptersDone: done, chapter: Math.min(4, s.chapter + 1) });
  },
  prevChapter: () => set({ chapter: Math.max(0, get().chapter - 1) }),
  setReducedMotion: (b) => set({ reducedMotion: b }),
}));

// 调试与自动化测试钩子
if (typeof window !== 'undefined') {
  (window as unknown as { __lab: typeof useLab }).__lab = useLab;
}

export { SPEED };
