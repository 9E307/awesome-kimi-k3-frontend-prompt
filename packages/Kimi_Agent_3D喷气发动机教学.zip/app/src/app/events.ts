// 统一事件系统（轻量类型化发射器）
export type AppEvent =
  | 'starterEngaged'
  | 'spoolStarted'
  | 'ignition'
  | 'idleReached'
  | 'throttleChanged'
  | 'compressorStage'
  | 'combustion'
  | 'turbineExtraction'
  | 'nozzleAcceleration'
  | 'shutdownStarted'
  | 'engineStopped'
  | 'surgeWarning'
  | 'traceStarted'
  | 'traceStation'
  | 'traceCompleted'
  | 'faultSelected'
  | 'faultResolved'
  | 'partSelected'
  | 'stateChanged';

export interface EventPayload {
  station?: number;
  partId?: string;
  value?: number;
  message?: string;
}

type Handler = (p: EventPayload) => void;

class Emitter {
  private map = new Map<AppEvent, Set<Handler>>();
  on(e: AppEvent, h: Handler): () => void {
    if (!this.map.has(e)) this.map.set(e, new Set());
    this.map.get(e)!.add(h);
    return () => this.map.get(e)?.delete(h);
  }
  emit(e: AppEvent, p: EventPayload = {}) {
    this.map.get(e)?.forEach((h) => {
      try {
        h(p);
      } catch (err) {
        console.error(`[event ${e}]`, err);
      }
    });
  }
}

export const appEvents = new Emitter();
