// 应用装配：3D 场景 + 全部 UI 覆盖层 + 章节联动
import { useEffect } from 'react';
import { EngineScene } from '../scene/EngineScene';
import { Overlay } from '../ui/Overlay';
import { ControlDesk } from '../ui/ControlDesk';
import { EngineReadout } from '../ui/EngineReadout';
import { PartInfo } from '../ui/PartInfo';
import { CycleDiagram } from '../ui/CycleDiagram';
import { FaultChallenge } from '../ui/FaultChallenge';
import { ResultCard } from '../ui/ResultCard';
import { PlaqueStack } from '../ui/PlaqueStack';
import { useLab } from './store';
import '../styles/index.css';

export default function App() {
  const chapter = useLab((s) => s.chapter);
  const t = useLab((s) => s.t);
  const lang = useLab((s) => s.lang);

  useEffect(() => {
    document.documentElement.lang = lang === 'zh' ? 'zh-CN' : 'en';
  }, [lang]);

  // 章节教学预设
  useEffect(() => {
    const lab = useLab.getState();
    switch (chapter) {
      case 0:
        lab.setCameraMode('global');
        lab.setFlowLayer('pressure');
        break;
      case 1:
        lab.setCutaway(true);
        lab.setCameraMode('combustor');
        lab.setHighlightedPart('primaryHoles');
        break;
      case 2:
        lab.setCutaway(false);
        lab.setHighlightedPart('mainShaft');
        lab.setCameraMode('global');
        break;
      case 3:
        lab.setHighlightedPart('nozzle');
        lab.setCameraMode('nozzle');
        lab.setFlowLayer('velocity');
        break;
      case 4: {
        lab.setHighlightedPart(null);
        lab.setCameraMode('global');
        const running = ['IDLE', 'SPOOLING', 'RUNNING'].includes(lab.phase);
        if (running && !lab.traceAir) lab.toggleTraceAir();
        else if (!running) lab.pushPlaque({ key: 'hintNeedStart', tone: 'info' });
        break;
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chapter]);

  return (
    <div className="app-shell">
      <EngineScene />
      <Overlay />
      <EngineReadout />
      <ControlDesk />
      <PartInfo />
      <CycleDiagram />
      <FaultChallenge />
      <ResultCard />
      <PlaqueStack />
      <footer className="disclaimer">
        <span className="disc-full">{t('disclaimer')}</span>
        <span className="disc-short">{t('disclaimerShort')}</span>
      </footer>
    </div>
  );
}
