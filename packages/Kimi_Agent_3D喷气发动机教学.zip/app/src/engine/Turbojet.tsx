// 涡轮喷气发动机 R3F 组件：装配、旋转、爆炸、剖切、高亮、火焰
import { useEffect, useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { buildEngine, findPartId } from './buildEngine';
import { applyExplosion, setPartHighlight } from './animations';
import { sim, updateSim } from './engineState';
import { useLab } from '../app/store';
import { PART_MAP } from './partMetadata';
import { engineAudio } from '../audio/EngineAudio';
import type { StationId } from '../flow/stationModel';

const CUT_PLANE = new THREE.Plane(new THREE.Vector3(0, -Math.SQRT1_2, -Math.SQRT1_2), 0.297);

export function Turbojet() {
  const engine = useMemo(() => buildEngine(), []);
  const highlightRecords = useRef<{ obj: THREE.Object3D; mat: THREE.Material | THREE.Material[] }[] | null>(null);
  const arrowsRef = useRef<THREE.Group>(null);
  const arrowInRef = useRef<THREE.Group>(null);
  const arrowOutRef = useRef<THREE.Group>(null);

  const selectedPartId = useLab((s) => s.selectedPartId);
  const highlightedPartId = useLab((s) => s.highlightedPartId);
  const cutaway = useLab((s) => s.cutaway);
  const casingOpacity = useLab((s) => s.casingOpacity);
  const traceAir = useLab((s) => s.traceAir);

  // 部件高亮
  useEffect(() => {
    const id = highlightedPartId ?? selectedPartId;
    highlightRecords.current = setPartHighlight(
      engine.root, id, engine.materials.highlight, highlightRecords.current,
    );
  }, [selectedPartId, highlightedPartId, engine]);

  // 剖切平面与机匣透明度（追踪空气时自动透亮）
  useEffect(() => {
    const eff = traceAir ? Math.min(casingOpacity, 0.18) : casingOpacity;
    for (const mesh of engine.casingMeshes) {
      const m = mesh.material as THREE.MeshStandardMaterial;
      m.clippingPlanes = cutaway ? [CUT_PLANE] : null;
      m.opacity = eff;
      m.depthWrite = eff > 0.6;
      m.needsUpdate = false;
    }
  }, [cutaway, casingOpacity, traceAir, engine]);

  // 动量箭头（第 4 章）
  const arrows = useMemo(() => {
    const mk = (color: string) => {
      const g = new THREE.Group();
      const shaft = new THREE.Mesh(
        new THREE.CylinderGeometry(0.035, 0.035, 1, 10).rotateZ(-Math.PI / 2),
        new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.9 }),
      );
      shaft.position.x = 0.5;
      const head = new THREE.Mesh(
        new THREE.ConeGeometry(0.11, 0.32, 12).rotateZ(-Math.PI / 2),
        new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.95 }),
      );
      head.position.x = 1.16;
      g.add(shaft, head);
      return g;
    };
    return { mk };
  }, []);

  useEffect(() => {
    return () => engine.dispose();
  }, [engine]);

  useFrame((_, rawDt) => {
    updateSim(rawDt);
    engineAudio.update();
    const lab = useLab.getState();
    const dt = Math.min(rawDt, 0.05);

    // 主轴旋转
    engine.spool.rotation.x = sim.rotorAngle;

    // 爆炸插值
    const ec = THREE.MathUtils.damp(lab.explodeCurrent, lab.explodeTarget, 4, dt);
    if (Math.abs(ec - lab.explodeCurrent) > 1e-4) {
      lab.setExplodeCurrent(ec);
      applyExplosion(engine.root, ec);
    }

    // 火焰
    const flicker = 0.82 + 0.18 * Math.sin(sim.time * 37) * Math.sin(sim.time * 23.7);
    engine.flameMat.opacity = 0.8 * sim.flame * flicker;
    engine.flameGroup.visible = sim.flame > 0.02;
    engine.flameGroup.scale.setScalar(0.85 + 0.3 * sim.flame * flicker);
    engine.flameGroup.scale.x = 1;
    engine.nozzleGlowMat.opacity = 0.2 * sim.flame * Math.min(1, (sim.egt - 1) / 1.6);

    // 喘振抖动
    engine.root.position.y = sim.surge > 0.05 ? Math.sin(sim.time * 42) * 0.03 * sim.surge : 0;

    // 站位环
    const wantStation =
      lab.activeStation ??
      (lab.selectedPartId ? PART_MAP.get(lab.selectedPartId)?.station ?? null : null);
    engine.stationRings.forEach((ring, sid) => {
      const on = wantStation === sid;
      ring.visible = on;
      if (on) {
        engine.stationRingMat.opacity = 0.55 + 0.3 * Math.sin(sim.time * 6);
        engine.stationRingMat.color.set(lab.traceAir ? '#f2c45f' : '#6fc7e8');
      }
    });

    // 扭矩追踪环：涡轮 → 压气机
    const torqueOn = lab.traceTorque && sim.n1 > 0.05;
    engine.torqueRing.visible = torqueOn;
    if (torqueOn) {
      const f = (sim.time * 0.55) % 1;
      engine.torqueRing.position.x = 1.55 - f * 4.1;
      engine.torqueMat.opacity = 0.9 * Math.sin(f * Math.PI);
    } else {
      engine.torqueMat.opacity = 0;
    }

    // 动量箭头（第 4 章，索引 3）
    const showArrows = lab.chapter === 3;
    if (arrowsRef.current) arrowsRef.current.visible = showArrows;
    if (showArrows && arrowInRef.current && arrowOutRef.current) {
      const v0 = Math.max(0.05, 0.25 * sim.n1);
      const v8 = Math.max(0.05, sim.exhaustVel);
      arrowInRef.current.scale.set(v0 * 1.6, 1, 1);
      arrowOutRef.current.scale.set(v8 * 2.2, 1, 1);
    }
  });

  const onPartClick = (e: { object: THREE.Object3D; delta: number; stopPropagation: () => void }) => {
    if (e.delta > 6) return; // 拖拽旋转不选中
    const lab = useLab.getState();
    const id = findPartId(e.object);
    if (id && PART_MAP.has(id)) {
      e.stopPropagation();
      lab.selectPart(id);
      const meta = PART_MAP.get(id)!;
      lab.setActiveStation(null);
      lab.setActiveCycleSeg(meta.cycleSeg);
    }
  };

  return (
    <group>
      <primitive object={engine.root} onClick={onPartClick} />
      {/* 中心线 */}
      <CenterLine />
      {/* 动量箭头组 */}
      <group ref={arrowsRef} visible={false}>
        <group ref={arrowInRef} position={[-5.4, 0, 1.5]}>
          <MomentumArrow mk={arrows.mk} color="#6fc7e8" label="V0" />
        </group>
        <group ref={arrowOutRef} position={[4.4, 0, 1.5]}>
          <MomentumArrow mk={arrows.mk} color="#f08a4b" label="Ve" />
        </group>
      </group>
    </group>
  );
}

function MomentumArrow({ mk, color }: { mk: (c: string) => THREE.Group; color: string; label: string }) {
  const g = useMemo(() => mk(color), [mk, color]);
  return <primitive object={g} />;
}

function CenterLine() {
  const line = useMemo(() => {
    const geo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(-6.4, 0, 0),
      new THREE.Vector3(6.4, 0, 0),
    ]);
    const mat = new THREE.LineDashedMaterial({
      color: '#9d978a', transparent: true, opacity: 0.28, dashSize: 0.35, gapSize: 0.22,
    });
    const l = new THREE.Line(geo, mat);
    l.computeLineDistances();
    return l;
  }, []);
  return <primitive object={line} />;
}

export { findPartId };
export type { StationId };
