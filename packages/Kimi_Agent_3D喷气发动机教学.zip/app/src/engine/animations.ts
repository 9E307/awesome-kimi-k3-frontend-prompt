// 爆炸 / 高亮 / 剖切等连续动画辅助（每帧调用，零分配）
import * as THREE from 'three';

const tmpV = new THREE.Vector3();

/** 对所有带 userData.explode 的对象应用连续爆炸偏移 */
export function applyExplosion(root: THREE.Object3D, t: number) {
  root.traverse((o) => {
    const ex = o.userData.explode as THREE.Vector3 | undefined;
    if (!ex) return;
    if (!o.userData.basePos) {
      o.userData.basePos = o.position.clone();
    }
    const base = o.userData.basePos as THREE.Vector3;
    tmpV.copy(ex).multiplyScalar(t).add(base);
    o.position.copy(tmpV);
  });
}

/** 切换部件高亮：把部件网格材质换成高亮材质，返回恢复函数 */
export function setPartHighlight(
  root: THREE.Object3D,
  partId: string | null,
  highlightMat: THREE.Material,
  prev: { obj: THREE.Object3D; mat: THREE.Material | THREE.Material[] }[] | null,
) {
  // 先恢复上一次
  if (prev) {
    for (const r of prev) {
      if (r.obj instanceof THREE.Mesh) r.obj.material = r.mat;
    }
  }
  const records: { obj: THREE.Object3D; mat: THREE.Material | THREE.Material[] }[] = [];
  if (!partId) return records;
  root.traverse((o) => {
    if (o.userData.partId !== partId) return;
    if (o instanceof THREE.Mesh) {
      // 跳过加色透明材质（火焰、辉光等）
      const m = o.material as THREE.Material;
      if ((m as THREE.MeshBasicMaterial).blending === THREE.AdditiveBlending) return;
      records.push({ obj: o, mat: o.material });
      o.material = highlightMat;
    }
  });
  return records;
}
