// 共享材质与基础零件工厂
import * as THREE from 'three';
import { COLORS } from '../app/engineConfig';
import { makeBladeGeometry, layoutBladeRing } from './bladeGeometry';

export interface EngineMaterials {
  titanium: THREE.MeshStandardMaterial;
  nickel: THREE.MeshStandardMaterial;
  steel: THREE.MeshStandardMaterial;
  blade: THREE.MeshStandardMaterial;
  stator: THREE.MeshStandardMaterial;
  liner: THREE.MeshStandardMaterial;
  copper: THREE.MeshStandardMaterial;
  dark: THREE.MeshStandardMaterial;
  ceramic: THREE.MeshStandardMaterial;
  flame: THREE.MeshBasicMaterial;
  highlight: THREE.MeshStandardMaterial;
  stationRing: THREE.MeshBasicMaterial;
  torque: THREE.MeshBasicMaterial;
}

export function makeMaterials(): EngineMaterials {
  return {
    titanium: new THREE.MeshStandardMaterial({
      color: COLORS.titanium, metalness: 0.85, roughness: 0.38, side: THREE.DoubleSide,
    }),
    nickel: new THREE.MeshStandardMaterial({
      color: COLORS.nickel, metalness: 0.8, roughness: 0.42, side: THREE.DoubleSide,
    }),
    steel: new THREE.MeshStandardMaterial({
      color: '#4c545b', metalness: 0.9, roughness: 0.3,
    }),
    blade: new THREE.MeshStandardMaterial({
      color: '#c3ccd2', metalness: 0.92, roughness: 0.25,
    }),
    stator: new THREE.MeshStandardMaterial({
      color: '#7d868d', metalness: 0.88, roughness: 0.34,
    }),
    liner: new THREE.MeshStandardMaterial({
      color: '#6e5a41', metalness: 0.55, roughness: 0.6, side: THREE.DoubleSide,
    }),
    copper: new THREE.MeshStandardMaterial({
      color: '#b5763f', metalness: 0.85, roughness: 0.35,
    }),
    dark: new THREE.MeshStandardMaterial({
      color: '#2b3136', metalness: 0.6, roughness: 0.7,
    }),
    ceramic: new THREE.MeshStandardMaterial({
      color: '#8f8672', metalness: 0.2, roughness: 0.85,
    }),
    flame: new THREE.MeshBasicMaterial({
      color: COLORS.flame, transparent: true, opacity: 0,
      blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide,
    }),
    highlight: new THREE.MeshStandardMaterial({
      color: COLORS.air, emissive: COLORS.air, emissiveIntensity: 0.9,
      metalness: 0.4, roughness: 0.3,
    }),
    stationRing: new THREE.MeshBasicMaterial({
      color: COLORS.air, transparent: true, opacity: 0.0,
      blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide,
    }),
    torque: new THREE.MeshBasicMaterial({
      color: COLORS.flame, transparent: true, opacity: 0,
      blending: THREE.AdditiveBlending, depthWrite: false,
    }),
  };
}

/** 开口圆筒（沿 X 轴），用 LatheGeometry 生成 */
export function barrelX(
  rIn: number, rOut: number, x0: number, x1: number, mat: THREE.Material, radialSeg = 48,
): THREE.Mesh {
  const pts = [
    new THREE.Vector2(rIn, x0),
    new THREE.Vector2(rOut, x0),
    new THREE.Vector2(rOut, x1),
    new THREE.Vector2(rIn, x1),
    new THREE.Vector2(rIn, x0),
  ];
  const geo = new THREE.LatheGeometry(pts, radialSeg);
  geo.rotateZ(-Math.PI / 2); // Lathe 默认绕 Y，转到 X
  const mesh = new THREE.Mesh(geo, mat);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  return mesh;
}

/** 锥台壳（沿 X） */
export function coneShellX(
  r0: number, r1: number, thickness: number, x0: number, x1: number, mat: THREE.Material, radialSeg = 48,
): THREE.Mesh {
  const t = thickness;
  const pts = [
    new THREE.Vector2(Math.max(0.01, r0 - t), x0),
    new THREE.Vector2(r0, x0),
    new THREE.Vector2(r1, x1),
    new THREE.Vector2(Math.max(0.01, r1 - t), x1),
    new THREE.Vector2(Math.max(0.01, r0 - t), x0),
  ];
  const geo = new THREE.LatheGeometry(pts, radialSeg);
  geo.rotateZ(-Math.PI / 2);
  const mesh = new THREE.Mesh(geo, mat);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  return mesh;
}

/** 实心锥台（沿 X） */
export function coneX(r0: number, r1: number, len: number, mat: THREE.Material, radialSeg = 32): THREE.Mesh {
  const geo = new THREE.CylinderGeometry(r1, r0, len, radialSeg);
  geo.rotateZ(-Math.PI / 2);
  const mesh = new THREE.Mesh(geo, mat);
  mesh.castShadow = true;
  return mesh;
}

/** 叶片环（InstancedMesh） */
export function bladeRing(
  count: number, hubRadius: number, span: number, chord: number, thick: number,
  twist: number, lean: number, mat: THREE.Material, staggerDeg = 0,
): THREE.InstancedMesh {
  const geo = makeBladeGeometry(span, chord, thick, twist, lean);
  const im = new THREE.InstancedMesh(geo, mat, count);
  layoutBladeRing(im, count, hubRadius, staggerDeg);
  im.castShadow = true;
  im.frustumCulled = false;
  return im;
}

/** 螺栓环（InstancedMesh，小圆柱沿 X 分布） */
export function boltRing(
  count: number, radius: number, mat: THREE.Material,
): THREE.InstancedMesh {
  const geo = new THREE.CylinderGeometry(0.035, 0.035, 0.16, 10);
  geo.rotateZ(-Math.PI / 2); // 螺栓轴向 → X（沿发动机轴线穿法兰）
  const im = new THREE.InstancedMesh(geo, mat, count);
  const m = new THREE.Matrix4();
  const q = new THREE.Quaternion();
  const pos = new THREE.Vector3();
  const scl = new THREE.Vector3(1, 1, 1);
  for (let i = 0; i < count; i++) {
    const a = (i / count) * Math.PI * 2;
    pos.set(0, Math.sin(a) * radius, Math.cos(a) * radius);
    m.compose(pos, q, scl);
    im.setMatrixAt(i, m);
  }
  im.instanceMatrix.needsUpdate = true;
  im.frustumCulled = false;
  return im;
}

/** 法兰环 */
export function flange(radius: number, width: number, mat: THREE.Material): THREE.Mesh {
  return barrelX(radius - 0.06, radius + 0.1, -width / 2, width / 2, mat, 48);
}
