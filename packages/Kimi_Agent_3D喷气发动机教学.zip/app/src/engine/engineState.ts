// 确定性教学发动机仿真（每帧更新，非 React 状态）
import { useLab } from '../app/store';
import { SPEED, densityRatio } from '../app/engineConfig';
import { appEvents } from '../app/events';

export interface SimState {
  n1: number; // 归一化主轴转速 0..1
  flame: number; // 火焰强度 0..1
  fuelFlow: number; // 归一化燃油流量 0..1
  starter: number; // 启动机功率 0..1
  massFlow: number; // 归一化质量流量
  thrust: number; // 归一化推力
  t3: number; // 涡轮前温度比 T/T0
  egt: number; // 排气温度比
  exhaustVel: number; // 归一化排气速度
  surge: number; // 喘振强度 0..1
  nozzleBlock: number; // 喷管阻塞 0..1
  flameout: boolean; // 熄火故障
  rotorAngle: number; // 主轴角（弧度，用于叶片旋转）
  time: number;
}

export const sim: SimState = {
  n1: 0,
  flame: 0,
  fuelFlow: 0,
  starter: 0,
  massFlow: 0,
  thrust: 0,
  t3: 1,
  egt: 1,
  exhaustVel: 0,
  surge: 0,
  nozzleBlock: 0,
  flameout: false,
  rotorAngle: 0,
  time: 0,
};

function approach(cur: number, target: number, rate: number, dt: number): number {
  const d = target - cur;
  const step = rate * dt;
  if (Math.abs(d) <= step) return target;
  return cur + Math.sign(d) * step;
}

let surgeWarned = false;
let ignitedOnce = false;

export function updateSim(rawDt: number) {
  const lab = useLab.getState();
  const timeScale = lab.slowMotion ? 0.22 : 1;
  const dt = Math.min(rawDt, 0.05) * timeScale;
  sim.time += dt;

  // 故障状态注入
  sim.flameout = lab.activeFault === 'flameout';
  sim.nozzleBlock = approach(sim.nozzleBlock, lab.activeFault === 'nozzleBlock' ? 1 : 0, 0.8, dt);

  const surgeActive = lab.activeFault === 'surge' && ['IDLE', 'RUNNING', 'SPOOLING'].includes(lab.phase);
  sim.surge = approach(sim.surge, surgeActive ? 1 : 0, surgeActive ? 1.5 : 0.5, dt);
  if (sim.surge > 0.6 && !surgeWarned) {
    surgeWarned = true;
    appEvents.emit('surgeWarning');
    lab.pushPlaque({ key: 'hintSurge', tone: 'danger' });
  }
  if (sim.surge < 0.1) surgeWarned = false;

  // 油门实际值平滑跟随目标
  const thr = approach(lab.throttleCurrent, lab.throttleTarget, 0.6, dt);
  if (Math.abs(thr - lab.throttleCurrent) > 1e-4) lab.setThrottleCurrent(thr);

  const runningLike = ['IDLE', 'SPOOLING', 'RUNNING', 'SURGE'].includes(lab.phase);

  // 燃油与火焰
  let fuelTarget = 0;
  if (lab.phase === 'IGNITION') fuelTarget = 0.35;
  else if (runningLike) fuelTarget = 0.28 + 0.72 * thr;
  if (sim.flameout) fuelTarget = 0;
  sim.fuelFlow = approach(sim.fuelFlow, fuelTarget, fuelTarget > sim.fuelFlow ? 2.5 : 4, dt);

  const flameTarget = sim.fuelFlow > 0.02 && sim.n1 > SPEED.lightOffMin && !sim.flameout ? 1 : 0;
  // 火焰建立约 700ms，熄灭更快
  sim.flame = approach(sim.flame, flameTarget, sim.flame < flameTarget ? 1 / 0.7 : 4, dt);

  // 状态机
  switch (lab.phase) {
    case 'OFF':
      sim.starter = 0;
      sim.n1 = approach(sim.n1, 0, 0.25, dt);
      break;
    case 'STARTING': {
      sim.starter = 1;
      sim.n1 = approach(sim.n1, SPEED.starterMax, 0.055, dt);
      if (sim.n1 >= SPEED.starterMax - 0.005) {
        lab.setPhase('IGNITION');
        appEvents.emit('ignition');
        if (!ignitedOnce) {
          ignitedOnce = true;
          appEvents.emit('combustion');
        }
      }
      break;
    }
    case 'IGNITION': {
      sim.starter = approach(sim.starter, 0, 1.2, dt);
      sim.n1 = approach(sim.n1, SPEED.idle, 0.09, dt);
      if (sim.flame > 0.98) {
        lab.setPhase('IDLE');
      }
      break;
    }
    case 'IDLE':
    case 'SPOOLING':
    case 'RUNNING': {
      sim.starter = 0;
      // 熄火时涡轮失去能量来源，主轴衰减到风车转速
      const nTarget =
        sim.flame > 0.15 ? SPEED.idle + (SPEED.max - SPEED.idle) * thr : 0.12;
      const rate = sim.surge > 0.5 ? 0.5 : nTarget > sim.n1 ? 0.16 : 0.22;
      sim.n1 = approach(sim.n1, nTarget, rate, dt);
      // 喘振振荡
      if (sim.surge > 0.02) {
        sim.n1 = Math.max(0.2, sim.n1 + Math.sin(sim.time * 21) * 0.05 * sim.surge * dt * 8);
      }
      const settled = Math.abs(sim.n1 - nTarget) < 0.015;
      const want = settled ? (thr > 0.02 ? 'RUNNING' : 'IDLE') : 'SPOOLING';
      if (lab.phase !== want) lab.setPhase(want as 'IDLE');
      break;
    }
    case 'SHUTDOWN': {
      sim.starter = 0;
      // 先断油（fuelTarget 已为 0），主轴惰转
      sim.n1 = approach(sim.n1, 0, 0.09, dt);
      if (sim.n1 < 0.004) {
        sim.n1 = 0;
        lab.setPhase('OFF');
      }
      break;
    }
    case 'SURGE':
      break;
  }

  // 主轴角（叶片旋转），转速映射到视觉角速度
  sim.rotorAngle += sim.n1 * 26 * dt;

  // 温度与能量
  const n = sim.n1;
  const cpr = 1 + 7 * n * n;
  const t2 = Math.pow(cpr, 0.31);
  const fuelNorm = 0.35 + 0.65 * thr;
  const t3Target = sim.flame > 0.01 ? t2 + (2.9 - t2) * fuelNorm * sim.flame : t2;
  sim.t3 = approach(sim.t3, t3Target, 1.2, dt);
  const t4 = Math.max(1, sim.t3 - (t2 - 1) * 1.03);
  sim.egt = approach(sim.egt, t4, 1.2, dt);

  // 质量流量与推力（定性）
  const density = densityRatio(lab.altitudeKm);
  sim.massFlow = n * density * (1 - 0.3 * sim.nozzleBlock);
  const p3 = cpr * 0.96;
  const p4 = Math.max(1, p3 * Math.pow(t4 / Math.max(sim.t3, 1.001), 4));
  const er = Math.max(1, p4);
  const t8 = t4 * Math.pow(1 / er, 0.25);
  const v8raw = Math.sqrt(Math.max(0, t4 - t8));
  const v8norm = Math.min(1, (v8raw / 0.48) * (1 - 0.7 * sim.nozzleBlock)) * (n > 0.01 ? 1 : 0);
  sim.exhaustVel = v8norm;
  sim.thrust = Math.min(1, sim.massFlow * v8norm);
}

if (typeof window !== 'undefined') {
  (window as unknown as { __sim: SimState }).__sim = sim;
}

export function resetSim() {
  sim.n1 = 0;
  sim.flame = 0;
  sim.fuelFlow = 0;
  sim.starter = 0;
  sim.massFlow = 0;
  sim.thrust = 0;
  sim.t3 = 1;
  sim.egt = 1;
  sim.exhaustVel = 0;
  sim.surge = 0;
  sim.nozzleBlock = 0;
  sim.flameout = false;
  sim.rotorAngle = 0;
  sim.time = 0;
}
