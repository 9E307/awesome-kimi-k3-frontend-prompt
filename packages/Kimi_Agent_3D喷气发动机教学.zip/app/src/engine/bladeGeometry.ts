// 可复用扭曲叶片 BufferGeometry（压气机 / 涡轮共用）
import * as THREE from 'three';

/**
 * 生成一片沿径向伸展、带安装角与扭转的叶片。
 * @param span   叶片径向长度
 * @param chord  弦长（沿轴向）
 * @param thick  厚度
 * @param twistDeg 根部到尖部的总扭转角
 * @param leanDeg  安装倾角（周向倾斜）
 */
export function makeBladeGeometry(
  span: number,
  chord: number,
  thick: number,
  twistDeg = 32,
  leanDeg = 12,
): THREE.BufferGeometry {
  const SECTIONS = 5;
  const positions: number[] = [];
  const normals: number[] = [];
  const indices: number[] = [];

  const twist = THREE.MathUtils.degToRad(twistDeg);
  const lean = THREE.MathUtils.degToRad(leanDeg);

  // 每个截面是一个扁平六边形（类叶型），绕径向轴扭转
  const sectionPts = (c: number, t: number) => [
    new THREE.Vector2(-c * 0.5, 0),
    new THREE.Vector2(-c * 0.28, t * 0.5),
    new THREE.Vector2(c * 0.3, t * 0.42),
    new THREE.Vector2(c * 0.5, 0),
    new THREE.Vector2(c * 0.3, -t * 0.42),
    new THREE.Vector2(-c * 0.28, -t * 0.5),
  ];

  const ringStart: number[] = [];
  for (let s = 0; s < SECTIONS; s++) {
    const f = s / (SECTIONS - 1);
    const r = f * span;
    const ang = twist * (f - 0.35); // 扭转
    const leanOff = Math.tan(lean) * r;
    const c = chord * (1 - 0.18 * f); // 尖部略缩
    const t = thick * (1 - 0.3 * f);
    const pts = sectionPts(c, t);
    ringStart.push(positions.length / 3);
    const ca = Math.cos(ang);
    const sa = Math.sin(ang);
    for (const p of pts) {
      // 截面平面：局部 x=弦向（轴向+周向混合），y=厚度（周向）
      const lx = p.x;
      const ly = p.y;
      // 扭转：绕径向（Z 局部）旋转
      const rx = lx * ca - ly * sa;
      const ry = lx * sa + ly * ca;
      // 叶片沿局部 +Z 径向伸展；轴向 = 全局 X，周向由外层实例旋转决定
      positions.push(rx, ry + leanOff, r);
      normals.push(0, 1, 0);
    }
  }

  const P = 6; // 每环点数
  for (let s = 0; s < SECTIONS - 1; s++) {
    const a0 = ringStart[s];
    const b0 = ringStart[s + 1];
    for (let i = 0; i < P; i++) {
      const j = (i + 1) % P;
      indices.push(a0 + i, b0 + i, b0 + j);
      indices.push(a0 + i, b0 + j, a0 + j);
    }
  }
  // 端面封口
  const cap = (start: number, flip: boolean) => {
    for (let i = 1; i < P - 1; i++) {
      if (flip) indices.push(start, start + i + 1, start + i);
      else indices.push(start, start + i, start + i + 1);
    }
  };
  cap(ringStart[0], true);
  cap(ringStart[SECTIONS - 1], false);

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

/** 将叶片按环形布置写入 InstancedMesh（轮毂中心在原点、轴为全局 X） */
export function layoutBladeRing(
  mesh: THREE.InstancedMesh,
  count: number,
  hubRadius: number,
  staggerDeg = 0,
) {
  const m = new THREE.Matrix4();
  const q = new THREE.Quaternion();
  const pos = new THREE.Vector3();
  const scl = new THREE.Vector3(1, 1, 1);
  const xAxis = new THREE.Vector3(1, 0, 0);
  for (let i = 0; i < count; i++) {
    const a = (i / count) * Math.PI * 2 + THREE.MathUtils.degToRad(staggerDeg);
    // 叶片局部 +Z 指向径向：先绕 X 旋转 a
    q.setFromAxisAngle(xAxis, a);
    pos.set(0, 0, 0);
    m.compose(pos, q, scl);
    // 把叶片根部平移到轮毂半径：在旋转后的 -Z 方向移动 -hubRadius → 等价于局部平移
    const t = new THREE.Matrix4().makeTranslation(0, 0, hubRadius);
    m.multiply(t);
    mesh.setMatrixAt(i, m);
  }
  mesh.instanceMatrix.needsUpdate = true;
}
