// 全部可选部件元数据（≥30 项）
import type { StationId } from '../flow/stationModel';

export type SystemId = 'intake' | 'compressor' | 'combustor' | 'turbine' | 'shaft' | 'exhaust' | 'casing';

export interface PartMeta {
  id: string;
  system: SystemId;
  zh: string;
  en: string;
  fn: { zh: string; en: string };
  upstream: { zh: string; en: string };
  downstream: { zh: string; en: string };
  station: StationId | null;
  cycleSeg: number | null; // 0..3
}

export const SYSTEM_NAMES: Record<SystemId, { zh: string; en: string }> = {
  intake: { zh: '进气系统', en: 'Intake' },
  compressor: { zh: '压气机', en: 'Compressor' },
  combustor: { zh: '扩压与燃烧', en: 'Diffuser & Combustion' },
  turbine: { zh: '涡轮', en: 'Turbine' },
  shaft: { zh: '轴系与支撑', en: 'Shaft & Support' },
  exhaust: { zh: '排气', en: 'Exhaust' },
  casing: { zh: '机匣与紧固件', en: 'Casing & Hardware' },
};

const P = (
  id: string, system: SystemId, zh: string, en: string,
  fnZh: string, fnEn: string,
  upZh: string, upEn: string,
  downZh: string, downEn: string,
  station: StationId | null, cycleSeg: number | null,
): PartMeta => ({
  id, system, zh, en,
  fn: { zh: fnZh, en: fnEn },
  upstream: { zh: upZh, en: upEn },
  downstream: { zh: downZh, en: downEn },
  station, cycleSeg,
});

export const PARTS: PartMeta[] = [
  // ── 进气 ──
  P('intakeLip', 'intake', '进气唇口', 'Intake lip',
    '圆滑唇口把外界空气平顺引入进气道，减少分离与畸变。',
    'Rounded lip guides ambient air smoothly into the duct.',
    '大气', 'Atmosphere', '进气道', 'Intake duct', 0, null),
  P('intakeDuct', 'intake', '进气道', 'Intake duct',
    '收敛流道把空气加速并整流，送往压气机进口。',
    'Contracting duct accelerates and conditions the air.',
    '进气唇口', 'Intake lip', '压气机进口导叶', 'Inlet guide vanes', 0, null),

  // ── 压气机 ──
  P('igv', 'compressor', '进口可调导叶', 'Variable inlet guide vanes',
    '教学用可调导叶，预设进入第一级的气流角度。',
    'Teaching vanes preset the swirl angle into stage one.',
    '进气道', 'Intake duct', '第 1 级压气机转子', 'Compressor rotor 1', 1, 0),
  P('frontBearingHousing', 'shaft', '前轴承壳体', 'Front bearing housing',
    '支撑主轴前端，承受径向与轴向载荷。',
    'Supports the front of the shaft, taking radial and axial loads.',
    '发动机支架', 'Engine stand', '主轴', 'Main shaft', 1, null),
  ...[1, 2, 3, 4, 5, 6].map((i) =>
    P(`compRotor${i}`, 'compressor', `第 ${i} 级压气机转子`, `Compressor rotor ${i}`,
      '把轴功传给空气，提高总压与总温。',
      'Hands shaft work to the air, raising total pressure and temperature.',
      '主轴（扭矩来自涡轮）', 'Main shaft (torque from the turbine)',
      i < 6 ? `第 ${i} 级静子` : '扩压器',
      i < 6 ? `Stator ${i}` : 'Diffuser', 1, 0)),
  ...[1, 2, 3, 4, 5, 6].map((i) =>
    P(`compStator${i}`, 'compressor', `第 ${i} 级静子`, `Stator ${i}`,
      '消除部分旋流，并把气流重新引向下一转子级。',
      'Removes swirl and re-aims the flow into the next rotor stage.',
      i === 1 ? '第 1 级压气机转子' : `第 ${i - 1} 级静子气流出角`,
      i === 1 ? 'Compressor rotor 1' : `Stator ${i - 1} exit angle`,
      i < 6 ? `第 ${i + 1} 级压气机转子` : '扩压器',
      i < 6 ? `Compressor rotor ${i + 1}` : 'Diffuser', 1, 0)),
  P('compDiscs', 'compressor', '压气机转子盘', 'Compressor discs',
    '把各级叶片连成刚性鼓筒，传递扭矩。',
    'Ties the blade rows into a rigid drum and carries torque.',
    '主轴', 'Main shaft', '各级压气机转子', 'Compressor rotors', 1, 0),
  P('compCasing', 'casing', '压气机机匣', 'Compressor casing',
    '收敛外通道维持叶尖间隙，承受内压。',
    'Tapered outer path keeps tip clearance and holds pressure.',
    '静子叶片', 'Stator vanes', '燃烧室机匣', 'Combustor casing', 2, 0),

  // ── 扩压与燃烧 ──
  P('diffuser', 'combustor', '扩压器', 'Diffuser',
    '扩张流道降低流速、继续升压，为稳定燃烧创造条件。',
    'Diverging passage slows the flow and recovers pressure.',
    '末级压气机', 'Last compressor stage', '燃烧室', 'Combustor', 2, 0),
  P('combOuterLiner', 'combustor', '燃烧室外衬套', 'Combustor outer liner',
    '稳定火焰，并通过分级进气完成冷却和掺混。',
    'Stabilises the flame; staged holes cool and dilute the gas.',
    '扩压器来流', 'Diffuser flow', '火焰区 / 涡轮导向叶片', 'Flame zone / turbine nozzle', 3, 1),
  P('combInnerLiner', 'combustor', '燃烧室内衬套', 'Combustor inner liner',
    '与外衬套构成环形火焰筒，保护主轴与轴承。',
    'Forms the annular flame tube, shielding shaft and bearings.',
    '扩压器来流', 'Diffuser flow', '火焰区', 'Flame zone', 3, 1),
  P('primaryHoles', 'combustor', '主燃孔', 'Primary holes',
    '引入约两成空气与燃油混合，形成主燃区。',
    'Admit ~20% of air to mix with fuel in the primary zone.',
    '衬套外环形通道', 'Annulus around liners', '主燃区火焰', 'Primary flame', 3, 1),
  P('dilutionHoles', 'combustor', '掺混孔', 'Dilution holes',
    '掺入剩余冷空气，把出口温度削平到涡轮可承受的范围。',
    'Mix in the remaining cool air to flatten the exit temperature.',
    '衬套外环形通道', 'Annulus around liners', '涡轮导向叶片', 'Turbine nozzle', 3, 1),
  P('fuelNozzles', 'combustor', '燃油喷嘴（10 个）', 'Fuel nozzles (×10)',
    '把燃油雾化成细滴喷入主燃区。',
    'Atomise fuel into the primary zone.',
    '燃油总管（附件）', 'Fuel manifold (accessory)', '主燃区火焰', 'Primary flame', 3, 1),
  P('igniter', 'combustor', '点火器', 'Igniter',
    '启动时打出高能火花，点燃混合气后退出工作。',
    'Sparks once at start, then sits idle.',
    '启动电系统', 'Aircraft electrics', '主燃区火焰', 'Primary flame', 3, 1),
  P('flameZone', 'combustor', '火焰区', 'Flame zone',
    '燃油与空气在此持续燃烧，把化学能变成热能。',
    'Fuel and air burn here, turning chemistry into heat.',
    '燃油喷嘴 + 主燃孔空气', 'Fuel nozzles + primary air', '涡轮导向叶片', 'Turbine nozzle', 3, 1),
  P('combCasing', 'casing', '燃烧室机匣', 'Combustor casing',
    '承受最高内压的圆筒机匣，容纳整个环形燃烧室。',
    'Highest-pressure barrel housing the annular combustor.',
    '压气机机匣', 'Compressor casing', '涡轮机匣', 'Turbine casing', 3, 1),

  // ── 涡轮 ──
  P('turbineNozzle', 'turbine', '涡轮导向叶片', 'Turbine nozzle guide vanes',
    '转向并加速热气，使其以合适角度进入涡轮转子。',
    'Turns and accelerates hot gas into the rotor at the right angle.',
    '燃烧室出口热气', 'Hot gas from combustor', '第 1 级涡轮转子', 'Turbine rotor 1', 3, 2),
  P('turbineRotor1', 'turbine', '第 1 级涡轮转子', 'Turbine rotor 1',
    '从热气中提取能量并转化为轴扭矩。',
    'Extracts energy from the hot gas as shaft torque.',
    '涡轮导向叶片', 'Nozzle guide vanes', '主轴 / 第 2 级涡轮转子', 'Main shaft / turbine rotor 2', 4, 2),
  P('turbineRotor2', 'turbine', '第 2 级涡轮转子', 'Turbine rotor 2',
    '继续提取剩余能量，补充轴扭矩。',
    'Takes more energy out, topping up the torque.',
    '第 1 级涡轮转子排气', 'Rotor 1 exit gas', '主轴', 'Main shaft', 4, 2),
  P('turbineDiscs', 'turbine', '涡轮盘', 'Turbine discs',
    '在高温下把叶片载荷传给主轴。',
    'Carry blade loads into the shaft at high temperature.',
    '涡轮转子叶片', 'Turbine blades', '主轴', 'Main shaft', 4, 2),
  P('heatShield', 'turbine', '热屏蔽结构', 'Heat shield',
    '挡住辐射热，保护涡轮盘与轴承腔。',
    'Shields the discs and bearing cavity from radiation.',
    '燃烧室火焰辐射', 'Flame radiation', '主轴后段', 'Rear shaft', 4, 2),

  // ── 轴系 ──
  P('mainShaft', 'shaft', '主轴', 'Main shaft',
    '把涡轮扭矩传给前方压气机。',
    'Carries turbine torque forward to the compressor.',
    '涡轮转子（扭矩源）', 'Turbine rotors (torque source)', '压气机转子', 'Compressor rotors', 4, 2),
  P('frontBearing', 'shaft', '前轴承', 'Front bearing',
    '支撑主轴前端，保持转子居中。',
    'Keeps the spool centred at the front.',
    '前轴承壳体', 'Front bearing housing', '主轴', 'Main shaft', 1, null),
  P('rearBearing', 'shaft', '后轴承', 'Rear bearing',
    '支撑主轴热端，承受轴向推力。',
    'Supports the hot end and takes axial thrust.',
    '轴承支撑', 'Bearing support', '主轴', 'Main shaft', 4, null),
  P('bearingSupports', 'shaft', '轴承支撑', 'Bearing supports',
    '把轴承载荷传入机匣与安装节。',
    'Route bearing loads into the casing and mounts.',
    '机匣', 'Casings', '前后轴承', 'Front & rear bearings', 4, null),
  P('gearbox', 'shaft', '附件齿轮箱（简化）', 'Accessory gearbox (simplified)',
    '从主轴取少量功率，驱动燃油泵等附件。',
    'Takes a little shaft power for fuel pumps and accessories.',
    '主轴', 'Main shaft', '燃油泵 / 附件', 'Fuel pump / accessories', 2, null),
  P('starter', 'shaft', '启动机', 'Starter',
    '启动时先带动主轴与压气机旋转，点火后脱开。',
    'Spins the shaft and compressor first; disengages after light-off.',
    '外部电源 / 气源', 'External power / air', '主轴', 'Main shaft', 1, null),

  // ── 排气 ──
  P('exhaustCone', 'exhaust', '排气锥', 'Exhaust cone',
    '整流涡轮出口气流，支撑尾喷管内表面。',
    'Straightens turbine exit flow; forms the inner nozzle wall.',
    '涡轮出口', 'Turbine exit', '喷管', 'Nozzle', 4, 3),
  P('nozzle', 'exhaust', '收敛喷管', 'Convergent nozzle',
    '把剩余压力与热能转化为排气速度。',
    'Turns leftover pressure and heat into exhaust velocity.',
    '涡轮出口热气', 'Hot gas from turbine', '高速射流（推力）', 'Fast jet (thrust)', 8, 3),
  P('nozzleThroat', 'exhaust', '喷管喉部', 'Nozzle throat',
    '最小截面积处决定质量流量与出口速度。',
    'The smallest area sets mass flow and exit velocity.',
    '收敛喷管', 'Convergent nozzle', '排气尾流', 'Exhaust wake', 8, 3),
  P('exhaustWake', 'exhaust', '排气尾流', 'Exhaust wake',
    '高速射流与大气混合，动量通量体现为推力。',
    'Jet mixes with the air; momentum flux shows up as thrust.',
    '喷管喉部', 'Nozzle throat', '大气', 'Atmosphere', 8, 3),

  // ── 机匣与紧固件 ──
  P('topCasing', 'casing', '可开启顶部机匣', 'Openable top casing',
    '教学检修口，打开后可直视压气机与燃烧室。',
    'Teaching access door: peer straight into the core.',
    '压气机机匣', 'Compressor casing', '内部部件', 'Internal parts', null, null),
  P('casingSegments', 'casing', '分段外机匣', 'Split outer casings',
    '分段法兰连接，便于装配与分解。',
    'Flanged segments for assembly and teardown.',
    '法兰与螺栓', 'Flanges & bolts', '整机结构', 'Whole structure', null, null),
  P('bolts', 'casing', '检查螺栓', 'Inspection bolts',
    '沿法兰压紧各段机匣，承受分离力。',
    'Clamp the flanges against gas loads.',
    '机匣法兰', 'Casing flanges', '分段外机匣', 'Casing segments', null, null),
  P('flanges', 'casing', '连接法兰', 'Flanges',
    '传递轴向与周向载荷，保证气密。',
    'Carry axial and hoop loads, keep gas in.',
    '分段外机匣', 'Casing segments', '检查螺栓', 'Bolts', null, null),
  P('mountStruts', 'casing', '安装支柱', 'Mount struts',
    '把推力与重量传给发动机支架。',
    'Pass thrust and weight into the stand.',
    '机匣', 'Casings', '发动机支架', 'Engine stand', null, null),
  P('engineStand', 'casing', '发动机支架', 'Engine stand',
    '博物馆式展台，承受整机重量与推力。',
    'Museum stand carrying weight and thrust.',
    '安装支柱', 'Mount struts', '地面', 'Ground', null, null),
];

export const PART_MAP: Map<string, PartMeta> = new Map(PARTS.map((p) => [p.id, p]));
