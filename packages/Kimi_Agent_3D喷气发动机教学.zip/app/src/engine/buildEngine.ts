// 程序化组装整台教学涡轮喷气发动机
import * as THREE from 'three';
import { AXIS, COMPRESSOR, COMBUSTOR, TURBINE, NOZZLE, SHAFT } from '../app/engineConfig';
import {
  makeMaterials, barrelX, coneShellX, coneX, bladeRing, boltRing, flange,
} from './engineParts';
import type { EngineMaterials } from './engineParts';
import type { StationId } from '../flow/stationModel';

export interface BuiltEngine {
  root: THREE.Group;
  spool: THREE.Group;
  materials: EngineMaterials;
  casingMeshes: THREE.Mesh[];
  flameGroup: THREE.Group;
  flameMat: THREE.MeshBasicMaterial;
  stationRings: Map<StationId, THREE.Mesh>;
  stationRingMat: THREE.MeshBasicMaterial;
  torqueRing: THREE.Mesh;
  torqueMat: THREE.MeshBasicMaterial;
  shaftMesh: THREE.Mesh;
  nozzleGlowMat: THREE.MeshBasicMaterial;
  dispose: () => void;
}

interface RegOptions {
  explode?: THREE.Vector3;
  casing?: boolean;
}

function reg(obj: THREE.Object3D, partId: string, opts: RegOptions = {}) {
  obj.userData.partId = partId;
  if (opts.explode) obj.userData.explode = opts.explode.clone();
  obj.traverse((c) => {
    c.userData.partId = partId;
    if (opts.explode && !c.userData.explode) c.userData.explode = opts.explode.clone();
    if (opts.casing && c instanceof THREE.Mesh) c.userData.isCasing = true;
  });
  return obj;
}

export function buildEngine(): BuiltEngine {
  const M = makeMaterials();
  const root = new THREE.Group();
  root.name = 'turbojet';
  const spool = new THREE.Group();
  spool.name = 'spool';
  root.add(spool);

  const casingMeshes: THREE.Mesh[] = [];
  const casingCold = M.titanium.clone();
  casingCold.transparent = true;
  const casingHot = M.nickel.clone();
  casingHot.transparent = true;

  const addCasing = (mesh: THREE.Mesh, hot = false) => {
    mesh.material = hot ? casingHot : casingCold;
    mesh.material.clipShadows = true;
    mesh.userData.isCasing = true;
    casingMeshes.push(mesh);
    return mesh;
  };

  const C = COMPRESSOR;
  const stageW = (C.xEnd - C.xStart) / C.stages;
  const lerp = THREE.MathUtils.lerp;

  // ── 进气唇口（Lathe 圆唇） ──
  {
    const pts: THREE.Vector2[] = [];
    for (let i = 0; i <= 12; i++) {
      const a = (i / 12) * Math.PI * 0.5;
      pts.push(new THREE.Vector2(1.02 + 0.13 * Math.sin(a), -4.75 - 0.13 * (1 - Math.cos(a))));
    }
    pts.push(new THREE.Vector2(1.02, -3.0));
    pts.push(new THREE.Vector2(0.97, -3.0));
    pts.push(new THREE.Vector2(0.99, -4.7));
    const g = new THREE.LatheGeometry(pts, 56);
    g.rotateZ(-Math.PI / 2);
    const lip = new THREE.Mesh(g, casingCold);
    lip.castShadow = true;
    lip.userData.isCasing = true;
    casingMeshes.push(lip);
    root.add(reg(lip, 'intakeLip', { explode: new THREE.Vector3(-2.6, 0, 0) }));
  }

  // ── 进气道 ──
  {
    const duct = addCasing(coneShellX(1.02, 1.02, 0.06, -4.7, -3.0, casingCold));
    root.add(reg(duct, 'intakeDuct', { explode: new THREE.Vector3(-2.0, 0, 0) }));
  }

  // ── 前轴承壳体 + 整流锥（随轴转） ──
  {
    const g = new THREE.Group();
    const spinner = coneX(0.34, 0.02, 0.85, M.steel);
    spinner.position.x = -3.0;
    const housing = coneShellX(0.34, 0.36, 0.05, -2.95, -2.55, M.steel);
    g.add(spinner, housing);
    spool.add(reg(g, 'frontBearingHousing', { explode: new THREE.Vector3(-0.9, 0, 0) }));
  }

  // ── 进口导叶（静） ──
  {
    const g = new THREE.Group();
    const ring = bladeRing(24, 0.36, 0.6, 0.16, 0.02, 8, 25, M.stator);
    ring.position.x = -2.95;
    g.add(ring);
    root.add(reg(g, 'igv', { explode: new THREE.Vector3(-1.2, 0, 0) }));
  }

  // ── 主轴 ──
  const shaftGeo = new THREE.CylinderGeometry(SHAFT.radius, SHAFT.radius, SHAFT.xEnd - SHAFT.xStart, 24);
  shaftGeo.rotateZ(-Math.PI / 2);
  const shaftMesh = new THREE.Mesh(shaftGeo, M.steel);
  shaftMesh.position.x = (SHAFT.xStart + SHAFT.xEnd) / 2;
  shaftMesh.castShadow = true;
  spool.add(reg(shaftMesh, 'mainShaft', { explode: new THREE.Vector3(0, -0.3, 0) }));

  // ── 压气机鼓筒（转子盘） ──
  {
    const pts = [
      new THREE.Vector2(C.hubRadiusFront, C.xStart - 0.1),
      new THREE.Vector2(C.hubRadiusRear, C.xEnd),
      new THREE.Vector2(C.hubRadiusRear - 0.08, C.xEnd),
      new THREE.Vector2(C.hubRadiusFront - 0.08, C.xStart - 0.1),
      new THREE.Vector2(C.hubRadiusFront, C.xStart - 0.1),
    ];
    const g = new THREE.LatheGeometry(pts, 40);
    g.rotateZ(-Math.PI / 2);
    const drum = new THREE.Mesh(g, M.steel);
    drum.castShadow = true;
    spool.add(reg(drum, 'compDiscs', { explode: new THREE.Vector3(0, -0.18, 0) }));
  }

  // ── 压气机级：转子（转）+ 静子（静） ──
  for (let i = 0; i < C.stages; i++) {
    const f = i / (C.stages - 1);
    const hub = lerp(C.hubRadiusFront, C.hubRadiusRear, f);
    const tip = lerp(C.tipRadiusFront, C.tipRadiusRear, f);
    const xr = C.xStart + stageW * (i + 0.28);
    const xs = C.xStart + stageW * (i + 0.72);

    const rotor = bladeRing(C.rotorBlades, hub - 0.02, tip - hub + 0.02, 0.17 - f * 0.05, 0.022, 38, 22, M.blade);
    rotor.position.x = xr;
    spool.add(reg(rotor, `compRotor${i + 1}`, { explode: new THREE.Vector3(-0.25 - (C.stages - 1 - i) * 0.35, 0, 0) }));

    const stator = bladeRing(C.statorBlades, tip + 0.01, -(tip - hub) - 0.02, 0.14 - f * 0.04, 0.018, -30, -18, M.stator, 6);
    stator.position.x = xs;
    root.add(reg(stator, `compStator${i + 1}`, { explode: new THREE.Vector3(-0.42 - (C.stages - 1 - i) * 0.35, 0, 0) }));
  }

  // ── 压气机机匣 ──
  {
    const cas = addCasing(coneShellX(C.tipRadiusFront + 0.07, C.tipRadiusRear + 0.07, 0.07, C.xStart - 0.18, C.xEnd + 0.05, casingCold));
    root.add(reg(cas, 'compCasing', { explode: new THREE.Vector3(0, 1.7, 0) }));
  }

  // ── 扩压器 ──
  {
    const g = new THREE.Group();
    const outer = coneShellX(0.79, COMBUSTOR.outerRadius, 0.05, -0.82, -0.55, M.titanium);
    const inner = coneShellX(0.52, COMBUSTOR.innerRadius, 0.05, -0.82, -0.55, M.titanium);
    g.add(outer, inner);
    root.add(reg(g, 'diffuser', { explode: new THREE.Vector3(0.4, 0, 0) }));
  }

  // ── 燃烧室机匣 ──
  {
    const cas = addCasing(barrelX(COMBUSTOR.outerRadius, COMBUSTOR.outerRadius + 0.09, COMBUSTOR.xStart, COMBUSTOR.xEnd, casingHot), true);
    root.add(reg(cas, 'combCasing', { explode: new THREE.Vector3(0, 1.9, 0) }));
  }

  // ── 衬套与火焰筒 ──
  {
    const g = new THREE.Group();
    const liner = barrelX(COMBUSTOR.linerOuter - 0.04, COMBUSTOR.linerOuter, -0.48, 0.55, M.liner);
    // 头部穹顶
    const dome = coneShellX(COMBUSTOR.linerOuter, COMBUSTOR.linerInner, 0.04, -0.5, -0.48, M.liner);
    g.add(liner, dome);
    root.add(reg(g, 'combOuterLiner', { explode: new THREE.Vector3(0, 1.15, 0) }));
  }
  {
    const liner = barrelX(COMBUSTOR.linerInner - 0.04, COMBUSTOR.linerInner, -0.48, 0.55, M.liner);
    root.add(reg(liner, 'combInnerLiner', { explode: new THREE.Vector3(0, -0.85, 0) }));
  }

  // ── 主燃孔 / 掺混孔（外衬套上的小圆环） ──
  const holeRing = (x: number, partId: string, explode: THREE.Vector3) => {
    const g = new THREE.Group();
    const geo = new THREE.TorusGeometry(0.05, 0.014, 8, 16);
    for (let i = 0; i < COMBUSTOR.fuelNozzles; i++) {
      const a = (i / COMBUSTOR.fuelNozzles) * Math.PI * 2;
      const h = new THREE.Mesh(geo, M.dark);
      h.position.set(x, Math.sin(a) * COMBUSTOR.linerOuter, Math.cos(a) * COMBUSTOR.linerOuter);
      h.rotation.x = a;
      g.add(h);
    }
    root.add(reg(g, partId, { explode }));
  };
  holeRing(-0.28, 'primaryHoles', new THREE.Vector3(0, 1.3, 0));
  holeRing(0.28, 'dilutionHoles', new THREE.Vector3(0, 1.42, 0));

  // ── 燃油喷嘴（10 个独立网格，各自沿径向外移） ──
  {
    const g = new THREE.Group();
    const geo = new THREE.CylinderGeometry(0.028, 0.045, 0.16, 10);
    for (let i = 0; i < COMBUSTOR.fuelNozzles; i++) {
      const a = (i / COMBUSTOR.fuelNozzles) * Math.PI * 2;
      const nz = new THREE.Mesh(geo, M.copper);
      const r = 0.93;
      nz.position.set(-0.36, Math.sin(a) * r, Math.cos(a) * r);
      nz.rotation.x = a; // 指向圆心
      nz.userData.partId = 'fuelNozzles';
      nz.userData.explode = new THREE.Vector3(0, Math.sin(a) * 0.55, Math.cos(a) * 0.55);
      g.add(nz);
    }
    g.userData.partId = 'fuelNozzles';
    root.add(g);
  }

  // ── 点火器 ──
  {
    const geo = new THREE.CylinderGeometry(0.04, 0.06, 0.2, 10);
    const ig = new THREE.Mesh(geo, M.copper);
    ig.position.set(-0.1, 0.93, 0);
    ig.userData.partId = 'igniter';
    ig.userData.explode = new THREE.Vector3(0, 0.9, 0.25);
    root.add(ig);
  }

  // ── 火焰区（10 朵火焰，加色发光） ──
  const flameGroup = new THREE.Group();
  const flameMat = M.flame;
  {
    const geo = new THREE.ConeGeometry(0.09, 0.7, 10, 1, false);
    geo.rotateZ(-Math.PI / 2);
    for (let i = 0; i < COMBUSTOR.fuelNozzles; i++) {
      const a = (i / COMBUSTOR.fuelNozzles) * Math.PI * 2;
      const f = new THREE.Mesh(geo, flameMat);
      f.position.set(0.08, Math.sin(a) * 0.76, Math.cos(a) * 0.76);
      f.userData.partId = 'flameZone';
      flameGroup.add(f);
    }
    flameGroup.userData.partId = 'flameZone';
    root.add(flameGroup);
  }

  // ── 涡轮导向叶片（静） ──
  {
    const g = new THREE.Group();
    const vanes = bladeRing(TURBINE.guideVanes, TURBINE.hubRadius - 0.02, TURBINE.tipRadius - TURBINE.hubRadius + 0.04, 0.15, 0.02, 18, 55, M.stator);
    vanes.position.x = 0.82;
    g.add(vanes);
    root.add(reg(g, 'turbineNozzle', { explode: new THREE.Vector3(0.45, 0, 0) }));
  }

  // ── 涡轮转子（转）与涡轮盘 ──
  const turbineDiscGeo = new THREE.CylinderGeometry(TURBINE.hubRadius + 0.02, TURBINE.hubRadius + 0.02, 0.12, 36);
  turbineDiscGeo.rotateZ(-Math.PI / 2);
  [1.12, 1.52].forEach((x, i) => {
    const rotor = bladeRing(
      TURBINE.bladesPerStage, TURBINE.hubRadius - 0.02, TURBINE.tipRadius - TURBINE.hubRadius + 0.04,
      0.16, 0.024, 44, 30, M.nickel,
    );
    rotor.position.x = x;
    spool.add(reg(rotor, `turbineRotor${i + 1}`, { explode: new THREE.Vector3(0.7 + i * 0.6, 0, 0) }));
  });
  {
    const g = new THREE.Group();
    [1.12, 1.52].forEach((x) => {
      const d = new THREE.Mesh(turbineDiscGeo, M.steel);
      d.position.x = x;
      d.castShadow = true;
      g.add(d);
    });
    spool.add(reg(g, 'turbineDiscs', { explode: new THREE.Vector3(0.3, -0.1, 0) }));
  }

  // ── 热屏蔽 ──
  {
    const shield = coneShellX(0.6, 0.5, 0.04, 0.62, 1.85, M.ceramic);
    root.add(reg(shield, 'heatShield', { explode: new THREE.Vector3(0.2, 0.8, 0) }));
  }

  // ── 涡轮机匣（计入分段机匣） ──
  {
    const cas = addCasing(barrelX(0.92, 0.99, 0.72, 1.95, casingHot), true);
    const rearCone = addCasing(coneShellX(0.92, NOZZLE.radiusIn + 0.02, 0.07, 1.95, 2.35, casingHot), true);
    const g = new THREE.Group();
    g.add(cas, rearCone);
    root.add(reg(g, 'casingSegments', { explode: new THREE.Vector3(0, 1.9, 0) }));
  }

  // ── 顶部可开启机匣（压气机上盖） ──
  {
    const geo = new THREE.CylinderGeometry(1.13, 1.13, 1.4, 24, 1, true, Math.PI / 4, Math.PI / 2);
    geo.rotateZ(-Math.PI / 2);
    const top = new THREE.Mesh(geo, casingCold);
    top.position.x = -1.9;
    top.castShadow = true;
    top.userData.isCasing = true;
    casingMeshes.push(top);
    root.add(reg(top, 'topCasing', { explode: new THREE.Vector3(0, 2.3, 0) }));
  }

  // ── 轴承与支撑 ──
  {
    const g = new THREE.Group();
    const race = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.07, 12, 24), M.dark);
    race.rotation.y = Math.PI / 2;
    race.position.x = -2.7;
    const balls = bladeRing(10, 0.24, 0.09, 0.05, 0.05, 0, 0, M.steel);
    balls.position.x = -2.7;
    g.add(race, balls);
    root.add(reg(g, 'frontBearing', { explode: new THREE.Vector3(-0.7, -0.15, 0) }));
  }
  {
    const g = new THREE.Group();
    const race = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.07, 12, 24), M.dark);
    race.rotation.y = Math.PI / 2;
    race.position.x = 1.82;
    g.add(race);
    root.add(reg(g, 'rearBearing', { explode: new THREE.Vector3(0.8, -0.15, 0) }));
  }
  {
    const g = new THREE.Group();
    const front = coneShellX(0.3, 0.95, 0.05, -2.72, -2.62, M.titanium);
    const rear = coneShellX(0.3, 0.9, 0.05, 1.8, 1.9, M.titanium);
    g.add(front, rear);
    root.add(reg(g, 'bearingSupports', { explode: new THREE.Vector3(0, -0.5, 0) }));
  }

  // ── 附件齿轮箱与启动机 ──
  {
    const g = new THREE.Group();
    const box = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.45, 0.55), M.dark);
    box.position.set(-1.6, -1.18, 0);
    const drive = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.7, 10), M.steel);
    drive.position.set(-1.6, -0.8, 0);
    g.add(box, drive);
    root.add(reg(g, 'gearbox', { explode: new THREE.Vector3(0, -0.9, 0) }));
  }
  {
    const g = new THREE.Group();
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.5, 14), M.copper);
    body.rotation.z = Math.PI / 2;
    body.position.set(-2.5, -1.05, 0.28);
    const shaft2 = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.5, 8), M.steel);
    shaft2.position.set(-2.5, -0.72, 0.28);
    g.add(body, shaft2);
    root.add(reg(g, 'starter', { explode: new THREE.Vector3(-0.5, -0.7, 0) }));
  }

  // ── 排气锥（随轴转） ──
  {
    const cone = coneX(0.48, 0.08, 1.6, M.steel);
    cone.position.x = 2.6;
    spool.add(reg(cone, 'exhaustCone', { explode: new THREE.Vector3(1.6, 0, 0) }));
  }

  // ── 收敛喷管与喉部 ──
  const nozzleGlowMat = new THREE.MeshBasicMaterial({
    color: '#f08a4b', transparent: true, opacity: 0,
    blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide,
  });
  {
    const nz = addCasing(coneShellX(NOZZLE.radiusIn, NOZZLE.radiusThroat, 0.06, NOZZLE.xStart, NOZZLE.xEnd, casingHot), true);
    root.add(reg(nz, 'nozzle', { explode: new THREE.Vector3(2.2, 0, 0) }));
    // 内壁热辉光
    const glowGeo = new THREE.LatheGeometry(
      [new THREE.Vector2(NOZZLE.radiusIn - 0.03, NOZZLE.xStart), new THREE.Vector2(NOZZLE.radiusThroat - 0.03, NOZZLE.xEnd)],
      40,
    );
    glowGeo.rotateZ(-Math.PI / 2);
    const glow = new THREE.Mesh(glowGeo, nozzleGlowMat);
    glow.userData.partId = 'nozzle';
    // 作为喷管子节点随爆炸一起移动，不单独设置 explode
    nz.add(glow);
    glow.position.set(0, 0, 0);
  }
  {
    const throat = new THREE.Mesh(new THREE.TorusGeometry(NOZZLE.radiusThroat, 0.045, 12, 36), M.nickel);
    throat.rotation.y = Math.PI / 2;
    throat.position.x = NOZZLE.xEnd - 0.05;
    root.add(reg(throat, 'nozzleThroat', { explode: new THREE.Vector3(2.5, 0, 0) }));
  }
  {
    // 排气尾流（近乎透明的可点击体积）
    const wakeMat = new THREE.MeshBasicMaterial({
      color: '#f08a4b', transparent: true, opacity: 0.015,
      blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide,
    });
    const geo = new THREE.CylinderGeometry(0.62, 1.15, 2.6, 24, 1, true);
    geo.rotateZ(Math.PI / 2);
    const wake = new THREE.Mesh(geo, wakeMat);
    wake.position.x = NOZZLE.xEnd + 1.3;
    root.add(reg(wake, 'exhaustWake', { explode: new THREE.Vector3(2.8, 0, 0) }));
  }

  // ── 法兰与螺栓 ──
  {
    const g = new THREE.Group();
    const f1 = flange(1.06, 0.12, M.titanium); f1.position.x = -0.66; f1.userData.explode = new THREE.Vector3(-0.75, 0, 0);
    const f2 = flange(1.1, 0.12, M.nickel); f2.position.x = 0.7; f2.userData.explode = new THREE.Vector3(0.75, 0, 0);
    const f3 = flange(1.0, 0.12, M.nickel); f3.position.x = 1.98; f3.userData.explode = new THREE.Vector3(1.2, 0, 0);
    [f1, f2, f3].forEach((f) => { f.userData.partId = 'flanges'; g.add(f); });
    g.userData.partId = 'flanges';
    root.add(g);
  }
  {
    const g = new THREE.Group();
    const b1 = boltRing(14, 1.13, M.steel); b1.position.x = -0.66; b1.userData.explode = new THREE.Vector3(-0.95, 0, 0);
    const b2 = boltRing(14, 1.17, M.steel); b2.position.x = 0.7; b2.userData.explode = new THREE.Vector3(0.95, 0, 0);
    const b3 = boltRing(12, 1.07, M.steel); b3.position.x = 1.98; b3.userData.explode = new THREE.Vector3(1.4, 0, 0);
    [b1, b2, b3].forEach((b) => { b.userData.partId = 'bolts'; g.add(b); });
    g.userData.partId = 'bolts';
    root.add(g);
  }

  // ── 安装支柱与支架 ──
  {
    const g = new THREE.Group();
    const s1 = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.75, 0.3), M.dark);
    s1.position.set(-1.2, -1.25, 0);
    const s2 = s1.clone(); s2.position.x = 1.4;
    g.add(s1, s2);
    root.add(reg(g, 'mountStruts', { explode: new THREE.Vector3(0, -1.2, 0) }));
  }
  {
    const g = new THREE.Group();
    const rail1 = new THREE.Mesh(new THREE.BoxGeometry(6.4, 0.14, 0.22), M.dark);
    rail1.position.set(-0.2, -1.68, 0.4);
    const rail2 = rail1.clone(); rail2.position.z = -0.4;
    const leg1 = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.5, 1.1), M.dark);
    leg1.position.set(-2.8, -1.95, 0);
    const leg2 = leg1.clone(); leg2.position.x = 2.4;
    g.add(rail1, rail2, leg1, leg2);
    g.traverse((c) => { if (c instanceof THREE.Mesh) c.receiveShadow = true; });
    root.add(reg(g, 'engineStand', { explode: new THREE.Vector3(0, -1.6, 0) }));
  }

  // ── 站位高亮环 ──
  const stationRingMat = M.stationRing;
  const stationRings = new Map<StationId, THREE.Mesh>();
  const ringRadii: Record<StationId, number> = { 0: 1.3, 1: 1.12, 2: 0.92, 3: 1.16, 4: 1.02, 8: 0.68 };
  (Object.keys(ringRadii) as unknown as StationId[]).forEach((id) => {
    const sid = Number(id) as StationId;
    const geo = new THREE.TorusGeometry(ringRadii[sid], 0.02, 8, 48);
    const ring = new THREE.Mesh(geo, stationRingMat);
    ring.rotation.y = Math.PI / 2;
    ring.position.x =
      sid === 0 ? AXIS.station.s0 : sid === 1 ? AXIS.station.s1 : sid === 2 ? AXIS.station.s2
      : sid === 3 ? AXIS.station.s3 : sid === 4 ? AXIS.station.s4 : AXIS.station.s8;
    ring.visible = false;
    stationRings.set(sid, ring);
    root.add(ring);
  });

  // ── 扭矩追踪环 ──
  const torqueMat = M.torque;
  const torqueRing = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.05, 10, 28), torqueMat);
  torqueRing.rotation.y = Math.PI / 2;
  torqueRing.visible = false;
  root.add(torqueRing);

  const dispose = () => {
    root.traverse((o) => {
      if (o instanceof THREE.Mesh) {
        o.geometry.dispose();
      }
    });
    Object.values(M).forEach((m) => m.dispose());
    casingCold.dispose();
    casingHot.dispose();
    nozzleGlowMat.dispose();
  };

  return {
    root, spool, materials: M, casingMeshes,
    flameGroup, flameMat, stationRings, stationRingMat,
    torqueRing, torqueMat, shaftMesh, nozzleGlowMat, dispose,
  };
}

/** 由射线命中对象向上寻找 partId */
export function findPartId(obj: THREE.Object3D | null): string | null {
  let cur: THREE.Object3D | null = obj;
  while (cur) {
    if (cur.userData.partId) return cur.userData.partId as string;
    cur = cur.parent;
  }
  return null;
}
