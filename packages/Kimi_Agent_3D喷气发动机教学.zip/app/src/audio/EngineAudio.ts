// 程序化发动机声音：仅 Web Audio API，无外部音频素材
import { sim } from '../engine/engineState';
import { useLab } from '../app/store';
import { appEvents } from '../app/events';

class EngineAudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private starterOsc: OscillatorNode | null = null;
  private starterGain: GainNode | null = null;
  private compOsc: OscillatorNode | null = null;
  private compGain: GainNode | null = null;
  private turbOsc: OscillatorNode | null = null;
  private turbGain: GainNode | null = null;
  private airSrc: AudioBufferSourceNode | null = null;
  private airFilter: BiquadFilterNode | null = null;
  private airGain: GainNode | null = null;
  private combSrc: AudioBufferSourceNode | null = null;
  private combFilter: BiquadFilterNode | null = null;
  private combGain: GainNode | null = null;
  private detachEvents: (() => void)[] = [];
  private started = false;

  private makeNoiseBuffer(ctx: AudioContext): AudioBuffer {
    const len = ctx.sampleRate * 2;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    return buf;
  }

  /** 必须在用户手势中调用 */
  ensure() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') void this.ctx.resume();
      return;
    }
    const ctx = new AudioContext();
    this.ctx = ctx;
    this.master = ctx.createGain();
    this.master.gain.value = 0;
    this.master.connect(ctx.destination);

    // 启动机啸声
    this.starterOsc = ctx.createOscillator();
    this.starterOsc.type = 'sawtooth';
    this.starterGain = ctx.createGain();
    this.starterGain.gain.value = 0;
    this.starterOsc.connect(this.starterGain).connect(this.master);
    this.starterOsc.start();

    // 压气机低频
    this.compOsc = ctx.createOscillator();
    this.compOsc.type = 'triangle';
    this.compGain = ctx.createGain();
    this.compGain.gain.value = 0;
    this.compOsc.connect(this.compGain).connect(this.master);
    this.compOsc.start();

    // 涡轮高次谐波
    this.turbOsc = ctx.createOscillator();
    this.turbOsc.type = 'sine';
    this.turbGain = ctx.createGain();
    this.turbGain.gain.value = 0;
    this.turbOsc.connect(this.turbGain).connect(this.master);
    this.turbOsc.start();

    // 宽带气流噪声
    const noise = this.makeNoiseBuffer(ctx);
    this.airSrc = ctx.createBufferSource();
    this.airSrc.buffer = noise;
    this.airSrc.loop = true;
    this.airFilter = ctx.createBiquadFilter();
    this.airFilter.type = 'bandpass';
    this.airFilter.frequency.value = 600;
    this.airFilter.Q.value = 0.7;
    this.airGain = ctx.createGain();
    this.airGain.gain.value = 0;
    this.airSrc.connect(this.airFilter).connect(this.airGain).connect(this.master);
    this.airSrc.start();

    // 燃烧低频
    this.combSrc = ctx.createBufferSource();
    this.combSrc.buffer = noise;
    this.combSrc.loop = true;
    this.combFilter = ctx.createBiquadFilter();
    this.combFilter.type = 'lowpass';
    this.combFilter.frequency.value = 160;
    this.combGain = ctx.createGain();
    this.combGain.gain.value = 0;
    this.combSrc.connect(this.combFilter).connect(this.combGain).connect(this.master);
    this.combSrc.start();

    // 事件音效
    this.detachEvents.push(
      appEvents.on('ignition', () => this.ignitionClick()),
      appEvents.on('surgeWarning', () => this.surgeThud()),
      appEvents.on('partSelected', () => this.uiClick(660)),
      appEvents.on('faultResolved', () => this.uiClick(880)),
    );
    this.started = true;
  }

  private smooth(param: AudioParam, v: number, tc = 0.12) {
    if (!this.ctx) return;
    param.setTargetAtTime(v, this.ctx.currentTime, tc);
  }

  update() {
    if (!this.ctx || !this.master || !this.started) return;
    const lab = useLab.getState();
    const n = sim.n1;

    this.smooth(this.master.gain, lab.soundOn ? 0.5 : 0, 0.15);

    // 启动机：仅在 STARTING 阶段，音高随转速上升
    const starterOn = lab.phase === 'STARTING' ? 1 : 0;
    this.smooth(this.starterGain!.gain, 0.05 * starterOn * (0.4 + n), 0.1);
    this.smooth(this.starterOsc!.frequency, 180 + n * 2600, 0.15);

    // 压气机低频 55→175 Hz
    this.smooth(this.compGain!.gain, 0.055 * n, 0.15);
    this.smooth(this.compOsc!.frequency, 55 + n * 120, 0.2);

    // 涡轮谐波
    this.smooth(this.turbGain!.gain, 0.02 * n * sim.flame, 0.2);
    this.smooth(this.turbOsc!.frequency, 200 + n * 720, 0.25);

    // 气流噪声
    this.smooth(this.airGain!.gain, 0.11 * n * (0.5 + 0.5 * sim.flame + 0.2), 0.15);
    this.smooth(this.airFilter!.frequency, 380 + n * 2100, 0.2);

    // 燃烧低频
    this.smooth(this.combGain!.gain, 0.16 * sim.fuelFlow * sim.flame, 0.2);

    // 喘振抖动增益
    if (sim.surge > 0.3 && this.airGain) {
      const w = 1 + Math.sin(sim.time * 21) * 0.5 * sim.surge;
      this.airGain.gain.value = Math.max(0, this.airGain.gain.value * w);
    }
  }

  private oneShotOsc(freq: number, dur: number, gain: number, type: OscillatorType = 'sine') {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    g.gain.setValueAtTime(gain, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
    osc.connect(g).connect(this.master);
    osc.start();
    osc.stop(ctx.currentTime + dur);
    osc.onended = () => {
      osc.disconnect();
      g.disconnect();
    };
  }

  private oneShotNoise(dur: number, gain: number, filterFreq: number, type: BiquadFilterType = 'lowpass') {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    const src = ctx.createBufferSource();
    src.buffer = this.makeNoiseBuffer(ctx);
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.frequency.value = filterFreq;
    const g = ctx.createGain();
    g.gain.setValueAtTime(gain, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
    src.connect(f).connect(g).connect(this.master);
    src.start();
    src.stop(ctx.currentTime + dur);
    src.onended = () => {
      src.disconnect();
      f.disconnect();
      g.disconnect();
    };
  }

  ignitionClick() {
    this.oneShotOsc(1400, 0.06, 0.12, 'square');
    this.oneShotNoise(0.5, 0.1, 500);
  }

  surgeThud() {
    this.oneShotOsc(58, 0.5, 0.22, 'sine');
    this.oneShotNoise(0.35, 0.14, 240);
  }

  uiClick(freq = 660) {
    this.oneShotOsc(freq, 0.05, 0.05, 'square');
  }

  dispose() {
    this.detachEvents.forEach((d) => d());
    this.detachEvents = [];
    void this.ctx?.close();
    this.ctx = null;
    this.started = false;
  }
}

export const engineAudio = new EngineAudioEngine();
